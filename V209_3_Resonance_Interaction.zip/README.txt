
V209.3 Resonance Interaction System

Purpose:
Enable natural interaction between players/AI through resonance fields.

Core Mechanics:
- attraction (similar resonance)
- neutral (close but different)
- repulsion (very different)

Result:
Interaction emerges without UI or commands.
