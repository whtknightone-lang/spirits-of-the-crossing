
using UnityEngine;

public class FieldBlender : MonoBehaviour
{
    public ResonanceField field;

    void OnTriggerStay(Collider other)
    {
        ResonanceField otherField = other.GetComponent<ResonanceField>();
        if (otherField == null) return;

        float avg = (field.resonance + otherField.resonance) * 0.5f;
        field.resonance = Mathf.Lerp(field.resonance, avg, Time.deltaTime);
    }
}
