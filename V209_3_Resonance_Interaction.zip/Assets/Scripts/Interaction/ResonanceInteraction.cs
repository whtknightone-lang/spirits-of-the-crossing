
using UnityEngine;

public class ResonanceInteraction : MonoBehaviour
{
    public ResonanceField field;
    public float forceStrength = 2f;

    void Update()
    {
        foreach (ResonanceInteraction other in FindObjectsOfType<ResonanceInteraction>())
        {
            if (other == this) continue;

            float diff = field.GetDifference(other.field);
            Vector3 dir = (other.transform.position - transform.position).normalized;

            if (diff < 0.2f)
            {
                // attract
                transform.position += dir * forceStrength * Time.deltaTime;
            }
            else if (diff > 0.5f)
            {
                // repel
                transform.position -= dir * forceStrength * Time.deltaTime;
            }
        }
    }
}
