
using UnityEngine;

public class ResonanceField : MonoBehaviour
{
    [Range(0f,1f)] public float resonance = 0.5f;
    [Range(0f,1f)] public float coherence = 0.5f;

    public float GetDifference(ResonanceField other)
    {
        return Mathf.Abs(resonance - other.resonance);
    }
}
