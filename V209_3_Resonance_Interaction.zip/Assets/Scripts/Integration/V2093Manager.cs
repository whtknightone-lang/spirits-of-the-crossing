
using UnityEngine;

public class V2093Manager : MonoBehaviour
{
    void Start()
    {
        Debug.Log("Resonance Interaction System Active");
    }
}
