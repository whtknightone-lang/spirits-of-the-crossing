
# V53 Evolving Ecosystem

Adds:
- food chain (plants → herbivores → predators placeholder)
- reproduction + population dynamics
- sacrifice system: low-energy agents convert into ecosystem nourishment

Core idea:
Nature can choose to nurture through sacrifice → supporting future life.
