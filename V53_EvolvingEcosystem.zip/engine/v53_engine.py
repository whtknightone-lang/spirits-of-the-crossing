
import pygame, numpy as np
from systems.ecosystem import Ecosystem
from systems.sacrifice import SacrificeSystem

class V53Engine:
    def __init__(self,size,device):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.sacrifice=SacrificeSystem()
        self.font=pygame.font.SysFont("arial",16)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.sacrifice.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for a in self.ecosystem.animals:
            x=int(a["pos"][1]*scale)+40
            y=int(a["pos"][0]*scale)+40
            color=(100,200,100) if a["type"]=="herbivore" else (200,100,100)
            pygame.draw.circle(screen,color,(x,y),3)

        for p in self.ecosystem.plants:
            x=int(p["pos"][1]*scale)+40
            y=int(p["pos"][0]*scale)+40
            pygame.draw.circle(screen,(100,255,150),(x,y),2)

        y=760
        lines=[
            "V53 Evolving Ecosystem",
            f"Animals: {len(self.ecosystem.animals)}",
            f"Plants: {len(self.ecosystem.plants)}",
            f"Sacrifice events: {self.sacrifice.events}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
