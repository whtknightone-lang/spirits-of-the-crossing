
import pygame, torch
from engine.v53_engine import V53Engine

pygame.init()
screen = pygame.display.set_mode((1500,960))
clock = pygame.time.Clock()

engine = V53Engine(128, "cuda" if torch.cuda.is_available() else "cpu")

running=True
while running:
    dt=clock.tick(60)/1000.0
    for e in pygame.event.get():
        if e.type==pygame.QUIT:
            running=False

    engine.update(dt)
    engine.render(screen)
    pygame.display.flip()

pygame.quit()
