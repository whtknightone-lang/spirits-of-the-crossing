
import random

class Ecosystem:
    def __init__(self,size):
        self.size=size
        self.animals=[{
            "pos":[random.random()*size,random.random()*size],
            "energy":1.0,
            "type":random.choice(["herbivore","predator"])
        } for _ in range(80)]

        self.plants=[{
            "pos":[random.random()*size,random.random()*size],
            "energy":1.0
        } for _ in range(120)]

    def update(self,dt):
        for p in self.plants:
            p["energy"]=min(1.0,p["energy"]+0.01)

        for a in self.animals:
            a["pos"][0]+=random.uniform(-1,1)*dt*10
            a["pos"][1]+=random.uniform(-1,1)*dt*10
            a["energy"]-=0.01

            # herbivores eat plants
            if a["type"]=="herbivore":
                for p in self.plants:
                    if abs(a["pos"][0]-p["pos"][0])<1 and abs(a["pos"][1]-p["pos"][1])<1:
                        a["energy"]+=0.2
                        p["energy"]=0

            # reproduction
            if a["energy"]>1.5:
                self.animals.append({
                    "pos":a["pos"][:],
                    "energy":1.0,
                    "type":a["type"]
                })
                a["energy"]=0.8

        # regrow plants
        if len(self.plants)<150:
            self.plants.append({
                "pos":[random.random()*self.size,random.random()*self.size],
                "energy":1.0
            })
