
class SacrificeSystem:
    def __init__(self):
        self.events=0

    def update(self,eco):
        # animals with low energy may "sacrifice" to feed ecosystem
        for a in eco.animals:
            if a["energy"]<0.2:
                # become plant energy (nurture)
                eco.plants.append({
                    "pos":a["pos"][:],
                    "energy":0.5
                })
                a["energy"]=0
                self.events+=1
