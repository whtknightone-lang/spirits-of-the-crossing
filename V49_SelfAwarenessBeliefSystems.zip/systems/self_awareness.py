
class SelfAwarenessSystem:
    def update(self, agents, player, memory):
        px, py = player.grid_position()
        local_mean = float(memory.now_field.mean().item())

        for a in agents:
            dx = px - a["pos"][0]
            dy = py - a["pos"][1]
            dist = max(0.001, (dx*dx + dy*dy) ** 0.5)
            proximity = max(0.0, 1.0 - dist / 40.0)

            current = a.get("self_awareness", 0.0)
            msg = a.get("msg", 0.0)
            current += 0.01 * proximity
            current += 0.004 * msg
            current += 0.003 * local_mean
            current = max(0.0, min(1.0, current))
            a["self_awareness"] = current
