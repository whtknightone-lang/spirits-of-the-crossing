
import random, torch
class AgentWorld:
    def __init__(self, size, device, n):
        self.size = size
        self.device = device
        self.agents = [{
            "pos": [random.random() * size, random.random() * size],
            "velocity": [0.0, 0.0],
        } for _ in range(n)]

    def update(self, dt, now, potential, player):
        px, py = player.grid_position()
        for a in self.agents:
            ax, ay = a["pos"]
            dx = px - ax
            dy = py - ay
            dist = max(0.001, (dx*dx + dy*dy) ** 0.5)

            wander = 0.5 + a.get("self_awareness", 0.0)
            if a.get("belief", 0.0) > 0:
                ax += (dx / dist) * dt * 4.0 * wander
                ay += (dy / dist) * dt * 4.0 * wander
            else:
                ax += random.uniform(-1, 1) * dt * 14.0 * wander
                ay += random.uniform(-1, 1) * dt * 14.0 * wander

            ax = max(0, min(self.size - 1, ax))
            ay = max(0, min(self.size - 1, ay))
            a["pos"] = [ax, ay]

    def aggregate_world_emotion(self):
        field = torch.zeros((self.size, self.size), device=self.device)
        for a in self.agents:
            x = int(a["pos"][0])
            y = int(a["pos"][1])
            field[x, y] += a.get("belief", 0.0) * 0.2 + a.get("self_awareness", 0.0) * 0.1
        return field
