
# V49 Self-Awareness + Belief Systems

Run:
pip install -r requirements.txt
python main.py

New in V49:
- Agents develop self-awareness
- Agents form belief orientations
- Beliefs respond to source feedback, communication, and local world state
- Meditation and bursts still interact with the larger system

Controls:
- Move: WASD or arrow keys
- SPACE: meditate
- E: expression burst
- Q: kindness burst
- B: belief realignment
