
import pygame, numpy as np
from systems.resonance_memory import ResonanceMemorySystem
from systems.player_body import PlayerBody
from systems.agent_world import AgentWorld
from systems.communication import CommunicationSystem
from systems.meditation import MeditationSystem
from systems.source_feedback import SourceFeedbackSystem
from systems.self_awareness import SelfAwarenessSystem
from systems.belief_systems import BeliefSystemEngine

class V49Engine:
    def __init__(self, size, device):
        self.size = size
        self.device = device

        self.memory = ResonanceMemorySystem(size, device)
        self.player = PlayerBody(size, device)
        self.world = AgentWorld(size, device, 120)

        self.comm = CommunicationSystem()
        self.meditation = MeditationSystem()
        self.source = SourceFeedbackSystem()
        self.awareness = SelfAwarenessSystem()
        self.beliefs = BeliefSystemEngine()

        self.font = pygame.font.SysFont("arial", 16)

    def handle_key(self, key):
        if key == pygame.K_SPACE:
            self.meditation.toggle()
        elif key == pygame.K_e:
            self.player.emit_expression_burst(self.memory.now_field)
        elif key == pygame.K_q:
            self.player.emit_kindness_burst(self.memory.now_field)
        elif key == pygame.K_b:
            self.beliefs.force_realignment(self.world.agents)

    def handle_input(self, dt):
        self.player.handle_movement(pygame.key.get_pressed(), dt)

    def update(self, dt):
        self.memory.update(dt, self.world.aggregate_world_emotion(), self.player.resonance_mean())
        self.player.update(dt, self.memory.now_field, self.memory.potential_field)
        self.world.update(dt, self.memory.now_field, self.memory.potential_field, self.player)

        self.comm.update(self.world.agents)
        self.awareness.update(self.world.agents, self.player, self.memory)
        self.beliefs.update(self.world.agents, self.memory, self.source)

        if self.meditation.active:
            self.memory.now_field += self.meditation.align(self.memory)

        feedback = self.source.compute(self.memory, self.player, self.world)
        self.memory.now_field += feedback
        self.memory.potential_field += feedback * 0.5
        self.memory.clamp_all()

    def render(self, screen):
        screen.fill((10, 10, 20))

        arr = self.memory.now_field.detach().cpu().numpy()
        arr = (arr - arr.min()) / (arr.max() + 1e-5)
        img = np.stack([arr * 255, arr * 205, 255 - arr * 145], axis=-1).astype("uint8")

        surf = pygame.surfarray.make_surface(np.transpose(img, (1, 0, 2)))
        surf = pygame.transform.scale(surf, (700, 700))
        screen.blit(surf, (40, 40))

        # draw agents
        scaled = 700 / self.size
        for a in self.world.agents:
            x = int(a["pos"][1] * scaled) + 40
            y = int(a["pos"][0] * scaled) + 40
            belief = a.get("belief", 0.0)
            aware = a.get("self_awareness", 0.0)
            color = (
                max(0, min(255, int(110 + belief * 90))),
                max(0, min(255, int(140 + aware * 80))),
                max(0, min(255, int(180 - belief * 70))),
            )
            pygame.draw.circle(screen, color, (x, y), 3)

        px, py = self.player.grid_position()
        pygame.draw.circle(screen, (255, 255, 255), (int(py * scaled) + 40, int(px * scaled) + 40), 7)

        meditation_status = "ON" if self.meditation.active else "OFF"
        avg_awareness = sum(a.get("self_awareness", 0.0) for a in self.world.agents) / max(1, len(self.world.agents))
        avg_belief = sum(a.get("belief", 0.0) for a in self.world.agents) / max(1, len(self.world.agents))

        lines = [
            "V49 Self-Awareness + Belief Systems",
            "SPACE meditate | E expression burst | Q kindness burst | B belief realignment",
            f"Meditation: {meditation_status}",
            f"Source signal: {self.source.last_signal:.3f}",
            f"Average self-awareness: {avg_awareness:.3f}",
            f"Average belief orientation: {avg_belief:.3f}",
            f"Agents: {len(self.world.agents)}",
        ]

        y = 760
        for l in lines:
            screen.blit(self.font.render(l, True, (240, 240, 240)), (40, y))
            y += 20
