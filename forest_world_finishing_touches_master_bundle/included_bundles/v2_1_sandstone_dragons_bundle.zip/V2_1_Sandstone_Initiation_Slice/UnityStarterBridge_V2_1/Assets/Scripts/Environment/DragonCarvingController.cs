using UnityEngine;
using Upsilon.CEF;

namespace Upsilon.Environment
{
    public class DragonCarvingController : MonoBehaviour
    {
        public enum ElementType { Air, Earth, Fire, Water }

        [SerializeField] private ElementType element = ElementType.Air;
        [SerializeField] private Renderer[] renderersToDrive;
        [SerializeField] private Light accentLight;
        [SerializeField] private Transform reliefRoot;
        [SerializeField] private float glowMin = 0.05f;
        [SerializeField] private float glowMax = 2.5f;
        [SerializeField] private float pulseSpeed = 1.2f;

        private static readonly int EmissionColor = Shader.PropertyToID("_EmissionColor");
        private MaterialPropertyBlock block;
        private CEFSharedState state;

        private void Start()
        {
            block = new MaterialPropertyBlock();
            if (CEFStateBus.Instance != null)
                CEFStateBus.Instance.OnStateUpdated += HandleStateUpdated;
        }

        private void OnDestroy()
        {
            if (CEFStateBus.Instance != null)
                CEFStateBus.Instance.OnStateUpdated -= HandleStateUpdated;
        }

        private void HandleStateUpdated(CEFSharedState s)
        {
            state = s;
        }

        private void Update()
        {
            if (state == null) return;

            float channel = GetElementChannel();
            float pulse = 0.5f + 0.5f * Mathf.Sin(Time.time * pulseSpeed);
            float intensity = Mathf.Lerp(glowMin, glowMax, channel * 0.7f + state.creativeEdge * 0.3f) * (0.8f + pulse * 0.2f);
            Color c = GetElementColor() * intensity;

            if (renderersToDrive != null)
            {
                foreach (var r in renderersToDrive)
                {
                    if (r == null) continue;
                    r.GetPropertyBlock(block);
                    block.SetColor(EmissionColor, c);
                    r.SetPropertyBlock(block);
                }
            }

            if (accentLight != null)
            {
                accentLight.color = GetElementColor();
                accentLight.intensity = intensity;
            }

            if (reliefRoot != null)
            {
                float scalePulse = 1f + 0.02f * pulse + 0.03f * state.globeStrength;
                reliefRoot.localScale = Vector3.one * scalePulse;
            }
        }

        private float GetElementChannel()
        {
            if (state.channels == null || state.channels.Length < 7) return state.creativeEdge;
            return element switch
            {
                ElementType.Air => state.channels[1],
                ElementType.Earth => state.channels[2],
                ElementType.Fire => state.channels[5],
                ElementType.Water => 0.5f * (state.channels[0] + state.channels[3]),
                _ => state.creativeEdge,
            };
        }

        private Color GetElementColor()
        {
            return element switch
            {
                ElementType.Air => new Color(0.65f, 0.82f, 1f),
                ElementType.Earth => new Color(0.78f, 0.62f, 0.38f),
                ElementType.Fire => new Color(1f, 0.45f, 0.18f),
                ElementType.Water => new Color(0.35f, 0.72f, 1f),
                _ => Color.white,
            };
        }
    }
}
