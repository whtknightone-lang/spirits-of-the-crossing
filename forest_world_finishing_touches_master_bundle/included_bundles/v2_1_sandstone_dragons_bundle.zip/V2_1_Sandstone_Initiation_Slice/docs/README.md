# V2.1 Sandstone Initiation Slice

This update layers the four elemental dragons into the Petra-inspired carved threshold and grand chamber.

Dragons are not placed as separate living NPCs in the first read. They are embedded into the architecture as guardian carvings, relief bands, statue fragments, and portal marks that can later awaken.
