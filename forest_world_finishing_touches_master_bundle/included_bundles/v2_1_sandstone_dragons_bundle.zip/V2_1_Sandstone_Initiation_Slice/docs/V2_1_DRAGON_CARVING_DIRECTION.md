# Four Elemental Dragons in the Sandstone Carving

## Core approach
The dragons should read as ancient sandstone guardians already present in the cave-temple rather than newly added fantasy props.

Use them in four architectural layers:
1. threshold guardians at entrance and exit
2. carved wall reliefs in the grand chamber
3. portal alcove signatures
4. high sanctum spirit forms that can later animate

## Dragon placement

### Air Dragon
- Place high in the entrance facade, spanning upper cornice lines and broken ledges.
- Shape language: long neck, swept wings, spiral tail, wind-cut feathered stone channels.
- Function: introduces portal sightlines, guidance, uplift, sky intelligence.
- Visual motifs: eroded wing traces, spiral vents, dust-stream grooves.

### Earth Dragon
- Place low and structural, coiled through the lower plinths and side buttresses.
- Shape language: thick body, heavy claws, horned brow, layered stone scales.
- Function: stability, grounding, protection of first steps, chamber support.
- Visual motifs: load-bearing ribs, cracked strata, embedded claws, root-like fractures.

### Fire Dragon
- Place at the inner chamber transition and near the AI stabilization sanctum.
- Shape language: flared jaw, solar mane, volcanic ribbing, ascending sweep.
- Function: activation, will, transformation, AI embodiment pressure.
- Visual motifs: ember channels, flame-cut recesses, sharp radial scoring.

### Water Dragon
- Place near the exit threshold and around the first portal alcove.
- Shape language: flowing spine, smooth horn arcs, wave-scaled body, serpentine curves.
- Function: passage, adaptation, emotional continuity, portal crossing.
- Visual motifs: worn runoff channels, basin cuts, polished curves, ribbon stone bands.

## Entrance composition
- Tight canyon approach with partial glimpses of the Air and Earth dragons only.
- Earth dragon anchors the lower doorway and side walls.
- Air dragon is only fully readable after the reveal.
- Keep dragons integrated into the cliff face so the facade still reads as carved architecture first.

## Grand chamber composition
- Four dragons occupy the chamber as cardinal presences.
- North / upper vault: Air
- South / lower foundation ring: Earth
- East / sanctum side: Fire
- West / portal-water side: Water

The player does not meet them as creatures first.
They first read them as mythic intelligence embedded in stone.

## Animal and spirit relationship
- Animal guide helps the player read the chamber safely.
- Animal spirit reveals the dragon that best matches the player's first stabilized resonance.
- AI figure stabilizes under the influence of Fire + Air motifs, suggesting will plus intelligence.

## Portal logic
Each portal alcove can inherit dragon traces.
- Air portal: higher worlds, sky, motion, signal
- Earth portal: caves, mountains, endurance, guardians
- Fire portal: conflict, transformation, force, forging
- Water portal: passage, memory, healing, emotional worlds

## Lighting notes
- Air: cool shafts, dust sparkle, elevated rim light
- Earth: warm grounded bounce, low amber shadow
- Fire: concentrated hot highlights, sharper contrast
- Water: soft reflected motion, blue-gold shimmer

## Scale guidance
Do not fully expose every dragon at once.
Use partial reads:
- head emerging from wall
- wing line embedded in cornice
- tail wrapping a portal frame
- claw supporting a ledge

This preserves mystery and grandeur.

## Best first implementation
For V2.1, add:
- four large relief compositions in the chamber
- entrance facade dragon integration pass
- exit threshold dragon integration pass
- color-coded but still sandstone-first material accents
- a simple script to pulse dragon emissive accents from CEF state
