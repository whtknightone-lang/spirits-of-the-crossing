# Prefab updates for V2.1

Add these prefabs:

- PF_DragonRelief_Air
- PF_DragonRelief_Earth
- PF_DragonRelief_Fire
- PF_DragonRelief_Water
- PF_DragonEntranceFacade
- PF_DragonExitFacade
- PF_DragonAccentLight_Air
- PF_DragonAccentLight_Earth
- PF_DragonAccentLight_Fire
- PF_DragonAccentLight_Water

Suggested hierarchy under the cave root:

PF_SandstoneCaveRoot
├── EntranceFacade
│   ├── AirDragonRelief_High
│   └── EarthDragonRelief_Low
├── GrandChamber
│   ├── DragonReliefs
│   │   ├── Air_NorthHigh
│   │   ├── Earth_SouthLow
│   │   ├── Fire_EastSanctum
│   │   └── Water_WestPortal
│   ├── AIStabilizationSanctum
│   ├── ResonanceDisk_Center
│   └── PortalAlcoves
└── ExitThreshold
    ├── WaterDragonFrame
    └── FireDragonTrace
