# V2 Sandstone Initiation Slice

This package extends the V1 sandstone cave slice with a Petra-inspired threshold language and a larger ceremonial interior.

## V2 goals
- Add a narrow sandstone approach with a monumental rock-cut reveal
- Expand the cave into a grand central chamber
- Turn portals into carved alcove destinations
- Give the AI stabilization a rear sanctum
- Add an upper spirit overlook for the animal spirit
- Preserve the original onboarding loop

## Core player loop
1. Approach through the slot canyon
2. Reach the carved threshold façade
3. Enter the grand chamber
4. Step onto the resonance disk
5. Animal awakens
6. Animal spirit appears above
7. AI stabilizes in the rear sanctum
8. First portal opens in a carved alcove
9. Exit through the active threshold / portal frame

## Included
- V2 scene layout spec
- Updated prefab hierarchy
- Lighting and art direction notes
- Additional Unity starter scripts for entrance reveal and chamber ambience
- A build checklist for integrating V2 with the existing V1 scripts
