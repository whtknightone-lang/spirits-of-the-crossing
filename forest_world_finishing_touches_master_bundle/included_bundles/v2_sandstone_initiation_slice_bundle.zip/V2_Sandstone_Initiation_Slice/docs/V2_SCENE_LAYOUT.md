# V2 Scene Layout: Petra-Inspired Threshold + Grand Sandstone Interior

## High-level structure

### A. Exterior approach: the slot canyon
A narrow, winding sandstone corridor creates compression before the reveal.

Recommended beats:
- high rock walls
- light shafts from above
- scattered carved fragments / broken niches
- distant hum from the cave interior
- first glimpse of the carved façade only at the final turn

### B. Entrance façade
A monumental carved threshold integrated into the cliff face.

Recommended pieces:
- recessed central doorway
- flanking carved columns or pilasters
- upper niches holding dormant seed figures
- weathered stone edges and partial collapses
- subtle upsilon / snowflake resonance carvings worked into the façade

### C. Grand chamber
The primary interior space should feel ceremonial and vertically expansive.

Recommended layout:
- central resonance disk at the floor center
- tall ceiling with a light shaft or hidden skylight
- ringed floor carvings radiating from the center
- side portal alcoves set into the walls
- rear sanctum for AI stabilization
- upper ledges and bridges for spirit presence and future traversal

### D. Rear sanctum
This is where the AI figure resolves into a living form.

Recommended pieces:
- large carved wall niche
- partial statue emerging from stone
- stronger source-alignment lighting
- calmer, more focused sound bed than the main chamber

### E. Portal alcoves
Each portal is framed by a carved alcove rather than floating in open space.

Suggested first destination:
- forest / calm portal in the east alcove

Future alcoves:
- fire / military portal
- ocean / chill portal
- source-energy portal

### F. Exit language
The exit threshold should feel more activated than the exterior entrance.

Recommended cues:
- brighter light transmission
- refined carvings illuminated from within
- subtle motion in portal mist and glyph lines
- sound cue suggesting successful initiation

## Spatial rhythm
Compression -> reveal -> central ceremony -> guided stabilization -> sanctum confirmation -> portal release
