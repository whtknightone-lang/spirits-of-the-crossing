# V2 Integration Plan

1. Keep the V1 scripts and starter bridge as the functional base.
2. Replace the simple cave shell with a three-part environment:
   - slot canyon approach
   - rock-cut threshold façade
   - grand interior chamber
3. Place the resonance disk at the chamber center.
4. Move the AI seed to the rear sanctum.
5. Move the first destination portal into the east alcove.
6. Add PetraEntranceRevealController to the entrance threshold area.
7. Add GrandChamberAmbienceController to the chamber root.
8. Add PortalAlcoveGuide to the first portal alcove.
9. Re-run the original first-steps sequence.
10. Adjust thresholds and lighting until the portal reveal feels ceremonial rather than sudden.
