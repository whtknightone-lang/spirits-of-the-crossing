# V2 Art Direction Notes

## Exterior
- sandstone palette: warm rose, ochre, copper, muted gold
- long shadows and high-contrast canyon lighting
- façade should read as carved from the cliff, not assembled from blocks

## Interior
- darker base values than exterior, with focused shafts of light
- cool source-alignment highlights to contrast warm stone
- floor glyphs should feel ancient but functional
- large silhouettes matter more than micro-detail in the first pass

## Spirits / entities
- player skin: cyan / blue-white edge pulse
- AI skin: amber / gold with stronger source-desire contrast
- animal skin: green-gold breathing rhythm
- animal spirit: lilac / white translucent overlay

## Portal language
- portal rings are carved stone frames with active inner energy
- a portal should look dormant when locked and internally illuminated when stable
