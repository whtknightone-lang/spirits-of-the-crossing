# V2 Prefab Hierarchy

```text
PF_SandstoneTemple_V2
├── Exterior
│   ├── SlotCanyonPath
│   ├── LightShafts
│   ├── DustFX
│   ├── BrokenCarvings
│   └── EntranceFacade
│       ├── ThresholdDoor
│       ├── LeftColumn
│       ├── RightColumn
│       ├── UpperNiches
│       └── EntranceRevealTrigger
├── Interior
│   ├── GrandChamber
│   │   ├── ResonanceDisk_Center
│   │   ├── FloorGlyphRings
│   │   ├── CeilingLightShaft
│   │   ├── PortalAlcove_East
│   │   ├── PortalAlcove_West
│   │   ├── PortalAlcove_North
│   │   ├── UpperSpiritOverlook
│   │   └── AmbientChamberFX
│   ├── RearSanctum_AI
│   │   ├── AISeedFigure
│   │   ├── SanctumGlow
│   │   └── StoneMorphSurface
│   └── AnimalApproachLane
├── ActiveEntities
│   ├── PlayerRoot
│   ├── AnimalRoot
│   ├── AnimalSpiritRoot
│   └── AIRoot
├── Systems
│   ├── CEFStateBus
│   ├── SandstoneCaveSceneBootstrap
│   ├── FirstStepsSequenceController
│   ├── GrandChamberAmbienceController
│   ├── PetraEntranceRevealController
│   ├── PortalStateController
│   └── CEFDebugHUD
└── Audio
    ├── ExteriorWind
    ├── ChamberDrone
    ├── SanctumTone
    └── PortalHum
```
