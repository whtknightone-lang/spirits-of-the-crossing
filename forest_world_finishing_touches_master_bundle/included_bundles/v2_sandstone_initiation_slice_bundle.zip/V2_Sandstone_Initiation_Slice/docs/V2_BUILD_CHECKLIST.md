# V2 Build Checklist

## Environment
- [ ] Block out the slot canyon path
- [ ] Build the rock-cut entrance façade
- [ ] Expand the grand chamber volume
- [ ] Add rear sanctum niche
- [ ] Add at least one portal alcove
- [ ] Add upper spirit overlook silhouette

## Systems
- [ ] Keep V1 cave scripts in place
- [ ] Add PetraEntranceRevealController to façade trigger zone
- [ ] Add GrandChamberAmbienceController to the chamber root
- [ ] Point the resonance disk and portal systems to the new positions

## First playable target
- [ ] Exterior approach works
- [ ] Entrance reveal works
- [ ] Chamber ambience reacts to state
- [ ] Existing first-steps sequence still completes
- [ ] First portal opens in the east alcove
