using UnityEngine;
using Upsilon.CEF;

namespace Upsilon.Environment
{
    public class PetraEntranceRevealController : MonoBehaviour
    {
        [SerializeField] private Transform facadeRoot;
        [SerializeField] private Light revealLight;
        [SerializeField] private ParticleSystem dustFX;
        [SerializeField] private AudioSource revealAudio;
        [SerializeField] private float revealDistance = 12f;
        [SerializeField] private float moveOffsetZ = -0.8f;
        [SerializeField] private Transform player;

        private Vector3 startPos;
        private CEFSharedState state;

        private void Start()
        {
            if (facadeRoot != null) startPos = facadeRoot.localPosition;
            if (CEFStateBus.Instance != null)
                CEFStateBus.Instance.OnStateUpdated += HandleStateUpdated;
        }

        private void OnDestroy()
        {
            if (CEFStateBus.Instance != null)
                CEFStateBus.Instance.OnStateUpdated -= HandleStateUpdated;
        }

        private void HandleStateUpdated(CEFSharedState s) => state = s;

        private void Update()
        {
            if (player == null || facadeRoot == null) return;

            float dist = Vector3.Distance(player.position, transform.position);
            float near = Mathf.InverseLerp(revealDistance, 0f, dist);
            float edgeBoost = state != null ? state.creativeEdge * 0.25f : 0f;
            float t = Mathf.Clamp01(near + edgeBoost);

            facadeRoot.localPosition = startPos + new Vector3(0f, 0f, Mathf.Lerp(0f, moveOffsetZ, t));

            if (revealLight != null)
                revealLight.intensity = Mathf.Lerp(0.6f, 3.2f, t);

            if (dustFX != null)
            {
                var emission = dustFX.emission;
                emission.rateOverTime = Mathf.Lerp(3f, 18f, t);
                if (!dustFX.isPlaying) dustFX.Play();
            }

            if (revealAudio != null)
                revealAudio.volume = Mathf.Lerp(0.1f, 0.8f, t);
        }
    }
}
