using UnityEngine;
using Upsilon.CEF;

namespace Upsilon.Portals
{
    public class PortalAlcoveGuide : MonoBehaviour
    {
        [SerializeField] private Transform guideLight;
        [SerializeField] private float bobHeight = 0.15f;
        [SerializeField] private float bobSpeed = 1.4f;
        [SerializeField] private Renderer alcoveGlyphRenderer;

        private static readonly int EmissionColor = Shader.PropertyToID("_EmissionColor");
        private MaterialPropertyBlock block;
        private CEFSharedState state;

        private void Start()
        {
            block = new MaterialPropertyBlock();
            if (CEFStateBus.Instance != null)
                CEFStateBus.Instance.OnStateUpdated += HandleStateUpdated;
        }

        private void OnDestroy()
        {
            if (CEFStateBus.Instance != null)
                CEFStateBus.Instance.OnStateUpdated -= HandleStateUpdated;
        }

        private void HandleStateUpdated(CEFSharedState s) => state = s;

        private void Update()
        {
            if (guideLight != null)
            {
                var p = guideLight.localPosition;
                p.y = Mathf.Sin(Time.time * bobSpeed) * bobHeight;
                guideLight.localPosition = p;
            }

            if (state != null && alcoveGlyphRenderer != null)
            {
                alcoveGlyphRenderer.GetPropertyBlock(block);
                var c = Color.Lerp(new Color(0.2f, 0.15f, 0.08f), new Color(0.55f, 0.9f, 1f), state.sourceAlignment);
                block.SetColor(EmissionColor, c * Mathf.Lerp(0.3f, 2.2f, state.creativeEdge));
                alcoveGlyphRenderer.SetPropertyBlock(block);
            }
        }
    }
}
