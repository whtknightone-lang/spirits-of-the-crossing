using UnityEngine;
using Upsilon.CEF;

namespace Upsilon.Cave
{
    public class GrandChamberAmbienceController : MonoBehaviour
    {
        [SerializeField] private Light[] chamberLights;
        [SerializeField] private ParticleSystem dustMotes;
        [SerializeField] private ParticleSystem spiritAmbient;
        [SerializeField] private AudioSource chamberDrone;
        [SerializeField] private Transform centralGlyphRing;
        [SerializeField] private float glyphSpinSpeed = 4f;

        private CEFSharedState state;

        private void Start()
        {
            if (CEFStateBus.Instance != null)
                CEFStateBus.Instance.OnStateUpdated += HandleStateUpdated;
        }

        private void OnDestroy()
        {
            if (CEFStateBus.Instance != null)
                CEFStateBus.Instance.OnStateUpdated -= HandleStateUpdated;
        }

        private void HandleStateUpdated(CEFSharedState s) => state = s;

        private void Update()
        {
            if (state == null) return;

            float ambient = state.coherence * 0.4f + state.sourceAlignment * 0.4f + state.creativeEdge * 0.2f;

            if (chamberLights != null)
            {
                foreach (var l in chamberLights)
                {
                    if (l == null) continue;
                    l.intensity = Mathf.Lerp(0.8f, 4.5f, ambient);
                    l.color = Color.Lerp(new Color(1f, 0.75f, 0.45f), new Color(0.75f, 0.9f, 1f), state.sourceAlignment);
                }
            }

            if (dustMotes != null)
            {
                var em = dustMotes.emission;
                em.rateOverTime = Mathf.Lerp(8f, 30f, ambient);
                if (!dustMotes.isPlaying) dustMotes.Play();
            }

            if (spiritAmbient != null)
            {
                var em = spiritAmbient.emission;
                em.rateOverTime = Mathf.Lerp(0f, 20f, Mathf.Clamp01((state.identity + state.sourceAlignment) * 0.5f));
                if (!spiritAmbient.isPlaying) spiritAmbient.Play();
            }

            if (chamberDrone != null)
            {
                chamberDrone.volume = Mathf.Lerp(0.2f, 0.8f, ambient);
                chamberDrone.pitch = Mathf.Lerp(0.92f, 1.08f, state.creativeEdge);
            }

            if (centralGlyphRing != null)
            {
                centralGlyphRing.Rotate(Vector3.up, glyphSpinSpeed * Mathf.Lerp(0.2f, 1f, state.creativeEdge) * Time.deltaTime, Space.Self);
            }
        }
    }
}
