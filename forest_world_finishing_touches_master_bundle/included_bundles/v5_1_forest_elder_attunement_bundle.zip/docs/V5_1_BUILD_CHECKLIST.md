# V5.1 Build Checklist

- [ ] Add stag encounter controller to V4 forest scene
- [ ] Add fairy swarm and gnome keeper nodes
- [ ] Add attunement ability controller to player and optional AI
- [ ] Add healing targets for AI, animal, dryad, tree, and forest zone
- [ ] Add food offering node and water call node
- [ ] Add hawk support request node
- [ ] Connect forest memory recorder to outcomes
- [ ] Modulate visibility and success with V5 planetary harmonics/weather
- [ ] Keep all actions voluntary and ask-based
