# Planetary Harmonics Extension for V5.1

Planetary and moon conditions now modulate forest attunement.

Examples:
- Tide Moon high: water asking is easier, reflection pools are clearer
- Hush Moon high: fairies and spirit stag appear more often in mist
- Iron Moon high: gnomes are more active near roots and stone
- Ember Moon high: healing may require more patience; storms intensify
- Source Star high: attunement success and gentle offerings increase

Weather links:
- Mist -> fairy visibility, spirit permeability
- Rain -> healing boost, tree restoration boost
- Storm -> fracture pressure, high transformation chance
- Aurora -> rare elder insight and magnetic pathway shifts
