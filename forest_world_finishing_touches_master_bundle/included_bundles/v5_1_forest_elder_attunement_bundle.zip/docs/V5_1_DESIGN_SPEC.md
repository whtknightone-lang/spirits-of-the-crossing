# V5.1 Design Spec

## Core idea
The forest is no longer just a destination.
It becomes a responsive living field where the player can attune and work energy in cooperation with:
- AI counterpart
- companion animal
- animal spirit
- elder spirit stag
- fairies
- gnomes
- dryads
- trees
- birds / hawks
- water sources

## Main loop
1. Enter V4 forest spring clearing
2. Restore spring resonance
3. Elder Spirit Stag appears
4. Fairies and gnomes begin to reveal themselves
5. Player learns attunement actions
6. Player, AI, and companions can help heal beings and places
7. Food / water / animal-call interactions unlock
8. Forest memory updates
9. Return portal outcome reflects what was nurtured

## Attunement actions
- Heal target
- Ask for fruit / food
- Find water
- Call water
- Request animal hunt support
- Restore dryad / tree / forest patch
- Calm companions or AI
- Ask rather than command

## Rule
Attunement succeeds best when resonance is calm, coherent, and relational.
