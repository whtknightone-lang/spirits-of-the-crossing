# Attunement Actions

## 1. Heal
Targets:
- player
- AI
- companion animal
- dryad
- tree
- forest zone

Effect:
- lowers fracture
- raises coherence
- raises trust if done with care

## 2. Ask for fruit / food
Targets:
- tree
- vine
- root patch
- gnome-kept garden spot

Effect:
- food may be offered freely
- abundance rises if gratitude and sharing are present

## 3. Find or call water
Targets:
- spring
- hidden seep
- shallow channel
- rock basin

Effect:
- reveals or strengthens water source
- helps healing and portal calm

## 4. Ask hawks or others to hunt
Targets:
- hawk
- owl
- fox
- wolf-like ally
- other local creature

Effect:
- creature may help locate prey or food
- never guaranteed
- depends on trust and need

## 5. Heal forest dryads / trees / forest in general
Targets:
- individual tree
- dryad node
- blighted patch
- forest network zone

Effect:
- long-term forest recovery
- improves elder affinity
- alters future offerings and sightings

## Rule
These are invitations and exchanges, not domination powers.
