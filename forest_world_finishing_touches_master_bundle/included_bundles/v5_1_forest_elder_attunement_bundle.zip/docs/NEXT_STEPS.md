# Next best moves after V5.1

1. V5.2 concrete Unity scene hierarchy + prefab layer for the forest
2. V6 planetary orbit / skymap dashboard
3. VR haptics + biometrics for attunement sorting assistance
4. Tropical destination slice with alternate elder ecology
