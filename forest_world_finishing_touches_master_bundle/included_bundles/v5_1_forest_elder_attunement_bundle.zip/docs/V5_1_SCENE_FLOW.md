# V5.1 Scene Flow

1. Arrival from cave
2. Spring restoration begins
3. Weather and harmonic state settle or intensify
4. Fairies flicker near the spring if calm rises
5. Gnome signs appear near roots or stones
6. Elder Spirit Stag appears in reflection, then at forest edge
7. Player unlocks attunement interactions
8. Optional actions:
   - heal AI
   - soothe animal
   - heal dryad/tree
   - ask tree for fruit
   - call water to basin
   - ask hawk to hunt
9. Forest memory records what was asked, given, healed, and shared
10. Return portal updates based on care rather than conquest
