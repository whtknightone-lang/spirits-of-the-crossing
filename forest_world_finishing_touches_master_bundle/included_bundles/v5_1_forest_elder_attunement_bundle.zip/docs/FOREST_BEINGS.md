# Forest Beings

## Fairies
Role:
- subtle signalers
- reveal hidden resonance paths
- amplify healing or fruit-offering zones
- playful, not fully reliable
- stronger during mist, dusk, and hush-moon conditions

Behaviors:
- appear in groups near healthy energy
- scatter when fracture rises
- circle around successful attunement
- can carry small energy packets between player, tree, and spring

## Gnomes
Role:
- keepers of roots, stones, seed caches, and practical forest balance
- stabilize local geometry and hidden passages
- more grounded and selective than fairies

Behaviors:
- appear near roots, carved stones, or hidden alcoves
- help reveal buried water or food caches
- respond well to patient players
- dislike greed and waste

## Dryads
Role:
- tree-linked intelligences
- can be weakened, sleeping, wounded, or flourishing
- healing them improves the forest globally

## Hawks and other hunters
Role:
- hunting support when asked respectfully
- path scouts
- aerial witnesses
- can decline or misread the request if the player is agitated
