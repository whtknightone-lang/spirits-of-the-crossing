using UnityEngine;
using Upsilon.CEF;

namespace Upsilon.V5_1
{
    public class FairySwarmController : MonoBehaviour
    {
        [SerializeField] private ParticleSystem fairyParticles;
        [SerializeField] private Light fairyLight;

        private void Update()
        {
            if (CEFStateBus.Instance == null) return;
            var s = CEFStateBus.Instance.CurrentState;
            bool visible = s.sourceAlignment >= 0.5f && s.fractureRisk <= 0.35f;

            if (fairyParticles != null)
            {
                if (visible && !fairyParticles.isPlaying) fairyParticles.Play();
                if (!visible && fairyParticles.isPlaying) fairyParticles.Stop();
            }

            if (fairyLight != null)
                fairyLight.intensity = visible ? 1.8f : 0f;
        }
    }
}
