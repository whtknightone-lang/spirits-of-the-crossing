using UnityEngine;

namespace Upsilon.V5_1
{
    public class HealingTarget : MonoBehaviour
    {
        public enum TargetType
        {
            Player,
            AI,
            Animal,
            Dryad,
            Tree,
            ForestZone
        }

        [SerializeField] private TargetType targetType;
        [SerializeField] private float healthState = 0.5f;
        [SerializeField] private Light targetLight;

        public void ApplyHealing(float amount)
        {
            healthState = Mathf.Clamp01(healthState + amount);
            if (targetLight != null)
                targetLight.intensity = Mathf.Lerp(0.5f, 3f, healthState);
        }

        public float GetHealthState() => healthState;
    }
}
