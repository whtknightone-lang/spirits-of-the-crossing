using UnityEngine;
using Upsilon.V5;

namespace Upsilon.V5_1
{
    public class ForestMemoryOutcomeRecorder : MonoBehaviour
    {
        [SerializeField] private ResonanceMemoryLedger ledger;

        public void RecordOutcome(string eventName, float gratitude, float waste, float elderTrustDelta, float rebirthSeed)
        {
            if (ledger != null)
                ledger.Record(eventName, gratitude, waste, elderTrustDelta, rebirthSeed);
        }
    }
}
