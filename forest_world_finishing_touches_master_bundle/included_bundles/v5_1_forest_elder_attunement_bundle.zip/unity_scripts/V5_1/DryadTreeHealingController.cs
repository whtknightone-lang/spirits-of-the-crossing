using UnityEngine;

namespace Upsilon.V5_1
{
    public class DryadTreeHealingController : MonoBehaviour
    {
        [SerializeField] private HealingTarget dryad;
        [SerializeField] private HealingTarget tree;
        [SerializeField] private HealingTarget forestZone;

        public void HealAll(float amount)
        {
            if (dryad != null) dryad.ApplyHealing(amount);
            if (tree != null) tree.ApplyHealing(amount * 0.8f);
            if (forestZone != null) forestZone.ApplyHealing(amount * 0.6f);
        }
    }
}
