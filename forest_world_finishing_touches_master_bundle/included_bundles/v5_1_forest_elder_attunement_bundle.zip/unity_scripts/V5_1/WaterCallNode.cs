using UnityEngine;

namespace Upsilon.V5_1
{
    public class WaterCallNode : MonoBehaviour
    {
        [SerializeField] private ParticleSystem waterFX;
        [SerializeField] private Light waterLight;
        [SerializeField] private float waterPresence = 0.3f;

        public bool CallWater(float attunementQuality)
        {
            waterPresence = Mathf.Clamp01(waterPresence + attunementQuality * 0.35f);
            bool success = waterPresence >= 0.5f;

            if (waterFX != null && success && !waterFX.isPlaying) waterFX.Play();
            if (waterLight != null) waterLight.intensity = Mathf.Lerp(0.4f, 2.5f, waterPresence);

            return success;
        }
    }
}
