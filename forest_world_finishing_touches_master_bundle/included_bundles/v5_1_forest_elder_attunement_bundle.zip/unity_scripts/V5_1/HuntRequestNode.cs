using UnityEngine;

namespace Upsilon.V5_1
{
    public class HuntRequestNode : MonoBehaviour
    {
        [SerializeField] private GameObject hawkVisual;
        [SerializeField] private bool helping;

        public bool RequestSupport(float attunementQuality, float needLevel)
        {
            float score = attunementQuality * 0.7f + needLevel * 0.3f;
            helping = score >= 0.5f;
            if (hawkVisual != null) hawkVisual.SetActive(helping);
            return helping;
        }
    }
}
