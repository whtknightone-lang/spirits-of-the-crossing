using UnityEngine;
using Upsilon.CEF;

namespace Upsilon.V5_1
{
    public class AttunementAbilityController : MonoBehaviour
    {
        [SerializeField] private float healStrength = 0.2f;
        [SerializeField] private float waterCallStrength = 0.2f;
        [SerializeField] private float foodAskStrength = 0.2f;
        [SerializeField] private float huntRequestStrength = 0.2f;

        public bool CanAttune()
        {
            if (CEFStateBus.Instance == null) return false;
            var s = CEFStateBus.Instance.CurrentState;
            return s.coherence >= 0.45f && s.fractureRisk <= 0.40f;
        }

        public float GetAttunementQuality()
        {
            if (CEFStateBus.Instance == null) return 0f;
            var s = CEFStateBus.Instance.CurrentState;
            return Mathf.Clamp01(0.35f * s.coherence + 0.25f * s.sourceAlignment + 0.2f * s.identity + 0.2f * (1f - s.fractureRisk));
        }

        public float UseHeal() => CanAttune() ? healStrength * GetAttunementQuality() : 0f;
        public float AskForFood() => CanAttune() ? foodAskStrength * GetAttunementQuality() : 0f;
        public float CallWater() => CanAttune() ? waterCallStrength * GetAttunementQuality() : 0f;
        public float RequestHunt() => CanAttune() ? huntRequestStrength * GetAttunementQuality() : 0f;
    }
}
