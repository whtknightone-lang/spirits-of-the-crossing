using UnityEngine;

namespace Upsilon.V5_1
{
    public class FoodOfferingNode : MonoBehaviour
    {
        [SerializeField] private GameObject fruitVisuals;
        [SerializeField] private bool offered;
        [SerializeField] private float abundance = 0.5f;

        public bool AskForFood(float attunementQuality, bool shared, bool grateful)
        {
            float chance = abundance * attunementQuality;
            if (shared) chance += 0.15f;
            if (grateful) chance += 0.15f;

            offered = chance >= 0.45f;
            if (fruitVisuals != null) fruitVisuals.SetActive(offered);
            return offered;
        }
    }
}
