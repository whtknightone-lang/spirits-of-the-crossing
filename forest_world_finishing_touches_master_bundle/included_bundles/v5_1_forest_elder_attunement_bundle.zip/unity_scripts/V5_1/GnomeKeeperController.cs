using UnityEngine;

namespace Upsilon.V5_1
{
    public class GnomeKeeperController : MonoBehaviour
    {
        [SerializeField] private GameObject rootCacheVisuals;
        [SerializeField] private bool patientPlayerRequired = true;

        public bool RevealCache(float attunementQuality, bool playerPatient)
        {
            bool success = attunementQuality >= 0.45f && (!patientPlayerRequired || playerPatient);
            if (rootCacheVisuals != null) rootCacheVisuals.SetActive(success);
            return success;
        }
    }
}
