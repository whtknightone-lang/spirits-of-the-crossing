using UnityEngine;
using Upsilon.V5;
using Upsilon.CEF;

namespace Upsilon.V5_1
{
    public class ForestElderEncounterController : MonoBehaviour
    {
        [SerializeField] private ElderSpiritStagController stag;
        [SerializeField] private GameObject fairyRoot;
        [SerializeField] private GameObject gnomeRoot;
        [SerializeField] private Light encounterLight;

        public bool EncounterActive { get; private set; }

        private void Update()
        {
            if (CEFStateBus.Instance == null) return;
            var s = CEFStateBus.Instance.CurrentState;

            bool calmEnough = s.coherence >= 0.52f && s.fractureRisk <= 0.35f;
            EncounterActive = calmEnough;

            if (fairyRoot != null) fairyRoot.SetActive(calmEnough && s.sourceAlignment >= 0.50f);
            if (gnomeRoot != null) gnomeRoot.SetActive(calmEnough && s.identity >= 0.50f);

            if (encounterLight != null)
                encounterLight.intensity = calmEnough ? 2.6f : 0.8f;
        }
    }
}
