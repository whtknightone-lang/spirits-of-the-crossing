# V5.1 Forest Elder Attunement Bundle

This package wires the Elder Spirit Stag directly into the V4 forest scene and expands the forest into a living attunement ecosystem.

Included:
- playable stag encounter integration layer
- fairies and gnomes as optional helper / witness beings
- player, AI, and animal attunement abilities
- healing for player / AI / animals / dryads / trees / forest zones
- asking for fruit or vegetable food
- finding or calling water
- asking hawks or other creatures to hunt
- forest restoration systems
- updated resonance memory hooks

Design rule:
Everything remains voluntary. Beings can help, decline, observe, depart, and return.
