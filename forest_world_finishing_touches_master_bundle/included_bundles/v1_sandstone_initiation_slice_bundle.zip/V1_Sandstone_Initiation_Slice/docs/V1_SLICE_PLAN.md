# V1 Sandstone Initiation Slice Plan

## Core deliverable
A working Unity vertical slice that proves the onboarding ritual and the live resonance loop.

## Scene A: Sandstone Cave
- Dormant cave ambience
- Resonance disk at center
- Player skin active
- Animal statue seed -> animal guide
- Animal spirit reveal
- AI statue seed -> AI counterpart
- Portal ring unlocks when thresholds are met

## Scene B: First Destination
Choose one:
- Forest clearing
- Stone chamber puzzle
- Planet glimpse chamber

## Systems to wire next
- `CEFUdpReceiver.cs`
- `XRHapticsDriver.cs`
- `PortalTravelTrigger.cs`
- `SpiritBondVisualizer.cs`
- `SceneTransitionController.cs`

## Live state mapping
- Coherence -> world stability
- Novelty -> portal shimmer / particles
- Identity -> entity core brightness
- Fracture risk -> warning flicker / harsher haptics
- Source alignment -> spirit clarity / portal readiness
- Creative edge -> global resonance pulse

## Haptics plan
- Low soft pulse on cave entry
- Guiding pulse near resonance disk
- Strong synchronized pulse on portal stabilization
- Warning buzz if fracture rises too high

## Success criteria
- The player can complete the cave ritual without debug controls
- The AI/player/animal/spirit relationship is readable in motion and light
- The portal transition feels earned, not scripted
- The system works with synthetic and live state
