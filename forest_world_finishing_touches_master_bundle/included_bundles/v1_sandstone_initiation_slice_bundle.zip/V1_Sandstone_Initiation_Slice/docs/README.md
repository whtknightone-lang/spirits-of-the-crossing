# V1 Sandstone Initiation Slice

This bundle combines the current Upsilon/CEF-2 prototype materials into a single package for the first playable vertical slice.

## Included
- `existing_bundles/sandstone_cave_scripts_bundle.zip`
  - Sandstone cave Unity C# scripts
- `existing_bundles/upsilon_unity_starter_bridge_bundle.zip`
  - Unity starter bridge scaffold
- `existing_bundles/cef2_upsilon_creative_edge_bundle.zip`
  - CEF-2 Python prototype and architecture notes
- `docs/V1_SLICE_PLAN.md`
  - Exact next-step scope for the first playable slice

## Goal of V1
A small playable loop:
1. Enter sandstone cave
2. Step onto resonance disk
3. Animal awakens
4. Animal spirit appears
5. AI stabilizes
6. Portal opens
7. Player enters portal
8. Destination scene loads

## Recommended immediate integration order
1. Import cave scripts into Unity project
2. Import starter bridge scripts
3. Hook synthetic state first
4. Connect live UDP receiver
5. Add controller haptics
6. Create one destination scene

