using UnityEngine;

namespace Upsilon.OuterWorld
{
    public class CompanionChoiceBeacon : MonoBehaviour
    {
        [SerializeField] private Transform companion;
        [SerializeField] private float joinDistance = 4f;
        [SerializeField] private bool joined;

        public bool IsJoined => joined;

        private void Update()
        {
            if (companion == null) return;
            if (Vector3.Distance(companion.position, transform.position) <= joinDistance)
                joined = true;
        }

        public void ReleaseCompanion()
        {
            joined = false;
        }
    }
}
