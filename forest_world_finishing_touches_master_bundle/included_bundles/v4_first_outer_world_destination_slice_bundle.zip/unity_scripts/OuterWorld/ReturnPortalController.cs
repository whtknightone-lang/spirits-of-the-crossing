using UnityEngine;

namespace Upsilon.OuterWorld
{
    public class ReturnPortalController : MonoBehaviour
    {
        [SerializeField] private GameObject portalVisuals;
        [SerializeField] private Collider portalTrigger;
        private bool returnEnabled;

        public void SetReturnEnabled(bool enabled)
        {
            returnEnabled = enabled;
            if (portalVisuals != null) portalVisuals.SetActive(enabled);
            if (portalTrigger != null) portalTrigger.enabled = enabled;
        }

        public bool CanReturn()
        {
            return returnEnabled;
        }
    }
}
