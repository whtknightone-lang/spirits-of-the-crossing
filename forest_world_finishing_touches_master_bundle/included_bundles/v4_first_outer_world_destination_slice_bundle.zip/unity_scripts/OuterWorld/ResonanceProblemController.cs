using UnityEngine;
using Upsilon.CEF;

namespace Upsilon.OuterWorld
{
    public class ResonanceProblemController : MonoBehaviour
    {
        [SerializeField] private float coherenceThreshold = 0.56f;
        [SerializeField] private float fractureMax = 0.35f;
        [SerializeField] private Renderer springRenderer;
        [SerializeField] private Light springLight;

        public bool IsEngaged { get; private set; }
        public bool IsResolved { get; private set; }

        private static readonly int EmissionColor = Shader.PropertyToID("_EmissionColor");
        private MaterialPropertyBlock block;

        private void Start()
        {
            block = new MaterialPropertyBlock();
        }

        private void Update()
        {
            if (CEFStateBus.Instance == null) return;
            var s = CEFStateBus.Instance.CurrentState;
            IsEngaged = true;

            IsResolved = s.coherence >= coherenceThreshold &&
                         s.fractureRisk <= fractureMax &&
                         s.sourceAlignment >= 0.52f;

            if (springRenderer != null)
            {
                springRenderer.GetPropertyBlock(block);
                Color c = IsResolved ? new Color(0.45f, 0.9f, 1f) : new Color(0.18f, 0.35f, 0.4f);
                block.SetColor(EmissionColor, c * (IsResolved ? 2.8f : 0.8f));
                springRenderer.SetPropertyBlock(block);
            }

            if (springLight != null)
                springLight.intensity = IsResolved ? 4f : 1.2f;
        }
    }
}
