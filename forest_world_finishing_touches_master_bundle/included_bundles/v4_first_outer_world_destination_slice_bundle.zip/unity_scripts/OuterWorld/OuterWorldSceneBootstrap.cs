using UnityEngine;

namespace Upsilon.OuterWorld
{
    public class OuterWorldSceneBootstrap : MonoBehaviour
    {
        [SerializeField] private Transform player;
        [SerializeField] private Transform aiCompanion;
        [SerializeField] private Transform animalCompanion;
        [SerializeField] private Transform spiritCompanion;
        [SerializeField] private Transform arrivalPoint;

        private void Start()
        {
            if (player != null && arrivalPoint != null)
                player.position = arrivalPoint.position;
        }
    }
}
