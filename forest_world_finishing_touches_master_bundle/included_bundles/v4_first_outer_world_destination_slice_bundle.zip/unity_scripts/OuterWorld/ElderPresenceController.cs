using UnityEngine;

namespace Upsilon.OuterWorld
{
    public class ElderPresenceController : MonoBehaviour
    {
        [SerializeField] private ResonanceProblemController resonanceProblem;
        [SerializeField] private GameObject elderVisuals;
        [SerializeField] private Light elderLight;

        public bool HasManifested { get; private set; }

        private void Update()
        {
            bool show = resonanceProblem != null && resonanceProblem.IsResolved;
            HasManifested = show;

            if (elderVisuals != null)
                elderVisuals.SetActive(show);

            if (elderLight != null)
                elderLight.intensity = show ? 3.5f : 0f;
        }
    }
}
