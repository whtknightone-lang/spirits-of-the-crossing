using UnityEngine;

namespace Upsilon.OuterWorld
{
    public class OuterWorldSequenceController : MonoBehaviour
    {
        public enum Stage
        {
            Arrival,
            Exploration,
            SpringAttunement,
            ElderPresence,
            ReturnReady
        }

        [SerializeField] private Stage currentStage = Stage.Arrival;
        [SerializeField] private ResonanceProblemController resonanceProblem;
        [SerializeField] private ElderPresenceController elderPresence;
        [SerializeField] private ReturnPortalController returnPortal;

        private void Update()
        {
            if (currentStage == Stage.Arrival)
                currentStage = Stage.Exploration;

            if (currentStage == Stage.Exploration && resonanceProblem != null && resonanceProblem.IsEngaged)
                currentStage = Stage.SpringAttunement;

            if (currentStage == Stage.SpringAttunement && resonanceProblem != null && resonanceProblem.IsResolved)
                currentStage = Stage.ElderPresence;

            if (currentStage == Stage.ElderPresence && elderPresence != null && elderPresence.HasManifested)
            {
                currentStage = Stage.ReturnReady;
                if (returnPortal != null) returnPortal.SetReturnEnabled(true);
            }
        }
    }
}
