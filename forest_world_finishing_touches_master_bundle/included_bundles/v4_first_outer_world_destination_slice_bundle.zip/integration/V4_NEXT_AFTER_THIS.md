# What comes after V4

Best next move after V4:
- V5 Elder Trial Slice
or
- VR/Haptics integration pass on cave + V4 destination
or
- Bioskin / sorting input prototype using optional biometrics
