# V4 Build Checklist

- [ ] Create `ForestSpringClearing_V1` scene
- [ ] Add arrival portal ring and return anchor
- [ ] Place spring pool and elder reflection area
- [ ] Add one elder visual sign (Water)
- [ ] Add outer-world scripts from this bundle
- [ ] Reuse V3 voluntary companion logic
- [ ] Reuse CEF state bus / live UDP bridge
- [ ] Add one resonance mark reward
- [ ] Confirm return portal only opens after elder presence manifests
