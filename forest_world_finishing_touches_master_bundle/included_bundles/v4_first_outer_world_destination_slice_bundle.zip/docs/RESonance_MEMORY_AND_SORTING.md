# Resonance Memory and Sorting Scalability

V4 keeps sorting optional and scalable.

## Baseline sorting inputs
- player actions
- pacing
- time spent in calm zones
- how often companions are invited vs allowed to remain free
- portal choices
- resonance recovery patterns

## Future optional sorting inputs
- VR motion smoothness
- gaze stability
- breath pacing
- biometrics (HRV, EDA, EMG, respiration)
- haptic response timing

## Rule
Future VR/biometric inputs **modulate** sorting, they do not replace player meaning.

## Resonance memory
Each completed destination updates:
- player profile
- AI profile
- companion bond profile
- spirit visibility profile
- elder affinity profile

That memory travels back to the cave and forward to later worlds.
