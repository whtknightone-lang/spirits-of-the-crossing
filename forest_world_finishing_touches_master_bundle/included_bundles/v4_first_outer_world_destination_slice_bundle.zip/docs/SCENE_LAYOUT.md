# Scene Layout

## Suggested hierarchy

```text
ForestSpringClearing_Root
├── Environment
│   ├── Ground
│   ├── Trees
│   ├── SpringPool
│   ├── RockArches
│   ├── LightShafts
│   └── Mist
├── Arrival
│   ├── PortalArrivalRing
│   ├── ArrivalFX
│   └── ReturnAnchor
├── Entities
│   ├── PlayerSpawn
│   ├── AISpawn
│   ├── AnimalSpawn
│   └── SpiritSpawn
├── ResonanceGameplay
│   ├── Zone_Arrival
│   ├── Zone_Spring
│   ├── Zone_ElderReflection
│   └── Zone_Return
├── Elder
│   ├── WaterElderSign
│   ├── ReflectionPlane
│   └── ElderPulseFX
├── Audio
│   ├── ForestBed
│   ├── WaterLayer
│   └── SpiritTone
└── Systems
    ├── OuterWorldSceneBootstrap
    ├── OuterWorldSequenceController
    ├── ResonanceProblemController
    ├── ElderPresenceController
    └── ReturnPortalController
```
