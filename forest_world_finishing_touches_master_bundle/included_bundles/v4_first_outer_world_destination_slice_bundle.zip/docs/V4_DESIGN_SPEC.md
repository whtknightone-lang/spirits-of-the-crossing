# V4 Design Spec — First Outer-World Destination Slice

## Destination choice
The strongest first destination is a **small forest clearing with water**, because it contrasts the carved sandstone cave and naturally supports:
- healing
- adaptation
- soft sorting
- voluntary companion behavior
- visible environmental resonance

## Scene identity
Name: `ForestSpringClearing_V1`

Mood:
- quiet
- luminous
- slightly sacred
- alive but not crowded
- designed for first trust-building outside the cave

## Core entities
- Player
- AI counterpart
- Companion animal
- Animal spirit
- Water elder sign/presence

## Spatial layout
- portal arrival ring
- shallow spring pool
- fallen stone arch
- elder reflection pool
- one side path / hidden niche
- return portal anchor

## Main problem
The spring is partially out of tune.
The player does not "fight" it.
Instead the player, AI, animal, and spirit help bring the area into a healthy resonance band.

## Mechanics
- stand in field zones
- move in rhythm
- stay calm enough for spirit visibility
- let companions choose whether to join
- align portal-return state after restoration

## Success condition
The pool clears, the elder sign appears in reflection/light, and the player receives a resonance mark.

## Failure state
No hard fail. The system remains voluntary.
Companions can step away, the area can remain partially unstable, and the player can return later.
