# First Outer-World Quest

## Quest name
`Restore the First Spring`

## Steps
1. Arrive from cave portal
2. Companion animal decides whether to approach the spring
3. AI scans and offers interpretation
4. Animal spirit becomes more visible if calm/coherence rises
5. Player enters spring resonance zone
6. Shared field stabilizes water and surrounding life
7. Water elder sign appears
8. Resonance mark granted
9. Return portal becomes available

## Voluntary design
- The animal may stay near the edge first
- The AI may enter before or after the player
- The spirit may only appear intermittently
- The elder sign never forces interaction
