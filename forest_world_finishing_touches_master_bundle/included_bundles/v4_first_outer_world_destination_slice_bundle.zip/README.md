# V4 First Outer-World Destination Slice

This package defines the first playable outer-world destination after the Sandstone Initiation Slice.

Core loop:
1. Enter Petra-like sandstone cave
2. Complete initiation and open first portal
3. Travel to a small outer-world destination
4. Meet the sign/presence of one elder element
5. Solve one resonance problem with Player + AI + Animal + Spirit
6. Earn a resonance mark
7. Return to the cave changed

This V4 package is designed to extend:
- V1 Sandstone Initiation Slice
- V2 grand cave / Petra-like entrance
- V2.1 dragon carving integration
- V3 Voluntary Companion Bond Slice

Recommended first outer-world:
**Forest Spring Clearing** with a **Water elder sign** and optional **Air traces** overhead.
