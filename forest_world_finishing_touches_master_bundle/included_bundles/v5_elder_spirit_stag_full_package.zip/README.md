# V5 Elder Spirit Stag + Sacred Offering Cycle + Planetary Harmonics

This package expands the Upsilon world in two directions:

1. Forest elder ecology
   - Elder Spirit Stag
   - Sacred Offering Cycle
   - Voluntary self-offering / food-offering / renewal logic
   - Rebirth and resonance memory

2. Cosmic world-state layer
   - Planetary harmonics
   - Orbital resonance
   - Magnetic field influence
   - Weather modulation for planets and moons
   - World sorting hooks back into cave / portal / elder systems
