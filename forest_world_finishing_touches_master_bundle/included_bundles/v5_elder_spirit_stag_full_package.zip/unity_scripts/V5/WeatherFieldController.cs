using UnityEngine;

namespace Upsilon.V5
{
    public class WeatherFieldController : MonoBehaviour
    {
        public enum WeatherMode { Clear, Mist, Rain, Storm, Fog, Aurora }

        [SerializeField] private WeatherMode currentMode = WeatherMode.Mist;
        [SerializeField] private Light worldLight;
        [SerializeField] private ParticleSystem weatherFX;

        public void SetWeather(WeatherMode mode)
        {
            currentMode = mode;
            if (weatherFX != null && !weatherFX.isPlaying) weatherFX.Play();
        }

        private void Update()
        {
            if (worldLight == null) return;

            switch (currentMode)
            {
                case WeatherMode.Clear: worldLight.intensity = 1.1f; break;
                case WeatherMode.Mist: worldLight.intensity = 0.85f; break;
                case WeatherMode.Rain: worldLight.intensity = 0.75f; break;
                case WeatherMode.Storm: worldLight.intensity = 0.55f; break;
                case WeatherMode.Fog: worldLight.intensity = 0.65f; break;
                case WeatherMode.Aurora: worldLight.intensity = 0.95f; break;
            }
        }
    }
}
