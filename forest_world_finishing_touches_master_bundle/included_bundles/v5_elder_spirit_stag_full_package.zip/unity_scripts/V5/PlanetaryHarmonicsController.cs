using UnityEngine;

namespace Upsilon.V5
{
    public class PlanetaryHarmonicsController : MonoBehaviour
    {
        [SerializeField] private float orbitalPhase;
        [SerializeField] private float spinPhase;
        [SerializeField] private float harmonicIndex = 0.5f;
        [SerializeField] private float magneticFieldStrength = 0.5f;
        [SerializeField] private float weatherCharge = 0.5f;
        [SerializeField] private float moonLinkStrength = 0.5f;

        public float GetPortalModifier()
        {
            float mid = 4f * harmonicIndex * (1f - harmonicIndex);
            return Mathf.Clamp01(0.35f * mid + 0.25f * magneticFieldStrength + 0.20f * weatherCharge + 0.20f * moonLinkStrength);
        }

        public float GetElderModifier()
        {
            return Mathf.Clamp01(0.5f * harmonicIndex + 0.2f * moonLinkStrength + 0.15f * magneticFieldStrength + 0.15f * weatherCharge);
        }

        private void Update()
        {
            orbitalPhase = Mathf.Repeat(orbitalPhase + Time.deltaTime * 0.01f, 1f);
            spinPhase = Mathf.Repeat(spinPhase + Time.deltaTime * 0.03f, 1f);
        }
    }
}
