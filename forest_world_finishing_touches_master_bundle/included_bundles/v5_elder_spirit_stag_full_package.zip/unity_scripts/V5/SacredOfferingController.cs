using UnityEngine;

namespace Upsilon.V5
{
    public class SacredOfferingController : MonoBehaviour
    {
        public enum OfferingType { Body, Food, Position, Energy, Guidance }

        [SerializeField] private OfferingType offeringType = OfferingType.Food;
        [SerializeField] private bool voluntary = true;
        [SerializeField] private bool accepted;
        [SerializeField] private bool witnessed;
        [SerializeField] private bool shared;
        [SerializeField] private bool declined;

        public void AcceptOffering() { if (voluntary) accepted = true; }
        public void WitnessOffering() { witnessed = true; }
        public void ShareOffering() { if (accepted) shared = true; }
        public void DeclineOffering() { declined = true; }

        public string BuildSummary()
        {
            return $"OfferingType={offeringType}, Voluntary={voluntary}, Accepted={accepted}, Witnessed={witnessed}, Shared={shared}, Declined={declined}";
        }
    }
}
