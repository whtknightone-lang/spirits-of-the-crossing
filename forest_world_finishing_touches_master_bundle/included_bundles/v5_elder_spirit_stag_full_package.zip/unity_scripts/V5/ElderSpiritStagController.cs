using UnityEngine;
using Upsilon.CEF;

namespace Upsilon.V5
{
    public class ElderSpiritStagController : MonoBehaviour
    {
        public enum StagState { Hidden, Observing, Near, Witnessing, Offering, Fading, RebirthEcho }

        [SerializeField] private GameObject visualsRoot;
        [SerializeField] private Light stagLight;
        [SerializeField] private float coherenceThreshold = 0.58f;
        [SerializeField] private float sourceThreshold = 0.55f;
        [SerializeField] private bool injuredOldStag = true;

        public StagState CurrentState { get; private set; } = StagState.Hidden;

        private void Update()
        {
            if (CEFStateBus.Instance == null) return;
            var s = CEFStateBus.Instance.CurrentState;

            if (s.coherence < 0.35f || s.fractureRisk > 0.45f)
                CurrentState = StagState.Hidden;
            else if (s.coherence >= 0.35f && s.sourceAlignment >= 0.40f)
                CurrentState = StagState.Observing;
            if (s.coherence >= coherenceThreshold && s.sourceAlignment >= sourceThreshold)
                CurrentState = injuredOldStag ? StagState.Witnessing : StagState.Near;
            if (injuredOldStag && s.identity >= 0.60f && s.fractureRisk < 0.30f)
                CurrentState = StagState.Offering;

            bool visible = CurrentState != StagState.Hidden;
            if (visualsRoot != null) visualsRoot.SetActive(visible);
            if (stagLight != null) stagLight.intensity = visible ? 3.0f : 0f;
        }
    }
}
