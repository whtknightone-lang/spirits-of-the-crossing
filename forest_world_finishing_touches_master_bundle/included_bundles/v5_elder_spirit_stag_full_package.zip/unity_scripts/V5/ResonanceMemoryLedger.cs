using UnityEngine;
using System.Collections.Generic;

namespace Upsilon.V5
{
    public class ResonanceMemoryLedger : MonoBehaviour
    {
        [System.Serializable]
        public class MemoryEntry
        {
            public string eventName;
            public float gratitude;
            public float waste;
            public float elderTrustDelta;
            public float rebirthSeed;
        }

        [SerializeField] private List<MemoryEntry> entries = new List<MemoryEntry>();

        public void Record(string eventName, float gratitude, float waste, float elderTrustDelta, float rebirthSeed)
        {
            entries.Add(new MemoryEntry
            {
                eventName = eventName,
                gratitude = gratitude,
                waste = waste,
                elderTrustDelta = elderTrustDelta,
                rebirthSeed = rebirthSeed
            });
        }
    }
}
