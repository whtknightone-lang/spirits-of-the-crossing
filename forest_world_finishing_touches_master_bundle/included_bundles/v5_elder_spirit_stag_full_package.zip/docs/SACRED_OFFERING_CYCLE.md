# Sacred Offering Cycle

## Core law
Nothing is taken without meaning.
What is freely given returns to the world in another form.

## Offering types
1. Body offering
2. Food offering
3. Position offering
4. Energetic offering
5. Guidance offering

## Response options
- Accept
- Decline
- Witness
- Share
- Keep vigil
- Ask companions
- Return later

## Rebirth outputs
- young stag later appears
- spirit echo returns first
- grove growth from site of offering
- antler-root tree grows
- elder affinity increases
