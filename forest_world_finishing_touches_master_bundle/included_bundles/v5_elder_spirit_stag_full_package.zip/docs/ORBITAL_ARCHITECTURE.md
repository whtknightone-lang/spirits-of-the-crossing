# Orbital Architecture

## Suggested body roles
- Primary world: Forest / cave origin world
- Moon A: Tide / reflection / water memory
- Moon B: Ember / action / transformation
- Moon C: Hush / dream / spirit permeability
- Moon D: Iron / magnetic tension / machine influence
- Dark world: contrast / learning / disharmony modulation
- Source star: coherence / joy / recall / renewal

## Orbit effects
- conjunction boosts harmonic mixing
- opposition creates tension and sorting pressure
- eclipse events amplify elder signs
- perigee increases local field intensity
- resonance lock between moons creates rare portal windows
