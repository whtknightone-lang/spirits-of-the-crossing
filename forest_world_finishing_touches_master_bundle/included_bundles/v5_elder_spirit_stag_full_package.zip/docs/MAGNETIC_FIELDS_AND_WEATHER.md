# Magnetic Fields and Weather

## Magnetic field gameplay meaning
Magnetic fields are invisible ordering pressures.

Possible effects:
- compass-like pull on portals
- changing aurora / sky color
- creature agitation or calm
- enhanced memory retention in certain zones
- distortion around unstable worlds

## Weather meaning
Weather is not just decoration.
It carries resonance state.

Examples:
- light mist = spirit permeability
- rain = healing and memory conductivity
- electrical storm = fire/air tension, risk and transformation
- still warm air = trust / quiet / offering readiness
- dense wind = path revelation or concealment
