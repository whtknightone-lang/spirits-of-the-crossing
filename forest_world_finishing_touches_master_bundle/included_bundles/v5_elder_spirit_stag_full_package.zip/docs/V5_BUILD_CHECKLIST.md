# V5 Build Checklist

- [ ] Add Elder Spirit Stag encounter zone to V4 forest clearing
- [ ] Add Sacred Offering event node
- [ ] Add tree or vine food-offering prop
- [ ] Connect companion witness / choice logic
- [ ] Add planetary harmonics controller singleton
- [ ] Add weather field controller per destination
- [ ] Define moons and planetary roles in config
- [ ] Connect magnetic/weather modifiers to portal and elder visibility
- [ ] Record outcomes into resonance memory ledger
- [ ] Confirm voluntary choice remains central
