# V5 Design Spec

## Main idea
V5 joins mythic forest law with planetary world law.

At the local level, the player can encounter the Elder Spirit Stag and participate in a Sacred Offering Cycle.
At the cosmic level, planets and moons modulate resonance conditions through harmonics, magnetic fields, orbital timing, and weather.

This means:
- the forest is alive and remembers
- the sky is alive and influences the forest
- portals can sort based on local and orbital conditions
- elder presences can intensify during specific harmonic windows

## Pillars
1. Voluntary offering, never forced sacrifice
2. Rebirth rather than simple deletion
3. Planetary harmonics as living timing system
4. Magnetic/weather fields as world mood regulators
5. Resonance memory linking all scales
