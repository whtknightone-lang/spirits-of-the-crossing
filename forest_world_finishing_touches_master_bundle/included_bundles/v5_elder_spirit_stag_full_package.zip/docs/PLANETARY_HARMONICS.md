# Planetary Harmonics Layer

## Purpose
Planetary harmonics provide a living timing structure for portals, weather, elder intensity, and sorting.

## Main variables per celestial body
- orbital_phase
- spin_phase
- harmonic_index
- resonance_color_bias
- magnetic_field_strength
- weather_charge
- tidal_influence
- eclipse_factor
- moon_link_strength

## Gameplay meaning
- high water harmonic + moon tide + low fracture = spring clearing heals faster
- strong magnetic unrest + storm charge = portals become unstable or dramatic
- eclipse factor + elder affinity = spirit stag appears in reflection before body
