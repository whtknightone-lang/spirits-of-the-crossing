# V5 Integration with existing slices

## Cave
The cave stores resonance memory from offerings and elder encounters.
Dragon carvings may glow differently depending on planetary harmonics.

## V4 Forest Spring Clearing
This becomes the first place where:
- Water elder sign becomes stronger
- Elder Spirit Stag can be encountered
- weather and moon phase affect spirit visibility
- voluntary offering cycle can be triggered
