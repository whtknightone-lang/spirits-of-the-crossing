# Elder Spirit Stag

## Identity
The Elder Spirit Stag is the first fully realized elder presence in the forest branch.

He represents:
- generational passage
- dignity
- restraint
- chosen giving
- renewal
- forest sovereignty

## Presentation
- visible first as distant silhouette, reflection, hoof-light, or antler-glow
- full encounter only when resonance conditions are calm enough
- body reads as stag + old tree + spirit-light
- scars carry memory, not gore

## Behavioral states
- Hidden
- Observing
- Near
- Witnessing
- Offering
- Fading
- Rebirth Echo
