# Best next moves after V5

1. V5.1 actual Unity forest-elder scene scripts wired into V4
2. V6 Planetary Orbit Dashboard / skymap UI
3. VR haptics + biometrics as optional sorting modulators
4. Moon-specific destination slices
5. Elder dragon trial slices
