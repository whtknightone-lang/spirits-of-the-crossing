
V232 + V233 Ruin World-State + Co-Activation System

V232:
- Ruin activation changes shared world state
- opens paths, unlocks areas, shifts wells

V233:
- Multiplayer co-activation of ruins
- requires aligned group resonance / participation
- larger events emerge from shared activation

Core idea:
Ruins are multiplayer myth engines that alter reality for everyone in the world.
