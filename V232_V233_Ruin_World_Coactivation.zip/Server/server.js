
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8082 });

let worldState = {
  pathOpened: false,
  areaUnlocked: false,
  wellEnergy: 0.5
};

let ruinParticipation = {};

wss.on('connection', ws => {
  ws.on('message', msg => {
    let data = {};
    try { data = JSON.parse(msg); } catch(e) { return; }

    if (data.type === 'register_participant') {
      if (!ruinParticipation[data.ruinId]) ruinParticipation[data.ruinId] = [];
      ruinParticipation[data.ruinId].push({
        playerId: data.playerId,
        resonance: data.resonance || 0
      });
      broadcast({
        type: 'participant_update',
        ruinId: data.ruinId,
        participants: ruinParticipation[data.ruinId]
      });
    }

    if (data.type === 'try_coactivate') {
      const entries = ruinParticipation[data.ruinId] || [];
      const count = entries.length;
      const avg = count > 0 ? entries.reduce((a, p) => a + p.resonance, 0) / count : 0;

      if (count >= (data.requiredParticipants || 2) && avg >= (data.minimumAverageResonance || 0.6)) {
        worldState.pathOpened = true;
        worldState.areaUnlocked = true;
        worldState.wellEnergy = Math.min(1, worldState.wellEnergy + 0.25);

        ruinParticipation[data.ruinId] = [];

        broadcast({
          type: 'coactivation_success',
          ruinId: data.ruinId,
          worldState
        });
      } else {
        broadcast({
          type: 'coactivation_failed',
          ruinId: data.ruinId,
          participants: count,
          averageResonance: avg
        });
      }
    }
  });
});

function broadcast(payload) {
  const msg = JSON.stringify(payload);
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(msg);
    }
  });
}

console.log("V232/V233 ruin multiplayer server running on 8082");
