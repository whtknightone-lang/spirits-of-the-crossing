
using UnityEngine;

public class RuinCoActivationSync : MonoBehaviour
{
    public string ruinId = "ruin_01";
    public SharedWorldState worldState;
    public RuinWorldStateEffect effect;
    public CoActivationRequirement requirement;

    public void TryCoActivate(float averageResonance)
    {
        if (requirement == null || effect == null || worldState == null) return;

        if (requirement.CanTrigger(averageResonance))
        {
            effect.Apply();
            worldState.ApplyRuinEffect(effect);
            Debug.Log("Co-activation succeeded for ruin: " + ruinId);
            requirement.ResetParticipants();
        }
        else
        {
            Debug.Log("Co-activation failed: not enough aligned participants");
        }
    }
}
