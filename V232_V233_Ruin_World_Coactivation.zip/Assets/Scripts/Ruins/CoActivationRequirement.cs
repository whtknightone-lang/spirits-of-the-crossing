
using UnityEngine;

public class CoActivationRequirement : MonoBehaviour
{
    public int requiredParticipants = 2;
    public int currentParticipants = 0;
    public float minimumAverageResonance = 0.6f;

    public bool CanTrigger(float averageResonance)
    {
        return currentParticipants >= requiredParticipants && averageResonance >= minimumAverageResonance;
    }

    public void RegisterParticipant()
    {
        currentParticipants++;
    }

    public void ResetParticipants()
    {
        currentParticipants = 0;
    }
}
