
using UnityEngine;

public class RuinWorldStateEffect : MonoBehaviour
{
    public bool pathOpened;
    public bool areaUnlocked;
    public float wellShift;

    public void Apply()
    {
        pathOpened = true;
        areaUnlocked = true;
        wellShift += 0.25f;
        Debug.Log("World state changed by ruin activation");
    }
}
