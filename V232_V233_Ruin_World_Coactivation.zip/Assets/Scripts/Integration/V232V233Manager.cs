
using UnityEngine;

public class V232V233Manager : MonoBehaviour
{
    public CoActivationRequirement requirement;
    public RuinCoActivationSync ruinSync;
    public float simulatedAverageResonance = 0.7f;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            requirement.RegisterParticipant();
            Debug.Log("Participant registered. Count=" + requirement.currentParticipants);
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            ruinSync.TryCoActivate(simulatedAverageResonance);
        }
    }
}
