
using UnityEngine;

public class SharedWorldState : MonoBehaviour
{
    public bool pathOpened;
    public bool areaUnlocked;
    public float wellEnergy = 0.5f;

    public void ApplyRuinEffect(RuinWorldStateEffect effect)
    {
        if (effect == null) return;
        pathOpened |= effect.pathOpened;
        areaUnlocked |= effect.areaUnlocked;
        wellEnergy = Mathf.Clamp01(wellEnergy + effect.wellShift);
        Debug.Log("Shared world updated: path=" + pathOpened + " area=" + areaUnlocked + " well=" + wellEnergy);
    }
}
