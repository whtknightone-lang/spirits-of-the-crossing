# V243.3 AI Portal Selection Layer

This package extends the sandstone cave demo so AI agents participate in portal and planet selection instead of only reacting after the fact.

## What it adds
- AI resonance agents with their own portal leanings
- AI consensus + source pressure blended into portal scoring
- portal profiles with ancient ruin motifs and ghost alien likenesses
- reveal manager that lets AI participation strengthen or soften portal glimpses
- spirit animation hook that moves AI-linked statue spirits toward the center disk

## Included scripts
- `Assets/Scripts/AI/AIPortalSelectionTypes.cs`
- `Assets/Scripts/AI/AIResonanceAgent.cs`
- `Assets/Scripts/AI/AICaveParticipationController.cs`
- `Assets/Scripts/AI/AISpiritPortalBehavior.cs`
- `Assets/Scripts/Portals/PortalProfileLoader.cs`
- `Assets/Scripts/Portals/ResonancePortalInterpreter.cs`
- `Assets/Scripts/Portals/GlimpsePortalController.cs`
- `Assets/Scripts/Portals/CavePortalRevealManager.cs`
- `Assets/StreamingAssets/portal_profiles_ai.json`

## Fast hookup
1. Add `PortalProfileLoader` to an empty GameObject.
2. Add `ResonancePortalInterpreter` and assign the loader.
3. Add `AICaveParticipationController` and assign the interpreter.
4. Create 2-5 AI statue/ghost entities with `AIResonanceAgent`.
5. Register them in `AICaveParticipationController.activeAgents`.
6. Add one `GlimpsePortalController` per portal recess.
7. Add `CavePortalRevealManager` and assign the interpreter + portals.
8. Call `EvaluatePortals()` then `RefreshPortalReveals()` during your session update or when a player completes a response sample.

## Suggested AI roles
- Companion spirit favors forest + source.
- Machine witness favors fire + source.
- Ruin ghost alien favors air + source.
- Source echo strongly favors source wells.
- Planetary scout favors ocean or air depending on zone.

## Design note
The cave is now an ancient ruin machine. The center disk, portal seams, and statue spirits are one integrated reading instrument. Portal glimpses should feel like world memories leaking through carved stone.
