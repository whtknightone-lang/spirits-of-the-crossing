using UnityEngine;
using V243.CaveDemo.AI;

namespace V243.CaveDemo.Portals
{
    public class GlimpsePortalController : MonoBehaviour
    {
        public ResonancePortalType portalType;
        [Range(0f, 1f)] public float revealAmount;
        [Range(0f, 1f)] public float stability;
        public bool isActiveThreshold;

        [Header("Optional references")]
        public GameObject glimpseVisualRoot;
        public ParticleSystem ghostAlienParticles;
        public AudioSource portalAudio;
        public Renderer portalRenderer;
        public string ruinMotif;
        public string ghostAlienLikeness;

        MaterialPropertyBlock _block;

        void Awake()
        {
            _block = new MaterialPropertyBlock();
        }

        public void Configure(string motif, string likeness)
        {
            ruinMotif = motif;
            ghostAlienLikeness = likeness;
        }

        public void SetReveal(float amount)
        {
            revealAmount = Mathf.Clamp01(amount);
            if (glimpseVisualRoot != null)
                glimpseVisualRoot.SetActive(revealAmount > 0.05f);
            if (portalAudio != null)
                portalAudio.volume = revealAmount * 0.65f;
            if (ghostAlienParticles != null)
            {
                var emission = ghostAlienParticles.emission;
                emission.rateOverTime = 3f + revealAmount * 18f;
            }
            UpdateMaterial();
        }

        public void SetStability(float value)
        {
            stability = Mathf.Clamp01(value);
            UpdateMaterial();
        }

        public void ActivateThreshold()
        {
            isActiveThreshold = true;
            SetReveal(1f);
            SetStability(1f);
        }

        void UpdateMaterial()
        {
            if (portalRenderer == null) return;
            portalRenderer.GetPropertyBlock(_block);
            _block.SetFloat("_RevealAmount", revealAmount);
            _block.SetFloat("_Stability", stability);
            _block.SetFloat("_GhostAlienPresence", revealAmount * Mathf.Lerp(0.3f, 1f, stability));
            portalRenderer.SetPropertyBlock(_block);
        }
    }
}
