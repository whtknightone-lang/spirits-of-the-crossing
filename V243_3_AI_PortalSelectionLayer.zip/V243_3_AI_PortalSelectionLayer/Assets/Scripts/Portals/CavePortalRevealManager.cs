using System.Collections.Generic;
using UnityEngine;
using V243.CaveDemo.AI;

namespace V243.CaveDemo.Portals
{
    public class CavePortalRevealManager : MonoBehaviour
    {
        public ResonancePortalInterpreter interpreter;
        public List<GlimpsePortalController> portals = new List<GlimpsePortalController>();

        [Header("AI blending")]
        [Range(0f, 1f)] public float aiVisualBoost = 0.15f;

        [ContextMenu("Refresh Portal Reveals")]
        public void RefreshPortalReveals()
        {
            if (interpreter == null) return;

            foreach (var portal in portals)
            {
                if (portal == null) continue;

                float reveal = 0.06f;
                float stability = 0.12f;

                if (portal.portalType == interpreter.currentPortal)
                {
                    reveal = 0.88f;
                    stability = 0.82f;
                }
                else if (portal.portalType == interpreter.achievablePortal)
                {
                    reveal = 0.56f;
                    stability = 0.48f;
                }
                else if (portal.portalType == interpreter.challengePortal)
                {
                    reveal = 0.4f;
                    stability = 0.26f;
                }

                if (interpreter.aiParticipation != null)
                {
                    float aiBoost = interpreter.aiParticipation.GetAIBoostForPortal(portal.portalType) * aiVisualBoost;
                    reveal += aiBoost;
                    stability += aiBoost * 0.5f;
                }

                var profile = interpreter.GetProfile(portal.portalType);
                if (profile != null)
                    portal.Configure(profile.ruinMotif, profile.ghostAlienLikeness);

                portal.SetReveal(reveal);
                portal.SetStability(stability);
            }
        }

        public void CommitToCurrentPortal()
        {
            foreach (var portal in portals)
            {
                if (portal != null && portal.portalType == interpreter.currentPortal)
                    portal.ActivateThreshold();
            }
        }
    }
}
