using System.Collections.Generic;
using UnityEngine;
using V243.CaveDemo.AI;
using V243.CaveDemo.Portals;

namespace V243.CaveDemo
{
    public class ResonancePortalInterpreter : MonoBehaviour
    {
        [Header("Inputs")]
        public PortalProfileLoader profileLoader;
        public PlayerResponseSample sample = new PlayerResponseSample();
        public AICaveParticipationController aiParticipation;

        [Header("Outputs")]
        public List<ResonancePortalProfile> portalProfiles = new List<ResonancePortalProfile>();
        public ResonancePortalType currentPortal;
        public ResonancePortalType achievablePortal;
        public ResonancePortalType challengePortal;
        public List<PortalScoreResult> lastScores = new List<PortalScoreResult>();

        void Awake()
        {
            if (profileLoader != null)
            {
                var collection = profileLoader.LoadProfiles();
                portalProfiles = collection.portals;
            }
        }

        [ContextMenu("Evaluate Portals")]
        public void EvaluatePortals()
        {
            if (portalProfiles == null || portalProfiles.Count == 0)
                return;

            if (aiParticipation != null)
                aiParticipation.EvaluateAI(sample);

            lastScores.Clear();
            foreach (var p in portalProfiles)
            {
                float playerScore =
                    sample.stillnessScore * p.stillnessWeight +
                    sample.flowScore * p.flowWeight +
                    sample.spinScore * p.spinWeight +
                    sample.pairSyncScore * p.pairWeight +
                    sample.calmScore * p.calmWeight +
                    sample.joyScore * p.joyWeight +
                    sample.wonderScore * p.wonderWeight +
                    sample.sourceAlignmentScore * p.sourceWeight -
                    sample.distortionScore * p.distortionPenalty;

                float aiBoost = aiParticipation != null ? aiParticipation.GetAIBoostForPortal(p.portalType) * p.aiPreferenceWeight : 0f;
                float score = playerScore + aiBoost;

                if (aiParticipation != null && aiParticipation.aiPreferredPortal == p.portalType)
                    score += aiParticipation.aiConsensus * 0.2f;

                if (aiParticipation != null && aiParticipation.aiChallengePortal == p.portalType)
                    score += aiParticipation.aiSourcePressure * 0.08f;

                lastScores.Add(new PortalScoreResult { portalType = p.portalType, score = score });
            }

            lastScores.Sort((a, b) => b.score.CompareTo(a.score));
            currentPortal = lastScores[0].portalType;
            achievablePortal = lastScores.Count > 1 ? lastScores[1].portalType : currentPortal;
            challengePortal = lastScores.Count > 2 ? lastScores[2].portalType : achievablePortal;
        }

        public ResonancePortalProfile GetProfile(ResonancePortalType portalType)
        {
            return portalProfiles.Find(p => p.portalType == portalType);
        }
    }
}
