using System.IO;
using UnityEngine;
using V243.CaveDemo.AI;

namespace V243.CaveDemo.Portals
{
    public class PortalProfileLoader : MonoBehaviour
    {
        public string fileName = "portal_profiles_ai.json";
        public PortalProfileCollection loadedProfiles;

        public PortalProfileCollection LoadProfiles()
        {
            string path = Path.Combine(Application.streamingAssetsPath, fileName);
            if (!File.Exists(path))
            {
                Debug.LogWarning($"Portal profile file not found: {path}");
                loadedProfiles = new PortalProfileCollection();
                return loadedProfiles;
            }

            string json = File.ReadAllText(path);
            loadedProfiles = JsonUtility.FromJson<PortalProfileCollection>(json);
            if (loadedProfiles == null)
                loadedProfiles = new PortalProfileCollection();
            return loadedProfiles;
        }
    }
}
