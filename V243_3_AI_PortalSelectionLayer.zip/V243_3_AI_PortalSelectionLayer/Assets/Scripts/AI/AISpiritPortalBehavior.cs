using UnityEngine;

namespace V243.CaveDemo.AI
{
    public class AISpiritPortalBehavior : MonoBehaviour
    {
        public AIResonanceAgent agent;
        public AICaveParticipationController participation;
        public Animator animator;

        [Header("Output values")]
        [Range(0f, 1f)] public float emergeIntensity;
        [Range(0f, 1f)] public float driftIntensity;
        public ResonancePortalType favoredPortal;

        void Update()
        {
            if (agent == null || participation == null)
                return;

            favoredPortal = participation.aiPreferredPortal;
            emergeIntensity = Mathf.Clamp01(agent.agreementWithPlayer * 0.5f + agent.sourceResponse * 0.5f);
            driftIntensity = Mathf.Clamp01(1f - agent.agreementWithPlayer);

            if (animator != null)
            {
                animator.SetFloat("EmergeIntensity", emergeIntensity);
                animator.SetFloat("DriftIntensity", driftIntensity);
                animator.SetInteger("FavoredPortal", (int)favoredPortal);
                animator.SetBool("MoveToCenterDisk", emergeIntensity > 0.55f);
            }
        }
    }
}
