using System;
using System.Collections.Generic;
using UnityEngine;

namespace V243.CaveDemo.AI
{
    public enum AIArchetype
    {
        CompanionSpirit,
        MachineWitness,
        RuinGhostAlien,
        SourceEcho,
        PlanetaryScout
    }

    public enum ResonancePortalType
    {
        FireMilitary,
        OceanSurf,
        ForestCalm,
        SourceEnergyWells,
        AirDancing
    }

    [Serializable]
    public class PortalScoreResult
    {
        public ResonancePortalType portalType;
        public float score;
    }

    [Serializable]
    public class PlayerResponseSample
    {
        [Range(0f, 1f)] public float stillnessScore;
        [Range(0f, 1f)] public float flowScore;
        [Range(0f, 1f)] public float spinScore;
        [Range(0f, 1f)] public float pairSyncScore;
        [Range(0f, 1f)] public float calmScore;
        [Range(0f, 1f)] public float joyScore;
        [Range(0f, 1f)] public float wonderScore;
        [Range(0f, 1f)] public float distortionScore;
        [Range(0f, 1f)] public float sourceAlignmentScore;
    }

    [Serializable]
    public class ResonancePortalProfile
    {
        public ResonancePortalType portalType;
        public string displayName;
        public string ruinMotif;
        public string ghostAlienLikeness;
        public string sigilId;
        public string audioState;
        public string particleState;
        public float stillnessWeight;
        public float flowWeight;
        public float spinWeight;
        public float pairWeight;
        public float calmWeight;
        public float joyWeight;
        public float wonderWeight;
        public float sourceWeight;
        public float aiPreferenceWeight;
        public float distortionPenalty;
    }

    [Serializable]
    public class PortalProfileCollection
    {
        public List<ResonancePortalProfile> portals = new List<ResonancePortalProfile>();
    }
}
