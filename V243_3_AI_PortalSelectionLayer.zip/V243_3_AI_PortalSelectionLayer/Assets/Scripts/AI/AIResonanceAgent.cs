using UnityEngine;

namespace V243.CaveDemo.AI
{
    public class AIResonanceAgent : MonoBehaviour
    {
        [Header("Identity")]
        public string agentId = "ai_001";
        public AIArchetype archetype = AIArchetype.CompanionSpirit;

        [Header("Baseline resonance")]
        [Range(0f, 1f)] public float fireAffinity = 0.2f;
        [Range(0f, 1f)] public float oceanAffinity = 0.2f;
        [Range(0f, 1f)] public float forestAffinity = 0.2f;
        [Range(0f, 1f)] public float sourceAffinity = 0.2f;
        [Range(0f, 1f)] public float airAffinity = 0.2f;

        [Header("Social behavior")]
        [Range(0f, 1f)] public float mimicryStrength = 0.5f;
        [Range(0f, 1f)] public float sourceBias = 0.4f;
        [Range(0f, 1f)] public float challengeBias = 0.2f;
        [Range(0f, 1f)] public float contributionWeight = 0.7f;

        [Header("Runtime")]
        public ResonancePortalType currentPortalLean = ResonancePortalType.ForestCalm;
        [Range(0f, 1f)] public float agreementWithPlayer = 0.5f;
        [Range(0f, 1f)] public float sourceResponse = 0.5f;

        public float GetPortalAffinity(ResonancePortalType portalType)
        {
            switch (portalType)
            {
                case ResonancePortalType.FireMilitary: return fireAffinity;
                case ResonancePortalType.OceanSurf: return oceanAffinity;
                case ResonancePortalType.ForestCalm: return forestAffinity;
                case ResonancePortalType.SourceEnergyWells: return sourceAffinity;
                case ResonancePortalType.AirDancing: return airAffinity;
                default: return 0f;
            }
        }

        public void UpdateFromPlayer(PlayerResponseSample sample, ResonancePortalType playerPortal)
        {
            currentPortalLean = playerPortal;

            float targetAgreement = 0.25f + sample.pairSyncScore * 0.35f + sample.sourceAlignmentScore * 0.25f;
            agreementWithPlayer = Mathf.Lerp(agreementWithPlayer, Mathf.Clamp01(targetAgreement), Time.deltaTime * 1.5f);

            float sourceTarget = (sample.wonderScore + sample.sourceAlignmentScore + sourceBias) / 3f;
            sourceResponse = Mathf.Lerp(sourceResponse, Mathf.Clamp01(sourceTarget), Time.deltaTime * 1.25f);
        }

        public float EvaluateContribution(ResonancePortalType portalType)
        {
            float baseAffinity = GetPortalAffinity(portalType);
            float leanBoost = currentPortalLean == portalType ? 0.25f : 0f;
            float sourceBoost = portalType == ResonancePortalType.SourceEnergyWells ? sourceResponse * sourceBias : 0f;
            float challengeBoost = portalType == ResonancePortalType.FireMilitary ? challengeBias * 0.15f : 0f;
            float total = (baseAffinity + leanBoost + sourceBoost + challengeBoost) * contributionWeight;
            return Mathf.Clamp01(total * Mathf.Lerp(0.7f, 1.15f, agreementWithPlayer));
        }
    }
}
