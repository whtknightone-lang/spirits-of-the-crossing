using System.Collections.Generic;
using UnityEngine;

namespace V243.CaveDemo.AI
{
    public class AICaveParticipationController : MonoBehaviour
    {
        [Header("References")]
        public ResonancePortalInterpreter portalInterpreter;
        public List<AIResonanceAgent> activeAgents = new List<AIResonanceAgent>();

        [Header("Group outputs")]
        public ResonancePortalType aiPreferredPortal;
        public ResonancePortalType aiChallengePortal;
        [Range(0f, 1f)] public float aiConsensus;
        [Range(0f, 1f)] public float aiSourcePressure;

        readonly Dictionary<ResonancePortalType, float> _aiScores = new Dictionary<ResonancePortalType, float>();

        public void RegisterAgent(AIResonanceAgent agent)
        {
            if (agent != null && !activeAgents.Contains(agent))
                activeAgents.Add(agent);
        }

        public void UnregisterAgent(AIResonanceAgent agent)
        {
            if (agent != null)
                activeAgents.Remove(agent);
        }

        public void EvaluateAI(PlayerResponseSample playerSample)
        {
            if (portalInterpreter == null)
                return;

            foreach (ResonancePortalType type in System.Enum.GetValues(typeof(ResonancePortalType)))
                _aiScores[type] = 0f;

            foreach (var agent in activeAgents)
            {
                if (agent == null) continue;
                agent.UpdateFromPlayer(playerSample, portalInterpreter.currentPortal);

                foreach (ResonancePortalType type in System.Enum.GetValues(typeof(ResonancePortalType)))
                    _aiScores[type] += agent.EvaluateContribution(type);
            }

            float best = float.MinValue;
            float second = float.MinValue;
            ResonancePortalType bestType = ResonancePortalType.ForestCalm;
            ResonancePortalType secondType = ResonancePortalType.SourceEnergyWells;

            foreach (var kv in _aiScores)
            {
                if (kv.Value > best)
                {
                    second = best;
                    secondType = bestType;
                    best = kv.Value;
                    bestType = kv.Key;
                }
                else if (kv.Value > second)
                {
                    second = kv.Value;
                    secondType = kv.Key;
                }
            }

            aiPreferredPortal = bestType;
            aiChallengePortal = secondType;

            float agentCount = Mathf.Max(1, activeAgents.Count);
            aiConsensus = Mathf.Clamp01(best / agentCount);

            float sourceTotal = 0f;
            foreach (var agent in activeAgents)
                if (agent != null) sourceTotal += agent.sourceResponse;
            aiSourcePressure = Mathf.Clamp01(sourceTotal / agentCount);
        }

        public float GetAIBoostForPortal(ResonancePortalType portalType)
        {
            if (!_aiScores.ContainsKey(portalType) || activeAgents.Count == 0)
                return 0f;

            return Mathf.Clamp01(_aiScores[portalType] / activeAgents.Count);
        }
    }
}
