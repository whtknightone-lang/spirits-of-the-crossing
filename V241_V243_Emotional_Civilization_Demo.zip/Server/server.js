
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8083 });

wss.on('connection', ws => {
  ws.on('message', msg => {
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(msg);
      }
    });
  });
});

console.log("Emotional multiplayer demo server running on 8083");
