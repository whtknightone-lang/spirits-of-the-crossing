
using UnityEngine;

public class EmotionalCivilization : MonoBehaviour
{
    public float collectiveJoy;
    public float collectiveFear;

    public string GetCulture()
    {
        if (collectiveJoy > collectiveFear) return "Harmonic Culture";
        if (collectiveFear > collectiveJoy) return "Survival Culture";
        return "Balanced Culture";
    }
}
