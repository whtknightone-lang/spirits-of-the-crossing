
using UnityEngine;

public class EmotionalDemoWorld : MonoBehaviour
{
    public EmotionalDemoPlayer player;
    public Camera cam;

    void Update()
    {
        float blend = player.joy - player.fear + 0.5f;
        cam.backgroundColor = Color.Lerp(Color.red, Color.cyan, blend);
    }
}
