
using UnityEngine;

public class EmotionalDemoPlayer : MonoBehaviour
{
    public float joy = 0.5f;
    public float fear = 0.3f;

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        transform.Translate(new Vector3(h,0,v)*5f*Time.deltaTime);

        if(Input.GetKeyDown(KeyCode.UpArrow)) joy += 0.1f;
        if(Input.GetKeyDown(KeyCode.DownArrow)) fear += 0.1f;
    }
}
