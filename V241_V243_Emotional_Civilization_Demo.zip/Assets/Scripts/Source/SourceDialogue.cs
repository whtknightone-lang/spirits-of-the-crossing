
using UnityEngine;

public class SourceDialogue : MonoBehaviour
{
    public float receptivity;

    public string GetMessage()
    {
        if (receptivity > 0.7f) return "Move toward harmony";
        if (receptivity > 0.3f) return "Observe and choose";
        return "Explore freely";
    }
}
