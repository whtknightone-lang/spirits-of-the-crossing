
using UnityEngine;

public class EmotionalConflict : MonoBehaviour
{
    public float tension;

    public string Resolve()
    {
        if (tension > 0.7f) return "Break / Split";
        if (tension > 0.4f) return "Transform";
        return "Stable";
    }
}
