
import pygame, numpy as np
from systems.resonance_memory import ResonanceMemorySystem
from systems.player_body import PlayerBody
from systems.agent_world import AgentWorld
from systems.species_system import SpeciesSystem
from systems.sensory_system import SensorySystem

class V52Engine:
    def __init__(self,size,device):
        self.size=size
        self.device=device

        self.memory=ResonanceMemorySystem(size,device)
        self.player=PlayerBody(size,device)
        self.world=AgentWorld(size,device,120)

        self.species=SpeciesSystem(size)
        self.senses=SensorySystem(size,device)

        self.font=pygame.font.SysFont("arial",16)

    def handle_key(self,key):
        if key==pygame.K_e:
            self.player.emit_expression_burst(self.memory.now_field)

    def handle_input(self,dt):
        self.player.handle_movement(pygame.key.get_pressed(),dt)

    def update(self,dt):
        self.memory.update(dt,
            self.world.aggregate_world_emotion(),
            self.player.resonance_mean()
        )

        self.player.update(dt,self.memory.now_field,self.memory.potential_field)
        self.world.update(dt,self.memory.now_field,self.memory.potential_field,self.player)

        self.species.update(self.memory)
        self.senses.update(self.player,self.world,self.species)

        self.memory.clamp_all()

    def render(self,screen):
        screen.fill((10,10,20))

        arr=self.memory.now_field.detach().cpu().numpy()
        arr=(arr-arr.min())/(arr.max()+1e-5)
        img=np.stack([arr*255,arr*200,255-arr*150],axis=-1).astype("uint8")

        surf=pygame.surfarray.make_surface(np.transpose(img,(1,0,2)))
        surf=pygame.transform.scale(surf,(700,700))
        screen.blit(surf,(40,40))

        scale=700/self.size

        # draw species (animals)
        for a in self.species.animals:
            x=int(a["pos"][1]*scale)+40
            y=int(a["pos"][0]*scale)+40
            color=(100,200,100) if a["type"]=="herbivore" else (200,100,100)
            pygame.draw.circle(screen,color,(x,y),3)

        # draw player
        px,py=self.player.grid_position()
        pygame.draw.circle(screen,(255,255,255),(int(py*scale)+40,int(px*scale)+40),6)

        # UI
        y=760
        lines=[
            "V52 Species + Sensory System",
            f"Smell: {self.senses.smell:.3f}",
            f"Hearing: {self.senses.hearing:.3f}",
            f"Touch: {self.senses.touch:.3f}",
            f"Taste: {self.senses.taste:.3f}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
