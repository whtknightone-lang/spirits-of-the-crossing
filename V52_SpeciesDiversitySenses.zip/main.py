
import pygame, torch
from engine.v52_engine import V52Engine

pygame.init()
screen = pygame.display.set_mode((1500, 960))
clock = pygame.time.Clock()

engine = V52Engine(128, "cuda" if torch.cuda.is_available() else "cpu")

running = True
while running:
    dt = clock.tick(60)/1000.0
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
        elif e.type == pygame.KEYDOWN:
            engine.handle_key(e.key)

    engine.handle_input(dt)
    engine.update(dt)
    engine.render(screen)
    pygame.display.flip()

pygame.quit()
