
# V52 Species Diversity + Sensory System

Adds:
- animals (predators + herbivores)
- sensory perception system (smell, hearing, touch, taste)
- new learning inputs from environment

Future:
- ecosystems
- food chains
- adaptive evolution
