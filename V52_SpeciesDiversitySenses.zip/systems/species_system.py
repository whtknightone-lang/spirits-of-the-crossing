
import random

class SpeciesSystem:
    def __init__(self,size):
        self.size=size
        self.animals=[{
            "pos":[random.random()*size,random.random()*size],
            "type": random.choice(["herbivore","predator"])
        } for _ in range(80)]

    def update(self,memory):
        for a in self.animals:
            a["pos"][0]+=random.uniform(-1,1)*0.5
            a["pos"][1]+=random.uniform(-1,1)*0.5
