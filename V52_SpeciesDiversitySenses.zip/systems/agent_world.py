
import torch
class AgentWorld:
    def __init__(self,size,device,n):
        self.size=size
        self.device=device
        self.agents=[]

    def update(self,dt,now,potential,player): pass

    def aggregate_world_emotion(self):
        return torch.zeros((self.size,self.size))
