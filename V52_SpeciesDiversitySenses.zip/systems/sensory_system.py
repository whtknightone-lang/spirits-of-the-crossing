
import math

class SensorySystem:
    def __init__(self,size,device):
        self.smell=0.0
        self.hearing=0.0
        self.touch=0.0
        self.taste=0.0

    def update(self,player,world,species):
        px,py=player.grid_position()

        smell=0
        hearing=0
        touch=0

        for a in species.animals:
            dx=px-a["pos"][0]
            dy=py-a["pos"][1]
            d=math.sqrt(dx*dx+dy*dy)

            if d<10: smell+=1
            if d<5: hearing+=1
            if d<2: touch+=1

        self.smell=min(1.0,smell/10)
        self.hearing=min(1.0,hearing/10)
        self.touch=min(1.0,touch/5)
        self.taste=self.touch*0.5
