
import torch, pygame
class PlayerBody:
    def __init__(self,size,device):
        self.size=size
        self.device=device
        self.pos=torch.tensor([size/2,size/2],device=device)

    def handle_movement(self,keys,dt):
        if keys[pygame.K_w]: self.pos[0]-=20*dt
        if keys[pygame.K_s]: self.pos[0]+=20*dt
        if keys[pygame.K_a]: self.pos[1]-=20*dt
        if keys[pygame.K_d]: self.pos[1]+=20*dt
        self.pos=torch.clamp(self.pos,0,self.size-1)

    def update(self,dt,now,potential): pass

    def emit_expression_burst(self,field):
        x,y=self.grid_position()
        field[x,y]+=0.2

    def grid_position(self):
        return int(self.pos[0].item()),int(self.pos[1].item())

    def resonance_mean(self):
        return 0.0
