
using UnityEngine;
using ArtificialUniverse.Civilization;

namespace ArtificialUniverse.Scenarios
{
    public class ScenarioSystem : MonoBehaviour
    {
        public enum ScenarioType { GoldenAge, Collapse, Balance }

        public ScenarioType current;

        private CivilizationSystem civ;

        void Awake()
        {
            civ = FindObjectOfType<CivilizationSystem>();
        }

        public void ApplyScenario(ScenarioType type)
        {
            current = type;

            if (civ == null) return;

            switch (type)
            {
                case ScenarioType.GoldenAge:
                    civ.harmony = 0.8f;
                    civ.conflict = 0.1f;
                    break;

                case ScenarioType.Collapse:
                    civ.harmony = 0.2f;
                    civ.conflict = 0.8f;
                    break;

                case ScenarioType.Balance:
                    civ.harmony = 0.5f;
                    civ.conflict = 0.5f;
                    break;
            }
        }
    }
