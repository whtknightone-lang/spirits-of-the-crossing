
using UnityEngine;
using ArtificialUniverse.Adaptive;
using ArtificialUniverse.Scenarios;
using ArtificialUniverse.Missions;

namespace ArtificialUniverse.Core
{
    public class V123IntegrationManager : MonoBehaviour
    {
        void Start()
        {
            if (FindObjectOfType<AdaptiveUniverseSystem>() == null)
                gameObject.AddComponent<AdaptiveUniverseSystem>();

            if (FindObjectOfType<ScenarioSystem>() == null)
                gameObject.AddComponent<ScenarioSystem>();

            if (FindObjectOfType<MissionSystem>() == null)
                gameObject.AddComponent<MissionSystem>();

            if (FindObjectOfType<ArtificialUniverse.UI.MissionUI>() == null)
                gameObject.AddComponent<ArtificialUniverse.UI.MissionUI>();
        }
    }
