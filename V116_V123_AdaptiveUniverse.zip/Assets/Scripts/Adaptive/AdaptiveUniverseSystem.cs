
using UnityEngine;
using ArtificialUniverse.Civilization;

namespace ArtificialUniverse.Adaptive
{
    public class AdaptiveUniverseSystem : MonoBehaviour
    {
        private CivilizationSystem civ;

        public float playerInfluence;

        void Awake()
        {
            civ = FindObjectOfType<CivilizationSystem>();
        }

        void Update()
        {
            if (civ == null) return;

            playerInfluence = civ.harmony - civ.conflict;

            // adapt difficulty
            civ.conflict = Mathf.Clamp01(civ.conflict + (0.5f - playerInfluence) * 0.01f);
            civ.harmony = Mathf.Clamp01(civ.harmony + playerInfluence * 0.01f);
        }
    }
