
using UnityEngine;
using ArtificialUniverse.Civilization;

namespace ArtificialUniverse.Missions
{
    public class MissionSystem : MonoBehaviour
    {
        public string currentMission = "Grow population to 100";
        public bool completed;

        private CivilizationSystem civ;

        void Awake()
        {
            civ = FindObjectOfType<CivilizationSystem>();
        }

        void Update()
        {
            if (civ == null) return;

            if (!completed && civ.population > 100)
            {
                completed = true;
                Debug.Log("Mission Complete!");
            }
        }
    }
