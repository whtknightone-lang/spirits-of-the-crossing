
using UnityEngine;
using ArtificialUniverse.Missions;

namespace ArtificialUniverse.UI
{
    public class MissionUI : MonoBehaviour
    {
        private MissionSystem mission;

        void Awake()
        {
            mission = FindObjectOfType<MissionSystem>();
        }

        void OnGUI()
        {
            if (mission == null) return;

            GUI.Label(new Rect(20,450,400,25),"=== MISSION ===");
            GUI.Label(new Rect(20,470,400,25), mission.currentMission);

            if (mission.completed)
                GUI.Label(new Rect(20,500,400,25),"Status: COMPLETE");
        }
    }
