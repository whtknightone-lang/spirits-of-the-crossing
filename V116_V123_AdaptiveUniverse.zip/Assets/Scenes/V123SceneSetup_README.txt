
Scene Setup:

1. Ensure previous systems exist (V114 + V115)

2. Add:
   - AdaptiveUniverseSystem
   - ScenarioSystem
   - MissionSystem
   - MissionUI
   - V123IntegrationManager

3. Optional:
   Call ScenarioSystem.ApplyScenario() from UI buttons

You now have:
- adaptive difficulty
- scenario presets
- mission objectives
