
# V116–V123 Adaptive Universe

Adds:
- Adaptive universe (responds to player behavior)
- Scenario presets (golden age, collapse, balance)
- Mission system (objectives + progression)

This layer turns the simulation into a directed playable experience.
