
from engine.snowflake.brain_3d import SnowflakeBrain3D

class DemoAgent:

    def __init__(self):
        self.brain = SnowflakeBrain3D()

    def step(self):
        self.brain.step()
