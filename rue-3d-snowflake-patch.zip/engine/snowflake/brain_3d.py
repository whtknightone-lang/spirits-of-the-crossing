
import numpy as np

class SnowflakeBrain3D:

    def __init__(self, n_nodes=21):
        self.n = n_nodes
        self.phases = np.random.rand(self.n) * 2 * np.pi

        # positions on sphere
        pos = np.random.randn(self.n, 3)
        pos /= np.linalg.norm(pos, axis=1)[:, None]
        self.positions = pos

        # adjacency (simple sparse)
        self.matrix = self._build_matrix()

        # outer layer (upsilon)
        self.outer = list(range(7, self.n))

    def _build_matrix(self):
        K = np.zeros((self.n, self.n))
        def connect(a,b,w):
            K[a,b]=w
            K[b,a]=w

        for i in range(1,7):
            connect(0,i,1.0)

        inner = [1,2,3,4,5,6]
        for i in range(6):
            connect(inner[i], inner[(i+1)%6],0.6)

        for i in range(7,self.n):
            connect(i, (i+1-7)% (self.n-7)+7,0.3)

        return K

    def step(self, drive=0.0):

        diff = self.phases[:,None] - self.phases[None,:]

        dist = np.linalg.norm(
            self.positions[:,None,:] - self.positions[None,:,:],
            axis=2
        )

        coupling = np.sin(diff) * self.matrix / (1 + dist)

        velocity = coupling.sum(axis=1)

        # outer layer faster
        velocity[self.outer] *= 1.3

        velocity *= 0.04
        velocity += drive
        velocity = np.clip(velocity,-0.18,0.18)

        self.phases += velocity
        self.phases = np.mod(self.phases, 2*np.pi)
