
import numpy as np
import matplotlib.pyplot as plt
from engine.agents.demo_agent import DemoAgent

agent = DemoAgent()

plt.ion()
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

for step in range(1000):

    agent.step()

    ax.clear()

    pos = agent.brain.positions
    colors = agent.brain.phases / (2*np.pi)

    ax.scatter(pos[:,0], pos[:,1], pos[:,2], c=colors)

    ax.set_xlim([-1,1])
    ax.set_ylim([-1,1])
    ax.set_zlim([-1,1])

    plt.pause(0.01)

plt.ioff()
plt.show()
