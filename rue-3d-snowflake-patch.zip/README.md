
# RUE 3D Snowflake Brain Patch

This patch upgrades the Snowflake Brain to a **3D spherical structure** with:

- 3D node positions inside a sphere
- distance-based coupling
- faster-reacting outer (upsilon) layer
- stable bounded dynamics

## Key Features

- volumetric signal propagation
- faster outer-layer responsiveness
- stronger internal coherence
- improved clustering and learning

## Run Demo

```bash
pip install -r requirements.txt
python experiments/run_3d_brain_demo.py
```
