
V213 + V214 Aura + Path + Energy System

V213:
- Intermittent aura perception
- visual resonance fields around beings
- optional / not always visible

V214:
- possible future paths visualization
- non-dominance rule (no entity can control another)
- energy play without force

Core Idea:
Perception expands, but control is never imposed.
