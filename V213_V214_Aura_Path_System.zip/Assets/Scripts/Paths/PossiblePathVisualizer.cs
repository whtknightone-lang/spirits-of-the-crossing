
using UnityEngine;

public class PossiblePathVisualizer : MonoBehaviour
{
    public Transform[] possiblePoints;
    public LineRenderer line;

    void Update()
    {
        if (possiblePoints == null || line == null) return;

        line.positionCount = possiblePoints.Length;

        for (int i = 0; i < possiblePoints.Length; i++)
        {
            line.SetPosition(i, possiblePoints[i].position);
        }
    }
}
