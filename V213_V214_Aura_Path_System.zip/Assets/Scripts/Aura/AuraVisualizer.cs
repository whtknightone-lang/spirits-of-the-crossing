
using UnityEngine;

public class AuraVisualizer : MonoBehaviour
{
    public float resonance = 0.5f;
    public Renderer rend;
    public bool auraVisible;

    void Update()
    {
        // aura only appears intermittently
        auraVisible = Mathf.Sin(Time.time * 0.5f) > 0.8f;

        if (rend == null) return;

        if (auraVisible)
        {
            rend.enabled = true;
            rend.material.color = Color.Lerp(Color.red, Color.cyan, resonance);
        }
        else
        {
            rend.enabled = false;
        }
    }
}
