
using UnityEngine;

public class NonDominanceRule : MonoBehaviour
{
    public void Enforce(float influence)
    {
        // clamp influence so no entity can dominate
        float clamped = Mathf.Clamp(influence, -0.2f, 0.2f);
        Debug.Log("Influence limited to: " + clamped);
    }
}
