
using UnityEngine;

public class EnergyInteraction : MonoBehaviour
{
    public float energyLevel = 0.5f;

    void OnTriggerStay(Collider other)
    {
        EnergyInteraction otherEnergy = other.GetComponent<EnergyInteraction>();
        if (otherEnergy == null) return;

        float avg = (energyLevel + otherEnergy.energyLevel) * 0.5f;

        // share energy, no domination
        energyLevel = Mathf.Lerp(energyLevel, avg, Time.deltaTime);
    }
}
