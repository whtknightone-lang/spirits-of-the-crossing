
using UnityEngine;

public class AIInstructorBehavior : MonoBehaviour
{
    public AIArchetype archetype;

    void Update()
    {
        if (archetype == null) return;

        if (Input.GetKeyDown(KeyCode.T))
        {
            Debug.Log(archetype.Teach());
        }
    }
}
