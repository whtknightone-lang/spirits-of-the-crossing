
using UnityEngine;

public class DruidInstructor : AIArchetype
{
    void Awake() { archetypeName = "Druid"; }

    public override string Teach()
    {
        return "Listen to the forest. Growth follows harmony.";
    }
}
