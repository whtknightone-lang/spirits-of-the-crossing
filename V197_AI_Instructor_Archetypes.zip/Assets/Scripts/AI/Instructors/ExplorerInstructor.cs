
using UnityEngine;

public class ExplorerInstructor : AIArchetype
{
    void Awake() { archetypeName = "Explorer"; }

    public override string Teach()
    {
        return "Push forward. Strength reveals new paths.";
    }
}
