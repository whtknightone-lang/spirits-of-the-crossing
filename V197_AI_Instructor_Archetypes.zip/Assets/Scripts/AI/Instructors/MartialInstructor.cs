
using UnityEngine;

public class MartialInstructor : AIArchetype
{
    void Awake() { archetypeName = "Martial"; }

    public override string Teach()
    {
        return "Flow with precision. Strike with awareness.";
    }
}
