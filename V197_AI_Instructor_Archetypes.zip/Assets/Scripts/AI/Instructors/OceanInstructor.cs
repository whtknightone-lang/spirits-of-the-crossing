
using UnityEngine;

public class OceanInstructor : AIArchetype
{
    void Awake() { archetypeName = "Ocean"; }

    public override string Teach()
    {
        return "Breathe deep. The depths respond to calm.";
    }
}
