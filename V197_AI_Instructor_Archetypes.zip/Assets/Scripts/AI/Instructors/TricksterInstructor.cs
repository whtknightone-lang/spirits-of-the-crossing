
using UnityEngine;

public class TricksterInstructor : AIArchetype
{
    void Awake() { archetypeName = "Trickster"; }

    public override string Teach()
    {
        return "Not everything is as it seems... try again differently.";
    }
}
