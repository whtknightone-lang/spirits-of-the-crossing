
using UnityEngine;

public class AIArchetype : MonoBehaviour
{
    public string archetypeName;

    public virtual string Teach()
    {
        return "Observe and learn.";
    }
}
