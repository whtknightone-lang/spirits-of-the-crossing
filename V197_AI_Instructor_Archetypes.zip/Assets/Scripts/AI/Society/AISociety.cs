
using UnityEngine;
using System.Collections.Generic;

public class AISociety : MonoBehaviour
{
    public List<AIArchetype> members = new List<AIArchetype>();

    public string Collaborate()
    {
        if (members.Count == 0) return "...";

        return "Multiple intelligences are shaping this world together.";
    }
}
