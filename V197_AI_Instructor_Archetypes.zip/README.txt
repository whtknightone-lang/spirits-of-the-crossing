
V197 AI Instructor Archetypes + AI Society

Adds:
- AI-to-AI interaction layer
- Instructor archetypes (martial, druid, strength, oceanic, trickster)
- Teaching behaviors + learning loops
- AI society collaboration

Core Idea:
AI entities become teachers, each embodying a domain and guiding players differently.
