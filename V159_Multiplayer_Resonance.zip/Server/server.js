
const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8080 });

let players = [];

wss.on('connection', function connection(ws) {
    players.push({ ws, resonance: 0 });

    ws.on('message', function incoming(message) {
        try {
            const data = JSON.parse(message);
            const player = players.find(p => p.ws === ws);
            if (player) player.resonance = data.r;
        } catch(e){}
    });

    ws.on('close', () => {
        players = players.filter(p => p.ws !== ws);
    });
});

setInterval(() => {
    if (players.length === 0) return;

    let avg = players.reduce((a,p)=>a+p.resonance,0)/players.length;

    const worldState = JSON.stringify({ global_resonance: avg });

    players.forEach(p => {
        if (p.ws.readyState === WebSocket.OPEN)
            p.ws.send(worldState);
    });

}, 100);
