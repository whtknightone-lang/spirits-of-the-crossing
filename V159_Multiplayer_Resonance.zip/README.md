
# V159 Multiplayer Resonance (Client + Server Starter)

Includes:
- Unity client networking scaffold (WebSocket)
- Resonance sync model (state-based, not action-based)
- Node.js server starter (authoritative field + broadcast)
- Docs for wiring into V158 systems

Flow:
Client emits resonance state -> Server aggregates -> World state broadcast -> Clients feel/update
