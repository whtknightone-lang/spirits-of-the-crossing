
using UnityEngine;
using System.Net.WebSockets;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

public class WebSocketClient : MonoBehaviour
{
    private ClientWebSocket ws = new ClientWebSocket();
    public string serverUri = "ws://localhost:8080";

    async void Start()
    {
        await ws.ConnectAsync(new Uri(serverUri), CancellationToken.None);
        Debug.Log("Connected to server");
        ReceiveLoop();
    }

    async void ReceiveLoop()
    {
        var buffer = new byte[1024];

        while (ws.State == WebSocketState.Open)
        {
            var result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
            string msg = Encoding.UTF8.GetString(buffer, 0, result.Count);
            Debug.Log("Server: " + msg);
        }
    }

    public async void Send(string message)
    {
        if (ws.State != WebSocketState.Open) return;
        var bytes = Encoding.UTF8.GetBytes(message);
        await ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
    }
}
