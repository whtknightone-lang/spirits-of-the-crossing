
using UnityEngine;

public class ResonanceSender : MonoBehaviour
{
    public float resonance = 0.5f;
    private WebSocketClient client;

    void Awake()
    {
        client = FindObjectOfType<WebSocketClient>();
    }

    void Update()
    {
        resonance = Mathf.PingPong(Time.time * 0.2f, 1f);

        if (client != null)
        {
            string payload = JsonUtility.ToJson(new ResonancePayload { r = resonance });
            client.Send(payload);
        }
    }

    [System.Serializable]
    public class ResonancePayload
    {
        public float r;
    }
}
