# Next steps after V127 integration

## Immediate
1. Open the project in Unity 2022.3 LTS or newer.
2. Let Unity resolve packages from `Packages/manifest.json`.
3. Open `Assets/Scenes/EntranceCave_VR.unity`.
4. Add a `Bootstrap` GameObject and attach:
   - `OriginalGameConnectionBootstrap`
   - `V127CosmosBridge`
   - `V127NextStepsRuntimeMarker`
5. Wire references for player, resonance engine, source guidance, world response, planet node, and universe cycle.

## Vertical-slice completion
6. Add an XR Origin / OpenXR rig.
7. Add left/right hand visuals and hook them to glove/haptic placeholders.
8. Place a portal trigger at the cave threshold.
9. Add one spirit-guide NPC with a minimal idle / call / acknowledge state machine.
10. Add spatial audio emitters for Source pulse, world hum, and shadow false-signal.

## Cosmos tie-in
11. Create realm bands in `LikeFrequencyWorldMatcher`:
    - Forest
    - Ocean
    - Mountain
    - Machine
    - DarkPlanet
    - SourceRiver
12. Route portal exit to `CosmosMap.unity`.
13. On realm entry, record world match, worthiness, contrast, and manifestation to planet history.
14. Trigger `UniverseCycleDirector.RegisterEncounter(...)` at the end of each successful attunement.

## V128 target
15. Build `V128_Playable_EntranceToCosmos` with:
    - a playable cave room
    - one successful portal opening path
    - one false-signal path
    - one planet-growth writeback
    - one universe rebirth pulse event
    - one AI companion entering the same or a similar-frequency world