# How to build in Unity

1. Install Unity Hub.
2. Install Unity 2022.3 LTS or Unity 6 with Android/Windows/Mac modules as needed.
3. Open the `entrance_room_cave_vertical_integration` folder as a Unity project.
4. Allow package restore.
5. Open `Assets/Scenes/EntranceCave_VR.unity`.
6. Resolve any missing script references caused by placeholder scenes in this scaffold.
7. Open Build Settings and add:
   - `Assets/Scenes/EntranceCave_VR.unity`
   - `Assets/Scenes/CosmosMap.unity`
8. Choose target platform.
9. Build.

## Recommended first target
- PC VR via OpenXR

## Recommended editor settings
- Color Space: Linear
- Input Handling: Both or Input System Package
- Active Render Pipeline: URP