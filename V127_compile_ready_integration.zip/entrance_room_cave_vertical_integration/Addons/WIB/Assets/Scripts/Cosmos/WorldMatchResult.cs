namespace WIB.Cosmos
{
    public struct WorldMatchResult
    {
        public string worldId;
        public float matchScore;
        public float thoughtManifestPotential;
        public float likeFrequencyConfidence;
    }
}
