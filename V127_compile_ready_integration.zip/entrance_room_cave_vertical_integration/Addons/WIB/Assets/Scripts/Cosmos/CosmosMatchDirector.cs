using UnityEngine;
using WIB.Player;
using WIB.Source;

namespace WIB.Cosmos
{
    public class CosmosMatchDirector : MonoBehaviour
    {
        [SerializeField] private LikeFrequencyMatcher matcher;
        [SerializeField] private SourceSignalDirector sourceSignalDirector;
        [SerializeField] private PlanetGrowthController planetGrowthController;
        [SerializeField] private UniverseBirthRebirthController universeBirthRebirthController;
        [SerializeField] private PlayerResonanceProfile[] activePlayers;

        public void Initialize()
        {
            foreach (var player in activePlayers)
            {
                RoutePlayer(player);
            }
        }

        public void RoutePlayer(PlayerResonanceProfile player)
        {
            if (player == null || matcher == null) return;
            WorldMatchResult result = matcher.FindBestWorld(player);
            float sourcePull = sourceSignalDirector == null ? 0f : sourceSignalDirector.ComputeSourcePull(player);

            Debug.Log($"Routing {player.playerId} to {result.worldId} | match={result.matchScore:F2} manifest={result.thoughtManifestPotential:F2} source={sourcePull:F2}");

            if (planetGrowthController != null)
                planetGrowthController.RegisterPlayerWorldMatch(player, result, sourcePull);

            if (universeBirthRebirthController != null)
                universeBirthRebirthController.RecordThoughtRouting(player, result);
        }
    }
}
