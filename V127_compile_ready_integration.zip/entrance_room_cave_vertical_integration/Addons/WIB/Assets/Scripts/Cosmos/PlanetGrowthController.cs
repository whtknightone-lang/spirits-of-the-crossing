using System.Collections.Generic;
using UnityEngine;
using WIB.Player;

namespace WIB.Cosmos
{
    public class PlanetGrowthController : MonoBehaviour
    {
        private readonly Dictionary<string, float> worldGrowth = new();

        public void RegisterPlayerWorldMatch(PlayerResonanceProfile player, WorldMatchResult result, float sourcePull)
        {
            float contribution = result.matchScore * 0.5f + result.thoughtManifestPotential * 0.3f + sourcePull * 0.2f;
            if (!worldGrowth.ContainsKey(result.worldId)) worldGrowth[result.worldId] = 0f;
            worldGrowth[result.worldId] += contribution;
            Debug.Log($"Planet/world {result.worldId} growth += {contribution:F2}");
        }
    }
}
