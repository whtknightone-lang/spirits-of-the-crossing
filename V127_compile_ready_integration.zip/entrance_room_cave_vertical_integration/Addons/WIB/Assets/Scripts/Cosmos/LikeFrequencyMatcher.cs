using System.Collections.Generic;
using UnityEngine;
using WIB.Player;
using WIB.World;

namespace WIB.Cosmos
{
    public class LikeFrequencyMatcher : MonoBehaviour
    {
        [SerializeField] private List<WorldResponseProfile> availableWorlds = new();

        public WorldMatchResult FindBestWorld(PlayerResonanceProfile profile)
        {
            WorldMatchResult best = default;
            float bestScore = float.MinValue;

            foreach (var world in availableWorlds)
            {
                float score = Score(profile, world);
                if (score > bestScore)
                {
                    bestScore = score;
                    best = new WorldMatchResult
                    {
                        worldId = world.worldId,
                        matchScore = score,
                        thoughtManifestPotential = ComputeManifestPotential(profile, world),
                        likeFrequencyConfidence = Mathf.Clamp01(score)
                    };
                }
            }

            return best;
        }

        private float Score(PlayerResonanceProfile p, WorldResponseProfile w)
        {
            if (p == null || w == null) return 0f;
            float harmonicFit = 1f - Mathf.Abs(p.joy - w.joyBias);
            float curiosityFit = 1f - Mathf.Abs(p.curiosity - w.curiosityBias);
            float courageFit = 1f - Mathf.Abs(p.courage - w.courageBias);
            float sourceFit = (p.attunementToSource * w.sourcePermeability);
            return Mathf.Clamp01((harmonicFit * 0.35f) + (curiosityFit * 0.2f) + (courageFit * 0.2f) + (sourceFit * 0.15f) + (p.coherence * 0.1f));
        }

        private float ComputeManifestPotential(PlayerResonanceProfile p, WorldResponseProfile w)
        {
            var thought = p.GetDominantThought();
            float thoughtEnergy = thought == null ? 0f : (thought.intensity * 0.5f + thought.clarity * 0.25f + thought.joyCharge * 0.25f);
            return Mathf.Clamp01((thoughtEnergy * 0.5f) + (w.sourcePermeability * 0.25f) + (p.coherence * 0.25f));
        }
    }
}
