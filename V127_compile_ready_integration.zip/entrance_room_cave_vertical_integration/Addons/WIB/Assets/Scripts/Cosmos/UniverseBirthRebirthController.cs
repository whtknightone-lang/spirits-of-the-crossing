using System.Collections.Generic;
using UnityEngine;
using WIB.Player;

namespace WIB.Cosmos
{
    public class UniverseBirthRebirthController : MonoBehaviour
    {
        private readonly List<string> routingArchive = new();
        [Range(0f, 1f)] public float rebirthThreshold = 0.85f;

        public void RecordThoughtRouting(PlayerResonanceProfile player, WorldMatchResult result)
        {
            routingArchive.Add($"{player.playerId}:{result.worldId}:{result.matchScore:F2}");
        }

        public bool EvaluateRebirthReadiness(float collectiveCoherence)
        {
            return collectiveCoherence >= rebirthThreshold;
        }
    }
}
