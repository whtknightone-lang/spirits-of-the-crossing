using System.Collections.Generic;
using UnityEngine;
using WIB.Player;

namespace WIB.Networking
{
    public class ResonanceLobbyRouter : MonoBehaviour
    {
        public List<PlayerResonanceProfile> players = new();

        public List<List<PlayerResonanceProfile>> BuildLikeFrequencyGroups(float threshold = 0.8f)
        {
            List<List<PlayerResonanceProfile>> groups = new();
            HashSet<PlayerResonanceProfile> consumed = new();

            foreach (var p in players)
            {
                if (p == null || consumed.Contains(p)) continue;
                var group = new List<PlayerResonanceProfile> { p };
                consumed.Add(p);

                foreach (var q in players)
                {
                    if (q == null || consumed.Contains(q)) continue;
                    float similarity = ResonanceSimilarity(p, q);
                    if (similarity >= threshold)
                    {
                        group.Add(q);
                        consumed.Add(q);
                    }
                }
                groups.Add(group);
            }
            return groups;
        }

        private float ResonanceSimilarity(PlayerResonanceProfile a, PlayerResonanceProfile b)
        {
            Vector4 av = a.GetResonanceVector();
            Vector4 bv = b.GetResonanceVector();
            float dist = Vector4.Distance(av, bv) / 2f;
            return Mathf.Clamp01(1f - dist);
        }
    }
}
