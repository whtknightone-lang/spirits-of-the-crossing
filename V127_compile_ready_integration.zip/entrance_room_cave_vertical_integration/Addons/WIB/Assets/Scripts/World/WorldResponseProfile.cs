using UnityEngine;

namespace WIB.World
{
    [CreateAssetMenu(menuName = "WIB/World/Response Profile")]
    public class WorldResponseProfile : ScriptableObject
    {
        public string worldId;
        public string displayName;
        [Range(0f, 1f)] public float baseHarmony = 0.5f;
        [Range(0f, 1f)] public float contrast = 0.5f;
        [Range(0f, 1f)] public float joyBias = 0.5f;
        [Range(0f, 1f)] public float curiosityBias = 0.5f;
        [Range(0f, 1f)] public float courageBias = 0.5f;
        [Range(0f, 1f)] public float sourcePermeability = 0.5f;
    }
}
