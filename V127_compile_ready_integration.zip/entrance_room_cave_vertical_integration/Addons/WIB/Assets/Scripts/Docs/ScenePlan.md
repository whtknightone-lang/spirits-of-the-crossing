# Scene Plan

## 1. Bootstrap
Initializes Source, cosmos matching, and player routing.

## 2. EntranceCave_VR
First resonance chamber. Players begin hearing/feeling Source and reveal dominant thought patterns.

## 3. ResonanceLobby
Human and AI players are grouped by like-frequency bands.

## 4. CosmosMap
Displays realms/worlds and routes players into the best-fit world.

## 5. PlanetGrowthSandbox
Shows how player thoughts and resonance grow a world over time.

## 6. UniverseBirthRebirthChamber
Aggregates world growth and collective coherence into a birth/rebirth event.
