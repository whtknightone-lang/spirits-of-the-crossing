using UnityEngine;
using WIB.Player;

namespace WIB.UI
{
    public class WouldntItBeNiceIfHUD : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile observedPlayer;

        public string GetStatusText()
        {
            if (observedPlayer == null) return "No player";
            var thought = observedPlayer.GetDominantThought();
            string thoughtText = thought == null ? "None" : thought.label;
            return $"Player: {observedPlayer.playerId}\nThought: {thoughtText}\nJoy: {observedPlayer.joy:F2}\nCoherence: {observedPlayer.coherence:F2}";
        }
    }
}
