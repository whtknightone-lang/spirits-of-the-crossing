using UnityEngine;

namespace WIB.Source
{
    [CreateAssetMenu(menuName = "WIB/Source/Essence Profile")]
    public class SourceEssenceProfile : ScriptableObject
    {
        [Range(0f, 1f)] public float purity = 1f;
        [Range(0f, 1f)] public float joy = 1f;
        [Range(0f, 1f)] public float truth = 1f;
        [Range(0f, 1f)] public float compassion = 1f;

        public bool IsClearPureJoy()
        {
            return purity > 0.99f && joy > 0.99f && truth > 0.99f && compassion > 0.99f;
        }
    }
}
