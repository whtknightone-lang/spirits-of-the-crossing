using UnityEngine;
using WIB.Player;

namespace WIB.Source
{
    public class SourceSignalDirector : MonoBehaviour
    {
        [SerializeField] private SourceEssenceProfile essence;

        public void Initialize()
        {
            Debug.Log("SourceSignalDirector initialized.");
        }

        public float ComputeSourcePull(PlayerResonanceProfile profile)
        {
            if (profile == null || essence == null) return 0f;
            if (!essence.IsClearPureJoy()) return 0f;

            var thought = profile.GetDominantThought();
            float desireScore = thought == null ? 0f : thought.intensity * thought.clarity;
            return Mathf.Clamp01((profile.attunementToSource * 0.4f) + (profile.joy * 0.25f) + (profile.coherence * 0.2f) + (desireScore * 0.15f));
        }
    }
}
