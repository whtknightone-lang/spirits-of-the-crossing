using UnityEngine;

namespace WIB.Core
{
    public class RuntimeBootstrap : MonoBehaviour
    {
        [SerializeField] private WIB.Cosmos.CosmosMatchDirector cosmosMatchDirector;
        [SerializeField] private WIB.Source.SourceSignalDirector sourceSignalDirector;

        private void Start()
        {
            if (sourceSignalDirector != null) sourceSignalDirector.Initialize();
            if (cosmosMatchDirector != null) cosmosMatchDirector.Initialize();
        }
    }
}
