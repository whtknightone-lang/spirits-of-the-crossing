using UnityEngine;
using WIB.Player;

namespace WIB.AI
{
    public class AIPlayerResonanceBrain : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile profile;
        [Range(0f, 1f)] public float adaptationRate = 0.1f;

        private void Reset()
        {
            profile = GetComponent<PlayerResonanceProfile>();
        }

        public void TickAgainstWorld(float worldHarmony, float worldContrast)
        {
            if (profile == null) return;
            profile.coherence = Mathf.Clamp01(Mathf.Lerp(profile.coherence, worldHarmony, adaptationRate * Time.deltaTime));
            profile.curiosity = Mathf.Clamp01(profile.curiosity + (worldContrast * 0.05f * Time.deltaTime));
            profile.fear = Mathf.Clamp01(profile.fear + (worldContrast * 0.02f * Time.deltaTime) - (worldHarmony * 0.03f * Time.deltaTime));
        }
    }
}
