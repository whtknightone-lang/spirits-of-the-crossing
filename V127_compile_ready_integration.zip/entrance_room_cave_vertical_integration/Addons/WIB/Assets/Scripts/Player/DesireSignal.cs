using System;
using UnityEngine;

namespace WIB.Player
{
    [Serializable]
    public class DesireSignal
    {
        public string id;
        public string label;
        [Range(0f, 1f)] public float intensity = 0.5f;
        [Range(0f, 1f)] public float clarity = 0.5f;
        [Range(0f, 1f)] public float resistance = 0.5f;
        [Range(0f, 1f)] public float joyCharge = 0.5f;
        [Range(0f, 1f)] public float fearCharge = 0.5f;
    }
}
