using System.Collections.Generic;
using UnityEngine;

namespace WIB.Player
{
    public class PlayerResonanceProfile : MonoBehaviour
    {
        [Header("Identity")]
        public string playerId = "player";
        public bool isAIPlayer;

        [Header("Dynamic State")]
        [Range(0f, 1f)] public float coherence = 0.5f;
        [Range(0f, 1f)] public float joy = 0.5f;
        [Range(0f, 1f)] public float curiosity = 0.5f;
        [Range(0f, 1f)] public float courage = 0.5f;
        [Range(0f, 1f)] public float fear = 0.5f;
        [Range(0f, 1f)] public float openness = 0.5f;
        [Range(0f, 1f)] public float embodiment = 0.5f;
        [Range(0f, 1f)] public float attunementToSource = 0.5f;

        [Header("Thought / Desire Stream")]
        public List<DesireSignal> activeThoughts = new();

        public DesireSignal GetDominantThought()
        {
            DesireSignal best = null;
            float bestScore = float.MinValue;
            foreach (var thought in activeThoughts)
            {
                float score = thought.intensity * 0.45f + thought.clarity * 0.25f + thought.joyCharge * 0.15f - thought.resistance * 0.10f - thought.fearCharge * 0.05f;
                if (score > bestScore)
                {
                    best = thought;
                    bestScore = score;
                }
            }
            return best;
        }

        public Vector4 GetResonanceVector()
        {
            return new Vector4(coherence, joy, curiosity, courage);
        }
    }
}
