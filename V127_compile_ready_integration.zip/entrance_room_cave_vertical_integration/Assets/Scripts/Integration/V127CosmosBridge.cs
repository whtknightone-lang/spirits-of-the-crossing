using UnityEngine;
using Resonance.Connections;
using Resonance.Cosmos;
using Resonance.Resonance;

namespace Resonance.Integration
{
    /// <summary>
    /// Bridges the entrance-cave vertical slice into the broader V127 cosmos loop.
    /// Treat this as the handoff point from the original room into the universe-scale systems.
    /// </summary>
    public class V127CosmosBridge : MonoBehaviour
    {
        [SerializeField] private OriginalGameConnectionBootstrap originalBootstrap;
        [SerializeField] private LikeFrequencyWorldMatcher worldMatcher;
        [SerializeField] private ThoughtManifestationRouter thoughtRouter;
        [SerializeField] private PlanetNodeController activePlanet;
        [SerializeField] private UniverseCycleDirector universeCycle;

        [Header("Runtime State")]
        public string matchedRealm = "EntranceCave";
        [Range(0f,1f)] public float manifestationBias = 0.5f;
        [Range(0f,1f)] public float caveWorthiness = 0.5f;

        private void Start()
        {
            if (originalBootstrap != null)
                Debug.Log(originalBootstrap.BuildStatusReport());
        }

        private void Update()
        {
            matchedRealm = worldMatcher != null ? worldMatcher.CurrentRealmMatch : "EntranceCave";
            manifestationBias = thoughtRouter != null ? thoughtRouter.GetManifestationBias() : 0.5f;
        }

        public void CommitEntranceOutcome(float worthinessOverride = -1f)
        {
            caveWorthiness = worthinessOverride >= 0f ? Mathf.Clamp01(worthinessOverride) : caveWorthiness;
            if (activePlanet != null)
                activePlanet.RegisterCaveOutcome(caveWorthiness);

            if (universeCycle != null && activePlanet != null)
            {
                float harmony = activePlanet.GetComponent<ResonanceEngine>() != null
                    ? activePlanet.GetComponent<ResonanceEngine>().CurrentSnapshot.harmony
                    : manifestationBias;
                universeCycle.RegisterEncounter(harmony, 1f - manifestationBias);
            }
        }
    }
}