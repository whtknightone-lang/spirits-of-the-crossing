using UnityEngine;

    namespace Resonance.Integration
    {
        /// <summary>
        /// Drop this in the bootstrap scene to keep the intended production roadmap visible in-editor.
        /// </summary>
        public class V127NextStepsRuntimeMarker : MonoBehaviour
        {
            [TextArea(10, 30)]
            public string productionRoadmap =
                "1. Open EntranceCave_VR scene.
" +
                "2. Add V127CosmosBridge to a Bootstrap object.
" +
                "3. Assign OriginalGameConnectionBootstrap, ThoughtManifestationRouter, LikeFrequencyWorldMatcher, PlanetNodeController, UniverseCycleDirector.
" +
                "4. Create realm bands for Forest, Ocean, Mountain, Machine, DarkPlanet, SourceRiver.
" +
                "5. Add OpenXR rig, hand prefabs, spatial audio emitters, and portal trigger colliders.
" +
                "6. Save a new scene named V127_Integrated_Bootstrap.
" +
                "7. Build a Windows/Mac player from Unity Build Settings after validation.";
        }
    }