using UnityEngine;
using Resonance.Resonance;
using Resonance.Cosmos;
using Resonance.Gameplay;

namespace Resonance.Connections
{
    /// <summary>
    /// Writes the entrance/cave outcome back to planets, universe memory, and realm routing.
    /// </summary>
    public class EntranceCaveCosmosConnector : MonoBehaviour
    {
        [SerializeField] private ResonanceEngine resonanceEngine;
        [SerializeField] private PortalController portalController;
        [SerializeField] private PlanetNodeController planetNode;
        [SerializeField] private UniverseCycleDirector universeCycle;
        [SerializeField] private LikeFrequencyWorldMatcher worldMatcher;
        [SerializeField] private ThoughtManifestationRouter thoughtRouter;

        [Range(0f, 1f)] public float lastWorthiness;
        public string pendingRealm = "EntranceCave";
        private bool completionApplied;

        public void Initialize()
        {
            pendingRealm = worldMatcher != null ? worldMatcher.CurrentRealmMatch : "EntranceCave";
        }

        private void Update()
        {
            if (resonanceEngine == null || portalController == null) return;
            pendingRealm = worldMatcher != null ? worldMatcher.CurrentRealmMatch : pendingRealm;
            if (completionApplied || !portalController.IsOpen) return;

            float manifestationBias = thoughtRouter != null ? thoughtRouter.GetManifestationBias() : 0.5f;
            lastWorthiness = Mathf.Clamp01(
                resonanceEngine.CurrentSnapshot.harmony * 0.45f +
                resonanceEngine.CurrentSnapshot.signalClarity * 0.25f +
                manifestationBias * 0.20f +
                (1f - resonanceEngine.CurrentSnapshot.distortionRisk) * 0.10f);

            planetNode?.RegisterCaveOutcome(lastWorthiness);
            universeCycle?.RegisterEncounter(resonanceEngine.CurrentSnapshot.harmony, resonanceEngine.CurrentSnapshot.distortionRisk);
            completionApplied = true;
        }

        public void ResetForNewRun()
        {
            completionApplied = false;
            lastWorthiness = 0f;
        }
    }
}
