using UnityEngine;
using Resonance.Resonance;
using Resonance.SourceSystem;
using Resonance.World;
using Resonance.Cosmos;
using Resonance.Gameplay;

namespace Resonance.Connections
{
    /// <summary>
    /// Top-level connection bootstrap for the original cave/entrance vertical.
    /// It runs lightweight validation and wires together the new cross-system connectors.
    /// </summary>
    public class OriginalGameConnectionBootstrap : MonoBehaviour
    {
        [SerializeField] private ResonanceEngine resonanceEngine;
        [SerializeField] private SourceGuidanceEngine sourceGuidance;
        [SerializeField] private WorldNatureResponseEngine worldNature;
        [SerializeField] private PortalController portalController;
        [SerializeField] private PlanetNodeController planetNode;
        [SerializeField] private UniverseCycleDirector universeCycle;
        [SerializeField] private ThoughtManifestationRouter thoughtRouter;
        [SerializeField] private LikeFrequencyWorldMatcher worldMatcher;
        [SerializeField] private EntranceCaveCosmosConnector caveConnector;

        private void Start()
        {
            Debug.Log(BuildStatusReport());
            if (thoughtRouter != null) thoughtRouter.Initialize();
            if (worldMatcher != null) worldMatcher.Initialize();
            if (caveConnector != null) caveConnector.Initialize();
        }

        public string BuildStatusReport()
        {
            return string.Format(
                "OriginalGameConnectionBootstrap ready | engine:{0} source:{1} world:{2} portal:{3} planet:{4} universe:{5}",
                resonanceEngine != null,
                sourceGuidance != null,
                worldNature != null,
                portalController != null,
                planetNode != null,
                universeCycle != null);
        }
    }
}
