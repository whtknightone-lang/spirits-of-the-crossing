# Original Game Build Connection Notes

This pack circles back to the original **EntranceCave_VR** build and adds the missing runtime connections between:

- player thought/desire routing
- Source bridge logic
- world nature response
- worthiness demonstration
- portal opening
- like-frequency world matching
- planet growth writeback
- universe birth/rebirth memory
- optional AI/human party resonance

## Add these components to the entrance scene root

1. `OriginalGameConnectionBootstrap`
2. `ThoughtManifestationRouter`
3. `LikeFrequencyWorldMatcher`
4. `SourceWorldCoCreationConnector`
5. `EntranceCaveCosmosConnector`
6. optional `AIHumanResonancePartyConnector`

## Suggested references

- `ThoughtManifestationRouter.player` -> the same `PlayerResonanceProfile` used by `XRInputRouter`
- `ThoughtManifestationRouter.resonanceEngine` -> existing `ResonanceEngine`
- `LikeFrequencyWorldMatcher.player` -> existing `PlayerResonanceProfile`
- `LikeFrequencyWorldMatcher.resonanceEngine` -> existing `ResonanceEngine`
- `SourceWorldCoCreationConnector.player` -> existing `PlayerResonanceProfile`
- `SourceWorldCoCreationConnector.sourceGuidance` -> existing `SourceGuidanceEngine`
- `SourceWorldCoCreationConnector.worldNature` -> existing `WorldNatureResponseEngine`
- `SourceWorldCoCreationConnector.worthinessDirector` -> existing `WorthinessDemonstrationDirector`
- `EntranceCaveCosmosConnector.portalController` -> existing `PortalController`
- `EntranceCaveCosmosConnector.planetNode` -> existing `PlanetNodeController`
- `EntranceCaveCosmosConnector.universeCycle` -> existing `UniverseCycleDirector`
- `EntranceCaveCosmosConnector.worldMatcher` -> `LikeFrequencyWorldMatcher`
- `EntranceCaveCosmosConnector.thoughtRouter` -> `ThoughtManifestationRouter`

## Example realm bands

- EntranceCave: target harmony `0.45`, tolerance `0.35`, joy bias `0.45`, shadow ceiling `0.70`
- ForestRealm: target harmony `0.70`, tolerance `0.20`, joy bias `0.65`, shadow ceiling `0.45`
- OceanRealm: target harmony `0.60`, tolerance `0.18`, joy bias `0.50`, shadow ceiling `0.55`
- MachineRealm: target harmony `0.78`, tolerance `0.12`, joy bias `0.35`, shadow ceiling `0.30`
- DarkPlanet: target harmony `0.32`, tolerance `0.25`, joy bias `0.20`, shadow ceiling `0.90`

## Runtime flow

1. XR input updates player state.
2. `ResonanceEngine` computes harmony, clarity, manifestation, portal readiness.
3. `ThoughtManifestationRouter` turns the strongest thought into a manifestation bias.
4. `SourceGuidanceEngine` builds a bridge from resisted threshold to desired outcome.
5. `SourceWorldCoCreationConnector` lets the world play back celebration + contrast.
6. `PortalController` opens once readiness is high and distortion is low.
7. `EntranceCaveCosmosConnector` writes worthiness to planets and universe memory.
8. `LikeFrequencyWorldMatcher` picks the next realm with a similar frequency.

This is still a scaffold. It gives you the actual connection code and scene hookup path, but not a compiled Unity build.
