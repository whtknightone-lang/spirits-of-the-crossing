using System;
using UnityEngine;
using Resonance.Resonance;

namespace Resonance.Connections
{
    [Serializable]
    public class RealmMatchBand
    {
        public string realmId;
        [Range(0f, 1f)] public float targetHarmony = 0.5f;
        [Range(0f, 1f)] public float tolerance = 0.15f;
        [Range(0f, 1f)] public float joyBias = 0.5f;
        [Range(0f, 1f)] public float shadowCeiling = 0.5f;
    }

    /// <summary>
    /// Matches players to worlds with similar frequency while leaving room for contrast-learning.
    /// </summary>
    public class LikeFrequencyWorldMatcher : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile player;
        [SerializeField] private ResonanceEngine resonanceEngine;
        [SerializeField] private RealmMatchBand[] realmBands;

        public string CurrentRealmMatch { get; private set; }
        public float CurrentMatchScore { get; private set; }

        public void Initialize()
        {
            RecomputeMatch();
        }

        private void Update()
        {
            RecomputeMatch();
        }

        private void RecomputeMatch()
        {
            CurrentRealmMatch = "EntranceCave";
            CurrentMatchScore = 0f;
            if (player == null || resonanceEngine == null || realmBands == null) return;

            float harmony = resonanceEngine.CurrentSnapshot.harmony;
            float joy = player.joy;
            float shadow = player.shadowLoad;

            foreach (var band in realmBands)
            {
                if (band == null) continue;
                float harmonyFit = 1f - Mathf.Clamp01(Mathf.Abs(harmony - band.targetHarmony) / Mathf.Max(0.001f, band.tolerance));
                float joyFit = 1f - Mathf.Abs(joy - band.joyBias);
                float shadowFit = shadow <= band.shadowCeiling ? 1f : 1f - (shadow - band.shadowCeiling);
                float score = Mathf.Clamp01(harmonyFit * 0.55f + joyFit * 0.25f + shadowFit * 0.20f);
                if (score > CurrentMatchScore)
                {
                    CurrentMatchScore = score;
                    CurrentRealmMatch = string.IsNullOrWhiteSpace(band.realmId) ? "UnknownRealm" : band.realmId;
                }
            }
        }
    }
}
