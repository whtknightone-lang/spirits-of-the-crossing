using UnityEngine;
using Resonance.Resonance;
using Resonance.SourceSystem;
using Resonance.World;

namespace Resonance.Connections
{
    /// <summary>
    /// Keeps Source pure while allowing the world to play back meaningful contrast,
    /// celebration, and demonstrations of worth and importance.
    /// </summary>
    public class SourceWorldCoCreationConnector : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile player;
        [SerializeField] private ResonanceEngine resonanceEngine;
        [SerializeField] private SourceGuidanceEngine sourceGuidance;
        [SerializeField] private WorldNatureResponseEngine worldNature;
        [SerializeField] private WorthinessDemonstrationDirector worthinessDirector;

        [Range(0f, 1f)] public float worldPlayfulness;
        [Range(0f, 1f)] public float contrastTeaching;
        public string activeBridgeMessage;

        private void Update()
        {
            if (player == null || resonanceEngine == null || sourceGuidance == null) return;

            GuidanceBridge bridge = resonanceEngine.CurrentBridge ?? sourceGuidance.BuildBridge(player);
            activeBridgeMessage = bridge != null ? bridge.bridgeMessage : string.Empty;

            float harmony = resonanceEngine.CurrentSnapshot.harmony;
            float distortion = resonanceEngine.CurrentSnapshot.distortionRisk;
            worldPlayfulness = Mathf.Clamp01(player.joy * 0.4f + harmony * 0.4f + (1f - distortion) * 0.2f);
            contrastTeaching = Mathf.Clamp01(player.shadowLoad * 0.45f + distortion * 0.35f + (1f - player.trust) * 0.2f);

            if (worldNature != null && bridge != null)
            {
                worldNature.ApplyResponse(player, bridge);
            }

            if (worthinessDirector != null)
            {
                worthinessDirector.Demonstrate(player);
            }
        }
    }
}
