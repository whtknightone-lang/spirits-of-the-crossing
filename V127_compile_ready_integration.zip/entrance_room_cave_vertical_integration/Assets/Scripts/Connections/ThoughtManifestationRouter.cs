using UnityEngine;
using Resonance.Resonance;
using Resonance.SourceSystem;

namespace Resonance.Connections
{
    /// <summary>
    /// Routes the strongest player thought/desire into a stable manifestation bias.
    /// This is the "wouldn't it be nice if" bridge back into the original build.
    /// </summary>
    public class ThoughtManifestationRouter : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile player;
        [SerializeField] private ResonanceEngine resonanceEngine;

        [Range(0f, 1f)] public float thoughtCharge;
        [Range(0f, 1f)] public float desireClarity;
        public string currentThoughtLabel;

        public void Initialize()
        {
            RefreshThoughtState();
        }

        private void Update()
        {
            RefreshThoughtState();
        }

        private void RefreshThoughtState()
        {
            if (player == null)
            {
                currentThoughtLabel = string.Empty;
                thoughtCharge = 0f;
                desireClarity = 0f;
                return;
            }

            DesireSignal strongest = player.GetStrongestDesiredOutcome();
            if (strongest == null)
            {
                currentThoughtLabel = string.Empty;
                thoughtCharge = 0f;
                desireClarity = 0f;
                return;
            }

            currentThoughtLabel = strongest.label;
            thoughtCharge = Mathf.Clamp01(strongest.strength * 0.65f + strongest.readiness * 0.35f);
            desireClarity = Mathf.Clamp01((1f - strongest.fearResistance) * 0.4f + strongest.readiness * 0.6f);
        }

        public float GetManifestationBias()
        {
            float harmony = resonanceEngine != null ? resonanceEngine.CurrentSnapshot.harmony : 0.5f;
            return Mathf.Clamp01(thoughtCharge * 0.5f + desireClarity * 0.25f + harmony * 0.25f);
        }
    }
}
