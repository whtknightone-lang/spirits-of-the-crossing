using System.Collections.Generic;
using UnityEngine;
using Resonance.Resonance;

namespace Resonance.Connections
{
    /// <summary>
    /// Lightweight group coordinator for human players, AI players, companions, or spirit proxies.
    /// The group can raise harmony, amplify contrast, and influence which world gets matched next.
    /// </summary>
    public class AIHumanResonancePartyConnector : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile primaryPlayer;
        [SerializeField] private List<PlayerResonanceProfile> partyMembers = new List<PlayerResonanceProfile>();
        [SerializeField] private ResonanceEngine resonanceEngine;

        [Range(0f, 1f)] public float partyHarmony;
        [Range(0f, 1f)] public float partyContrast;

        private void Update()
        {
            float totalHarmony = 0f;
            float totalContrast = 0f;
            int count = 0;

            if (primaryPlayer != null)
            {
                totalHarmony += ComputeIndividualHarmony(primaryPlayer);
                totalContrast += primaryPlayer.shadowLoad;
                count++;
            }

            foreach (var member in partyMembers)
            {
                if (member == null) continue;
                totalHarmony += ComputeIndividualHarmony(member);
                totalContrast += member.shadowLoad;
                count++;
            }

            if (count == 0)
            {
                partyHarmony = 0f;
                partyContrast = 0f;
                return;
            }

            partyHarmony = Mathf.Clamp01(totalHarmony / count);
            partyContrast = Mathf.Clamp01(totalContrast / count);

            if (resonanceEngine != null)
            {
                partyHarmony = Mathf.Clamp01(partyHarmony * 0.75f + resonanceEngine.CurrentSnapshot.harmony * 0.25f);
            }
        }

        private float ComputeIndividualHarmony(PlayerResonanceProfile profile)
        {
            return Mathf.Clamp01(profile.coherence * 0.35f + profile.trust * 0.25f + profile.joy * 0.20f + profile.openness * 0.20f);
        }
    }
}
