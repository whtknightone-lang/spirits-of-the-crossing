# Build status

Requested: compiled Unity build tied into V127.

What is included here:
- a merged, compile-ready Unity project scaffold based on the latest entrance-cave/original-build connection pack
- the broader "Wouldn't it be nice if..." world-matching architecture added under `Addons/WIB`
- package manifest placeholders for XR/OpenXR/URP/Input System
- `V127CosmosBridge.cs` to write the entrance-room outcome back into planet growth and universe-cycle memory
- roadmap and build instructions

What is **not** included:
- an actual compiled `.app` / `.exe` / Android APK
- a Unity-generated `Library/` or `Build/` folder

Why:
- this environment does not have the Unity Editor or platform build toolchains, so I cannot produce a true compiled player here.