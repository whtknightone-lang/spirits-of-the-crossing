
RUE V121–V130 + Elder Spirit Layer

Features:
- Elder Spirit system (Wolf, Owl, Bear, Eagle, Dragon)
- Civilizations bound to Spirits
- Spirit influence fields affecting agent goals
- Conflict emerges from differing Spirit strategies
- Mythology hooks (era labeling via dominant spirit)

Controls:
- WASD: move player
- 1–5: switch player alignment (Wolf, Owl, Bear, Eagle, Dragon)

Run:
pip install torch matplotlib
python run_v121.py
