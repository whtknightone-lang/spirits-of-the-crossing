
import matplotlib.pyplot as plt
from engine import SpiritWorld

world = SpiritWorld(50000)

plt.ion()
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

def on_key(event):
    if event.key == '1': world.player_spirit = 0
    if event.key == '2': world.player_spirit = 1
    if event.key == '3': world.player_spirit = 2
    if event.key == '4': world.player_spirit = 3
    if event.key == '5': world.player_spirit = 4

fig.canvas.mpl_connect('key_press_event', on_key)

for step in range(200):
    world.step()

    ax.clear()
    ax.scatter(
        world.position[:5000,0].numpy(),
        world.position[:5000,1].numpy(),
        world.position[:5000,2].numpy(),
        c=world.lineage[:5000].numpy(),
        s=1
    )

    ax.set_xlim(0,1)
    ax.set_ylim(0,1)
    ax.set_zlim(0,1)

    ax.set_title(f"Step {step} Player Spirit {world.player_spirit}")

    plt.pause(0.01)

plt.ioff()
plt.show()
