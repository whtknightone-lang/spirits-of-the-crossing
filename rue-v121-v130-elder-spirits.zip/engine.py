
import torch

GRID = 30
FACTIONS = 5
SPIRITS = 5

# spirit mapping
# 0 Wolf(expand), 1 Owl(stabilize), 2 Bear(defend), 3 Eagle(explore), 4 Dragon(risk)
class SpiritWorld:
    def __init__(self, n=50000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)
        self.velocity = torch.zeros(n,3)

        self.lineage = torch.randint(0, FACTIONS, (n,))
        self.goal_type = torch.randint(0,4,(n,))
        self.memory = torch.zeros(n)

        # assign one spirit per faction
        self.faction_spirit = torch.randint(0, SPIRITS, (FACTIONS,))
        self.player_spirit = 0

    def step(self):
        # base noise
        noise = 0.01 * torch.randn_like(self.velocity)

        # spirit influence
        for f in range(FACTIONS):
            mask = self.lineage == f
            spirit = int(self.faction_spirit[f])

            if spirit == 0:  # Wolf
                self.goal_type[mask] = 3  # expand
            elif spirit == 1:  # Owl
                self.goal_type[mask] = 2  # stabilize
            elif spirit == 2:  # Bear
                self.energy[mask] *= 1.0005
            elif spirit == 3:  # Eagle
                self.velocity[mask] += 0.005 * torch.randn_like(self.velocity[mask])
            elif spirit == 4:  # Dragon
                self.energy[mask] *= (1 + 0.002 * torch.randn_like(self.energy[mask]))

        # goal scoring
        grow = self.energy
        explore = torch.norm(self.velocity, dim=1)
        stabilize = -torch.abs(self.energy - 1.2)
        expand = torch.norm(self.position - 0.5, dim=1)

        scores = torch.stack([grow, explore, stabilize, expand], dim=1)
        chosen = scores[torch.arange(len(self.goal_type)), self.goal_type]

        # motion
        direction = torch.randn_like(self.velocity)
        direction = direction / (torch.norm(direction, dim=1, keepdim=True)+1e-6)

        self.velocity += noise + 0.01 * direction * chosen.unsqueeze(1)
        self.position += self.velocity
        self.position.clamp_(0,1)

        # energy + memory
        self.energy += 0.01 * torch.sin(torch.rand_like(self.energy))
        self.memory = 0.9*self.memory + 0.1*self.energy

        improve = self.energy > self.memory
        self.energy[improve] *= 1.001
        self.energy[~improve] *= 0.999

        self.energy *= 0.999
