
function scaleWorld(playerCount, resonance) {
    return {
        difficulty: playerCount * 0.1,
        richness: resonance
    };
}

module.exports = { scaleWorld };
