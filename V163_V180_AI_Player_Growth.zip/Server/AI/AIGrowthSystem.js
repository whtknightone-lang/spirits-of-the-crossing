
let aiPopulation = 10;

function updateAI(globalResonance) {
    aiPopulation += globalResonance * 0.5;
    return aiPopulation;
}

module.exports = { updateAI };
