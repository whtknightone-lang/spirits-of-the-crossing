
using UnityEngine;

public class AIEntity : MonoBehaviour
{
    public float intelligence;
    public float growthRate = 0.01f;

    void Update()
    {
        intelligence += Time.deltaTime * growthRate;
    }
}
