
using UnityEngine;

public class PlayerImpactScaling : MonoBehaviour
{
    public float playerInfluence;

    void Update()
    {
        playerInfluence = Mathf.PingPong(Time.time * 0.1f, 1f);
    }
}
