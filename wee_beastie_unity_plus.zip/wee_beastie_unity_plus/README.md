# Wee Beastie Unity Plus Pack

This pack gives you two things:
1. A stronger Wee Beastie Unity starter with royal behavior and a capsule-body rig.
2. A Source Planet population scaffold for the "thick like fog, seen in glimpses" idea.

## Included scripts
- ArchetypeTraits.cs
- SocialPresence.cs
- EmergentRole.cs
- RoleAffinityScorer.cs
- EmergentRoleBrain.cs
- CompanionMemory.cs
- ComfortSpot.cs
- HumanInteractionAnchor.cs
- BeastieCapsuleBodyRig.cs
- BeastieSimpleAnimationDriver.cs
- WeeBeastieAI.cs
- WeeBeastieDemoInput.cs
- SourcePopulationArchetype.cs
- FogCrowdAgent.cs
- SourcePlanetPopulationController.cs

## Quick Unity hookup for Wee Beastie
1. Copy the Scripts folder into Assets/Scripts.
2. Create a GameObject named `WeeBeastie`.
3. Add:
   - CharacterController
   - CompanionMemory
   - WeeBeastieAI
   - BeastieCapsuleBodyRig
   - BeastieSimpleAnimationDriver
   - EmergentRoleBrain
4. On the BeastieCapsuleBodyRig component, click **Build Capsule Body**.
5. Create a GameObject named `Human` and add HumanInteractionAnchor.
6. Create 3-5 comfort spots as empty GameObjects with ComfortSpot:
   - Chair / throne spot: higher displayPrestige
   - Sun patch: higher sunlight
   - Rug / rest spot: higher softness
7. Drag references into WeeBeastieAI:
   - Favorite Human
   - Human Anchor
   - Known Comfort Spots
8. Add WeeBeastieDemoInput to any scene object and assign Beastie + Human.

## Demo keys
- B = rebuild capsule body
- L = leash request
- P = pants request
- A = admiration / praise
- T = attempt pet
- C = clear requests
- Z = zoomies
- G = greeting drive
- R = rest drive
- O = admiration full

## Beastie behavior notes
Wee Beastie begins as a royal being:
- seeks display / comfort spots
- prefers admiration from a distance
- allows petting only after admiration and trust rise
- performs orbit ritual for leash / pants requests
- can zoom, settle, perch, observe, approach reluctantly, and withdraw gracefully

## Source Planet scaffold
Create an empty object named `SourcePlanetPopulation` and add SourcePlanetPopulationController.
Then press **Spawn Population**.

This creates a mist-thick crowd of primitive spirit forms that drift, pulse in visibility, and show as glimpses.
This is intentionally lightweight and meant as a first visual and systemic pass, not the final art layer.

## Morning roadmap
The next strong steps are:
1. Swap capsule body for a skinned mesh or stylized creature mesh.
2. Add Animator events for lick, preen, pose, and elegant withdrawal.
3. Replace primitive fog beings with spirit / god / mortal population families.
4. Add Source Planet zones so different populations gather in different densities and mythic layers.
5. Tie population visibility to player resonance and distance so the crowd feels alive, veiled, and selective.
