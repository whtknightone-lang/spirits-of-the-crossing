using UnityEngine;

[System.Serializable]
public class ArchetypeTraits
{
    [Range(0f, 1f)] public float beauty = 0.8f;
    [Range(0f, 1f)] public float strength = 0.35f;
    [Range(0f, 1f)] public float agility = 0.8f;
    [Range(0f, 1f)] public float intelligence = 0.55f;
    [Range(0f, 1f)] public float craft = 0.2f;
    [Range(0f, 1f)] public float slyness = 0.65f;
    [Range(0f, 1f)] public float loyalty = 0.75f;
    [Range(0f, 1f)] public float courage = 0.45f;
    [Range(0f, 1f)] public float patience = 0.5f;
    [Range(0f, 1f)] public float rituality = 0.9f;
    [Range(0f, 1f)] public float sociability = 0.4f;
    [Range(0f, 1f)] public float dominance = 0.65f;
    [Range(0f, 1f)] public float empathy = 0.55f;
    [Range(0f, 1f)] public float curiosity = 0.6f;
}
