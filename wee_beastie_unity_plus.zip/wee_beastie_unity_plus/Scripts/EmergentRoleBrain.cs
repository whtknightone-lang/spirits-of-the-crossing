using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class EmergentRoleBrain : MonoBehaviour
{
    public ArchetypeTraits traits = new ArchetypeTraits();
    public SocialPresence presence = new SocialPresence();

    public EmergentRole currentRole = EmergentRole.Undefined;
    public List<EmergentRole> secondaryRoles = new List<EmergentRole>();

    [Header("Dynamic Pressures")]
    [Range(0f, 1f)] public float protectionPressure;
    [Range(0f, 1f)] public float craftPressure;
    [Range(0f, 1f)] public float socialPressure;
    [Range(0f, 1f)] public float stealthPressure;
    [Range(0f, 1f)] public float ceremonialPressure = 0.5f;
    [Range(0f, 1f)] public float companionshipPressure = 0.7f;

    [Header("Dynamic Desire")]
    [Range(0f, 1f)] public float desireForAttention = 0.8f;
    [Range(0f, 1f)] public float desireForSafety = 0.4f;
    [Range(0f, 1f)] public float desireForFreedom = 0.6f;

    public void Start() { RecalculateRole(); }

    [ContextMenu("Recalculate Role")]
    public void RecalculateRole()
    {
        Dictionary<EmergentRole, float> scores = RoleAffinityScorer.ScoreRoles(traits, presence);
        Add(scores, EmergentRole.Guardian, protectionPressure * 0.25f + desireForSafety * 0.1f);
        Add(scores, EmergentRole.Artisan, craftPressure * 0.25f);
        Add(scores, EmergentRole.Diplomat, socialPressure * 0.25f);
        Add(scores, EmergentRole.Trickster, stealthPressure * 0.25f + desireForFreedom * 0.1f);
        Add(scores, EmergentRole.RitualKeeper, ceremonialPressure * 0.25f);
        Add(scores, EmergentRole.CourtlyBeauty, ceremonialPressure * 0.15f + desireForAttention * 0.1f);
        Add(scores, EmergentRole.Companion, companionshipPressure * 0.25f);
        Add(scores, EmergentRole.CeremonialGuardian, ceremonialPressure * 0.2f + protectionPressure * 0.15f);

        currentRole = scores.OrderByDescending(x => x.Value).First().Key;
        secondaryRoles = scores.OrderByDescending(x => x.Value).Skip(1).Take(2).Select(x => x.Key).ToList();
    }

    void Add(Dictionary<EmergentRole, float> scores, EmergentRole role, float delta)
    {
        if (!scores.ContainsKey(role)) scores[role] = 0f;
        scores[role] += delta;
    }
}
