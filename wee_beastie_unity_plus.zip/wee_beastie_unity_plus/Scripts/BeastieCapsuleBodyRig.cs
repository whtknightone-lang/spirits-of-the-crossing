using UnityEngine;

public class BeastieCapsuleBodyRig : MonoBehaviour
{
    public Transform body;
    public Transform head;
    public Transform tail;
    public Transform earL;
    public Transform earR;

    [ContextMenu("Build Capsule Body")]
    public void BuildCapsuleBody()
    {
        ClearChildren();
        body = CreatePrimitive("Body", PrimitiveType.Capsule, new Vector3(0f, 0.35f, 0f), new Vector3(0.55f, 0.5f, 0.85f));
        head = CreatePrimitive("Head", PrimitiveType.Sphere, new Vector3(0f, 0.62f, 0.42f), new Vector3(0.38f, 0.3f, 0.38f));
        tail = CreatePrimitive("Tail", PrimitiveType.Capsule, new Vector3(0f, 0.5f, -0.48f), new Vector3(0.12f, 0.22f, 0.12f));
        tail.localRotation = Quaternion.Euler(70f, 0f, 0f);
        earL = CreatePrimitive("EarL", PrimitiveType.Capsule, new Vector3(-0.12f, 0.83f, 0.45f), new Vector3(0.08f, 0.18f, 0.08f));
        earL.localRotation = Quaternion.Euler(20f, 0f, -25f);
        earR = CreatePrimitive("EarR", PrimitiveType.Capsule, new Vector3(0.12f, 0.83f, 0.45f), new Vector3(0.08f, 0.18f, 0.08f));
        earR.localRotation = Quaternion.Euler(20f, 0f, 25f);

        for (int i = 0; i < 4; i++)
        {
            float x = i < 2 ? -0.16f : 0.16f;
            float z = i % 2 == 0 ? 0.2f : -0.22f;
            Transform leg = CreatePrimitive("Leg" + i, PrimitiveType.Capsule, new Vector3(x, 0.08f, z), new Vector3(0.12f, 0.18f, 0.12f));
            leg.localRotation = Quaternion.Euler(0f, 0f, 0f);
        }
    }

    Transform CreatePrimitive(string n, PrimitiveType type, Vector3 localPos, Vector3 localScale)
    {
        GameObject go = GameObject.CreatePrimitive(type);
        go.name = n;
        go.transform.SetParent(transform, false);
        go.transform.localPosition = localPos;
        go.transform.localScale = localScale;
        DestroyColliderInEditOrPlay(go);
        return go.transform;
    }

    void ClearChildren()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            DestroyImmediateSafe(transform.GetChild(i).gameObject);
        }
    }

    void DestroyColliderInEditOrPlay(GameObject go)
    {
        Collider c = go.GetComponent<Collider>();
        if (c != null) DestroyImmediateSafe(c);
    }

    void DestroyImmediateSafe(Object obj)
    {
        if (Application.isPlaying) Destroy(obj); else DestroyImmediate(obj);
    }

    void Reset() { BuildCapsuleBody(); }
}
