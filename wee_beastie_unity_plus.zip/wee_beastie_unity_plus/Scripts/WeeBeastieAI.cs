using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class WeeBeastieAI : MonoBehaviour
{
    public enum BeastieState
    {
        Idle,
        Following,
        Greeting,
        OrbitRitual,
        Zoomies,
        SeekingComfort,
        Resting,
        Settling,
        AdmiringPose,
        RoyalObserve,
        ReluctantApproach,
        AllowBriefPet,
        GracefulWithdraw
    }

    [Header("References")]
    public Transform favoriteHuman;
    public HumanInteractionAnchor humanAnchor;
    public CompanionMemory memory;
    public List<ComfortSpot> knownComfortSpots = new List<ComfortSpot>();

    [Header("Movement")]
    public float walkSpeed = 1.8f;
    public float runSpeed = 4.2f;
    public float turnSpeed = 8f;
    public float stopDistance = 0.85f;
    public float followDistance = 1.6f;
    public float regalDistance = 2.1f;
    public float gravity = -9.81f;

    [Header("Base Personality")]
    [Range(0f, 1f)] public float affection = 0.8f;
    [Range(0f, 1f)] public float playfulness = 0.7f;
    [Range(0f, 1f)] public float ritualNeed = 0.9f;
    [Range(0f, 1f)] public float comfortSeeking = 0.9f;
    [Range(0f, 1f)] public float stubbornness = 0.35f;

    [Header("Royal Traits")]
    [Range(0f, 1f)] public float vanity = 0.9f;
    [Range(0f, 1f)] public float admirationNeed = 0.85f;
    [Range(0f, 1f)] public float regalDistancePreference = 0.75f;
    [Range(0f, 1f)] public float pettingTolerance = 0.35f;
    [Range(0f, 1f)] public float selectiveAffection = 0.8f;

    [Header("Drives / Gate")]
    [Range(0f, 1f)] public float affectionDrive = 0.45f;
    [Range(0f, 1f)] public float playDrive = 0.35f;
    [Range(0f, 1f)] public float comfortDrive = 0.65f;
    [Range(0f, 1f)] public float restDrive = 0.25f;
    [Range(0f, 1f)] public float admirationReceived = 0.2f;
    [Range(0f, 1f)] public float touchPermission = 0.1f;
    [Range(0f, 1f)] public float socialReserve = 0.7f;

    [Header("Debug")]
    public BeastieState currentState = BeastieState.Idle;
    public ComfortSpot currentComfortSpot;

    CharacterController controller;
    Vector3 velocity;
    float stateTimer;
    float chosenStateDuration;
    int requiredRitualCircles;
    int completedRitualCircles;
    float currentOrbitAngle;
    Vector3 zoomieCenter;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (memory == null) memory = GetComponent<CompanionMemory>();
        if (memory == null) memory = gameObject.AddComponent<CompanionMemory>();
    }

    void Start()
    {
        if (favoriteHuman != null) memory.favoriteHuman = favoriteHuman;
        EnterState(BeastieState.AdmiringPose);
    }

    void Update()
    {
        UpdateDrives();
        HandleRequests();
        UpdateState();
        ApplyGravity();
        if (humanAnchor != null) humanAnchor.ClearMomentaryRequests();
    }

    void UpdateDrives()
    {
        affectionDrive = Mathf.Clamp01(affectionDrive + Time.deltaTime * 0.025f);
        playDrive = Mathf.Clamp01(playDrive + Time.deltaTime * 0.02f);
        restDrive = Mathf.Clamp01(restDrive + Time.deltaTime * 0.01f);
        admirationReceived = Mathf.Clamp01(admirationReceived - Time.deltaTime * 0.01f);
        touchPermission = Mathf.Clamp01(touchPermission - Time.deltaTime * 0.015f);

        bool inComfort = currentComfortSpot != null && currentComfortSpot.IsPointInside(transform.position);
        if (inComfort)
        {
            comfortDrive = Mathf.Clamp01(comfortDrive + Time.deltaTime * 0.04f);
            restDrive = Mathf.Clamp01(restDrive - Time.deltaTime * 0.02f);
        }
        else
        {
            comfortDrive = Mathf.Clamp01(comfortDrive - Time.deltaTime * 0.01f);
        }
    }

    void HandleRequests()
    {
        if (humanAnchor == null) return;

        if (humanAnchor.admirationRequested)
        {
            admirationReceived = Mathf.Clamp01(admirationReceived + 0.25f);
            touchPermission = Mathf.Clamp01(touchPermission + 0.12f * humanAnchor.calmApproachLevel);
            socialReserve = Mathf.Clamp01(socialReserve - 0.08f * humanAnchor.calmApproachLevel);
            memory.admirationBank = admirationReceived;
            if (currentState == BeastieState.RoyalObserve || currentState == BeastieState.AdmiringPose)
                EnterState(BeastieState.ReluctantApproach);
        }

        if (humanAnchor.petAttemptRequested)
        {
            if (CanAllowPet())
                EnterState(BeastieState.AllowBriefPet);
            else
                EnterState(BeastieState.GracefulWithdraw);
        }

        if (humanAnchor.HasEquipRequest && currentState != BeastieState.OrbitRitual)
        {
            EnterOrbitRitual();
        }
    }

    void UpdateState()
    {
        stateTimer += Time.deltaTime;
        switch (currentState)
        {
            case BeastieState.Idle: TickIdle(); break;
            case BeastieState.Following: TickFollowing(); break;
            case BeastieState.Greeting: TickGreeting(); break;
            case BeastieState.OrbitRitual: TickOrbitRitual(); break;
            case BeastieState.Zoomies: TickZoomies(); break;
            case BeastieState.SeekingComfort: TickSeekingComfort(); break;
            case BeastieState.Resting: TickResting(); break;
            case BeastieState.Settling: TickSettling(); break;
            case BeastieState.AdmiringPose: TickAdmiringPose(); break;
            case BeastieState.RoyalObserve: TickRoyalObserve(); break;
            case BeastieState.ReluctantApproach: TickReluctantApproach(); break;
            case BeastieState.AllowBriefPet: TickAllowBriefPet(); break;
            case BeastieState.GracefulWithdraw: TickGracefulWithdraw(); break;
        }
    }

    void TickIdle()
    {
        FaceHumanSoftly();
        if (ShouldDoZoomies()) { EnterZoomies(); return; }
        if (ShouldSeekComfort()) { EnterSeekComfort(); return; }
        if (ShouldFollowHuman()) { EnterState(BeastieState.Following); return; }
        if (admirationNeed > 0.5f && stateTimer > 2f) { EnterState(BeastieState.RoyalObserve); }
    }

    void TickFollowing()
    {
        if (memory.favoriteHuman == null) { EnterState(BeastieState.Idle); return; }
        float dist = Vector3.Distance(transform.position, memory.favoriteHuman.position);
        if (dist > followDistance) MoveToward(memory.favoriteHuman.position, walkSpeed); else FaceHumanSoftly();
        if (ShouldDoZoomies()) { EnterZoomies(); return; }
        if (dist <= stopDistance && admirationNeed > 0.5f) EnterState(BeastieState.RoyalObserve);
    }

    void TickGreeting()
    {
        if (memory.favoriteHuman == null) { EnterState(BeastieState.Idle); return; }
        MoveToward(memory.favoriteHuman.position, walkSpeed);
        affectionDrive = Mathf.Clamp01(affectionDrive - Time.deltaTime * 0.22f);
        if (stateTimer >= chosenStateDuration) EnterState(BeastieState.RoyalObserve);
    }

    void TickOrbitRitual()
    {
        if (memory.favoriteHuman == null) { EnterState(BeastieState.Idle); return; }
        Transform anchor = memory.favoriteHuman;
        float orbitRadius = 0.9f;
        currentOrbitAngle += (2.7f + stubbornness) * Time.deltaTime;
        Vector3 offset = new Vector3(Mathf.Cos(currentOrbitAngle), 0f, Mathf.Sin(currentOrbitAngle)) * orbitRadius;
        MoveToward(anchor.position + offset, walkSpeed);

        if (stateTimer >= 1.15f)
        {
            completedRitualCircles++;
            stateTimer = 0f;
            if (completedRitualCircles >= requiredRitualCircles)
            {
                humanAnchor.ResolveEquipRequest(true);
                memory.lastSuccessfulRitualTime = Time.time;
                touchPermission = Mathf.Clamp01(touchPermission + 0.15f);
                EnterState(BeastieState.Following);
            }
        }
    }

    void TickZoomies()
    {
        Vector3 target = zoomieCenter + Random.insideUnitSphere * 2.2f;
        target.y = transform.position.y;
        MoveToward(target, runSpeed);
        playDrive = Mathf.Clamp01(playDrive - Time.deltaTime * 0.22f);
        restDrive = Mathf.Clamp01(restDrive + Time.deltaTime * 0.08f);
        if (stateTimer >= chosenStateDuration) EnterState(BeastieState.Settling);
    }

    void TickSeekingComfort()
    {
        if (currentComfortSpot == null) { EnterState(BeastieState.Idle); return; }
        MoveToward(currentComfortSpot.GetBestPoint(), walkSpeed);
        if (currentComfortSpot.IsPointInside(transform.position))
        {
            memory.favoriteComfortSpot = currentComfortSpot;
            memory.RecordRestPosition(transform.position);
            if (currentComfortSpot.displayPrestige > 6f) EnterState(BeastieState.AdmiringPose);
            else EnterState(BeastieState.Resting);
        }
    }

    void TickResting()
    {
        FaceHumanSoftly();
        if (stateTimer >= chosenStateDuration)
        {
            if (admirationNeed > 0.5f) EnterState(BeastieState.AdmiringPose);
            else EnterState(BeastieState.Idle);
        }
    }

    void TickSettling()
    {
        FaceHumanSoftly();
        if (stateTimer >= chosenStateDuration)
        {
            if (ShouldSeekComfort()) EnterSeekComfort(); else EnterState(BeastieState.Resting);
        }
    }

    void TickAdmiringPose()
    {
        if (currentComfortSpot == null || currentComfortSpot.displayPrestige < 5f)
            currentComfortSpot = FindBestDisplayOrComfortSpot();
        if (currentComfortSpot != null && !currentComfortSpot.IsPointInside(transform.position))
        {
            MoveToward(currentComfortSpot.GetBestPoint(), walkSpeed);
            return;
        }
        FaceHumanSoftly();
        if (stateTimer > 2.5f) EnterState(BeastieState.RoyalObserve);
    }

    void TickRoyalObserve()
    {
        if (memory.favoriteHuman == null) { EnterState(BeastieState.Idle); return; }
        float dist = Vector3.Distance(transform.position, memory.favoriteHuman.position);
        if (dist < regalDistance) MoveAwayFrom(memory.favoriteHuman.position, walkSpeed * 0.9f);
        else if (dist > regalDistance + 0.8f) MoveToward(memory.favoriteHuman.position, walkSpeed * 0.7f);
        else FaceHumanSoftly();

        if (admirationReceived > 0.45f) EnterState(BeastieState.ReluctantApproach);
        if (stateTimer > 6f && ShouldDoZoomies()) EnterZoomies();
    }

    void TickReluctantApproach()
    {
        if (memory.favoriteHuman == null) { EnterState(BeastieState.Idle); return; }
        Vector3 target = GetOffsetFromHuman(1.1f);
        MoveToward(target, walkSpeed);
        if (stateTimer > 1.25f)
        {
            touchPermission = Mathf.Clamp01(touchPermission + 0.18f);
            if (CanAllowPet()) EnterState(BeastieState.AllowBriefPet);
            else EnterState(BeastieState.RoyalObserve);
        }
    }

    void TickAllowBriefPet()
    {
        FaceHumanSoftly();
        touchPermission = Mathf.Clamp01(touchPermission - Time.deltaTime * 0.18f);
        affectionDrive = Mathf.Clamp01(affectionDrive - Time.deltaTime * 0.1f);
        if (stateTimer >= chosenStateDuration) EnterState(BeastieState.GracefulWithdraw);
    }

    void TickGracefulWithdraw()
    {
        if (memory.favoriteHuman == null) { EnterState(BeastieState.Idle); return; }
        MoveAwayFrom(memory.favoriteHuman.position, walkSpeed);
        if (stateTimer >= chosenStateDuration)
        {
            if (admirationNeed > 0.55f) EnterState(BeastieState.AdmiringPose); else EnterState(BeastieState.Idle);
        }
    }

    void EnterState(BeastieState newState)
    {
        currentState = newState;
        stateTimer = 0f;
        switch (newState)
        {
            case BeastieState.Idle: chosenStateDuration = Random.Range(1.5f, 3.5f); break;
            case BeastieState.Greeting: chosenStateDuration = 2.5f; break;
            case BeastieState.Resting: chosenStateDuration = Random.Range(4f, 9f); break;
            case BeastieState.Settling: chosenStateDuration = 2f; break;
            case BeastieState.Zoomies: chosenStateDuration = Random.Range(2.5f, 5f); break;
            case BeastieState.AllowBriefPet: chosenStateDuration = Mathf.Lerp(1.2f, 3f, pettingTolerance); break;
            case BeastieState.GracefulWithdraw: chosenStateDuration = 1.5f; break;
            case BeastieState.ReluctantApproach: chosenStateDuration = 1.4f; break;
        }
    }

    void EnterOrbitRitual()
    {
        EnterState(BeastieState.OrbitRitual);
        completedRitualCircles = 0;
        requiredRitualCircles = Random.Range(1, 4);
        currentOrbitAngle = Random.Range(0f, Mathf.PI * 2f);
    }

    void EnterZoomies()
    {
        EnterState(BeastieState.Zoomies);
        zoomieCenter = transform.position;
    }

    void EnterSeekComfort()
    {
        currentComfortSpot = FindBestDisplayOrComfortSpot();
        if (currentComfortSpot == null) { EnterState(BeastieState.Idle); return; }
        EnterState(BeastieState.SeekingComfort);
    }

    bool CanAllowPet()
    {
        float score = touchPermission * 0.45f + admirationReceived * 0.25f + (1f - socialReserve) * 0.15f + memory.bondStrength * 0.15f;
        return score > Mathf.Lerp(0.78f, 0.55f, pettingTolerance);
    }

    bool ShouldDoZoomies() => playDrive > 0.82f && restDrive < 0.7f && Random.value < 0.02f;
    bool ShouldSeekComfort() => comfortDrive < 0.45f || restDrive > 0.72f;
    bool ShouldFollowHuman()
    {
        if (memory.favoriteHuman == null) return false;
        float d = Vector3.Distance(transform.position, memory.favoriteHuman.position);
        return d > followDistance && affection > 0.4f && admirationNeed < 0.75f;
    }

    void MoveToward(Vector3 target, float speed)
    {
        Vector3 flatTarget = new Vector3(target.x, transform.position.y, target.z);
        Vector3 toTarget = flatTarget - transform.position;
        if (toTarget.magnitude > 0.05f)
        {
            Vector3 dir = toTarget.normalized;
            Quaternion rot = Quaternion.LookRotation(dir, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, rot, Time.deltaTime * turnSpeed);
            controller.Move(dir * speed * Time.deltaTime);
        }
    }

    void MoveAwayFrom(Vector3 target, float speed)
    {
        Vector3 away = transform.position - target;
        away.y = 0f;
        if (away.sqrMagnitude < 0.01f) away = -transform.forward;
        MoveToward(transform.position + away.normalized, speed);
    }

    Vector3 GetOffsetFromHuman(float distance)
    {
        Vector3 dir = (transform.position - memory.favoriteHuman.position).normalized;
        if (dir.sqrMagnitude < 0.01f) dir = memory.favoriteHuman.right;
        return memory.favoriteHuman.position + dir * distance;
    }

    void FaceHumanSoftly()
    {
        if (memory.favoriteHuman == null) return;
        Vector3 toHuman = memory.favoriteHuman.position - transform.position;
        toHuman.y = 0f;
        if (toHuman.sqrMagnitude > 0.01f)
        {
            Quaternion rot = Quaternion.LookRotation(toHuman.normalized, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, rot, Time.deltaTime * turnSpeed * 0.5f);
        }
    }

    void ApplyGravity()
    {
        if (controller.isGrounded && velocity.y < 0f) velocity.y = -2f;
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }

    ComfortSpot FindBestDisplayOrComfortSpot()
    {
        ComfortSpot best = memory.favoriteComfortSpot;
        float bestScore = float.MinValue;
        foreach (ComfortSpot spot in knownComfortSpots)
        {
            if (spot == null) continue;
            float score = spot.GetComfortScore(transform.position, memory.favoriteHuman);
            score += spot.displayPrestige * vanity;
            if (spot == memory.favoriteComfortSpot) score += 1.5f;
            if (score > bestScore) { bestScore = score; best = spot; }
        }
        return best;
    }
}
