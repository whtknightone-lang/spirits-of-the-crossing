using UnityEngine;

public class HumanInteractionAnchor : MonoBehaviour
{
    public bool leashRequested;
    public bool pantsRequested;
    public bool admirationRequested;
    public bool petAttemptRequested;
    [Range(0f, 1f)] public float calmApproachLevel = 0.7f;

    public bool HasEquipRequest => leashRequested || pantsRequested;

    public void RequestLeash() { leashRequested = true; }
    public void RequestPants() { pantsRequested = true; }
    public void RequestAdmiration() { admirationRequested = true; }
    public void RequestPetAttempt() { petAttemptRequested = true; }

    public void ResolveEquipRequest(bool success)
    {
        if (success)
        {
            leashRequested = false;
            pantsRequested = false;
        }
    }

    public void ClearMomentaryRequests()
    {
        admirationRequested = false;
        petAttemptRequested = false;
    }

    public void ClearAllRequests()
    {
        leashRequested = false;
        pantsRequested = false;
        admirationRequested = false;
        petAttemptRequested = false;
    }
}
