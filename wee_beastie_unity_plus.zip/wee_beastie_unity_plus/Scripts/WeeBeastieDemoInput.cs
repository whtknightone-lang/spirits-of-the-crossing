using UnityEngine;

public class WeeBeastieDemoInput : MonoBehaviour
{
    public HumanInteractionAnchor humanAnchor;
    public WeeBeastieAI beastie;
    public BeastieCapsuleBodyRig rig;

    void Update()
    {
        if (humanAnchor != null)
        {
            if (Input.GetKeyDown(KeyCode.L)) humanAnchor.RequestLeash();
            if (Input.GetKeyDown(KeyCode.P)) humanAnchor.RequestPants();
            if (Input.GetKeyDown(KeyCode.A)) humanAnchor.RequestAdmiration();
            if (Input.GetKeyDown(KeyCode.T)) humanAnchor.RequestPetAttempt();
            if (Input.GetKeyDown(KeyCode.C)) humanAnchor.ClearAllRequests();
        }
        if (beastie != null)
        {
            if (Input.GetKeyDown(KeyCode.Z)) beastie.playDrive = 1f;
            if (Input.GetKeyDown(KeyCode.G)) beastie.affectionDrive = 1f;
            if (Input.GetKeyDown(KeyCode.R)) beastie.restDrive = 1f;
            if (Input.GetKeyDown(KeyCode.O)) beastie.admirationReceived = 1f;
        }
        if (rig != null && Input.GetKeyDown(KeyCode.B)) rig.BuildCapsuleBody();
    }
}
