using UnityEngine;

[System.Serializable]
public class SocialPresence
{
    [Range(0f, 1f)] public float elegance = 0.95f;
    [Range(0f, 1f)] public float intimidation = 0.2f;
    [Range(0f, 1f)] public float charm = 0.75f;
    [Range(0f, 1f)] public float mystery = 0.7f;
    [Range(0f, 1f)] public float trustworthiness = 0.6f;
    [Range(0f, 1f)] public float magnetism = 0.9f;
}
