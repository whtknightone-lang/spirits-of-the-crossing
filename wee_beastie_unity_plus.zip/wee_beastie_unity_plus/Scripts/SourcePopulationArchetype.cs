using UnityEngine;

[CreateAssetMenu(menuName = "Source Planet/Population Archetype")]
public class SourcePopulationArchetype : ScriptableObject
{
    public string archetypeName = "Spirit";
    [Range(0f, 1f)] public float mythicalWeight = 0.8f;
    [Range(0f, 1f)] public float fogPresence = 0.7f;
    [Range(0f, 1f)] public float glimpseBias = 0.8f;
    [Range(0f, 1f)] public float heightBias = 0.5f;
    [Range(0f, 1f)] public float movementGrace = 0.7f;
}
