using System.Collections.Generic;

public static class RoleAffinityScorer
{
    public static Dictionary<EmergentRole, float> ScoreRoles(ArchetypeTraits t, SocialPresence s)
    {
        Dictionary<EmergentRole, float> scores = new Dictionary<EmergentRole, float>();

        scores[EmergentRole.Guardian] = t.strength * 0.28f + t.courage * 0.22f + t.loyalty * 0.2f + s.trustworthiness * 0.15f + s.intimidation * 0.15f;
        scores[EmergentRole.Scout] = t.agility * 0.35f + t.curiosity * 0.25f + t.intelligence * 0.15f + t.slyness * 0.15f + s.mystery * 0.1f;
        scores[EmergentRole.Trickster] = t.slyness * 0.35f + t.intelligence * 0.2f + t.agility * 0.15f + s.charm * 0.15f + s.mystery * 0.15f;
        scores[EmergentRole.CourtlyBeauty] = t.beauty * 0.35f + s.elegance * 0.25f + s.magnetism * 0.2f + t.rituality * 0.1f + t.dominance * 0.1f;
        scores[EmergentRole.Companion] = t.loyalty * 0.3f + t.empathy * 0.25f + t.sociability * 0.2f + s.charm * 0.15f + s.trustworthiness * 0.1f;
        scores[EmergentRole.Artisan] = t.craft * 0.4f + t.patience * 0.25f + t.intelligence * 0.2f + t.rituality * 0.15f;
        scores[EmergentRole.Healer] = t.empathy * 0.35f + t.patience * 0.25f + t.intelligence * 0.2f + s.trustworthiness * 0.2f;
        scores[EmergentRole.Diplomat] = t.intelligence * 0.2f + t.empathy * 0.2f + t.sociability * 0.2f + s.charm * 0.2f + s.trustworthiness * 0.2f;
        scores[EmergentRole.Watcher] = t.patience * 0.25f + t.curiosity * 0.2f + s.mystery * 0.2f + t.rituality * 0.2f + t.intelligence * 0.15f;
        scores[EmergentRole.RitualKeeper] = t.rituality * 0.35f + t.patience * 0.2f + t.loyalty * 0.15f + s.elegance * 0.15f + s.mystery * 0.15f;
        scores[EmergentRole.CeremonialGuardian] = t.loyalty * 0.2f + t.rituality * 0.25f + t.courage * 0.15f + s.elegance * 0.15f + s.trustworthiness * 0.15f + s.magnetism * 0.1f;
        return scores;
    }
}
