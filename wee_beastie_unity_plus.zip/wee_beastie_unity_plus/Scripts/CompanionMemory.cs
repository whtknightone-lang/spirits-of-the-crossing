using UnityEngine;

public class CompanionMemory : MonoBehaviour
{
    public Transform favoriteHuman;
    [Range(0f, 1f)] public float bondStrength = 0.82f;

    public ComfortSpot favoriteComfortSpot;
    public Vector3 lastKnownHumanPosition;
    public Vector3 lastRestPosition;
    public float lastSuccessfulRitualTime;
    public float admirationBank = 0.25f;
    public float trustBank = 0.6f;

    public void RecordHumanPosition(Vector3 pos) { lastKnownHumanPosition = pos; }
    public void RecordRestPosition(Vector3 pos) { lastRestPosition = pos; }
}
