using UnityEngine;

public class BeastieSimpleAnimationDriver : MonoBehaviour
{
    public BeastieCapsuleBodyRig rig;
    public WeeBeastieAI ai;
    public float tailWagSpeed = 7f;
    public float tailWagAmount = 22f;
    public float bodyBobSpeed = 4f;
    public float bodyBobAmount = 0.015f;

    Vector3 bodyStart;
    Quaternion tailStart;

    void Start()
    {
        if (rig == null) rig = GetComponent<BeastieCapsuleBodyRig>();
        if (ai == null) ai = GetComponent<WeeBeastieAI>();
        if (rig != null && rig.body != null) bodyStart = rig.body.localPosition;
        if (rig != null && rig.tail != null) tailStart = rig.tail.localRotation;
    }

    void Update()
    {
        if (rig == null) return;
        float moveAmp = ai != null && (ai.currentState == WeeBeastieAI.BeastieState.Zoomies || ai.currentState == WeeBeastieAI.BeastieState.Following) ? 1f : 0.35f;
        if (rig.body != null)
        {
            rig.body.localPosition = bodyStart + Vector3.up * Mathf.Sin(Time.time * bodyBobSpeed) * bodyBobAmount * moveAmp;
        }
        if (rig.tail != null)
        {
            float wag = Mathf.Sin(Time.time * tailWagSpeed) * tailWagAmount * moveAmp;
            rig.tail.localRotation = tailStart * Quaternion.Euler(wag, 0f, 0f);
        }
    }
}
