using System.Collections.Generic;
using UnityEngine;

public class SourcePlanetPopulationController : MonoBehaviour
{
    public List<SourcePopulationArchetype> archetypes = new List<SourcePopulationArchetype>();
    public int populationCount = 120;
    public float radius = 40f;
    public bool spawnOnStart = true;
    public Transform populationRoot;

    [Header("Visual")]
    public bool usePrimitiveBodies = true;
    public float minScale = 0.5f;
    public float maxScale = 2.2f;

    void Start()
    {
        if (spawnOnStart) SpawnPopulation();
    }

    [ContextMenu("Spawn Population")]
    public void SpawnPopulation()
    {
        if (populationRoot == null)
        {
            GameObject root = new GameObject("SourcePopulation");
            root.transform.SetParent(transform, false);
            populationRoot = root.transform;
        }
        ClearPopulation();
        for (int i = 0; i < populationCount; i++)
        {
            Vector2 c = Random.insideUnitCircle * radius;
            Vector3 pos = transform.position + new Vector3(c.x, Random.Range(-1f, 3f), c.y);
            CreateAgent(pos, i);
        }
    }

    void CreateAgent(Vector3 pos, int index)
    {
        GameObject agent = new GameObject("FogBeing_" + index);
        agent.transform.SetParent(populationRoot, false);
        agent.transform.position = pos;
        agent.transform.rotation = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);

        if (usePrimitiveBodies)
        {
            PrimitiveType type = (index % 3 == 0) ? PrimitiveType.Capsule : (index % 3 == 1) ? PrimitiveType.Sphere : PrimitiveType.Cylinder;
            GameObject body = GameObject.CreatePrimitive(type);
            body.transform.SetParent(agent.transform, false);
            body.transform.localPosition = Vector3.zero;
            float s = Random.Range(minScale, maxScale);
            body.transform.localScale = new Vector3(s * 0.6f, s, s * 0.6f);
            Renderer r = body.GetComponent<Renderer>();
            if (r != null)
            {
                r.material = new Material(Shader.Find("Standard"));
                Color color = Color.Lerp(new Color(1f, 1f, 1f, 0.18f), new Color(0.75f, 0.9f, 1f, 0.5f), Random.value);
                r.material.color = color;
                r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            }
            Collider col = body.GetComponent<Collider>();
            if (col != null) Destroy(col);
        }

        FogCrowdAgent fog = agent.AddComponent<FogCrowdAgent>();
        fog.moveRadius = Random.Range(1.5f, 5f);
        fog.driftSpeed = Random.Range(0.25f, 0.9f);
        fog.visibilityPulseSpeed = Random.Range(0.3f, 1.1f);
        fog.glimpseAmount = Random.Range(0.35f, 0.9f);
    }

    [ContextMenu("Clear Population")]
    public void ClearPopulation()
    {
        if (populationRoot == null) return;
        for (int i = populationRoot.childCount - 1; i >= 0; i--)
        {
            GameObject child = populationRoot.GetChild(i).gameObject;
            if (Application.isPlaying) Destroy(child); else DestroyImmediate(child);
        }
    }
}
