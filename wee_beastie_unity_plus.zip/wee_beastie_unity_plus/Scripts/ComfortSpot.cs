using UnityEngine;

public class ComfortSpot : MonoBehaviour
{
    [Range(0f, 10f)] public float softness = 8f;
    [Range(0f, 10f)] public float sunlight = 5f;
    [Range(0f, 10f)] public float familiarity = 7f;
    [Range(0f, 10f)] public float nearHumanPreference = 6f;
    [Range(0f, 10f)] public float displayPrestige = 4f;
    public float radius = 0.75f;

    public Vector3 GetBestPoint() => transform.position;

    public bool IsPointInside(Vector3 point)
    {
        Vector3 a = new Vector3(point.x, 0f, point.z);
        Vector3 b = new Vector3(transform.position.x, 0f, transform.position.z);
        return Vector3.Distance(a, b) <= radius;
    }

    public float GetComfortScore(Vector3 beastiePosition, Transform human)
    {
        float score = softness + sunlight + familiarity + displayPrestige * 0.5f;
        if (human != null)
        {
            float distToHuman = Vector3.Distance(transform.position, human.position);
            score += Mathf.Max(0f, nearHumanPreference - distToHuman);
        }
        float distToBeastie = Vector3.Distance(transform.position, beastiePosition);
        score -= distToBeastie * 0.35f;
        return score;
    }
}
