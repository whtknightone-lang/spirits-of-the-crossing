using UnityEngine;

public class FogCrowdAgent : MonoBehaviour
{
    public float moveRadius = 3f;
    public float driftSpeed = 0.6f;
    public float visibilityPulseSpeed = 0.8f;
    public float glimpseAmount = 0.5f;

    Vector3 origin;
    Vector3 nextTarget;
    Renderer[] renderers;

    void Start()
    {
        origin = transform.position;
        nextTarget = origin;
        renderers = GetComponentsInChildren<Renderer>();
    }

    void Update()
    {
        if ((transform.position - nextTarget).sqrMagnitude < 0.2f)
        {
            Vector2 c = Random.insideUnitCircle * moveRadius;
            nextTarget = origin + new Vector3(c.x, 0f, c.y);
        }
        transform.position = Vector3.MoveTowards(transform.position, nextTarget, driftSpeed * Time.deltaTime);
        transform.Rotate(0f, 12f * Time.deltaTime, 0f);

        float pulse = Mathf.Lerp(0.15f, 1f, (Mathf.Sin(Time.time * visibilityPulseSpeed + transform.position.x) + 1f) * 0.5f * glimpseAmount);
        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] != null && renderers[i].material.HasProperty("_Color"))
            {
                Color c = renderers[i].material.color;
                c.a = pulse;
                renderers[i].material.color = c;
            }
        }
    }
}
