
V196 AI Experience Generation Layer

Adds:
- AI-generated quests and experiences
- Player-adaptive content creation
- Experience planner system
- Integration with player relationship + resonance

Core Idea:
AI actively creates experiences tailored to each player.
