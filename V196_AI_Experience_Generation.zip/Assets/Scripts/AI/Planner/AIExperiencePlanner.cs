
using UnityEngine;

public class AIExperiencePlanner : MonoBehaviour
{
    public AIExperienceGenerator generator;
    public string currentExperience;

    void Update()
    {
        if (generator == null) return;

        currentExperience = generator.GenerateExperience();
    }
}
