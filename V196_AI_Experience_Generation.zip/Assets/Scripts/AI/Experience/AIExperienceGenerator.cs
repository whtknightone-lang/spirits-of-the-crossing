
using UnityEngine;

public class AIExperienceGenerator : MonoBehaviour
{
    public float playerResonance;
    public float relationshipStrength;

    public string GenerateExperience()
    {
        if (relationshipStrength > 0.7f)
            return "Create shared journey experience";

        if (playerResonance > 0.7f)
            return "Open high resonance pathway";

        if (playerResonance < 0.3f)
            return "Stabilization challenge";

        return "Exploration sequence";
    }
}
