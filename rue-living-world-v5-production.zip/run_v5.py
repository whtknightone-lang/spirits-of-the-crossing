
from engine.core.universe import Universe
from engine.agents.agent import Agent
from engine.player.player import Player

u = Universe()
player = Player()

# seed agents
u.agents = [Agent(i%3, i%5) for i in range(50)]

for i in range(200):
    for a in u.agents:
        a.step()
    player.act(u)
    u.step()

    if i % 50 == 0:
        print("Step:", i, "Agents:", len(u.agents))
