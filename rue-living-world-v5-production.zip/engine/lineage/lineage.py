
def update_lineage(agents):
    for a in agents:
        if a.energy > 2.0:
            a.lineage += 1
