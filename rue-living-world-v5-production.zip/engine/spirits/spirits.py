
class Spirit:
    def __init__(self, level="MINOR"):
        self.level = level

    def act(self, agents):
        for a in agents:
            if self.level == "MINOR":
                a.energy += 0.001
