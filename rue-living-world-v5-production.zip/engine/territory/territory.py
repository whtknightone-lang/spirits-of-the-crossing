
def update_territory(universe):
    universe.territory = {}
