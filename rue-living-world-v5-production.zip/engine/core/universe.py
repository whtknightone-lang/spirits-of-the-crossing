
class Universe:
    def __init__(self):
        self.time = 0
        self.agents = []
        self.planets = []
        self.spirits = []
        self.history = []

    def step(self):
        self.time += 1
        self.update_agents()
        self.update_environment()
        self.update_spirits()
        self.update_lineage()
        self.update_territory()
        self.update_mythology()
        self.update_player()

    def update_agents(self): pass
    def update_environment(self): pass
    def update_spirits(self): pass
    def update_lineage(self): pass
    def update_territory(self): pass
    def update_mythology(self): pass
    def update_player(self): pass
