
class Player:
    def __init__(self):
        self.energy = 5.0

    def act(self, universe):
        for a in universe.agents:
            a.energy += 0.001
