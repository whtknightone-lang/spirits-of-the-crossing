
import random

BIOMES = ["FOREST","DESERT","WATER","PLAINS","RUINS"]

def evolve_biome(current):
    if random.random() < 0.01:
        return random.choice(BIOMES)
    return current
