
def record(universe):
    if universe.time % 50 == 0:
        universe.history.append(f"Event at step {universe.time}")
