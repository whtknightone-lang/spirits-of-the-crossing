
class Agent:
    def __init__(self, planet_id=0, region_id=0):
        self.energy = 1.0
        self.planet_id = planet_id
        self.region_id = region_id
        self.lineage = 0
        self.role = "EXPLORER"

    def step(self):
        self.energy *= 0.99
