
print("Running RUE Living World Engine V4")

def step():
    print("Step executed in V4")

if __name__ == "__main__":
    for i in range(5):
        step()
