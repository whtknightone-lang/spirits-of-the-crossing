
# V115 Interactive Control Panel

Adds:
- Player control panel (sliders)
- Real-time influence over universe systems
- Hooks into civilization, source, and dark pressure

Goal:
Turn the dashboard into a playable "god interface"
