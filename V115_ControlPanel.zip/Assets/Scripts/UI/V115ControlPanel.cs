
using UnityEngine;
using ArtificialUniverse.Control;

namespace ArtificialUniverse.UI
{
    public class V115ControlPanel : MonoBehaviour
    {
        private UniverseControlSystem control;

        void Awake()
        {
            control = FindObjectOfType<UniverseControlSystem>();
        }

        void OnGUI()
        {
            if (control == null) return;

            int y = 250;

            GUI.Label(new Rect(20,y,300,25),"=== CONTROL PANEL ==="); y+=25;

            GUI.Label(new Rect(20,y,200,25),"Source Flow"); 
            control.sourceFlow = GUI.HorizontalSlider(new Rect(150,y+5,150,20), control.sourceFlow, 0f, 1f); y+=30;

            GUI.Label(new Rect(20,y,200,25),"Dark Pressure"); 
            control.darkPressure = GUI.HorizontalSlider(new Rect(150,y+5,150,20), control.darkPressure, 0f, 1f); y+=30;

            GUI.Label(new Rect(20,y,200,25),"Growth"); 
            control.growthMultiplier = GUI.HorizontalSlider(new Rect(150,y+5,150,20), control.growthMultiplier, 0.5f, 2f); y+=40;

            GUI.Label(new Rect(20,y,400,25),"Adjust sliders to shape the universe in real-time");
        }
    }
