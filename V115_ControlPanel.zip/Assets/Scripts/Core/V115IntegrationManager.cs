
using UnityEngine;
using ArtificialUniverse.Control;

namespace ArtificialUniverse.Core
{
    public class V115IntegrationManager : MonoBehaviour
    {
        void Start()
        {
            if (FindObjectOfType<UniverseControlSystem>() == null)
            {
                gameObject.AddComponent<UniverseControlSystem>();
            }

            if (FindObjectOfType<ArtificialUniverse.UI.V115ControlPanel>() == null)
            {
                gameObject.AddComponent<ArtificialUniverse.UI.V115ControlPanel>();
            }
        }
    }
