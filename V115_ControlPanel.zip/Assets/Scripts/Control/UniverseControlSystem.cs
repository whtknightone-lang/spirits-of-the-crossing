
using UnityEngine;
using ArtificialUniverse.Civilization;
using ArtificialUniverse.Source;

namespace ArtificialUniverse.Control
{
    public class UniverseControlSystem : MonoBehaviour
    {
        [Range(0f,1f)] public float sourceFlow = 0.6f;
        [Range(0f,1f)] public float darkPressure = 0.3f;
        [Range(0f,2f)] public float growthMultiplier = 1.0f;

        private CivilizationSystem civ;
        private SourceDarkFeedbackSystem source;

        void Awake()
        {
            civ = FindObjectOfType<CivilizationSystem>();
            source = FindObjectOfType<SourceDarkFeedbackSystem>();
        }

        void Update()
        {
            if (civ != null)
            {
                civ.harmony = Mathf.Clamp01(civ.harmony + (sourceFlow - 0.5f) * 0.01f);
                civ.conflict = Mathf.Clamp01(civ.conflict + (darkPressure - 0.5f) * 0.01f);
                civ.population *= growthMultiplier;
            }

            if (source != null)
            {
                source.sourceMood = sourceFlow;
                source.darkPlanetPressure = darkPressure;
            }
        }
    }
