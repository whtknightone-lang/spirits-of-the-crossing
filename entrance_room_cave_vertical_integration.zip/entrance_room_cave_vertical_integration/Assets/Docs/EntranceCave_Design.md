# Entrance Room / Cave Vertical Design

## Scene Intent
The cave is the first embodied lesson. It is not merely a starter room; it is the womb, threshold, and acoustic chamber where Source first meets the player in a form they can actually follow.

## Cave-specific themes
- Darkness without abandonment
- Echo as guidance rather than confusion
- Rock, water, wind, and light as living teachers
- Worthiness demonstrated by the world itself
- Contrast presented safely so the player learns discernment
- The first portal into cosmos-scale growth

## Main objects
- CaveMouthThreshold
- ResonancePool
- SourceCrystal
- EchoStoneRing
- PlanetSeedStalagmite
- ShadowFissure
- SpiritGuidePerch
- PortalArch

## Core loop
1. Enter cave and receive low-amplitude Source hum.
2. Read player resonance and select a bridge invitation.
3. World nature responds: drops, cave lights, wind eddies, mineral singing.
4. Cave demonstrates the player's worthiness and importance through playful confirmation.
5. Shadow fissure amplifies a tempting but misaligned signal.
6. Player chooses the subtler true resonance.
7. Portal arch stabilizes.
8. Planet seed awakens and logs a cosmos event.
9. Universe receives both problem and solution as one birth memory.

## Why the cave matters
The cave makes all later planetary and cosmic realms legible. It teaches that Source is pure, adaptive, and relational, while the world participates in testing, affirming, and demonstrating meaning.
