# Scene Setup: EntranceCave_VR

## GameObjects
- GameRoot
- XROrigin
- CaveEnvironment
- SourceCrystal
- ResonancePool
- PortalArch
- PlanetSeedStalagmite
- ShadowFissure
- SpiritGuidePerch
- Systems
  - XRInputRouter
  - ResonanceEngine
  - SourceGuidanceEngine
  - WorldNatureResponseEngine
  - WorthinessDemonstrationDirector
  - CaveThresholdDirector
  - ManifestationDirector
  - HapticsDirector
  - SpatialAudioDirector
  - PlanetNodeController
  - PlanetHistoryArchive
  - UniverseCycleDirector
  - MemoryArchive

## Wiring notes
- Assign `PlayerResonanceProfile` to all systems that read player state.
- Assign `SourceEssenceProfile` to `SourceGuidanceEngine`.
- Assign a cave-themed `WorldResponseProfile` to `WorldNatureResponseEngine`.
- Hook `CaveThresholdDirector` to `PortalController`, `PlanetNodeController`, and `UniverseCycleDirector`.
- Use editor keyboard values first, then XR hand/head input.

## Placeholder test plan
- Start in low coherence.
- Let the cave invite gently.
- Trigger a worthiness demonstration after first alignment improvement.
- Inject false signal from the ShadowFissure.
- Restore true signal by stillness/gesture/breath pacing.
- Open portal and record the event into planet history.
