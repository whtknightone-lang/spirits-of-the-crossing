using UnityEngine;
using Resonance.Resonance;

namespace Resonance.SourceSystem
{
    public class SourceGuidanceEngine : MonoBehaviour
    {
        [SerializeField] private SourceEssenceProfile essence;
        [Range(0f, 1f)] public float directness = 0.4f;
        [Range(0f, 1f)] public float gentleness = 0.9f;

        public GuidanceBridge BuildBridge(PlayerResonanceProfile player)
        {
            var desired = player.GetStrongestDesiredOutcome();
            var resisted = player.GetAvoidedThreshold();
            if (desired == null || resisted == null || essence == null || !essence.IsPure())
            {
                return null;
            }

            return new GuidanceBridge
            {
                playerAvoidsId = resisted.id,
                playerWantsId = desired.id,
                bridgeSymbol = SelectBridgeSymbol(player, desired),
                bridgeMessage = $"Pass through {resisted.label} and move toward {desired.label}.",
                bridgeIntensity = Mathf.Clamp01(desired.strength * 0.5f + resisted.fearResistance * 0.3f + (1f - player.trust) * 0.2f),
                likelyAcceptance = Mathf.Clamp01(player.trust * 0.35f + player.openness * 0.35f + desired.readiness * 0.30f)
            };
        }

        private string SelectBridgeSymbol(PlayerResonanceProfile player, DesireSignal desired)
        {
            if (player.coherence < 0.4f) return "EchoPulse";
            if (desired.label != null && desired.label.ToLower().Contains("growth")) return "MineralBloom";
            if (desired.label != null && desired.label.ToLower().Contains("freedom")) return "PortalWind";
            return "GoldenThread";
        }
    }
}
