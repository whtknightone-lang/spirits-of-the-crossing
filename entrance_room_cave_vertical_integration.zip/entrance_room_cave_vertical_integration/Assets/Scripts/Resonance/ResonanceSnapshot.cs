namespace Resonance.Resonance
{
    public struct ResonanceSnapshot
    {
        public float harmony;
        public float signalClarity;
        public float manifestation;
        public float portalReadiness;
        public float distortionRisk;
    }
}
