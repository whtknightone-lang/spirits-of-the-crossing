using UnityEngine;
using Resonance.SourceSystem;

namespace Resonance.Resonance
{
    public class ResonanceEngine : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile player;
        [SerializeField] private SourceGuidanceEngine sourceGuidance;

        public ResonanceSnapshot CurrentSnapshot { get; private set; }
        public GuidanceBridge CurrentBridge { get; private set; }

        private void Update()
        {
            if (player == null || sourceGuidance == null) return;
            CurrentBridge = sourceGuidance.BuildBridge(player);

            float harmony = Mathf.Clamp01(player.coherence * 0.45f + player.trust * 0.25f + player.joy * 0.2f + player.openness * 0.1f);
            CurrentSnapshot = new ResonanceSnapshot
            {
                harmony = harmony,
                signalClarity = Mathf.Clamp01(harmony - player.shadowLoad * 0.35f + 0.25f),
                manifestation = Mathf.Clamp01(harmony * 0.6f + player.openness * 0.4f),
                portalReadiness = Mathf.Clamp01(harmony * 0.7f + player.trust * 0.3f),
                distortionRisk = Mathf.Clamp01(player.shadowLoad * 0.65f + (1f - harmony) * 0.35f)
            };
        }
    }
}
