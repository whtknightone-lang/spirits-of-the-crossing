using System.Collections.Generic;
using UnityEngine;
using Resonance.Input;

namespace Resonance.Resonance
{
    public class PlayerResonanceProfile : MonoBehaviour
    {
        [Range(0f, 1f)] public float coherence = 0.5f;
        [Range(0f, 1f)] public float trust = 0.5f;
        [Range(0f, 1f)] public float joy = 0.5f;
        [Range(0f, 1f)] public float openness = 0.5f;
        [Range(0f, 1f)] public float shadowLoad = 0.5f;
        public List<DesireSignal> desires = new List<DesireSignal>();

        public void UpdateFromXR(XRInputFrame frame)
        {
            coherence = Mathf.Clamp01(Mathf.Lerp(coherence, (frame.stillness + frame.breathProxy) * 0.5f, 0.1f));
            trust = Mathf.Clamp01(Mathf.Lerp(trust, frame.intentionAxis, 0.05f));
            openness = Mathf.Clamp01(Mathf.Lerp(openness, frame.breathProxy, 0.05f));
            joy = Mathf.Clamp01(Mathf.Lerp(joy, 0.45f + frame.stillness * 0.35f, 0.05f));
        }

        public DesireSignal GetStrongestDesiredOutcome()
        {
            DesireSignal best = null;
            float bestScore = float.MinValue;
            foreach (var desire in desires)
            {
                float score = desire.strength * 0.55f + desire.readiness * 0.30f - desire.fearResistance * 0.15f;
                if (score > bestScore)
                {
                    best = desire;
                    bestScore = score;
                }
            }
            return best;
        }

        public DesireSignal GetAvoidedThreshold()
        {
            DesireSignal best = null;
            float bestScore = float.MinValue;
            foreach (var desire in desires)
            {
                float score = desire.fearResistance * 0.6f + desire.strength * 0.25f + (1f - desire.readiness) * 0.15f;
                if (score > bestScore)
                {
                    best = desire;
                    bestScore = score;
                }
            }
            return best;
        }
    }
}
