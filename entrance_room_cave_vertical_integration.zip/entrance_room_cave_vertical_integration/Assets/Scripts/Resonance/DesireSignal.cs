using System;

namespace Resonance.Resonance
{
    [Serializable]
    public class DesireSignal
    {
        public string id;
        public string label;
        public float strength = 0.5f;
        public float fearResistance = 0.5f;
        public float readiness = 0.5f;
    }
}
