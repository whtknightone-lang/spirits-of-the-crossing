using UnityEngine;
using Resonance.Resonance;

namespace Resonance.VR
{
    public class HapticsDirector : MonoBehaviour
    {
        [SerializeField] private ResonanceEngine engine;

        private void Update()
        {
            if (engine == null) return;
            // Placeholder for device SDK calls.
            float pulseStrength = engine.CurrentSnapshot.signalClarity;
            _ = pulseStrength;
        }
    }
}
