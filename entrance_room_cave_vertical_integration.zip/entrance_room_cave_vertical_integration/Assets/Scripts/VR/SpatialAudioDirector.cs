using UnityEngine;
using Resonance.Resonance;

namespace Resonance.VR
{
    public class SpatialAudioDirector : MonoBehaviour
    {
        [SerializeField] private ResonanceEngine engine;
        [SerializeField] private AudioSource sourceHum;
        [SerializeField] private AudioSource shadowHum;

        private void Update()
        {
            if (engine == null) return;
            if (sourceHum != null) sourceHum.volume = engine.CurrentSnapshot.signalClarity;
            if (shadowHum != null) shadowHum.volume = engine.CurrentSnapshot.distortionRisk * 0.8f;
        }
    }
}
