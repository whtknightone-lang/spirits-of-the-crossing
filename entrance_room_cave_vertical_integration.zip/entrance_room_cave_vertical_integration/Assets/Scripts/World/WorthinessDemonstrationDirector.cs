using UnityEngine;
using Resonance.Resonance;

namespace Resonance.World
{
    public class WorthinessDemonstrationDirector : MonoBehaviour
    {
        [SerializeField] private WorldResponseProfile profile;
        [SerializeField] private Renderer[] affirmingSurfaces;

        public void Demonstrate(PlayerResonanceProfile player)
        {
            if (profile == null || player == null) return;
            float worthy = Mathf.Clamp01(profile.worthinessEcho * 0.6f + player.trust * 0.4f);

            foreach (var surface in affirmingSurfaces)
            {
                if (surface != null && surface.material.HasProperty("_EmissionColor"))
                {
                    surface.material.SetColor("_EmissionColor", Color.white * worthy);
                }
            }
        }
    }
}
