using UnityEngine;

namespace Resonance.World
{
    [CreateAssetMenu(menuName = "Resonance/World/Response Profile")]
    public class WorldResponseProfile : ScriptableObject
    {
        [Range(0f, 1f)] public float celebrationIntensity = 0.8f;
        [Range(0f, 1f)] public float contrastIntensity = 0.5f;
        [Range(0f, 1f)] public float playfulness = 0.6f;
        [Range(0f, 1f)] public float worthinessEcho = 0.9f;
        [Range(0f, 1f)] public float importanceReflection = 0.85f;
        [Range(0f, 1f)] public float shadowTolerance = 0.4f;
    }
}
