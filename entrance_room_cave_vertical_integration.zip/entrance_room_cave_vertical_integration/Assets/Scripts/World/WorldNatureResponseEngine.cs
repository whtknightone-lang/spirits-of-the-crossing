using UnityEngine;
using Resonance.Resonance;
using Resonance.SourceSystem;

namespace Resonance.World
{
    public class WorldNatureResponseEngine : MonoBehaviour
    {
        [SerializeField] private WorldResponseProfile profile;
        [SerializeField] private Light caveLight;
        [SerializeField] private AudioSource worldTone;

        public void ApplyResponse(PlayerResonanceProfile player, GuidanceBridge bridge)
        {
            if (profile == null || player == null) return;

            float celebratory = Mathf.Clamp01(player.coherence * 0.5f + player.joy * 0.25f + profile.celebrationIntensity * 0.25f);
            float contrast = Mathf.Clamp01(player.shadowLoad * 0.5f + profile.contrastIntensity * 0.5f);

            if (caveLight != null)
            {
                caveLight.intensity = Mathf.Lerp(0.75f, 2.5f, celebratory);
            }

            if (worldTone != null)
            {
                worldTone.pitch = Mathf.Lerp(0.85f, 1.12f, celebratory);
                worldTone.volume = Mathf.Lerp(0.2f, 0.8f, 1f - contrast * 0.5f);
            }
        }
    }
}
