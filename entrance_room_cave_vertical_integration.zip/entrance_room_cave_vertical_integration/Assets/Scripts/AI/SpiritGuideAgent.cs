using UnityEngine;
using Resonance.Resonance;

namespace Resonance.AI
{
    public class SpiritGuideAgent : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile player;

        public string GetGuidanceLine()
        {
            if (player == null) return "Listen.";
            if (player.coherence < 0.45f) return "Be still enough to hear the cave sing back to you.";
            if (player.shadowLoad > 0.55f) return "Not every bright call is true. Stay with the gentler one.";
            return "You are being welcomed. Step through.";
        }
    }
}
