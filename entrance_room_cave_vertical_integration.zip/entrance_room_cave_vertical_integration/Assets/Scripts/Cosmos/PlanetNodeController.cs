using UnityEngine;
using Resonance.Resonance;

namespace Resonance.Cosmos
{
    public class PlanetNodeController : MonoBehaviour
    {
        [SerializeField] private ResonanceEngine engine;
        [SerializeField] private PlanetHistoryArchive archive;
        [Range(0f, 1f)] public float growth;

        public void RegisterCaveOutcome(float worthiness)
        {
            if (engine == null) return;
            growth = Mathf.Clamp01(growth + engine.CurrentSnapshot.manifestation * 0.2f + worthiness * 0.15f);
            archive?.Record(new PlanetResonanceEvent
            {
                eventLabel = "Entrance Cave Attunement",
                harmony = engine.CurrentSnapshot.harmony,
                contrast = engine.CurrentSnapshot.distortionRisk,
                worthiness = worthiness
            });
        }
    }
}
