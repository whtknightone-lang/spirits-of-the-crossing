using System.Collections.Generic;
using UnityEngine;

namespace Resonance.Cosmos
{
    public class PlanetHistoryArchive : MonoBehaviour
    {
        public readonly List<PlanetResonanceEvent> events = new List<PlanetResonanceEvent>();

        public void Record(PlanetResonanceEvent evt)
        {
            if (evt != null)
            {
                events.Add(evt);
            }
        }
    }
}
