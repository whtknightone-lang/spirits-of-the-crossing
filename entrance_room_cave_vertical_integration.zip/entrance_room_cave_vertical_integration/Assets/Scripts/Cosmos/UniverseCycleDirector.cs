using UnityEngine;

namespace Resonance.Cosmos
{
    public class UniverseCycleDirector : MonoBehaviour
    {
        [Range(0f, 1f)] public float birthMemory;
        [Range(0f, 1f)] public float rebirthPotential;

        public void RegisterEncounter(float harmony, float contrast)
        {
            birthMemory = Mathf.Clamp01(birthMemory + harmony * 0.12f);
            rebirthPotential = Mathf.Clamp01(rebirthPotential + contrast * 0.08f + harmony * 0.06f);
        }
    }
}
