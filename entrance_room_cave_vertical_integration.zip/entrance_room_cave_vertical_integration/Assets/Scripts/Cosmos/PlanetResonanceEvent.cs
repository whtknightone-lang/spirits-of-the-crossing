using System;

namespace Resonance.Cosmos
{
    [Serializable]
    public class PlanetResonanceEvent
    {
        public string eventLabel;
        public float harmony;
        public float contrast;
        public float worthiness;
    }
}
