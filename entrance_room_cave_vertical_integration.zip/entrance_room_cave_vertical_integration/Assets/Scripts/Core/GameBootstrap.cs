using UnityEngine;

namespace Resonance.Core
{
    public class GameBootstrap : MonoBehaviour
    {
        [SerializeField] private MonoBehaviour[] startupSystems;

        private void Start()
        {
            foreach (var system in startupSystems)
            {
                if (system != null)
                {
                    system.enabled = true;
                }
            }
        }
    }
}
