using UnityEngine;
using Resonance.Resonance;
using Resonance.World;
using Resonance.Gameplay;
using Resonance.Cosmos;
using Resonance.Persistence;

namespace Resonance.Core
{
    public class CaveThresholdDirector : MonoBehaviour
    {
        [SerializeField] private ResonanceEngine engine;
        [SerializeField] private WorldNatureResponseEngine worldNature;
        [SerializeField] private WorthinessDemonstrationDirector worthinessDirector;
        [SerializeField] private PortalController portal;
        [SerializeField] private PlanetNodeController planetNode;
        [SerializeField] private UniverseCycleDirector universeCycle;
        [SerializeField] private MemoryArchive memory;
        [SerializeField] private PlayerResonanceProfile player;

        private bool completionRecorded;

        private void Update()
        {
            if (engine == null || player == null) return;

            worldNature?.ApplyResponse(player, engine.CurrentBridge);
            worthinessDirector?.Demonstrate(player);

            if (!completionRecorded && portal != null && portal.IsOpen)
            {
                completionRecorded = true;
                float worthiness = Mathf.Clamp01(player.trust * 0.5f + player.joy * 0.25f + player.coherence * 0.25f);
                planetNode?.RegisterCaveOutcome(worthiness);
                universeCycle?.RegisterEncounter(engine.CurrentSnapshot.harmony, engine.CurrentSnapshot.distortionRisk);
                memory?.Add("Entrance cave opened the first portal and registered a birth/rebirth memory.");
            }
        }
    }
}
