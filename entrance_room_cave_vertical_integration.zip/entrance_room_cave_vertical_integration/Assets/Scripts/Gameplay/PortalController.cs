using UnityEngine;
using Resonance.Resonance;

namespace Resonance.Gameplay
{
    public class PortalController : MonoBehaviour
    {
        [SerializeField] private ResonanceEngine engine;
        [SerializeField] private GameObject portalVisual;
        [Range(0f,1f)] public float openThreshold = 0.72f;
        public bool IsOpen { get; private set; }

        private void Update()
        {
            if (engine == null) return;
            IsOpen = engine.CurrentSnapshot.portalReadiness >= openThreshold && engine.CurrentSnapshot.distortionRisk < 0.55f;
            if (portalVisual != null)
            {
                portalVisual.SetActive(IsOpen);
            }
        }
    }
}
