using UnityEngine;
using Resonance.Resonance;

namespace Resonance.Input
{
    public class XRInputRouter : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile player;

        private void Update()
        {
            var frame = new XRInputFrame
            {
                headForward = Camera.main != null ? Camera.main.transform.forward : Vector3.forward,
                stillness = 1f - Mathf.Abs(Input.GetAxisRaw("Horizontal")) * 0.5f,
                breathProxy = 0.5f + Mathf.Sin(Time.time) * 0.25f,
                vocalTone = 0.5f,
                intentionAxis = Mathf.Clamp01((Input.GetAxisRaw("Vertical") + 1f) * 0.5f)
            };

            if (player != null)
            {
                player.UpdateFromXR(frame);
            }
        }
    }
}
