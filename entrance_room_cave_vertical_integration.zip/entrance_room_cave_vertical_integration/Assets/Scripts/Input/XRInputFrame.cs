using UnityEngine;

namespace Resonance.Input
{
    public struct XRInputFrame
    {
        public Vector3 headForward;
        public Vector3 leftHandPosition;
        public Vector3 rightHandPosition;
        public float breathProxy;
        public float stillness;
        public float vocalTone;
        public float intentionAxis;
    }
}
