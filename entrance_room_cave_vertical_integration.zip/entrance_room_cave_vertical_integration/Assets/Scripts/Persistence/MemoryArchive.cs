using System.Collections.Generic;
using UnityEngine;

namespace Resonance.Persistence
{
    public class MemoryArchive : MonoBehaviour
    {
        [TextArea] public List<string> memoryLog = new List<string>();

        public void Add(string entry)
        {
            if (!string.IsNullOrWhiteSpace(entry))
            {
                memoryLog.Add(entry);
            }
        }
    }
}
