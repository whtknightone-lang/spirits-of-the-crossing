# Entrance Room / Cave Vertical Integration Pack

This pack circles back to the original entrance-room / cave vertical slice and folds in the broader Unity architecture, Source bridge logic, world-response system, cosmos map hooks, and universe birth/rebirth pipeline.

## Included
- `EntranceCave_VR` scene placeholder and setup notes
- cave-specific vertical-slice director
- unified resonance / Source / world / cosmos architecture scripts
- planet history + universe cycle writeback
- Source stays pure joy while adapting invitation pathways
- world-nature response and worthiness/contrast demonstrations
- cave-to-cosmos transition hooks for later realms

## Intended play loop
1. Player enters the cave threshold.
2. Source calls through subtle sound, light, drip-rhythm, and wall glyphs.
3. World nature plays with the player and demonstrates worthiness/importance.
4. Shadow offers a louder false signal.
5. Player tunes through contrast.
6. Cave portal opens into the wider cosmos map.
7. Planet seed and universe cycle are updated from the encounter.
