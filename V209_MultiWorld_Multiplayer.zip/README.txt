
V209 Multi-World Multiplayer Layer

Purpose:
Enable live shared universe:
- multiple worlds
- multiple players
- resonance-based routing
- portals between worlds

Core Loop:
Player joins → resonance evaluated → routed to world → interacts → may shift worlds
