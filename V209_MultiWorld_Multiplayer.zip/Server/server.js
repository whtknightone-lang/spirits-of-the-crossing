
const express = require('express');
const app = express();
app.use(express.json());

let worlds = {
    harmonic_world: [],
    balanced_world: [],
    chaotic_world: []
};

app.post('/join', (req, res) => {
    const { playerId, resonance } = req.body;

    let target = "chaotic_world";
    if (resonance > 0.75) target = "harmonic_world";
    else if (resonance > 0.5) target = "balanced_world";

    worlds[target].push(playerId);

    res.json({ world: target });
});

app.get('/worlds', (req, res) => {
    res.json(worlds);
});

app.listen(8080, () => console.log("V209 server running"));
