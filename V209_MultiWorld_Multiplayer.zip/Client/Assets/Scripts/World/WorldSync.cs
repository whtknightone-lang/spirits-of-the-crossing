
using UnityEngine;

public class WorldSync : MonoBehaviour
{
    public string worldId;

    public void JoinWorld(string id)
    {
        worldId = id;
        Debug.Log("Joined world: " + worldId);
    }
}
