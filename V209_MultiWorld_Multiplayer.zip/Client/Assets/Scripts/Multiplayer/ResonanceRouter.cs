
using UnityEngine;

public class ResonanceRouter : MonoBehaviour
{
    public float playerResonance;

    public string GetTargetWorld()
    {
        if (playerResonance > 0.75f) return "harmonic_world";
        if (playerResonance > 0.5f) return "balanced_world";
        return "chaotic_world";
    }
}
