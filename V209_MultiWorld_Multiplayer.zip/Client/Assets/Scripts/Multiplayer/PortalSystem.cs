
using UnityEngine;

public class PortalSystem : MonoBehaviour
{
    public string currentWorld;

    public void OpenPortal(string targetWorld)
    {
        Debug.Log("Opening portal to " + targetWorld);
        currentWorld = targetWorld;
    }
}
