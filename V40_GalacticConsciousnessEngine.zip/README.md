
# V40 Galactic Consciousness Engine

Run:
pip install -r requirements.txt
python v40_main.py

Features:
- Galaxy-level emotional field
- Planets with memory + civilizations
- Emergent spawning of new planets and life
- Non-scripted evolution of systems
