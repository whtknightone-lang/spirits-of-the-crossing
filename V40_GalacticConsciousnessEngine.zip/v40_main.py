
import pygame, random, torch
from galaxy_system import GalaxySystem

SIZE = 128
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

galaxy = GalaxySystem(SIZE, DEVICE)

pygame.init()
screen = pygame.display.set_mode((512,512))
clock = pygame.time.Clock()

def render():
    img = galaxy.render()
    surf = pygame.surfarray.make_surface(img)
    surf = pygame.transform.scale(surf, (512,512))
    screen.blit(surf,(0,0))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    galaxy.update()

    if random.random() < 0.02:
        galaxy.spawn_event()

    render()
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
