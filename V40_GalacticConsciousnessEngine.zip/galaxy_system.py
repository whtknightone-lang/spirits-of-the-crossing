
import torch, random, numpy as np

class GalaxySystem:
    def __init__(self, size, device):
        self.size = size
        self.device = device

        self.emotion_field = torch.zeros((7,size,size), device=device)
        self.planets = [self._new_planet() for _ in range(3)]

    def _new_planet(self):
        return {
            "field": torch.rand((7,self.size,self.size), device=self.device)*0.1,
            "memory": torch.zeros((7,self.size,self.size), device=self.device),
            "civilizations": [self._new_civ() for _ in range(random.randint(1,4))]
        }

    def _new_civ(self):
        return {
            "identity": torch.rand(7)*2-1,
            "energy": random.random()
        }

    def update(self):
        # galaxy-wide diffusion
        self.emotion_field += 0.005 * torch.randn_like(self.emotion_field)

        for planet in self.planets:
            planet["field"] += 0.01 * torch.randn_like(planet["field"])
            planet["memory"] += 0.001 * planet["field"]

            for civ in planet["civilizations"]:
                planet["field"] += civ["identity"].view(7,1,1) * civ["energy"] * 0.001

        # coupling planets into galaxy field
        for planet in self.planets:
            self.emotion_field += planet["field"] * 0.0001

    def spawn_event(self):
        # spontaneous new planet (emergent life)
        if random.random() < 0.5:
            self.planets.append(self._new_planet())

        # or evolve civilizations
        for planet in self.planets:
            if random.random() < 0.3:
                planet["civilizations"].append(self._new_civ())

    def render(self):
        field = self.emotion_field[0].detach().cpu().numpy()
        field = (field - field.min())/(field.max()+1e-5)

        img = np.uint8(field*255)
        img = np.stack([img, img//2, 255-img], axis=-1)
        return img
