
import pygame
from engine.v81_engine import V81Engine

pygame.init()
screen = pygame.display.set_mode((1500,960))
clock = pygame.time.Clock()

engine = V81Engine(128)

running=True
while running:
    dt=clock.tick(60)/1000.0
    for e in pygame.event.get():
        if e.type==pygame.QUIT:
            running=False

    engine.update(dt)
    engine.render(screen)
    pygame.display.flip()

pygame.quit()
