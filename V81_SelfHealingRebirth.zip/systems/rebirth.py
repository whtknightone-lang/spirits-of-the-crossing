
import random

class RebirthSystem:
    def __init__(self):
        self.count=0

    def update(self,eco):
        for e in eco.entities:
            if e["integrity"] <= 0:
                # rebirth
                e["stress"] = random.random()*0.5
                e["integrity"] = 1.0
                e["reborn"] = True
                self.count += 1
            else:
                e["reborn"] = False
