
class IntegritySystem:
    def update(self,eco):
        for e in eco.entities:
            e["integrity"] = max(0, min(1, 1 - e["stress"]))
