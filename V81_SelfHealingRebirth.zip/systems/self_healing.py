
class SelfHealingSystem:
    def update(self,eco):
        for e in eco.entities:
            if e["integrity"] < 0.4:
                e["stress"] *= 0.9  # self-correct
