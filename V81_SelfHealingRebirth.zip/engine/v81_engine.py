
import pygame
from systems.ecosystem import Ecosystem
from systems.integrity import IntegritySystem
from systems.rebirth import RebirthSystem
from systems.self_healing import SelfHealingSystem

class V81Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.integrity=IntegritySystem()
        self.healing=SelfHealingSystem()
        self.rebirth=RebirthSystem()

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(120):
            self.ecosystem.spawn_entity()

    def update(self,dt):
        self.ecosystem.update(dt)
        self.integrity.update(self.ecosystem)
        self.healing.update(self.ecosystem)
        self.rebirth.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            integrity=e.get("integrity",1)
            reborn=e.get("reborn",False)

            if reborn:
                color=(255,255,120)
            else:
                color=(int(255*(1-integrity)), int(255*integrity), 150)

            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V81 Self-Healing + Rebirth",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Rebirths: {self.rebirth.count}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
