
using UnityEngine;

public class BondAbilityUnlock : MonoBehaviour
{
    public SpiritBond bond;

    public bool abilityUnlocked;

    void Update()
    {
        if (bond != null && bond.bondStrength > 0.8f)
        {
            abilityUnlocked = true;
            Debug.Log("Spirit ability unlocked!");
        }
    }
}
