
using UnityEngine;

public class SpiritBond : MonoBehaviour
{
    public string spiritName;
    public float bondStrength;
    public float alignment;

    public void StrengthenBond(float value)
    {
        bondStrength += value;
        alignment = (alignment + bondStrength) * 0.5f;
    }
}
