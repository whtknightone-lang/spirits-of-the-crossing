
using UnityEngine;

public class SpiritResponse : MonoBehaviour
{
    public SpiritBond bond;

    public string Respond()
    {
        if (bond == null) return "...";

        if (bond.bondStrength > 0.7f)
            return "We are connected. I will guide you.";

        if (bond.bondStrength > 0.3f)
            return "I sense your presence.";

        return "You are not yet aligned.";
    }
}
