
V199 Spirit Bond + Player Alignment System

Adds:
- Player ↔ Spirit bonding system
- Alignment-based evolution
- Bond strength affects abilities and interactions

Core Idea:
Players form deep bonds with specific spirits which shape their journey.
