
import matplotlib.pyplot as plt
from engine import CelestialSystem

system = CelestialSystem()

plt.ion()
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

for step in range(300):
    system.step()

    ax.clear()

    # agents
    ax.scatter(system.position[:3000,0].numpy(),
               system.position[:3000,1].numpy(),
               system.position[:3000,2].numpy(),
               s=1)

    # planets
    ax.scatter(system.planets[:,0], system.planets[:,1], system.planets[:,2], s=80)

    # celestial bodies
    ax.scatter(system.bodies[:,0], system.bodies[:,1], system.bodies[:,2], s=40)

    ax.set_title(f"Step {step}")

    ax.set_xlim(0,1)
    ax.set_ylim(0,1)
    ax.set_zlim(0,1)

    plt.pause(0.01)

plt.ioff()
plt.show()
