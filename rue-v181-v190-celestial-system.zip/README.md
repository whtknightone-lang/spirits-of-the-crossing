
RUE V181–V190 Celestial Interaction System

Features:
- Multi-planet system (P0–P3 + 11 celestial bodies)
- Orbital simulation
- Cross-planet influence (energy + behavior)
- Alignment-based events
- Planet interaction layer

Run:
pip install torch matplotlib
python run_v181.py
