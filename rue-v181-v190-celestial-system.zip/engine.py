
import torch
import math
import random

class CelestialSystem:
    def __init__(self, n=15000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)

        # planets (P0–P3)
        self.planets = torch.rand(4,3)
        self.planet_energy = torch.ones(4)

        # 11 celestial bodies
        self.bodies = torch.rand(11,3)
        self.body_phase = torch.rand(11) * 2 * math.pi

        self.time = 0

    def step(self):
        self.time += 0.05

        # orbit bodies
        for i in range(len(self.bodies)):
            angle = self.body_phase[i] + self.time
            self.bodies[i,0] = 0.5 + 0.4 * math.cos(angle)
            self.bodies[i,1] = 0.5 + 0.4 * math.sin(angle)

        # influence planets
        for i in range(len(self.planets)):
            influence = 0
            for b in self.bodies:
                dist = torch.norm(self.planets[i] - b)
                influence += 1.0 / (dist + 0.1)

            self.planet_energy[i] += 0.001 * influence

        # global energy influence
        total_influence = self.planet_energy.mean()
        self.energy += 0.01 * total_influence

        # slight decay
        self.energy *= 0.999
