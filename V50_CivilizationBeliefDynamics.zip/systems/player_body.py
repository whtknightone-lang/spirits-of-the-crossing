
import torch, pygame
class PlayerBody:
    def __init__(self, size, device):
        self.size = size
        self.device = device
        self.pos = torch.tensor([size / 2, size / 2], device=device)
        self.core = torch.zeros(7, device=device)

    def handle_movement(self, keys, dt):
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            self.pos[0] -= 22 * dt
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            self.pos[0] += 22 * dt
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            self.pos[1] -= 22 * dt
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            self.pos[1] += 22 * dt
        self.pos = torch.clamp(self.pos, 0, self.size - 1)

    def update(self, dt, now, potential):
        x, y = self.grid_position()
        self.core += 0.01 * (now[x, y] - self.core)

    def emit_expression_burst(self, field):
        x, y = self.grid_position()
        field[max(0, x-2):x+3, max(0, y-2):y+3] += 0.18

    def emit_kindness_burst(self, field):
        x, y = self.grid_position()
        field[max(0, x-4):x+5, max(0, y-4):y+5] += 0.12

    def grid_position(self):
        return int(self.pos[0].item()), int(self.pos[1].item())

    def resonance_mean(self):
        return self.core.mean()
