
import pygame
import numpy as np
from systems.resonance_memory import ResonanceMemorySystem
from systems.player_body import PlayerBody
from systems.agent_world import AgentWorld
from systems.communication import CommunicationSystem
from systems.meditation import MeditationSystem
from systems.source_feedback import SourceFeedbackSystem
from systems.self_awareness import SelfAwarenessSystem
from systems.belief_systems import BeliefSystemEngine
from systems.civilization_system import CivilizationSystem

class V50Engine:
    def __init__(self, size, device):
        self.size = size
        self.device = device

        self.memory = ResonanceMemorySystem(size, device)
        self.player = PlayerBody(size, device)
        self.world = AgentWorld(size, device, 140)
        self.comm = CommunicationSystem()
        self.meditation = MeditationSystem()
        self.source = SourceFeedbackSystem()
        self.awareness = SelfAwarenessSystem()
        self.beliefs = BeliefSystemEngine()
        self.civilizations = CivilizationSystem()

        self.font = pygame.font.SysFont("arial", 16)

    def handle_key(self, key):
        if key == pygame.K_SPACE:
            self.meditation.toggle()
        elif key == pygame.K_e:
            self.player.emit_expression_burst(self.memory.now_field)
        elif key == pygame.K_q:
            self.player.emit_kindness_burst(self.memory.now_field)
        elif key == pygame.K_b:
            self.beliefs.force_realignment(self.world.agents)
        elif key == pygame.K_c:
            self.civilizations.force_recluster(self.world.agents)

    def handle_input(self, dt):
        self.player.handle_movement(pygame.key.get_pressed(), dt)

    def update(self, dt):
        self.memory.update(dt, self.world.aggregate_world_emotion(), self.player.resonance_mean())
        self.player.update(dt, self.memory.now_field, self.memory.potential_field)
        self.world.update(dt, self.memory.now_field, self.memory.potential_field, self.player)

        self.comm.update(self.world.agents)
        self.awareness.update(self.world.agents, self.player, self.memory)
        self.beliefs.update(self.world.agents, self.memory, self.source)
        self.civilizations.update(self.world.agents, self.memory, self.source)

        if self.meditation.active:
            self.memory.now_field += self.meditation.align(self.memory)

        feedback = self.source.compute(self.memory, self.player, self.world)
        self.memory.now_field += feedback
        self.memory.potential_field += feedback * 0.5

        civ_pressure = self.civilizations.civilization_field(self.size)
        self.memory.now_field += civ_pressure * 0.002
        self.memory.potential_field += civ_pressure * 0.001

        self.memory.clamp_all()

    def render(self, screen):
        screen.fill((10, 10, 20))

        arr = self.memory.now_field.detach().cpu().numpy()
        arr = (arr - arr.min()) / (arr.max() + 1e-5)
        img = np.stack([arr * 255, arr * 205, 255 - arr * 145], axis=-1).astype("uint8")
        surf = pygame.surfarray.make_surface(np.transpose(img, (1, 0, 2)))
        surf = pygame.transform.scale(surf, (760, 760))
        screen.blit(surf, (28, 32))

        scale = 760 / self.size

        # draw civilizations as territorial glow
        for civ in self.civilizations.civs:
            cx = int(civ["center"][1] * scale) + 28
            cy = int(civ["center"][0] * scale) + 32
            radius = max(8, int(civ["size"] * 0.35))
            belief = civ["belief"]
            color = (
                max(0, min(255, int(120 + belief * 100))),
                max(0, min(255, int(120 + civ["coherence"] * 110))),
                max(0, min(255, int(180 - belief * 70))),
            )
            pygame.draw.circle(screen, color, (cx, cy), radius, 2)

        # draw agents
        for a in self.world.agents:
            x = int(a["pos"][1] * scale) + 28
            y = int(a["pos"][0] * scale) + 32
            civ_id = a.get("civ_id", -1)
            belief = a.get("belief", 0.0)
            aware = a.get("self_awareness", 0.0)
            if civ_id >= 0:
                civ = self.civilizations.civs[civ_id % len(self.civilizations.civs)]
                base = civ["belief"]
            else:
                base = belief
            color = (
                max(0, min(255, int(110 + base * 90))),
                max(0, min(255, int(140 + aware * 90))),
                max(0, min(255, int(185 - base * 75))),
            )
            pygame.draw.circle(screen, color, (x, y), 3)

        # draw player
        px, py = self.player.grid_position()
        pygame.draw.circle(screen, (255, 255, 255), (int(py * scale) + 28, int(px * scale) + 32), 7)

        avg_awareness = sum(a.get("self_awareness", 0.0) for a in self.world.agents) / max(1, len(self.world.agents))
        avg_belief = sum(a.get("belief", 0.0) for a in self.world.agents) / max(1, len(self.world.agents))
        med = "ON" if self.meditation.active else "OFF"

        lines = [
            "V50 Civilization Belief Dynamics",
            "SPACE meditate | E expression | Q kindness | B belief realign | C recluster civilizations",
            f"Meditation: {med}",
            f"Source signal: {self.source.last_signal:.3f}",
            f"Avg self-awareness: {avg_awareness:.3f}",
            f"Avg belief orientation: {avg_belief:.3f}",
            f"Civilizations: {len(self.civilizations.civs)} | Alliances: {self.civilizations.alliance_count} | Tensions: {self.civilizations.tension_count}",
        ]

        y = 812
        for line in lines:
            screen.blit(self.font.render(line, True, (240, 240, 240)), (28, y))
            y += 20
