
# V50 Civilization Belief Dynamics

Run:
pip install -r requirements.txt
python main.py

New in V50:
- Civilizations emerge from shared belief bands
- Civilizations develop centers, size, coherence, alliances, and tensions
- Civilization pressure feeds back into the world field
- Philosophical alignment and conflict now happen at group scale

Controls:
- Move: WASD or arrow keys
- SPACE: meditate
- E: expression burst
- Q: kindness burst
- B: belief realignment
- C: force civilization reclustering
