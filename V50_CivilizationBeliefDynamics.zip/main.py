
import pygame, torch
from engine.v50_engine import V50Engine

WIDTH, HEIGHT = 1440, 920
GRID = 128

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("V50 Civilization Belief Dynamics")
clock = pygame.time.Clock()

device = "cuda" if torch.cuda.is_available() else "cpu"
engine = V50Engine(GRID, device)

running = True
while running:
    dt = clock.tick(60) / 1000.0

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
        elif e.type == pygame.KEYDOWN:
            engine.handle_key(e.key)

    engine.handle_input(dt)
    engine.update(dt)
    engine.render(screen)
    pygame.display.flip()

pygame.quit()
