
import matplotlib.pyplot as plt
from engine import AlignmentSystem

world = AlignmentSystem()

plt.ion()
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

def on_key(event):
    if event.key == 't':
        world.travel()

fig.canvas.mpl_connect('key_press_event', on_key)

for step in range(300):
    world.step(step)

    ax.clear()

    ax.scatter(world.position[:3000,0].numpy(),
               world.position[:3000,1].numpy(),
               world.position[:3000,2].numpy(),
               s=1)

    ax.scatter(world.planets[:,0], world.planets[:,1], world.planets[:,2], s=80)
    ax.scatter(world.bodies[:,0], world.bodies[:,1], world.bodies[:,2], s=40)

    ax.set_title(f"Step {step} Planet {world.player_planet} Events {len(world.timeline)}")

    ax.set_xlim(0,1)
    ax.set_ylim(0,1)
    ax.set_zlim(0,1)

    plt.pause(0.01)

plt.ioff()
plt.show()
