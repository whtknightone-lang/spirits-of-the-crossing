
RUE V191–V200 Alignment Events + Cross-Planet Travel + Timeline

Features:
- Alignment detection system
- Event trigger engine (solar flare, chaos, forest bloom, machine sync)
- Cross-planet travel (portals + alignment gates)
- Timeline logging (persistent history)

Run:
pip install torch matplotlib
python run_v191.py
