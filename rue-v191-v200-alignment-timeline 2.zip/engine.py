
import torch
import math
import random

class AlignmentSystem:
    def __init__(self, n=12000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)

        # planets
        self.planets = torch.rand(4,3)

        # celestial bodies
        self.bodies = torch.rand(11,3)
        self.phase = torch.rand(11) * 2 * math.pi

        self.time = 0
        self.timeline = []

        # player
        self.player_planet = 0

    def step(self, step):
        self.time += 0.05

        # orbit update
        for i in range(len(self.bodies)):
            angle = self.phase[i] + self.time
            self.bodies[i,0] = 0.5 + 0.4 * math.cos(angle)
            self.bodies[i,1] = 0.5 + 0.4 * math.sin(angle)

        # alignment detection
        alignment_score = 0
        for b in self.bodies:
            for p in self.planets:
                dist = torch.norm(b - p)
                alignment_score += 1.0 / (dist + 0.05)

        # event trigger
        if alignment_score > 150:
            self._trigger_event(step)

        # passive energy update
        self.energy += 0.01 * torch.sin(torch.rand_like(self.energy))
        self.energy *= 0.999

    def _trigger_event(self, step):
        event_type = random.choice(["solar_flare","forest_bloom","machine_sync","dragon_event"])

        if event_type == "solar_flare":
            self.energy *= 1.2
        elif event_type == "forest_bloom":
            self.energy += 0.2
        elif event_type == "machine_sync":
            self.energy = torch.ones_like(self.energy)
        elif event_type == "dragon_event":
            self.energy *= (1 + 0.2 * torch.randn_like(self.energy))

        self.timeline.append(f"Step {step}: {event_type} triggered")

    def travel(self):
        # cross-planet travel
        self.player_planet = random.randint(0,3)
        self.timeline.append(f"Player moved to planet {self.player_planet}")
