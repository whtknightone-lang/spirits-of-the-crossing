
print("Running RUE Living World Engine V3")

def step():
    print("Step executed in V3")

if __name__ == "__main__":
    for i in range(5):
        step()
