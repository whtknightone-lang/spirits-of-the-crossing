
import matplotlib.pyplot as plt
from engine import World

world = World()

plt.ion()
fig, ax = plt.subplots()

def on_key(event):
    if event.key == 'w': world.player_pos[1]+=0.03
    if event.key == 's': world.player_pos[1]-=0.03
    if event.key == 'a': world.player_pos[0]-=0.03
    if event.key == 'd': world.player_pos[0]+=0.03

    if event.key == '1': world.player_class = "Builder"
    if event.key == '2': world.player_class = "Disruptor"
    if event.key == '3': world.player_class = "Balancer"

fig.canvas.mpl_connect('key_press_event', on_key)

for step in range(600):
    world.step(step)

    ax.clear()
    ax.scatter(world.position[:,0].numpy(), world.position[:,1].numpy(), s=2)
    ax.scatter(world.player_pos[0].item(), world.player_pos[1].item(), s=60)

    ax.set_title(f"Score {round(world.score,1)} Level {round(world.level,2)} Era {world.era} Class {world.player_class}")
    ax.set_xlim(0,1)
    ax.set_ylim(0,1)

    plt.pause(0.01)

plt.ioff()
plt.show()
