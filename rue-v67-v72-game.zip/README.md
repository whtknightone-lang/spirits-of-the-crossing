
RUE V67–V72 Game Build

Features:
- Player classes (Builder, Disruptor, Balancer)
- Objectives system
- UI overlay (score, era, faction count)
- Progression (level + ability scaling)

Run:
pip install torch matplotlib
python run_v67.py
