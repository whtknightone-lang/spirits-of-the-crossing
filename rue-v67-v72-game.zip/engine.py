
import torch
import random

class World:
    def __init__(self, n=3000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,2)
        self.velocity = torch.zeros(n,2)
        self.lineage = torch.randint(0,6,(n,))
        self.player_pos = torch.tensor([0.5,0.5])
        self.score = 0
        self.level = 1
        self.era = "Genesis"
        self.objective = "Stabilize energy > 1.2"

        self.player_class = "Builder"

    def step(self, step):
        self.velocity += 0.01 * torch.randn_like(self.velocity)
        self.position += self.velocity
        self.position = torch.clamp(self.position,0,1)

        # player effect by class
        dist = torch.norm(self.position - self.player_pos, dim=1)

        if self.player_class == "Builder":
            self.energy += torch.exp(-dist*10)*0.02
        elif self.player_class == "Disruptor":
            self.energy -= torch.exp(-dist*10)*0.02
        elif self.player_class == "Balancer":
            self.energy += torch.exp(-dist*10)*0.01

        # dynamics
        self.energy += 0.01 * torch.sin(torch.rand_like(self.energy))
        self.energy *= 0.999

        avg_energy = self.energy.mean().item()
        self.score += avg_energy

        if avg_energy > 1.2:
            self.level += 0.01

        if step % 150 == 0:
            self.era = random.choice(["Expansion","Collapse","Balance"])
