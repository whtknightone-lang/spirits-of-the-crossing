
V187 Cooperative AI System

Includes:
- Emergent role detection (no fixed classes)
- Cooperative multi-node puzzles
- AI guidance (non-verbal hinting)
- Group state analyzer

Core Idea:
Players naturally fall into roles and solve puzzles together with AI support.
