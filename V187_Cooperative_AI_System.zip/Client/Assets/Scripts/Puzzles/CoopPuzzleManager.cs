
using UnityEngine;

public class CoopPuzzleManager : MonoBehaviour
{
    public CoopPuzzleNode[] nodes;
    public bool solved;

    void Update()
    {
        int complete = 0;
        foreach (var n in nodes)
        {
            if (n.IsComplete()) complete++;
        }

        solved = complete == nodes.Length;

        if (solved)
            Debug.Log("Cooperative puzzle solved!");
    }
}
