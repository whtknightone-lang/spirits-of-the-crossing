
using UnityEngine;

public class CoopPuzzleNode : MonoBehaviour
{
    public float value;
    public float requiredValue = 1f;

    public void Apply(float input)
    {
        value = Mathf.Clamp01(value + input);
    }

    public bool IsComplete()
    {
        return value >= requiredValue;
    }
}
