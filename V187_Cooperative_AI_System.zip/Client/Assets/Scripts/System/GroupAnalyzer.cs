
using UnityEngine;

public class GroupAnalyzer : MonoBehaviour
{
    public float avgResonance;
    public int playerCount;

    public void Analyze(float[] resonances)
    {
        float sum = 0f;
        foreach (var r in resonances) sum += r;
        avgResonance = sum / resonances.Length;
        playerCount = resonances.Length;
    }
}
