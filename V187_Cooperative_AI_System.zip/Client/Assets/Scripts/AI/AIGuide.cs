
using UnityEngine;

public class AIGuide : MonoBehaviour
{
    public Transform player;
    public Transform targetNode;

    void Update()
    {
        if (player == null || targetNode == null) return;

        Vector3 mid = Vector3.Lerp(player.position, targetNode.position, 0.5f);
        transform.position = Vector3.Lerp(transform.position, mid, Time.deltaTime);
        transform.LookAt(targetNode);
    }
}
