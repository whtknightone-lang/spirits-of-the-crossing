
using UnityEngine;

public class RoleDetector : MonoBehaviour
{
    public float resonance;
    public float curiosity;
    public float alignment;

    public string currentRole;

    void Update()
    {
        if (resonance > 0.7f) currentRole = "Stabilizer";
        else if (curiosity > 0.6f) currentRole = "Explorer";
        else if (alignment > 0.6f) currentRole = "Harmonizer";
        else currentRole = "Activator";
    }
}
