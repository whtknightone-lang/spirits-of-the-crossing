
import pygame, numpy as np, torch
from systems.joy_engine import JoyEngine
from systems.emotion_engine import EmotionEngine
from systems.core_continuity import CoreContinuitySystem
from systems.planetary_civilization import PlanetaryCivilizationSystem
from systems.galactic_consciousness import GalacticConsciousnessSystem
from systems.resonance_memory import ResonanceMemorySystem
from systems.player_body import PlayerBody
from systems.agent_world import AgentWorld

class V44Engine:
    def __init__(self, size, device):
        self.size=size
        self.device=device

        self.joy=JoyEngine(size,device)
        self.emotion=EmotionEngine(size,device)
        self.core=CoreContinuitySystem(200,size,device)
        self.planet=PlanetaryCivilizationSystem(size,device)
        self.galaxy=GalacticConsciousnessSystem(size,device)
        self.memory=ResonanceMemorySystem(size,device)

        self.player=PlayerBody(size,device)
        self.world=AgentWorld(size,device,100)

        self.font=pygame.font.SysFont("arial",16)

    def handle_key(self,key):
        if key==pygame.K_n: self.memory.inject_now(0.15)
        if key==pygame.K_m: self.memory.inject_memory(0.08)
        if key==pygame.K_f: self.memory.inject_potential(0.08)
        if key==pygame.K_e: self.player.emit_expression_burst(self.memory.now_field)
        if key==pygame.K_q: self.player.emit_kindness_burst(self.memory.now_field)

    def handle_input(self,dt):
        self.player.handle_movement(pygame.key.get_pressed(),dt)

    def update(self,dt):
        self.joy.update(dt)
        self.emotion.update(dt,self.joy.J)

        self.memory.update(dt,
            self.world.aggregate_world_emotion(),
            self.player.resonance_mean()
        )

        self.player.update(dt,self.memory.now_field,self.memory.potential_field)
        self.world.update(dt,self.memory.now_field,self.memory.potential_field,self.player)

        # universal motivation: move toward "feeling good"
        feeling = self.player.core.mean().item()
        self.joy.J += feeling*0.002
        self.emotion.field += feeling*0.001
        self.memory.now_field += feeling*0.001

    def render(self,screen):
        screen.fill((10,10,20))

        arr=self.memory.now_field.detach().cpu().numpy()
        arr=(arr-arr.min())/(arr.max()+1e-5)
        img=np.stack([arr*255,arr*180,255-arr*180],axis=-1).astype("uint8")

        surf=pygame.surfarray.make_surface(np.transpose(img,(1,0,2)))
        surf=pygame.transform.scale(surf,(700,700))
        screen.blit(surf,(40,40))

        # draw player
        px,py=self.player.grid_position()
        pygame.draw.circle(surf,(255,255,255),(py,px),6)

        y=760
        lines=[
            "V44 Unified Feeling Cosmos",
            "Everything is driven by 'feeling good'",
            f"Player feeling: {self.player.core.mean().item():.3f}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
