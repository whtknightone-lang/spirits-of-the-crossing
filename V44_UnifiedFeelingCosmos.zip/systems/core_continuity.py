class CoreContinuitySystem:
 def __init__(s,*a): pass