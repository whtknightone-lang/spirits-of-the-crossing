class PlanetaryCivilizationSystem:
 def __init__(s,*a): pass