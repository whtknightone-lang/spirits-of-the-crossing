class GalacticConsciousnessSystem:
 def __init__(s,*a): pass