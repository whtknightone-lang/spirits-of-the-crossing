class EmotionEngine:
 def __init__(s,*a): s.field=0
 def update(s,dt,J): pass