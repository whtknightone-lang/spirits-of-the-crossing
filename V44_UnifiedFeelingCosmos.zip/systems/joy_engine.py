from torch import zeros
class JoyEngine:
 def __init__(s,*a): s.J=zeros((1,1,128,128)); s.Psi=s.J.clone()
 def update(s,dt): pass