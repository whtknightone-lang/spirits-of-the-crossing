
import random, torch
class AgentWorld:
    def __init__(self,size,device,n):
        self.size=size
        self.device=device
        self.agents=[{"pos":[random.random()*size,random.random()*size]} for _ in range(n)]

    def update(self,dt,now,potential,player):
        for a in self.agents:
            a["pos"][0]+=random.uniform(-1,1)*dt*20
            a["pos"][1]+=random.uniform(-1,1)*dt*20

    def aggregate_world_emotion(self):
        return torch.zeros((self.size,self.size))
