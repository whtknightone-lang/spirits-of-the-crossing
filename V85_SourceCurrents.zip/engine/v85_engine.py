
import pygame
from systems.ecosystem import Ecosystem
from systems.source_currents import SourceCurrentsSystem
from systems.collective_meditation import CollectiveMeditationSystem
from systems.player import PlayerSystem

class V85Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.currents=SourceCurrentsSystem(size)
        self.collective=CollectiveMeditationSystem()
        self.player=PlayerSystem(self.ecosystem)

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(70):
            self.ecosystem.spawn_entity()

    def handle_key(self,key):
        self.player.handle_key(key)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.currents.update(self.ecosystem)
        self.collective.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,35))
        scale=700/self.size

        # draw currents
        for c in self.currents.currents:
            x=int(c[1]*scale)+40
            y=int(c[0]*scale)+40
            pygame.draw.circle(screen,(80,160,255),(x,y),1)

        # draw entities
        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            s=e.get("source_connection",0)
            g=e.get("group_field",0)

            color=(100, int(100+155*s), int(100+155*g))
            pygame.draw.circle(screen,color,(x,y),4)

        if self.player.selected:
            e=self.player.selected
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40
            pygame.draw.circle(screen,(255,255,255),(x,y),8,1)

        y=760
        lines=[
            "V85 Source Currents + Collective Meditation",
            "Click select | 1 meditate | 2 release",
            f"Entities: {len(self.ecosystem.entities)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
