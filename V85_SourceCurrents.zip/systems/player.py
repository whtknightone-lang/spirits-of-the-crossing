
import pygame

class PlayerSystem:
    def __init__(self,eco):
        self.eco=eco
        self.selected=None

    def handle_key(self,key):
        if not self.selected: return

        if key==pygame.K_1:
            self.selected["source_connection"] += 0.2

        if key==pygame.K_2:
            self.selected["source_connection"] *= 0.5

    def update(self):
        mouse=pygame.mouse.get_pressed()
        if mouse[0]:
            mx,my=pygame.mouse.get_pos()
            closest=None
            dist=9999
            for e in self.eco.entities:
                dx=mx-(e["pos"][1]*5+40)
                dy=my-(e["pos"][0]*5+40)
                d=dx*dx+dy*dy
                if d<dist:
                    dist=d
                    closest=e
            self.selected=closest
