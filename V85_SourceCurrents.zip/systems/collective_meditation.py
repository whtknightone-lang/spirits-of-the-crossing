
class CollectiveMeditationSystem:
    def update(self,eco):
        # simple group amplification
        for e in eco.entities:
            neighbors=0
            total=0
            for o in eco.entities:
                if o is e: continue
                dx=e["pos"][0]-o["pos"][0]
                dy=e["pos"][1]-o["pos"][1]
                dist=(dx*dx+dy*dy)**0.5
                if dist<6:
                    neighbors+=1
                    total+=o["source_connection"]

            if neighbors>3:
                e["group_field"] = total / neighbors
                e["source_connection"] += e["group_field"] * 0.01
            else:
                e["group_field"] *= 0.95
