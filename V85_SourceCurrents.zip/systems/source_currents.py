
import random

class SourceCurrentsSystem:
    def __init__(self,size):
        self.size=size
        self.currents=[
            [random.random()*size, random.random()*size]
            for _ in range(120)
        ]

    def update(self,eco):
        # currents drift
        for c in self.currents:
            c[0]+=random.uniform(-0.5,0.5)
            c[1]+=random.uniform(-0.5,0.5)

        # influence entities
        for e in eco.entities:
            for c in self.currents:
                dx=e["pos"][0]-c[0]
                dy=e["pos"][1]-c[1]
                dist=(dx*dx+dy*dy)**0.5
                if dist<4:
                    e["source_connection"] += 0.01

            e["source_connection"]=min(1.0,e["source_connection"])
