
import random, uuid

class Ecosystem:
    def __init__(self,size):
        self.size=size
        self.entities=[]

    def spawn_entity(self):
        self.entities.append({
            "id":str(uuid.uuid4()),
            "pos":[random.random()*self.size,random.random()*self.size],
            "source_connection":0.0,
            "group_field":0.0
        })

    def update(self,dt):
        for e in self.entities:
            e["pos"][0]+=random.uniform(-1,1)*dt*5
            e["pos"][1]+=random.uniform(-1,1)*dt*5
