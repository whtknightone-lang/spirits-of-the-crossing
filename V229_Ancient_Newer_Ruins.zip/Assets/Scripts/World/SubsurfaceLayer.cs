
using UnityEngine;

public class SubsurfaceLayer : MonoBehaviour
{
    public bool hidden = true;

    public void Reveal()
    {
        hidden = false;
        Debug.Log("Subsurface layer revealed");
    }
}
