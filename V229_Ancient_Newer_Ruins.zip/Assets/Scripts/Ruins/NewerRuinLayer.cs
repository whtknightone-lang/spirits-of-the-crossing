
using UnityEngine;

public class NewerRuinLayer : MonoBehaviour
{
    public bool builtOnAncient = true;
    public float decayLevel = 0.5f;

    void Start()
    {
        if (builtOnAncient)
            Debug.Log("Newer ruin layered over ancient structure");
    }
}
