
using UnityEngine;

public class AncientRuinNode : MonoBehaviour
{
    public float resonance = 0.8f;
    public string mythType = "Transformation";

    public void Activate()
    {
        Debug.Log("Ancient ruin activated: " + mythType);
    }
}
