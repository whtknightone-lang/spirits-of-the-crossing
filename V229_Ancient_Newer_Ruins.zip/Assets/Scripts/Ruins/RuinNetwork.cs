
using UnityEngine;
using System.Collections.Generic;

public class RuinNetwork : MonoBehaviour
{
    public List<AncientRuinNode> nodes = new List<AncientRuinNode>();

    public void Connect()
    {
        Debug.Log("Connecting ancient ruin network across worlds");
    }
}
