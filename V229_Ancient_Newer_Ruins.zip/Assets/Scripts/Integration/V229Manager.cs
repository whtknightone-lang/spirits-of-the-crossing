
using UnityEngine;

public class V229Manager : MonoBehaviour
{
    public RuinNetwork network;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            network.Connect();
        }
    }
}
