
using UnityEngine;

public class EnergyWell : MonoBehaviour
{
    public float intensity = 1.0f;
    public bool isSubsurface = false;

    void Update()
    {
        if (intensity > 0.8f)
            Debug.Log("Strong energy well detected");
    }
}
