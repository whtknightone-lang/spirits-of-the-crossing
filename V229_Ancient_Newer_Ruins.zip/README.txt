
V229 Ancient + Newer Ruins System

Includes:
- Ancient galactic ruin network
- Newer ruins layered on top of some ancient sites
- Energy wells (surface + subsurface)
- Multi-layer world structure

Core Idea:
History stacks. New civilizations build over old ones.
Some remember. Some forget.
