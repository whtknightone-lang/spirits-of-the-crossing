
import numpy as np

def build_matrix():
    K = np.zeros((21,21))

    def connect(a,b,w):
        K[a,b] = w
        K[b,a] = w

    for i in range(1,7):
        connect(0,i,1.0)

    inner=[1,2,3,4,5,6]
    for i in range(6):
        connect(inner[i],inner[(i+1)%6],0.65)

    mapping={1:[7,8],2:[9,10],3:[11,12],4:[13,14],5:[15,16],6:[17,18]}

    for k,v in mapping.items():
        for node in v:
            connect(k,node,0.5)

    outer=list(range(7,21))
    for i in range(len(outer)):
        connect(outer[i],outer[(i+1)%len(outer)],0.35)

    connect(1,19,0.45)
    connect(3,20,0.45)

    return K
