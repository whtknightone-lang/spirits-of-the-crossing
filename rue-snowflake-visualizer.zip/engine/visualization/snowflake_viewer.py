
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

class SnowflakeViewer:

    def __init__(self, matrix):
        self.matrix = matrix
        self.G = nx.Graph()

        for i in range(21):
            self.G.add_node(i)

        for i in range(21):
            for j in range(i+1,21):
                if matrix[i,j] != 0:
                    self.G.add_edge(i,j)

        self.pos = self._layout()

    def _layout(self):
        pos = {}

        # center
        pos[0] = (0,0)

        # inner ring
        for i in range(6):
            angle = 2*np.pi*i/6
            pos[i+1] = (np.cos(angle), np.sin(angle))

        # outer ring
        for i in range(14):
            angle = 2*np.pi*i/14
            pos[i+7] = (2*np.cos(angle), 2*np.sin(angle))

        return pos

    def draw(self, phases):

        colors = phases / (2*np.pi)

        plt.clf()
        nx.draw(
            self.G,
            self.pos,
            node_color=colors,
            cmap=plt.cm.hsv,
            with_labels=True,
            node_size=500,
            edge_color="gray"
        )

        plt.pause(0.01)
