
import numpy as np
import matplotlib.pyplot as plt

from engine.snowflake.adjacency import build_matrix
from engine.snowflake.oscillator import update
from engine.visualization.snowflake_viewer import SnowflakeViewer

matrix=build_matrix()
phases=np.random.rand(21)*2*np.pi

viewer=SnowflakeViewer(matrix)

plt.ion()

for step in range(2000):

    phases=update(phases,matrix)

    viewer.draw(phases)

plt.ioff()
plt.show()
