
RUE Snowflake Visualization Module

This package adds a real‑time visualization for the 21‑node snowflake brain.

Run:

pip install -r requirements.txt
python tests/run_snowflake_viewer.py

You will see the snowflake oscillator network animate in real time.
Node colors represent oscillator phase.
