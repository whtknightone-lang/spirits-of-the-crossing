
import random

class Ecosystem:
    def __init__(self,size):
        self.size=size
        self.entities=[]

    def spawn_entity(self):
        self.entities.append({
            "pos":[random.random()*self.size,random.random()*self.size],
            "experience":0.0,
            "mistakes":0,
            "soul_id":None
        })

    def update(self,dt):
        for e in self.entities:
            e["pos"][0]+=random.uniform(-1,1)*dt*10
            e["pos"][1]+=random.uniform(-1,1)*dt*10

            if random.random()<0.05:
                e["mistakes"]+=1
            else:
                e["experience"]+=0.02
