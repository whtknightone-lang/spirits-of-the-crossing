
import uuid

class SoulSystem:
    def __init__(self):
        self.archive={}

    def update(self,eco):
        for e in eco.entities:
            if e["soul_id"] is None:
                sid=str(uuid.uuid4())
                e["soul_id"]=sid
                self.archive[sid]={"lives":0,"learning":0.0}

            soul=self.archive[e["soul_id"]]
            soul["learning"]=e["experience"] + e["mistakes"]*0.5

    def recycle(self,eco):
        if eco.entities:
            e=eco.entities.pop(0)
            soul=self.archive.get(e["soul_id"])
            if soul:
                soul["lives"]+=1
