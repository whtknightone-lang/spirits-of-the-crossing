
class PurposeSystem:
    def update(self,eco):
        for e in eco.entities:
            learning = e["experience"] + e["mistakes"]*0.5

            if learning > 3:
                e["purpose"]="growth"
            elif e["mistakes"] > 5:
                e["purpose"]="challenge"
            else:
                e["purpose"]="explore"
