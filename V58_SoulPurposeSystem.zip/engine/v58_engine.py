
import pygame
from systems.ecosystem import Ecosystem
from systems.soul import SoulSystem
from systems.purpose import PurposeSystem

class V58Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.soul=SoulSystem()
        self.purpose=PurposeSystem()
        self.font=pygame.font.SysFont("arial",16)

    def handle_key(self,key):
        if key==pygame.K_1:
            self.ecosystem.spawn_entity()
        if key==pygame.K_r:
            self.soul.recycle(self.ecosystem)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.soul.update(self.ecosystem)
        self.purpose.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            p=e.get("purpose","none")
            if p=="growth": color=(120,255,180)
            elif p=="challenge": color=(255,140,140)
            elif p=="explore": color=(120,180,255)
            else: color=(200,200,200)

            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V58 Soul + Purpose System",
            "1 spawn | R recycle to source",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Soul memory size: {len(self.soul.archive)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
