
V203 Vibration Communication Layer

Purpose:
Shift communication from words → vibration.

Systems:
- Vibration field (core signal)
- Sound resonance engine
- Light harmonic feedback
- AI non-verbal expression
- Player perception layer

Core idea:
Action changes vibration → vibration teaches → words optional
