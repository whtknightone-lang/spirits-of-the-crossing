
using UnityEngine;

public class AIVibrationExpression : MonoBehaviour
{
    public VibrationField field;
    public Transform visual;

    void Update()
    {
        if (field == null || visual == null) return;

        float pulse = Mathf.Sin(Time.time * 3f) * 0.1f * field.resonance;
        visual.localScale = Vector3.one * (1f + pulse);

        float height = Mathf.Lerp(0f, 1f, field.coherence);
        visual.position = new Vector3(visual.position.x, height, visual.position.z);
    }
}
