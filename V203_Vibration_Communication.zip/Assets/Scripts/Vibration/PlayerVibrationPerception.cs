
using UnityEngine;

public class PlayerVibrationPerception : MonoBehaviour
{
    public VibrationField field;

    void Update()
    {
        if (field == null) return;

        if (field.resonance > 0.7f)
        {
            Debug.Log("Feels aligned and clear");
        }
        else if (field.resonance < 0.3f)
        {
            Debug.Log("Feels off / drifting");
        }
    }
}
