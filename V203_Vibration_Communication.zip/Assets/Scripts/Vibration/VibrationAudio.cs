
using UnityEngine;

public class VibrationAudio : MonoBehaviour
{
    public VibrationField field;
    public AudioSource source;

    void Update()
    {
        if (field == null || source == null) return;

        source.pitch = Mathf.Lerp(0.7f, 1.4f, field.resonance);
        source.volume = Mathf.Lerp(0.2f, 1f, field.coherence);
    }
}
