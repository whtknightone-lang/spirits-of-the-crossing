
using UnityEngine;

public class VibrationLight : MonoBehaviour
{
    public VibrationField field;
    public Light sceneLight;

    void Update()
    {
        if (field == null || sceneLight == null) return;

        sceneLight.intensity = Mathf.Lerp(0.5f, 2.5f, field.resonance);
        sceneLight.color = Color.Lerp(Color.red, Color.cyan, field.coherence);
    }
}
