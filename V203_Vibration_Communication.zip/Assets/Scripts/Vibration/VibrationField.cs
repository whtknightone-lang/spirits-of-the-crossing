
using UnityEngine;

public class VibrationField : MonoBehaviour
{
    [Range(0f,1f)] public float resonance = 0.5f;
    [Range(0f,1f)] public float coherence = 0.5f;

    public void ApplyShift(float amount)
    {
        resonance = Mathf.Clamp01(resonance + amount);
        coherence = Mathf.Clamp01(coherence + amount * 0.8f);
    }
}
