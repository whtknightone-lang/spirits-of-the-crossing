
function clusterPlayers(players) {
    const worlds = {};
    players.forEach(p => {
        const key = Math.floor(p.r * 3); // simple clustering
        if (!worlds[key]) worlds[key] = [];
        worlds[key].push(p);
    });
    return worlds;
}

module.exports = { clusterPlayers };
