
let civs = [];

function updateCivilizations(resonance) {
    civs.push({ level: resonance, growth: Math.random() });
    return civs;
}

module.exports = { updateCivilizations };
