
using UnityEngine;

public class WorldStateVisualizer : MonoBehaviour
{
    public float resonance;

    void Update()
    {
        transform.localScale = Vector3.one * (1f + resonance);
    }
}
