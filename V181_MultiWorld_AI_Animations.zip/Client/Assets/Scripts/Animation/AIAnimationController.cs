
using UnityEngine;

public class AIAnimationController : MonoBehaviour
{
    public Animator animator;
    public float emotionalState;

    void Update()
    {
        emotionalState = Mathf.PingPong(Time.time * 0.2f, 1f);
        if (animator != null)
        {
            animator.SetFloat("Emotion", emotionalState);
        }
    }
}
