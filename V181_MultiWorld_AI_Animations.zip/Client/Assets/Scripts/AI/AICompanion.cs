
using UnityEngine;

public class AICompanion : MonoBehaviour
{
    public Transform player;
    public float followStrength = 2f;

    void Update()
    {
        if (player == null) return;
        transform.position = Vector3.Lerp(transform.position, player.position, Time.deltaTime * followStrength);
    }
}
