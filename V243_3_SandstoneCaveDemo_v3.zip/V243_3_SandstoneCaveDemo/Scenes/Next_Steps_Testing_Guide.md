# Next Steps Testing Guide

## What was added

This pass adds two high-value iteration tools:

- `CaveDebugHUD.cs` for live score inspection during play mode
- `CaveAnimationStateBridge.cs` for piping resonance/session values into Animator parameters

These let you answer two important questions quickly:

1. Is the cave interpreting the player the way we expect?
2. Are the statue and portal animations reacting to the same logic as the sorting system?

## Recommended Unity hookup

### 1. Add a Debug HUD object

Create an empty GameObject named `DebugHUD` and attach:
- `CaveDebugHUD`

Assign:
- `PlayerResponseTracker`
- `PlanetAffinityInterpreter`
- `CaveSessionController`
- `AdaptiveCaveAudioController`
- `PortalUnlockController`

Play mode result:
- top-left live display of breath, flow, spin, pair sync, calm, joy, wonder, distortion, source
- current chakra band and crown hold time
- current and achievable planet outputs
- current audio mode and portal state

### 2. Add animation state bridge to statues

On each awakened statue or spirit rig, attach:
- `Animator`
- `CaveAnimationStateBridge`

Assign:
- `PlayerResponseTracker`
- `CaveSessionController`
- optional `SpiritLikenessController`
- optional `PortalUnlockController`

Suggested Animator parameters:
- `Breath` float
- `Flow` float
- `Spin` float
- `Pair` float
- `Calm` float
- `Joy` float
- `Wonder` float
- `Distortion` float
- `Source` float
- `ChakraIndex` int
- `CrownHold` bool
- `Awakened` bool
- `AtCenter` bool
- `PortalUnlocked` bool

## Fast debug controls

Existing:
- `1` Breath
- `2` Flow
- `3` Spin
- `4` Pair
- `Q` Calm
- `W` Joy
- `E` Wonder
- `R` Distortion
- `T` Source

Added in this pass:
- `Y` evaluate planet sorting immediately
- `U` reset player tracking
- `I` restart session and reset tracking
- `` ` `` toggle debug HUD

## Best tuning pass

### Solo meditation test
- increase Breath and Calm
- confirm seated spirit awakens
- confirm stillness score rises
- confirm likely result trends toward `SourceVeil` or `MachineOrder`

### Flow dance test
- increase Flow, Joy, Wonder
- confirm flow dancer awakens
- confirm `WaterFlow` or `ForestHeart` becomes dominant

### Dervish test
- increase Spin, Wonder, Source
- confirm dervish spirit awakens
- confirm `SkySpiral` becomes dominant

### Pair resonance test
- increase Pair and Joy
- confirm pair spirits awaken
- confirm social weighting influences `ForestHeart` or pair-oriented world logic

## Strong next steps after this pass

1. Add a world-space sigil mesh projector that actually draws symbols on cave floor and wall.
2. Add animation clips and blend trees for sit, flow, twirl, and pair movement.
3. Add a small world-space HUD over the center disk for non-debug player feedback.
4. Add persistence so the cave remembers prior affinity results across visits.
