using UnityEngine;

namespace V243.SandstoneCave
{
    public class CaveAnimationStateBridge : MonoBehaviour
    {
        [Header("References")]
        public Animator animator;
        public PlayerResponseTracker playerResponseTracker;
        public CaveSessionController sessionController;
        public SpiritLikenessController spiritLikeness;

        [Header("Animator Parameters")]
        public string breathParam = "Breath";
        public string flowParam = "Flow";
        public string spinParam = "Spin";
        public string pairParam = "Pair";
        public string calmParam = "Calm";
        public string joyParam = "Joy";
        public string wonderParam = "Wonder";
        public string distortionParam = "Distortion";
        public string sourceParam = "Source";
        public string chakraIndexParam = "ChakraIndex";
        public string crownHoldParam = "CrownHold";
        public string awakenedParam = "Awakened";
        public string atCenterParam = "AtCenter";
        public string portalUnlockedParam = "PortalUnlocked";

        [Header("Optional")]
        public PortalUnlockController portalUnlockController;

        private void Reset()
        {
            animator = GetComponent<Animator>();
        }

        private void Update()
        {
            if (animator == null)
            {
                return;
            }

            if (playerResponseTracker != null)
            {
                CavePlayerResonanceState s = playerResponseTracker.LiveState;
                SetFloatSafe(breathParam, s.breathCoherence);
                SetFloatSafe(flowParam, s.movementFlow);
                SetFloatSafe(spinParam, s.spinStability);
                SetFloatSafe(pairParam, s.socialSync);
                SetFloatSafe(calmParam, s.calm);
                SetFloatSafe(joyParam, s.joy);
                SetFloatSafe(wonderParam, s.wonder);
                SetFloatSafe(distortionParam, s.distortion);
                SetFloatSafe(sourceParam, s.sourceAlignment);
            }

            if (sessionController != null)
            {
                animator.SetInteger(chakraIndexParam, (int)sessionController.chakraState.activeBand);
                animator.SetBool(crownHoldParam, sessionController.chakraState.isHolding);
            }

            if (spiritLikeness != null)
            {
                animator.SetBool(awakenedParam, spiritLikeness.awakened);
                animator.SetBool(atCenterParam, spiritLikeness.atCenter);
            }

            if (portalUnlockController != null)
            {
                animator.SetBool(portalUnlockedParam, portalUnlockController.portalUnlocked);
            }
        }

        private void SetFloatSafe(string paramName, float value)
        {
            if (!string.IsNullOrWhiteSpace(paramName))
            {
                animator.SetFloat(paramName, value);
            }
        }
    }
}
