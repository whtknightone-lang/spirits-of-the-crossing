using System.Text;
using UnityEngine;

namespace V243.SandstoneCave
{
    public class CaveDebugHUD : MonoBehaviour
    {
        [Header("References")]
        public PlayerResponseTracker playerResponseTracker;
        public PlanetAffinityInterpreter planetAffinityInterpreter;
        public CaveSessionController sessionController;
        public AdaptiveCaveAudioController adaptiveAudioController;
        public PortalUnlockController portalUnlockController;

        [Header("Display")]
        public bool visible = true;
        public bool showControls = true;
        public KeyCode toggleKey = KeyCode.BackQuote;
        public Rect panelRect = new Rect(16f, 16f, 460f, 520f);

        private GUIStyle _labelStyle;
        private GUIStyle _titleStyle;
        private readonly StringBuilder _sb = new StringBuilder(2048);

        private void Update()
        {
            if (Input.GetKeyDown(toggleKey))
            {
                visible = !visible;
            }
        }

        private void OnGUI()
        {
            if (!visible)
            {
                return;
            }

            EnsureStyles();
            GUILayout.BeginArea(panelRect, GUI.skin.box);
            GUILayout.Label("V243 Sandstone Cave Debug", _titleStyle);

            _sb.Clear();

            if (sessionController != null)
            {
                _sb.AppendLine($"Session: {(sessionController.sessionRunning ? "RUNNING" : sessionController.sessionComplete ? "COMPLETE" : "IDLE")}");
                _sb.AppendLine($"Timer: {sessionController.sessionTimer:0.0}s / {sessionController.totalSessionLength:0.0}s");
                _sb.AppendLine($"Chakra: {sessionController.chakraState.activeBand}  Progress: {sessionController.chakraState.progress01:0.00}");
                _sb.AppendLine($"Crown Hold: {sessionController.chakraState.holdTimer:0.0}s  Holding: {sessionController.chakraState.isHolding}");
                _sb.AppendLine();
            }

            if (playerResponseTracker != null)
            {
                CavePlayerResonanceState s = playerResponseTracker.LiveState;
                _sb.AppendLine("Live Resonance");
                AppendBar("Breath", s.breathCoherence);
                AppendBar("Flow", s.movementFlow);
                AppendBar("Spin", s.spinStability);
                AppendBar("Pair", s.socialSync);
                AppendBar("Calm", s.calm);
                AppendBar("Joy", s.joy);
                AppendBar("Wonder", s.wonder);
                AppendBar("Distort", s.distortion);
                AppendBar("Source", s.sourceAlignment);
                _sb.AppendLine();

                PlayerResponseSample sample = playerResponseTracker.BuildSample();
                _sb.AppendLine("Tracked Peaks / Averages");
                AppendBar("Stillness", sample.stillnessScore);
                AppendBar("FlowPeak", sample.flowScore);
                AppendBar("SpinPeak", sample.spinScore);
                AppendBar("PairPeak", sample.pairSyncScore);
                AppendBar("Avg Calm", sample.calmScore);
                AppendBar("Avg Joy", sample.joyScore);
                AppendBar("Avg Wonder", sample.wonderScore);
                AppendBar("Avg Dist", sample.distortionScore);
                AppendBar("Avg Source", sample.sourceAlignmentScore);
                _sb.AppendLine();
            }

            if (planetAffinityInterpreter != null)
            {
                _sb.AppendLine("Planet Sorting");
                _sb.AppendLine($"Current: {planetAffinityInterpreter.currentAffinityPlanet} ({planetAffinityInterpreter.currentAffinityScore:0.00})");
                _sb.AppendLine($"Achievable: {planetAffinityInterpreter.achievableAffinityPlanet} ({planetAffinityInterpreter.achievableAffinityScore:0.00})");
                _sb.AppendLine();
            }

            if (adaptiveAudioController != null)
            {
                _sb.AppendLine($"Audio Mode: {adaptiveAudioController.currentMode}");
            }

            if (portalUnlockController != null)
            {
                _sb.AppendLine($"Portal Unlocked: {portalUnlockController.portalUnlocked}");
            }

            GUILayout.Label(_sb.ToString(), _labelStyle);

            if (showControls)
            {
                GUILayout.Space(6f);
                GUILayout.Label("Debug Keys", _titleStyle);
                GUILayout.Label("1 Breath  2 Flow  3 Spin  4 Pair", _labelStyle);
                GUILayout.Label("Q Calm  W Joy  E Wonder  R Distortion  T Source", _labelStyle);
                GUILayout.Label("Y Evaluate planets now  U Reset tracking  I Restart session", _labelStyle);
                GUILayout.Label("` Toggle HUD", _labelStyle);
            }

            GUILayout.EndArea();
        }

        private void AppendBar(string label, float value)
        {
            const int width = 20;
            int fill = Mathf.Clamp(Mathf.RoundToInt(value * width), 0, width);
            _sb.Append(label.PadRight(10));
            _sb.Append('[');
            for (int i = 0; i < width; i++)
            {
                _sb.Append(i < fill ? '#' : '-');
            }
            _sb.Append("] ");
            _sb.Append(value.ToString("0.00"));
            _sb.AppendLine();
        }

        private void EnsureStyles()
        {
            if (_labelStyle != null)
            {
                return;
            }

            _labelStyle = new GUIStyle(GUI.skin.label)
            {
                richText = false,
                fontSize = 14,
                wordWrap = false,
                alignment = TextAnchor.UpperLeft
            };

            _titleStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 16,
                fontStyle = FontStyle.Bold
            };
        }
    }
}
