
using UnityEngine;

public class MetaAwareness : MonoBehaviour
{
    public float metaLevel;

    void Update()
    {
        metaLevel += Time.deltaTime * 0.002f;
    }
}
