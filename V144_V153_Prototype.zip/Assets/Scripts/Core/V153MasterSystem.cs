
using UnityEngine;

public class V153MasterSystem : MonoBehaviour
{
    void Start()
    {
        if (FindObjectOfType<PrototypeIntegration>() == null)
            gameObject.AddComponent<PrototypeIntegration>();
    }
}
