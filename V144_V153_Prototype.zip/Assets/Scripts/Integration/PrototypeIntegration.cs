
using UnityEngine;

public class PrototypeIntegration : MonoBehaviour
{
    void Start()
    {
        AddIfMissing<MetaAwareness>();
        AddIfMissing<IdentityContinuity>();
        AddIfMissing<ElderConsciousness>();
    }

    void AddIfMissing<T>() where T : Component
    {
        if (FindObjectOfType<T>() == null)
            gameObject.AddComponent<T>();
    }
}
