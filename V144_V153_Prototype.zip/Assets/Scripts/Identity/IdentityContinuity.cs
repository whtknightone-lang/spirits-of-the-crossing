
using UnityEngine;

public class IdentityContinuity : MonoBehaviour
{
    public string identityID = "entity";
    public float continuityStrength;

    void Update()
    {
        continuityStrength += Time.deltaTime * 0.001f;
    }
}
