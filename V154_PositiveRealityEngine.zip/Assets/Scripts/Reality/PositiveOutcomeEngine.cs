
using UnityEngine;

public class PositiveOutcomeEngine : MonoBehaviour
{
    [Range(0f,1f)] public float alignment = 0.5f;

    public float EvaluateOutcome(float difficulty)
    {
        float outcome = Mathf.Lerp(difficulty, 1f, alignment);
        return outcome;
    }
}
