
using UnityEngine;

public class MeaningSystem : MonoBehaviour
{
    public float meaningLevel;

    public void RegisterExperience(float outcome)
    {
        meaningLevel += outcome * 0.1f;
    }
}
