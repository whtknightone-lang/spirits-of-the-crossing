
using UnityEngine;

public class SelfModel : MonoBehaviour
{
    public float confidence;
    public float expectation;

    void Update()
    {
        expectation = Mathf.Lerp(expectation, confidence, Time.deltaTime);
    }
}
