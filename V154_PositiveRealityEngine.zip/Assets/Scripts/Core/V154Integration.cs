
using UnityEngine;

public class V154Integration : MonoBehaviour
{
    void Start()
    {
        if (FindObjectOfType<PositiveOutcomeEngine>() == null)
            gameObject.AddComponent<PositiveOutcomeEngine>();

        if (FindObjectOfType<MeaningSystem>() == null)
            gameObject.AddComponent<MeaningSystem>();

        if (FindObjectOfType<SelfModel>() == null)
            gameObject.AddComponent<SelfModel>();
    }
}
