
import torch

class HighPerfWorld:
    def __init__(self, n=100000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)
        self.velocity = torch.zeros(n,3)

    def step(self):
        # vectorized movement
        self.velocity += 0.01 * torch.randn_like(self.velocity)
        self.position += self.velocity
        self.position.clamp_(0,1)

        # vectorized dynamics
        phase = torch.rand_like(self.energy)
        self.energy += 0.01 * torch.sin(phase)

        # decay
        self.energy *= 0.999
