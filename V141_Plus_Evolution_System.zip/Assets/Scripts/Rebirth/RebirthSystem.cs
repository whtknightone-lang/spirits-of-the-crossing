
using UnityEngine;

public class RebirthSystem : MonoBehaviour
{
    public float life;
    public bool dead;

    void Update()
    {
        life += Time.deltaTime;

        if (life > 30f && !dead)
        {
            dead = true;
            Debug.Log("Entity died, preparing rebirth...");
        }

        if (dead && life > 35f)
        {
            life = 0f;
            dead = false;
            Debug.Log("Reborn with new traits");
        }
    }
}
