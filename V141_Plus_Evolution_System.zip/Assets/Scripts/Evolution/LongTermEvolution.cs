
using UnityEngine;

public class LongTermEvolution : MonoBehaviour
{
    public float evolutionLevel;

    void Update()
    {
        evolutionLevel += Time.deltaTime * 0.001f;
    }
}
