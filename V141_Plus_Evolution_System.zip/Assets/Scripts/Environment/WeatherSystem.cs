
using UnityEngine;

public class WeatherSystem : MonoBehaviour
{
    public float rain;
    public float wind;
    public float temperature;

    void Update()
    {
        rain = Mathf.PingPong(Time.time * 0.05f, 1f);
        wind = Mathf.PingPong(Time.time * 0.03f, 1f);
        temperature = Mathf.Lerp(-10f, 35f, Mathf.PingPong(Time.time * 0.01f, 1f));
    }
}
