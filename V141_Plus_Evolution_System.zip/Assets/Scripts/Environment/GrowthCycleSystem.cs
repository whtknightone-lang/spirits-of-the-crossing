
using UnityEngine;

public class GrowthCycleSystem : MonoBehaviour
{
    public float growthPhase;

    void Update()
    {
        growthPhase = Mathf.PingPong(Time.time * 0.02f, 1f);
    }
}
