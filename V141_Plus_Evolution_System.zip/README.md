V141+ Evolution, Weather, Growth Cycles, Birth/Death/Reincarnation
