
using UnityEngine;

public class GroupCoherenceDetector : MonoBehaviour
{
    public float groupCoherence;

    public void Evaluate(float[] resonances)
    {
        float sum = 0f;
        foreach (float r in resonances) sum += r;
        float avg = sum / resonances.Length;

        float variance = 0f;
        foreach (float r in resonances) variance += Mathf.Abs(r - avg);

        groupCoherence = Mathf.Clamp01(1f - (variance / resonances.Length));
    }
}
