
using UnityEngine;

public class ReceptivityController : MonoBehaviour
{
    [Range(0f,1f)] public float receptivity = 0.5f;

    public float GetInfluence(float sourceSignal)
    {
        return sourceSignal * receptivity;
    }
}
