
using UnityEngine;

public class V2094Manager : MonoBehaviour
{
    public SourceTuningSystem source;
    public GroupCoherenceDetector group;
    public GuidedEventTrigger trigger;

    public ReceptivityController[] agents;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            float[] res = new float[agents.Length];
            for (int i = 0; i < agents.Length; i++)
                res[i] = agents[i].receptivity;

            group.Evaluate(res);
            source.GenerateSignal(group.groupCoherence);

            foreach (var a in agents)
            {
                float influence = a.GetInfluence(source.sourceSignal);
                Debug.Log("Agent influenced: " + influence);
            }

            trigger.TryTrigger(group.groupCoherence, source.sourceSignal);
        }
    }
}
