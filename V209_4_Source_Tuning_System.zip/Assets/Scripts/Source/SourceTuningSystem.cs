
using UnityEngine;

public class SourceTuningSystem : MonoBehaviour
{
    public float sourceSignal = 0f;
    public float tuningStrength = 1f;

    public void GenerateSignal(float groupCoherence)
    {
        sourceSignal = Mathf.Clamp01(groupCoherence * tuningStrength);
    }
}
