
V209.4 Source-Guided Co-Creation System

Core Features:
- Source tuning (guidance field)
- Per-entity receptivity (choice)
- Group coherence detection
- Guided event triggering

Core Idea:
Source offers alignment, entities choose to receive or not.
