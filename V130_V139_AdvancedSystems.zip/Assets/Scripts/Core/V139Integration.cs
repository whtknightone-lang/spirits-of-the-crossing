
using UnityEngine;

public class V139Integration : MonoBehaviour
{
    void Start()
    {
        if (FindObjectOfType<AdaptiveSourceAI>() == null)
            gameObject.AddComponent<AdaptiveSourceAI>();

        if (FindObjectOfType<ResonanceNetwork>() == null)
            gameObject.AddComponent<ResonanceNetwork>();

        if (FindObjectOfType<FullBodyDragon>() == null)
            gameObject.AddComponent<FullBodyDragon>();
    }
}
