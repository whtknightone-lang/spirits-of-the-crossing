
using UnityEngine;

public class AdaptiveSourceAI : MonoBehaviour
{
    public float playerHarmony;
    public float signalStrength;

    void Update()
    {
        // Source responds to player state
        signalStrength = Mathf.Lerp(signalStrength, playerHarmony, Time.deltaTime);
    }
}
