
using UnityEngine;
using System.Collections.Generic;

public class ResonanceNetwork : MonoBehaviour
{
    public List<float> playerResonance = new List<float>();

    public float globalResonance;

    void Update()
    {
        if (playerResonance.Count == 0) return;

        float sum = 0f;
        foreach (var r in playerResonance) sum += r;

        globalResonance = sum / playerResonance.Count;
    }
}
