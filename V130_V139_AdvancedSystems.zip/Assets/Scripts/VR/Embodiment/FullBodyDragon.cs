
using UnityEngine;

public class FullBodyDragon : MonoBehaviour
{
    public Transform leftHand;
    public Transform rightHand;

    public float lift = 0f;

    void Update()
    {
        if (leftHand == null || rightHand == null) return;

        float wingSpan = Vector3.Distance(leftHand.position, rightHand.position);
        lift = wingSpan * 0.1f;

        transform.position += Vector3.up * lift * Time.deltaTime;
    }
}
