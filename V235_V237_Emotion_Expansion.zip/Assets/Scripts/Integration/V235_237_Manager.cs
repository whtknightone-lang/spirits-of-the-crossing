
using UnityEngine;

public class V235_237_Manager : MonoBehaviour
{
    public EmotionDecision decision;
    public EmotionalMemory memory;
    public EmotionalField field;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            string action = decision.Decide();
            memory.Record(field.joy);
            Debug.Log("Decision: " + action + " | Avg Joy: " + memory.GetAverage());
        }
    }
}
