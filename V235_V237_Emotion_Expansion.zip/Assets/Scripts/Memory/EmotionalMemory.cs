
using UnityEngine;
using System.Collections.Generic;

public class EmotionalMemory : MonoBehaviour
{
    public List<float> pastJoy = new List<float>();

    public void Record(float joy)
    {
        pastJoy.Add(joy);
    }

    public float GetAverage()
    {
        if (pastJoy.Count == 0) return 0;
        float sum = 0;
        foreach (var j in pastJoy) sum += j;
        return sum / pastJoy.Count;
    }
}
