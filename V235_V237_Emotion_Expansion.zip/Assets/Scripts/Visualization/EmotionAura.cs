
using UnityEngine;

public class EmotionAura : MonoBehaviour
{
    public EmotionalField field;
    public Renderer rend;

    void Update()
    {
        if (rend == null || field == null) return;

        Color c = new Color(field.anger, field.joy, field.curiosity);
        rend.material.color = c;
    }
}
