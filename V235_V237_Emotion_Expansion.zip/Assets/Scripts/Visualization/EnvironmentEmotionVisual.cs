
using UnityEngine;

public class EnvironmentEmotionVisual : MonoBehaviour
{
    public EmotionalField field;

    void Update()
    {
        float intensity = field.joy - field.fear;
        RenderSettings.ambientLight = Color.Lerp(Color.red, Color.blue, intensity + 0.5f);
    }
}
