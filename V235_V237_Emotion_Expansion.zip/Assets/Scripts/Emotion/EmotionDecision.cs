
using UnityEngine;

public class EmotionDecision : MonoBehaviour
{
    public EmotionalField field;

    public string Decide()
    {
        if (field.fear > 0.6f) return "Avoid";
        if (field.curiosity > 0.6f) return "Explore";
        if (field.joy > 0.6f) return "Engage";
        return "Neutral";
    }
}
