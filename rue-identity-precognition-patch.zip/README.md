# RUE Identity + Precognition Patch

This patch adds two new layers to the 3D integrated RUE universe:

A. **Identity tuning artifact**
- persistent memory
- self-preference reward
- coherence preservation
- easy-to-edit tuning constants

B. **Precognition edge learning**
- one-step future probe
- 3 candidate drive tests
- future score using:
  - world match
  - identity continuity
  - internal coherence

## Jumping-off presets

### Preset A — Balanced Identity
- identity is visible but not rigid
- best for stable clustering

### Preset B — Exploratory Precognition
- identity is lighter
- future probing is stronger
- best for more dynamic migration and adaptation

## Run

```bash
pip install -r requirements.txt
python experiments/run_identity_precognition_viewer.py
```
