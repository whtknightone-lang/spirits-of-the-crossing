import numpy as np
from engine.snowflake.brain_3d import SnowflakeBrain3D

def circular_diff(a: float, b: float) -> float:
    return float(np.angle(np.exp(1j * (a - b))))

PRESETS = {
    "A": {
        "IDENTITY_GAIN": 0.22,
        "COHERENCE_FLOOR": 0.30,
        "COHERENCE_PENALTY": 0.08,
        "PREDICTION_GAIN": 0.35,
        "FUTURE_MATCH_WEIGHT": 0.50,
        "FUTURE_IDENTITY_WEIGHT": 0.30,
        "FUTURE_SYNC_WEIGHT": 0.20,
        "CANDIDATE_DRIVES": [-0.03, 0.0, 0.03],
    },
    "B": {
        "IDENTITY_GAIN": 0.16,
        "COHERENCE_FLOOR": 0.28,
        "COHERENCE_PENALTY": 0.06,
        "PREDICTION_GAIN": 0.42,
        "FUTURE_MATCH_WEIGHT": 0.55,
        "FUTURE_IDENTITY_WEIGHT": 0.20,
        "FUTURE_SYNC_WEIGHT": 0.25,
        "CANDIDATE_DRIVES": [-0.04, 0.0, 0.04],
    },
}

class Agent:
    def __init__(self, planet_id: int, region_id: int, preset: str = "A"):
        self.planet_id = planet_id
        self.region_id = region_id
        self.brain = SnowflakeBrain3D()
        self.energy = 2.0
        self.last_reward = 0.0
        self.last_penalty = 0.0
        self.last_prediction_gain = 0.0
        self.preset = PRESETS[preset].copy()

    def signature(self) -> float:
        return self.brain.mean_phase()

    def choose_future_drive(self, local_phase: float):
        best_drive = 0.0
        best_score = -1e9

        for d in self.preset["CANDIDATE_DRIVES"]:
            future = self.brain.simulate_one_step(drive=d)
            future_sync = self.brain.sync(future)
            future_identity = self.brain.identity_match(future)
            future_match = np.cos(circular_diff(self.brain.mean_phase(future), local_phase))

            score = (
                self.preset["FUTURE_MATCH_WEIGHT"] * future_match +
                self.preset["FUTURE_IDENTITY_WEIGHT"] * future_identity +
                self.preset["FUTURE_SYNC_WEIGHT"] * future_sync
            )

            if score > best_score:
                best_score = score
                best_drive = d

        return best_drive

    def reward_components(self, local_phase: float, local_energy: float, social_match: float):
        sig = self.signature()
        match = np.cos(circular_diff(sig, local_phase))

        positive = max(0.0, match - 0.10) * local_energy
        mismatch = max(0.0, 0.15 - match) * 0.35 * local_energy
        living_cost = 0.05
        social_bonus = max(0.0, social_match) * 0.10
        social_penalty = max(0.0, -social_match) * 0.08

        identity = self.brain.identity_match() * self.preset["IDENTITY_GAIN"]

        coherence = self.brain.sync()
        if coherence < self.preset["COHERENCE_FLOOR"]:
            mismatch += self.preset["COHERENCE_PENALTY"]

        reward = positive + social_bonus + identity
        penalty = mismatch + living_cost + social_penalty
        return reward, penalty, match

    def step(self, local_phase: float, local_energy: float, social_match: float):
        reward, penalty, match = self.reward_components(local_phase, local_energy, social_match)

        base_drive = np.tanh(local_energy / 5.0) * 0.012
        base_drive += 0.012 * social_match
        base_drive -= 0.010 * max(0.0, -social_match)
        base_drive += 0.012 * match

        future_drive = self.choose_future_drive(local_phase)
        total_drive = base_drive + self.preset["PREDICTION_GAIN"] * future_drive

        self.brain.step(drive=total_drive)
        self.energy += reward - penalty
        self.last_reward = reward
        self.last_penalty = penalty
        self.last_prediction_gain = self.preset["PREDICTION_GAIN"] * future_drive
