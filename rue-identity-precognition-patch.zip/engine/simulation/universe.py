import numpy as np
from engine.simulation.star import Star
from engine.simulation.planet import Planet
from engine.agents.agent import Agent

def circular_diff(a: float, b: float) -> float:
    return float(np.angle(np.exp(1j * (a - b))))

class Universe:
    def __init__(self, num_planets: int = 5, agents_per_planet: int = 16, regions_per_planet: int = 8, preset: str = "A"):
        self.star = Star()
        self.planets = [Planet(i, radius=2.5 + i * 1.8, n_regions=regions_per_planet) for i in range(num_planets)]
        self.agents = []
        for p in self.planets:
            for j in range(agents_per_planet):
                self.agents.append(Agent(planet_id=p.index, region_id=j % regions_per_planet, preset=preset))
        self.time = 0
        self.last_star_energy = 0.0
        self.preset = preset

    def _planet_agents(self, planet_id: int):
        return [a for a in self.agents if a.planet_id == planet_id]

    def _social_match_for_agent(self, agent, neighbors):
        if not neighbors:
            return 0.0
        sig = agent.signature()
        vals = []
        for other in neighbors:
            if other is agent:
                continue
            d = circular_diff(sig, other.signature())
            vals.append(np.cos(d))
        if not vals:
            return 0.0
        return float(np.mean(vals))

    def _move_agents(self):
        for p in self.planets:
            planet_agents = self._planet_agents(p.index)
            for agent in planet_agents:
                current = agent.region_id
                scores = []
                for rid in range(p.n_regions):
                    local_phase = p.region_phases[rid]
                    local_energy = p.region_energies[rid]
                    match = np.cos(circular_diff(agent.signature(), local_phase))

                    peers = [a for a in planet_agents if a.region_id == rid and a is not agent]
                    if peers:
                        peer_match = np.mean([np.cos(circular_diff(agent.signature(), peer.signature())) for peer in peers])
                    else:
                        peer_match = 0.0

                    crowd_penalty = 0.03 * len(peers)
                    score = 0.70 * match + 0.25 * peer_match + 0.20 * (local_energy / max(0.5, p.energy)) - crowd_penalty
                    scores.append(score)

                best_region = int(np.argmax(scores))
                if best_region != current and scores[best_region] > scores[current] + 0.08:
                    agent.region_id = best_region

    def step(self):
        self.time += 1
        self.last_star_energy = self.star.emit_energy()

        for p in self.planets:
            p.update_orbit()
            p.update_regions(self.last_star_energy)

        for p in self.planets:
            planet_agents = self._planet_agents(p.index)
            for agent in planet_agents:
                neighbors = [a for a in planet_agents if a.region_id == agent.region_id]
                social_match = self._social_match_for_agent(agent, neighbors)
                local_phase = p.region_phases[agent.region_id]
                local_energy = p.region_energies[agent.region_id]
                agent.step(local_phase=local_phase, local_energy=local_energy, social_match=social_match)

        self._move_agents()

    def all_phases(self):
        return np.concatenate([a.brain.phases for a in self.agents])

    def all_energies(self):
        return np.array([a.energy for a in self.agents], dtype=float)

    def mean_reward(self):
        return float(np.mean([a.last_reward for a in self.agents]))

    def mean_penalty(self):
        return float(np.mean([a.last_penalty for a in self.agents]))

    def mean_prediction_bias(self):
        return float(np.mean([a.last_prediction_gain for a in self.agents]))

    def mean_identity_persistence(self):
        vals = [a.brain.identity_match() for a in self.agents]
        return float(np.mean(vals))
