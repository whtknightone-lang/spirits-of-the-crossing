
using UnityEngine;

public class RegionalPuzzle : MonoBehaviour
{
    public float regionProgress;
    public bool unlocked;

    public void ApplyContribution(float value)
    {
        regionProgress += value * Time.deltaTime;
        if (regionProgress > 1f)
        {
            unlocked = true;
            Debug.Log("Region unlocked!");
        }
    }
}
