
using UnityEngine;

public class AIAdaptiveTeacher : MonoBehaviour
{
    public float groupPerformance;
    public float hintStrength;

    void Update()
    {
        // stronger hints if struggling
        hintStrength = Mathf.Lerp(2f, 0.2f, groupPerformance);

        transform.localScale = Vector3.one * (1f + hintStrength * 0.1f);
    }
}
