
using UnityEngine;

public class RoleEvolution : MonoBehaviour
{
    public string currentRole;
    public float roleExperience;

    void Update()
    {
        roleExperience += Time.deltaTime;

        if (roleExperience > 100f)
        {
            currentRole += "_Advanced";
        }
    }
}
