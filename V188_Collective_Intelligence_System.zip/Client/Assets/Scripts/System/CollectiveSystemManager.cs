
using UnityEngine;

public class CollectiveSystemManager : MonoBehaviour
{
    public float globalProgress;
    public int activePlayers;

    public void UpdateProgress(float value)
    {
        globalProgress += value;
    }
}
