
V188 Collective Intelligence System

Adds:
- Large-scale cooperative world puzzles
- Role evolution over time
- AI teaching intelligence (adaptive guidance)

Core Idea:
Groups evolve intelligence together across regions and time.
