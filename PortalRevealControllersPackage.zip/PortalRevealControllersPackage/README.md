# Portal Reveal Controllers Package

This package is the visual payoff layer for the SoloStrongUnifiedChamberField system.

## What "portal reveal controllers" means
These controllers take scored chamber outcomes (current portal, achievable portal, challenge portal) and turn them into visible, audible cave responses:
- glowing wall recesses
- animated portal glimpses
- floor sigil projection on the center disk
- world-space aura/light feedback
- threshold activation for the chosen portal

## Included scripts
- `PortalRevealTypes.cs`
- `PortalRevealConfigLoader.cs`
- `GlimpsePortalController.cs`
- `FloorSigilProjector.cs`
- `WorldSpaceFeedbackController.cs`
- `CavePortalRevealManager.cs`
- `PortalRevealDebugInput.cs`

## Included data
- `StreamingAssets/portal_reveal_visuals.json`

## Fast hookup
1. Create 5 wall portal recess GameObjects.
2. Add `GlimpsePortalController` to each recess and assign a unique `portalType`.
3. Add `PortalRevealConfigLoader` to a manager object.
4. Add `CavePortalRevealManager` to the same manager and populate the `portals` list.
5. Add `FloorSigilProjector` to the center disk.
6. Add `WorldSpaceFeedbackController` and assign the floor sigil projector.
7. Link `worldFeedback` in `CavePortalRevealManager`.
8. For quick testing, add `PortalRevealDebugInput`.

## Debug keys
- `1` Fire current / Air achievable / Forest challenge
- `2` Ocean current / Air achievable / Fire challenge
- `3` Forest current / Source achievable / Fire challenge
- `4` Source current / Forest achievable / Air challenge
- `5` Air current / Ocean achievable / Fire challenge
- `Enter` Commit to the current portal threshold

## Integration note
If you want to connect this to `SoloStrongPortalScorer`, call:
- `ApplyManualDecision(current, achievable, challenge)` after chamber scoring
- `RefreshPortalReveals()` when the chamber field changes
- `CommitToCurrentPortal()` when the player locks in

## Ancient layer included
All portal visual states include:
- `ruinMotif`
- `ghostAlienLikeness`

This lets the cave, center disk, and portal windows feel like one ancient ruin machine inhabited by ancestor-like alien spirits.
