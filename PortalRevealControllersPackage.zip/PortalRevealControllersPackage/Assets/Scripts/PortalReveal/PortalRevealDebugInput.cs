using UnityEngine;

public class PortalRevealDebugInput : MonoBehaviour
{
    public CavePortalRevealManager revealManager;

    void Update()
    {
        if (revealManager == null) return;

        if (Input.GetKeyDown(KeyCode.Alpha1))
            revealManager.ApplyManualDecision(ResonancePortalType.FireMilitary, ResonancePortalType.AirDancing, ResonancePortalType.ForestCalm);
        if (Input.GetKeyDown(KeyCode.Alpha2))
            revealManager.ApplyManualDecision(ResonancePortalType.OceanSurf, ResonancePortalType.AirDancing, ResonancePortalType.FireMilitary);
        if (Input.GetKeyDown(KeyCode.Alpha3))
            revealManager.ApplyManualDecision(ResonancePortalType.ForestCalm, ResonancePortalType.SourceEnergyWells, ResonancePortalType.FireMilitary);
        if (Input.GetKeyDown(KeyCode.Alpha4))
            revealManager.ApplyManualDecision(ResonancePortalType.SourceEnergyWells, ResonancePortalType.ForestCalm, ResonancePortalType.AirDancing);
        if (Input.GetKeyDown(KeyCode.Alpha5))
            revealManager.ApplyManualDecision(ResonancePortalType.AirDancing, ResonancePortalType.OceanSurf, ResonancePortalType.FireMilitary);
        if (Input.GetKeyDown(KeyCode.Return))
            revealManager.CommitToCurrentPortal();
    }
}
