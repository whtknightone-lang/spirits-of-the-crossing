using UnityEngine;

public class WorldSpaceFeedbackController : MonoBehaviour
{
    [Header("Scene References")]
    public Renderer auraRingRenderer;
    public Light chamberResponseLight;
    public ParticleSystem sourceThreadParticles;
    public FloorSigilProjector floorSigilProjector;

    [Header("Runtime")]
    public Color currentColor = Color.white;
    [Range(0f, 1f)] public float intensity;

    private static readonly int EmissionColor = Shader.PropertyToID("_EmissionColor");

    public void ApplyFeedback(ResonancePortalType portalType, Color color, float feedbackIntensity)
    {
        currentColor = color;
        intensity = Mathf.Clamp01(feedbackIntensity);

        if (auraRingRenderer != null)
        {
            foreach (var mat in auraRingRenderer.materials)
            {
                if (mat.HasProperty(EmissionColor))
                    mat.SetColor(EmissionColor, currentColor * Mathf.Lerp(0f, 2.25f, intensity));
            }
        }

        if (chamberResponseLight != null)
        {
            chamberResponseLight.color = currentColor;
            chamberResponseLight.intensity = Mathf.Lerp(0.2f, 4.5f, intensity);
        }

        if (sourceThreadParticles != null)
        {
            var main = sourceThreadParticles.main;
            main.startColor = currentColor;
            var emission = sourceThreadParticles.emission;
            emission.rateOverTime = Mathf.Lerp(2f, 45f, intensity);
            if (!sourceThreadParticles.isPlaying) sourceThreadParticles.Play();
        }

        if (floorSigilProjector != null)
            floorSigilProjector.SetPortalState(portalType, color, intensity);
    }
}
