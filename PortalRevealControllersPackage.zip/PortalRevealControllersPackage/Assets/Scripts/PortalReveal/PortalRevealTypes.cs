using System;
using UnityEngine;

[Serializable]
public enum ResonancePortalType
{
    FireMilitary,
    OceanSurf,
    ForestCalm,
    SourceEnergyWells,
    AirDancing
}

[Serializable]
public class PortalRevealVisualState
{
    public ResonancePortalType portalType;
    public string displayName;
    public string ruinMotif;
    public string ghostAlienLikeness;
    public Color baseColor = Color.white;
    public Color accentColor = Color.white;
    public string particleStateId;
    public string audioStateId;
    public string sigilId;
}

[Serializable]
public class PortalRevealVisualStateList
{
    public PortalRevealVisualState[] portals;
}
