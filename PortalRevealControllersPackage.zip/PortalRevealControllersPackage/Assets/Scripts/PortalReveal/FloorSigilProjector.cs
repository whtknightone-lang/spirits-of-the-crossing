using UnityEngine;

public class FloorSigilProjector : MonoBehaviour
{
    public Renderer sigilRenderer;
    public Light sigilLight;
    public Animator animator;

    [Range(0f, 1f)] public float revealAmount;
    public ResonancePortalType activePortal;
    public Color activeColor = Color.white;

    private static readonly int EmissionColor = Shader.PropertyToID("_EmissionColor");
    private static readonly int RevealAmount = Shader.PropertyToID("_RevealAmount");

    public void SetPortalState(ResonancePortalType portalType, Color portalColor, float amount)
    {
        activePortal = portalType;
        activeColor = portalColor;
        revealAmount = Mathf.Clamp01(amount);

        if (sigilRenderer != null)
        {
            foreach (var mat in sigilRenderer.materials)
            {
                if (mat.HasProperty(EmissionColor))
                    mat.SetColor(EmissionColor, activeColor * Mathf.Lerp(0f, 2f, revealAmount));
                if (mat.HasProperty(RevealAmount))
                    mat.SetFloat(RevealAmount, revealAmount);
            }
        }

        if (sigilLight != null)
        {
            sigilLight.enabled = revealAmount > 0.01f;
            sigilLight.color = activeColor;
            sigilLight.intensity = Mathf.Lerp(0f, 5f, revealAmount);
        }

        if (animator != null)
        {
            animator.SetFloat("RevealAmount", revealAmount);
            animator.SetInteger("PortalType", (int)activePortal);
        }
    }
}
