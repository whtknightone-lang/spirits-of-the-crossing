using System.Collections.Generic;
using UnityEngine;

public class CavePortalRevealManager : MonoBehaviour
{
    [Header("Inputs")]
    public PortalRevealConfigLoader configLoader;
    public List<GlimpsePortalController> portals = new List<GlimpsePortalController>();

    [Header("Optional Integration")]
    public MonoBehaviour soloStrongPortalScorerBehaviour;
    public WorldSpaceFeedbackController worldFeedback;

    [Header("Current Chamber Decision")]
    public ResonancePortalType currentPortal;
    public ResonancePortalType achievablePortal;
    public ResonancePortalType challengePortal;

    [Range(0f, 1f)] public float currentReveal = 0.9f;
    [Range(0f, 1f)] public float achievableReveal = 0.55f;
    [Range(0f, 1f)] public float challengeReveal = 0.35f;

    [Range(0f, 1f)] public float currentStability = 0.9f;
    [Range(0f, 1f)] public float achievableStability = 0.55f;
    [Range(0f, 1f)] public float challengeStability = 0.25f;

    public void ApplyManualDecision(ResonancePortalType current, ResonancePortalType achievable, ResonancePortalType challenge)
    {
        currentPortal = current;
        achievablePortal = achievable;
        challengePortal = challenge;
        RefreshPortalReveals();
    }

    public void RefreshPortalReveals()
    {
        foreach (var portal in portals)
        {
            if (portal == null) continue;

            if (configLoader != null && configLoader.TryGetState(portal.portalType, out var state))
                portal.ApplyVisualState(state);

            bool isCurrent = portal.portalType == currentPortal;
            bool isAchievable = portal.portalType == achievablePortal;
            bool isChallenge = portal.portalType == challengePortal;

            float reveal = 0.06f;
            float stability = 0.15f;

            if (isCurrent)
            {
                reveal = currentReveal;
                stability = currentStability;
            }
            else if (isAchievable)
            {
                reveal = achievableReveal;
                stability = achievableStability;
            }
            else if (isChallenge)
            {
                reveal = challengeReveal;
                stability = challengeStability;
            }

            portal.SetRoleFlags(isCurrent, isAchievable, isChallenge);
            portal.SetReveal(reveal);
            portal.SetStability(stability);
        }

        ApplyWorldFeedback();
    }

    public void CommitToCurrentPortal()
    {
        foreach (var portal in portals)
        {
            if (portal == null) continue;
            if (portal.portalType == currentPortal)
                portal.ActivateThreshold();
            else
                portal.DeactivateThreshold();
        }

        ApplyWorldFeedback(1f);
    }

    public void ApplyWorldFeedback(float forcedIntensity = -1f)
    {
        if (worldFeedback == null) return;

        foreach (var portal in portals)
        {
            if (portal == null) continue;
            if (portal.portalType != currentPortal) continue;

            float intensity = forcedIntensity >= 0f ? forcedIntensity : Mathf.Clamp01(portal.revealAmount * 0.85f + portal.stability * 0.15f);
            worldFeedback.ApplyFeedback(currentPortal, portal.accentColor, intensity);
            return;
        }
    }
}
