using UnityEngine;

public class GlimpsePortalController : MonoBehaviour
{
    [Header("Identity")]
    public ResonancePortalType portalType;
    public string displayName;
    [TextArea] public string ruinMotif;
    [TextArea] public string ghostAlienLikeness;

    [Header("Scene References")]
    public GameObject glimpseVisualRoot;
    public Renderer[] revealRenderers;
    public Light[] revealLights;
    public ParticleSystem[] revealParticles;
    public AudioSource portalAudio;
    public Animator animator;

    [Header("State")]
    [Range(0f, 1f)] public float revealAmount;
    [Range(0f, 1f)] public float stability;
    public bool isCurrentPortal;
    public bool isAchievablePortal;
    public bool isChallengePortal;
    public bool isActiveThreshold;

    [Header("Colors")]
    public Color baseColor = Color.white;
    public Color accentColor = Color.white;

    private static readonly int EmissionColor = Shader.PropertyToID("_EmissionColor");

    public void ApplyVisualState(PortalRevealVisualState state)
    {
        if (state == null) return;

        displayName = state.displayName;
        ruinMotif = state.ruinMotif;
        ghostAlienLikeness = state.ghostAlienLikeness;
        baseColor = state.baseColor;
        accentColor = state.accentColor;
        RefreshVisuals();
    }

    public void SetReveal(float amount)
    {
        revealAmount = Mathf.Clamp01(amount);
        RefreshVisuals();
    }

    public void SetStability(float value)
    {
        stability = Mathf.Clamp01(value);
        RefreshVisuals();
    }

    public void SetRoleFlags(bool current, bool achievable, bool challenge)
    {
        isCurrentPortal = current;
        isAchievablePortal = achievable;
        isChallengePortal = challenge;
        RefreshAnimator();
    }

    public void ActivateThreshold()
    {
        isActiveThreshold = true;
        revealAmount = 1f;
        stability = 1f;
        RefreshVisuals();
        RefreshAnimator();
    }

    public void DeactivateThreshold()
    {
        isActiveThreshold = false;
        RefreshAnimator();
    }

    public void RefreshVisuals()
    {
        if (glimpseVisualRoot != null)
            glimpseVisualRoot.SetActive(revealAmount > 0.03f);

        foreach (var r in revealRenderers)
        {
            if (r == null) continue;
            foreach (var mat in r.materials)
            {
                if (mat.HasProperty(EmissionColor))
                    mat.SetColor(EmissionColor, Color.Lerp(Color.black, accentColor, revealAmount * Mathf.Lerp(0.35f, 1f, stability)));
            }
        }

        foreach (var l in revealLights)
        {
            if (l == null) continue;
            l.enabled = revealAmount > 0.02f;
            l.color = Color.Lerp(baseColor, accentColor, 0.5f);
            l.intensity = Mathf.Lerp(0f, 4f, revealAmount * Mathf.Lerp(0.35f, 1f, stability));
        }

        foreach (var ps in revealParticles)
        {
            if (ps == null) continue;
            var emission = ps.emission;
            emission.rateOverTime = Mathf.Lerp(0f, 35f, revealAmount);
            var main = ps.main;
            main.startColor = Color.Lerp(baseColor, accentColor, 0.5f);
            if (revealAmount > 0.03f && !ps.isPlaying) ps.Play();
            if (revealAmount <= 0.03f && ps.isPlaying) ps.Stop();
        }

        if (portalAudio != null)
        {
            portalAudio.volume = revealAmount * Mathf.Lerp(0.2f, 0.85f, stability);
            portalAudio.pitch = Mathf.Lerp(0.9f, 1.05f, stability);
            if (revealAmount > 0.03f && !portalAudio.isPlaying) portalAudio.Play();
            if (revealAmount <= 0.03f && portalAudio.isPlaying) portalAudio.Stop();
        }

        RefreshAnimator();
    }

    private void RefreshAnimator()
    {
        if (animator == null) return;

        animator.SetFloat("RevealAmount", revealAmount);
        animator.SetFloat("Stability", stability);
        animator.SetBool("IsCurrent", isCurrentPortal);
        animator.SetBool("IsAchievable", isAchievablePortal);
        animator.SetBool("IsChallenge", isChallengePortal);
        animator.SetBool("IsActiveThreshold", isActiveThreshold);
    }
}
