using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class PortalRevealConfigLoader : MonoBehaviour
{
    [Header("StreamingAssets")]
    public string configFileName = "portal_reveal_visuals.json";

    [Header("Loaded Data")]
    public List<PortalRevealVisualState> loadedStates = new List<PortalRevealVisualState>();

    public bool LoadOnAwake = true;

    void Awake()
    {
        if (LoadOnAwake)
            Load();
    }

    public void Load()
    {
        loadedStates.Clear();
        string path = Path.Combine(Application.streamingAssetsPath, configFileName);
        if (!File.Exists(path))
        {
            Debug.LogWarning($"Portal reveal config not found: {path}");
            return;
        }

        string json = File.ReadAllText(path);
        var list = JsonUtility.FromJson<PortalRevealVisualStateList>(json);
        if (list?.portals == null)
        {
            Debug.LogWarning("Portal reveal config loaded but contained no portals.");
            return;
        }

        loadedStates.AddRange(list.portals);
    }

    public bool TryGetState(ResonancePortalType type, out PortalRevealVisualState state)
    {
        foreach (var s in loadedStates)
        {
            if (s.portalType == type)
            {
                state = s;
                return true;
            }
        }

        state = null;
        return false;
    }
}
