
# V127 Leaders + Migration + War System

Adds:
- City Leaders (personalities, traits)
- Population migration between cities
- War system with engagements and outcomes
- Integration with V124–V126 (cities, territory, conflict)

Controls:
- None required; systems run automatically once added to scene.

Notes:
- Attach V127Integration to a Systems GameObject.
- Ensure CitySystem exists in scene.
