
using UnityEngine;
using ArtificialUniverse.Leaders;
using ArtificialUniverse.Migration;
using ArtificialUniverse.War;

namespace ArtificialUniverse.Core
{
    public class V127Integration : MonoBehaviour
    {
        void Start()
        {
            if (FindObjectOfType<CityLeaderManager>() == null)
                gameObject.AddComponent<CityLeaderManager>();

            if (FindObjectOfType<MigrationSystem>() == null)
                gameObject.AddComponent<MigrationSystem>();

            if (FindObjectOfType<CityWarSystem>() == null)
                gameObject.AddComponent<CityWarSystem>();
        }
    }
