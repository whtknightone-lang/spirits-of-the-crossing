
using UnityEngine;
using ArtificialUniverse.Cities;

namespace ArtificialUniverse.War
{
    public class CityWarSystem : MonoBehaviour
    {
        private CitySystem cities;

        public float warThreshold = 0.3f;

        void Awake()
        {
            cities = FindObjectOfType<CitySystem>();
        }

        void Update()
        {
            if (cities == null) return;

            for (int i = 0; i < cities.cities.Count; i++)
            {
                for (int j = i+1; j < cities.cities.Count; j++)
                {
                    var a = cities.cities[i];
                    var b = cities.cities[j];

                    float dist = Vector3.Distance(a.position, b.position);
                    if (dist > 15f) continue;

                    if (a.stability < warThreshold || b.stability < warThreshold)
                    {
                        ResolveConflict(a, b);
                    }
                }
            }
        }

        void ResolveConflict(CityData a, CityData b)
        {
            float powerA = a.population * a.prosperity;
            float powerB = b.population * b.prosperity;

            if (powerA > powerB)
            {
                b.population *= 0.95f;
                a.prosperity += 0.01f * Time.deltaTime;
            }
            else
            {
                a.population *= 0.95f;
                b.prosperity += 0.01f * Time.deltaTime;
            }
        }
    }
