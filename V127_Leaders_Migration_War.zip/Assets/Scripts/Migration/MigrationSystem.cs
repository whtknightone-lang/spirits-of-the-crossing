
using UnityEngine;
using ArtificialUniverse.Cities;

namespace ArtificialUniverse.Migration
{
    public class MigrationSystem : MonoBehaviour
    {
        private CitySystem cities;

        public float migrationRate = 0.02f;

        void Awake()
        {
            cities = FindObjectOfType<CitySystem>();
        }

        void Update()
        {
            if (cities == null || cities.cities.Count < 2) return;

            for (int i = 0; i < cities.cities.Count; i++)
            {
                for (int j = i+1; j < cities.cities.Count; j++)
                {
                    var a = cities.cities[i];
                    var b = cities.cities[j];

                    if (a.stability < b.stability)
                    {
                        float flow = a.population * migrationRate * Time.deltaTime;
                        a.population -= flow;
                        b.population += flow;
                    }
                    else
                    {
                        float flow = b.population * migrationRate * Time.deltaTime;
                        b.population -= flow;
                        a.population += flow;
                    }
                }
            }
        }
    }
