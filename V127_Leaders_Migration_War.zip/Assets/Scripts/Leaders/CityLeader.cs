
using UnityEngine;

namespace ArtificialUniverse.Leaders
{
    public enum LeaderType { Peaceful, Balanced, Aggressive, Expansionist }

    public class CityLeader : MonoBehaviour
    {
        public LeaderType type = LeaderType.Balanced;

        [Range(0f,1f)] public float aggression = 0.5f;
        [Range(0f,1f)] public float diplomacy = 0.5f;
        [Range(0f,1f)] public float growthFocus = 0.5f;

        public void Randomize()
        {
            aggression = Random.Range(0.2f, 0.9f);
            diplomacy = Random.Range(0.2f, 0.9f);
            growthFocus = Random.Range(0.2f, 0.9f);

            if (aggression > 0.7f) type = LeaderType.Aggressive;
            else if (growthFocus > 0.7f) type = LeaderType.Expansionist;
            else if (diplomacy > 0.7f) type = LeaderType.Peaceful;
            else type = LeaderType.Balanced;
        }
    }
