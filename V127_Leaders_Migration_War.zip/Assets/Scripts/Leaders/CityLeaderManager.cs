
using UnityEngine;
using ArtificialUniverse.Cities;

namespace ArtificialUniverse.Leaders
{
    public class CityLeaderManager : MonoBehaviour
    {
        private CitySystem cities;

        void Awake()
        {
            cities = FindObjectOfType<CitySystem>();
        }

        void Start()
        {
            if (cities == null) return;

            foreach (var city in cities.cities)
            {
                var go = new GameObject(city.cityName + "_Leader");
                var leader = go.AddComponent<CityLeader>();
                leader.Randomize();
            }
        }
    }
