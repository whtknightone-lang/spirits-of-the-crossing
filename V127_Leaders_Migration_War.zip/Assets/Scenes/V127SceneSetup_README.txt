
V127 Scene Setup:

1. Ensure V124–V126 systems exist:
   - CitySystem
   - TerritorySystem
   - Conflict systems

2. Add:
   - CityLeaderManager
   - MigrationSystem
   - CityWarSystem
   - V127Integration

3. Result:
   - cities gain leaders
   - populations migrate dynamically
   - conflicts escalate into wars with outcomes
