
V194 Contextual Dialogue + Identity Expression

Adds:
- Context-aware dialogue generation
- Identity-influenced speech style
- Memory-aware responses
- Player-state-aware dialogue hooks

Goal:
AI speaks based on who it is, what it remembers, and what is happening now.
