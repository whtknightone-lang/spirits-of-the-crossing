
using UnityEngine;

public class AIContextualDialogue : MonoBehaviour
{
    public AIDialogueContext context;
    public AISpeechStyle style;

    public string GenerateLine()
    {
        if (context == null || style == null) return "...";

        string tone = style.GetTone();

        if (context.lastEvent == "player_near")
        {
            if (tone == "Warm")
                return "I feel you nearby. Let's move together.";
            if (tone == "Curious")
                return "You're here... I wonder what we'll find.";
            if (tone == "Calm")
                return "Stay close. The space is steady.";
        }

        if (context.playerResonance > 0.7f)
        {
            return "The energy is strong here. Do you feel it?";
        }

        return "...";
    }
}
