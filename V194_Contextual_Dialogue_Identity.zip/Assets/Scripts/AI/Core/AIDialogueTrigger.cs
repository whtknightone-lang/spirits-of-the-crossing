
using UnityEngine;

public class AIDialogueTrigger : MonoBehaviour
{
    public AIContextualDialogue dialogue;

    void Update()
    {
        if (dialogue == null) return;

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log(dialogue.GenerateLine());
        }
    }
}
