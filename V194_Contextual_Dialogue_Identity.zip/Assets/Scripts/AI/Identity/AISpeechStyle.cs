
using UnityEngine;

public class AISpeechStyle : MonoBehaviour
{
    public float curiosity;
    public float stability;
    public float connection;

    public string GetTone()
    {
        if (curiosity > stability && curiosity > connection)
            return "Curious";
        else if (stability > connection)
            return "Calm";
        else
            return "Warm";
    }
}
