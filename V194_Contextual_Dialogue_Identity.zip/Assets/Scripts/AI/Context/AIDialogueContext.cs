
using UnityEngine;

public class AIDialogueContext : MonoBehaviour
{
    public float playerResonance;
    public float distanceToPlayer;
    public string lastEvent;
}
