
using UnityEngine;

public class AIBodyExpression : MonoBehaviour
{
    public float resonance;
    public float alignment;

    void Update()
    {
        float scale = 1f + resonance * 0.2f;
        transform.localScale = new Vector3(scale, scale, scale);

        transform.rotation = Quaternion.Euler(0, alignment * 180f, 0);
    }
}
