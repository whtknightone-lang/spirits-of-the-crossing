
using UnityEngine;

public class VRPoseSync : MonoBehaviour
{
    public Transform head;
    public Transform leftHand;
    public Transform rightHand;

    public string Serialize()
    {
        return JsonUtility.ToJson(new PoseData {
            headPos = head.position,
            leftPos = leftHand.position,
            rightPos = rightHand.position
        });
    }

    [System.Serializable]
    public class PoseData
    {
        public Vector3 headPos;
        public Vector3 leftPos;
        public Vector3 rightPos;
    }
}
