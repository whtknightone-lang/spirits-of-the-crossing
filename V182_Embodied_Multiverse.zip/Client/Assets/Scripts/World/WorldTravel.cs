
using UnityEngine;

public class WorldTravel : MonoBehaviour
{
    public float resonance;

    void Update()
    {
        if (resonance > 0.7f)
            Debug.Log("Shift to high world");
        else if (resonance > 0.3f)
            Debug.Log("Shift to mid world");
        else
            Debug.Log("Shift to low world");
    }
}
