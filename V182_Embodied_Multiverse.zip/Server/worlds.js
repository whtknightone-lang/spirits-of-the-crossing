
function assignWorld(r){
    if(r > 0.7) return "high";
    if(r > 0.3) return "mid";
    return "low";
}

module.exports = { assignWorld };
