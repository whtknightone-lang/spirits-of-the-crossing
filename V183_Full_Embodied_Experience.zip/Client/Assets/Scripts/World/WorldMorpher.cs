
using UnityEngine;

public class WorldMorpher : MonoBehaviour
{
    public float resonance;
    public Material skyMat;

    void Update()
    {
        Color c = Color.Lerp(Color.gray, Color.cyan, resonance);
        skyMat.SetColor("_Color", c);

        RenderSettings.fogDensity = Mathf.Lerp(0.02f, 0.001f, resonance);
    }
}
