
using UnityEngine;

public class AIExpressiveBehavior : MonoBehaviour
{
    public Transform player;
    public float resonance;

    void Update()
    {
        if (player != null)
        {
            transform.position = Vector3.Lerp(
                transform.position,
                player.position + new Vector3(Mathf.Sin(Time.time), 0, 0),
                Time.deltaTime
            );
        }

        float sway = Mathf.Sin(Time.time * resonance);
        transform.Rotate(0, sway, 0);
    }
}
