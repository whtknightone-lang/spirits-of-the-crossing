
using UnityEngine;

[System.Serializable]
public class FullAvatarPose
{
    public Vector3 headPos;
    public Quaternion headRot;

    public Vector3 leftHandPos;
    public Quaternion leftHandRot;

    public Vector3 rightHandPos;
    public Quaternion rightHandRot;

    public Vector3 bodyPos;
    public Quaternion bodyRot;
}

public class FullAvatarSync : MonoBehaviour
{
    public Transform head, leftHand, rightHand, body;

    public string Serialize()
    {
        return JsonUtility.ToJson(new FullAvatarPose {
            headPos = head.position,
            headRot = head.rotation,
            leftHandPos = leftHand.position,
            leftHandRot = leftHand.rotation,
            rightHandPos = rightHand.position,
            rightHandRot = rightHand.rotation,
            bodyPos = body.position,
            bodyRot = body.rotation
        });
    }
}
