
V183 Full Embodied Experience

Adds:
- Full avatar sync (head, hands, body)
- Seamless world morphing (no discrete world switching)
- Expressive AI behavior (movement = communication)
