
let avatars = {};

function updateAvatar(id, pose) {
    avatars[id] = pose;
}

function getAvatars() {
    return avatars;
}

module.exports = { updateAvatar, getAvatars };
