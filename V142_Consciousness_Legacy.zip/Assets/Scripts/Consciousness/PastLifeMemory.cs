
using UnityEngine;
using System.Collections.Generic;

public class PastLifeMemory : MonoBehaviour
{
    public List<float> pastTraits = new List<float>();

    public void RecordLife(float trait)
    {
        pastTraits.Add(trait);
        if (pastTraits.Count > 10)
            pastTraits.RemoveAt(0);
    }

    public float GetInfluence()
    {
        float sum = 0f;
        foreach (var t in pastTraits) sum += t;
        return pastTraits.Count > 0 ? sum / pastTraits.Count : 0f;
    }
}
