
using UnityEngine;

public class ConsciousnessSystem : MonoBehaviour
{
    public float awareness = 0f;
    public float memoryDepth = 0f;

    void Update()
    {
        awareness += Time.deltaTime * 0.01f;
        memoryDepth += Time.deltaTime * 0.005f;
    }
}
