
using UnityEngine;

public class LegacySystem : MonoBehaviour
{
    public float legacyValue;

    public void AddLegacy(float value)
    {
        legacyValue += value;
    }

    public float GetLegacyInfluence()
    {
        return Mathf.Clamp01(legacyValue);
    }
}
