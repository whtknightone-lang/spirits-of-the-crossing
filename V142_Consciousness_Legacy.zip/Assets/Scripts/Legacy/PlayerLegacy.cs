
using UnityEngine;

public class PlayerLegacy : MonoBehaviour
{
    private LegacySystem legacy;

    void Awake()
    {
        legacy = FindObjectOfType<LegacySystem>();
    }

    void Update()
    {
        if (legacy == null) return;

        if (Input.GetKeyDown(KeyCode.P))
        {
            legacy.AddLegacy(0.1f);
            Debug.Log("Legacy increased");
        }
    }
}
