
using UnityEngine;

public class V142Integration : MonoBehaviour
{
    void Start()
    {
        if (FindObjectOfType<ConsciousnessSystem>() == null)
            gameObject.AddComponent<ConsciousnessSystem>();

        if (FindObjectOfType<PastLifeMemory>() == null)
            gameObject.AddComponent<PastLifeMemory>();

        if (FindObjectOfType<LegacySystem>() == null)
            gameObject.AddComponent<LegacySystem>();

        if (FindObjectOfType<PlayerLegacy>() == null)
            gameObject.AddComponent<PlayerLegacy>();
    }
}
