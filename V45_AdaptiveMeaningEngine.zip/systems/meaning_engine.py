
import numpy as np

class MeaningEngine:
    def __init__(self):
        self.last_score = 0.0

    def compute(self, player, memory):
        joy = float(player.core.mean().item())
        growth = abs(joy)
        coherence = 1.0 - abs(memory.now_field.mean().item())
        resistance = abs(memory.potential_field.mean().item())

        score = (
            0.4 * joy +
            0.3 * growth +
            0.2 * coherence +
            0.3 * resistance
        )

        self.last_score = score
        return score
