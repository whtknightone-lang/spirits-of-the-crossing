
# V45 Adaptive Meaning Engine

Run:
pip install -r requirements.txt
python main.py

Concept:
Meaning emerges from:
- Joy
- Growth
- Coherence
- Resistance

This keeps the system at the edge of chaos and prevents stagnation.
