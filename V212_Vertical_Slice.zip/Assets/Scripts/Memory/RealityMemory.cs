
using UnityEngine;
using System.Collections.Generic;

public class RealityMemory : MonoBehaviour
{
    public List<string> memoryLog = new List<string>();

    public void Record(string state)
    {
        memoryLog.Add(state);
        Debug.Log("Memory recorded: " + state);
    }
}
