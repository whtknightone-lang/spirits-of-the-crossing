
using UnityEngine;

public class EchoSelf : MonoBehaviour
{
    public Vector3 echoPosition;

    void Update()
    {
        transform.position = Vector3.Lerp(transform.position, echoPosition, Time.deltaTime);
    }
}
