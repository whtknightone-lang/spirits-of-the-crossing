
using UnityEngine;

public class WorldVisualizer : MonoBehaviour
{
    public SimplePlayerController player;
    public Camera cam;

    void Update()
    {
        if (player == null || cam == null) return;

        cam.backgroundColor = Color.Lerp(Color.red, Color.cyan, player.resonance);
    }
}
