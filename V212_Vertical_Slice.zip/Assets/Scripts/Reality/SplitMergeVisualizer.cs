
using UnityEngine;

public class SplitMergeVisualizer : MonoBehaviour
{
    public SimplePlayerController player;

    void Update()
    {
        if (player.resonance < 0.3f)
        {
            Debug.Log("Reality splitting...");
        }
        else if (player.resonance > 0.7f)
        {
            Debug.Log("Reality merging...");
        }
    }
}
