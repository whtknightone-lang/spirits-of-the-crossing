
V212 + Playable Vertical Slice

V212:
- Cross-reality memory (echo selves)
- remembers alternate paths

Vertical Slice:
- player moves
- resonance shifts world color
- split/merge feedback
- simple interactive loop

Goal:
Feel the system, not just simulate it.
