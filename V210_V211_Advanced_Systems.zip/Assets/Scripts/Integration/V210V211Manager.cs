
using UnityEngine;

public class V210V211Manager : MonoBehaviour
{
    public PersonalizedSourceSignal source;
    public DivergentRealitySystem reality;

    public IndividualityProfile[] agents;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            float total = 0f;

            foreach (var a in agents)
            {
                float signal = source.GetSignal(a.receptivity, a.individuality);
                Debug.Log("Agent Signal: " + signal);
                total += signal;
            }

            float avg = total / agents.Length;
            reality.Evaluate(avg);
        }
    }
}
