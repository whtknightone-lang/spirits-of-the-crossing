
using UnityEngine;

public class PersonalizedSourceSignal : MonoBehaviour
{
    public float baseSignal = 0.5f;

    public float GetSignal(float receptivity, float individuality)
    {
        float personalized = baseSignal * receptivity * (1f + individuality * 0.5f);
        return Mathf.Clamp01(personalized);
    }
}
