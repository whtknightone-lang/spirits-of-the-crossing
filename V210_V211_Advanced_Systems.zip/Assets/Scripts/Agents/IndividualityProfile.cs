
using UnityEngine;

public class IndividualityProfile : MonoBehaviour
{
    [Range(0f,1f)] public float individuality = 0.5f;
    [Range(0f,1f)] public float receptivity = 0.5f;
}
