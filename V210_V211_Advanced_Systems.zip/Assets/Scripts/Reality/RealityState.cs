
using UnityEngine;

public class RealityState : MonoBehaviour
{
    public string state = "stable";

    public void SetState(string newState)
    {
        state = newState;
        Debug.Log("Reality State: " + state);
    }
}
