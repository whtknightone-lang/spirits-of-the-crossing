
using UnityEngine;

public class DivergentRealitySystem : MonoBehaviour
{
    public float splitThreshold = 0.4f;
    public float mergeThreshold = 0.8f;

    public void Evaluate(float groupCoherence)
    {
        if (groupCoherence < splitThreshold)
        {
            Debug.Log("Reality Split: multiple divergent paths emerging");
        }
        else if (groupCoherence > mergeThreshold)
        {
            Debug.Log("Reality Merge: unified harmonic state achieved");
        }
    }
}
