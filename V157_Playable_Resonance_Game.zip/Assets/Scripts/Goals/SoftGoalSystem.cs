
using UnityEngine;

public class SoftGoalSystem : MonoBehaviour
{
    public float directionHint;

    void Update()
    {
        // gives subtle direction instead of explicit tasks
        directionHint = Mathf.PingPong(Time.time * 0.05f, 1f);
    }
}
