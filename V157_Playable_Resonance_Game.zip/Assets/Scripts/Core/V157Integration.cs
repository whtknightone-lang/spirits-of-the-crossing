
using UnityEngine;

public class V157Integration : MonoBehaviour
{
    void Start()
    {
        AddIfMissing<DesireSystem>();
        AddIfMissing<ExperienceRewardSystem>();
        AddIfMissing<SoftGoalSystem>();
        AddIfMissing<CreationSharingSystem>();
    }

    void AddIfMissing<T>() where T : Component
    {
        if (FindObjectOfType<T>() == null)
            gameObject.AddComponent<T>();
    }
}
