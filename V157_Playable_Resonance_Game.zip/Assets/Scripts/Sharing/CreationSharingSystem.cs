
using UnityEngine;

public class CreationSharingSystem : MonoBehaviour
{
    public int creations;

    public void Create()
    {
        creations++;
        Debug.Log("New creation shared with universe");
    }
}
