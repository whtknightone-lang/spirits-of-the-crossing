
using UnityEngine;

public class DesireSystem : MonoBehaviour
{
    public float curiosity = 0.5f;
    public float fulfillment = 0f;

    void Update()
    {
        // curiosity drives movement / engagement
        curiosity = Mathf.PingPong(Time.time * 0.1f, 1f);

        // fulfillment grows when curiosity is followed
        fulfillment = Mathf.Lerp(fulfillment, curiosity, Time.deltaTime * 0.2f);
    }
}
