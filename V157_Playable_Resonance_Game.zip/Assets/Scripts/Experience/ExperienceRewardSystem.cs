
using UnityEngine;

public class ExperienceRewardSystem : MonoBehaviour
{
    public float experience;
    public float joy;

    public void RegisterExperience(float alignment)
    {
        experience += alignment * 0.1f;
        joy += alignment * 0.05f;
    }
}
