
V157 Playable Resonance Experience Layer

Purpose:
Keep the system PLAYABLE while preserving resonance-based design.

Adds:
- Desire-driven exploration loop
- Experience rewards (non-punitive)
- Sharing/creation mechanics
- Soft goals (no forced objectives)

Core principle:
Players WANT to explore, not need to.
