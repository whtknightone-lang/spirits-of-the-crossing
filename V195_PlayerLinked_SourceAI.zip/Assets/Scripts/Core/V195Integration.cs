
using UnityEngine;

public class V195Integration : MonoBehaviour
{
    public AIPlayerRelationship relationship;
    public AISourceConnection source;

    void Update()
    {
        if (relationship == null || source == null) return;

        source.UpdateSource(relationship.sharedResonance);
    }
}
