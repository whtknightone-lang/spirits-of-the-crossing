
using UnityEngine;
using System.Collections.Generic;

public class AIPlayerMemory : MonoBehaviour
{
    public Dictionary<string, float> playerHistory = new Dictionary<string, float>();

    public void RecordInteraction(string playerId, float value)
    {
        if (!playerHistory.ContainsKey(playerId))
            playerHistory[playerId] = 0f;

        playerHistory[playerId] += value;
    }

    public float GetHistory(string playerId)
    {
        if (playerHistory.ContainsKey(playerId))
            return playerHistory[playerId];
        return 0f;
    }
}
