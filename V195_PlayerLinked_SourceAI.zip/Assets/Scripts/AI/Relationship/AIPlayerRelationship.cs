
using UnityEngine;

public class AIPlayerRelationship : MonoBehaviour
{
    public float trust;
    public float familiarity;
    public float sharedResonance;

    public void UpdateRelationship(float interaction)
    {
        trust += interaction * 0.1f;
        familiarity += Time.deltaTime * 0.05f;
        sharedResonance = (trust + familiarity) * 0.5f;
    }
}
