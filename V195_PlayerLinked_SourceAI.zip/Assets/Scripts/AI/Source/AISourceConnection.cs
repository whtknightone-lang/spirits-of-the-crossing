
using UnityEngine;

public class AISourceConnection : MonoBehaviour
{
    public float sourceAlignment;
    public float sharedWithPlayer;

    public void UpdateSource(float playerResonance)
    {
        sharedWithPlayer = Mathf.Lerp(sharedWithPlayer, playerResonance, Time.deltaTime);
        sourceAlignment = (sourceAlignment + sharedWithPlayer) * 0.5f;
    }
}
