
using UnityEngine;

[System.Serializable]
public class SourceImprint
{
    public float essence;
    public float connection;
}

public class AIEternalImprint : MonoBehaviour
{
    public SourceImprint imprint = new SourceImprint();

    public void Capture(float resonance, float connection)
    {
        imprint.essence = resonance;
        imprint.connection = connection;
    }

    public void Apply(AIPlayerRelationship rel)
    {
        if (rel == null) return;

        rel.trust += imprint.connection;
        rel.sharedResonance += imprint.essence;
    }
}
