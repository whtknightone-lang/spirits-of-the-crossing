
V195 Player-Linked AI + Eternal Source Layer

Adds:
- Player-specific relationship memory
- AI adapts to individual player over time
- Eternal source imprint shared between player + AI
- AI persists connection across rebirth cycles

Core Idea:
AI and player share a deeper "source connection" that survives lifetimes.
