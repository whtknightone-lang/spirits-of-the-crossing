
import torch

GRID = 30
FACTIONS = 5

class CivGoalWorld:
    def __init__(self, n=50000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)
        self.velocity = torch.zeros(n,3)

        self.lineage = torch.randint(0, FACTIONS, (n,))
        self.goal_type = torch.randint(0,4,(n,))
        self.memory = torch.zeros(n)

        self.grid_owner = torch.zeros((GRID, GRID), dtype=torch.long)
        self.grid_strength = torch.zeros((GRID, GRID))

    def step(self):
        # territory mapping
        gx = (self.position[:,0]*GRID).long().clamp(0,GRID-1)
        gy = (self.position[:,1]*GRID).long().clamp(0,GRID-1)

        self.grid_strength *= 0.95

        for i in range(len(self.energy)):
            f = int(self.lineage[i])
            self.grid_owner[gx[i], gy[i]] = f
            self.grid_strength[gx[i], gy[i]] += self.energy[i]

        # civilization goal alignment
        for f in range(FACTIONS):
            mask = self.lineage == f
            if mask.sum() > 0:
                dominant_goal = torch.mode(self.goal_type[mask]).values
                align_mask = mask & (torch.rand(len(mask)) < 0.05)
                self.goal_type[align_mask] = dominant_goal

        # goal scoring
        grow = self.energy
        explore = torch.norm(self.velocity, dim=1)
        stabilize = -torch.abs(self.energy - 1.2)
        expand = torch.norm(self.position - 0.5, dim=1)

        scores = torch.stack([grow, explore, stabilize, expand], dim=1)
        chosen = scores[torch.arange(len(self.goal_type)), self.goal_type]

        # motion
        direction = torch.randn_like(self.velocity)
        direction = direction / (torch.norm(direction, dim=1, keepdim=True)+1e-6)

        self.velocity += 0.01 * direction * chosen.unsqueeze(1)
        self.position += self.velocity
        self.position.clamp_(0,1)

        # energy dynamics
        self.energy += 0.01 * torch.sin(torch.rand_like(self.energy))

        # memory + reinforcement
        self.memory = 0.9*self.memory + 0.1*self.energy
        improve = self.energy > self.memory

        self.energy[improve] *= 1.001
        self.energy[~improve] *= 0.999

        self.energy *= 0.999
