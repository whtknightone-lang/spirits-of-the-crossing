
import matplotlib.pyplot as plt
from engine import CivGoalWorld

world = CivGoalWorld(50000)

plt.ion()
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

for step in range(200):
    world.step()

    ax.clear()
    ax.scatter(
        world.position[:5000,0].numpy(),
        world.position[:5000,1].numpy(),
        world.position[:5000,2].numpy(),
        c=world.lineage[:5000].numpy(),
        s=1
    )

    ax.set_xlim(0,1)
    ax.set_ylim(0,1)
    ax.set_zlim(0,1)

    ax.set_title(f"Step {step}")

    plt.pause(0.01)

plt.ioff()
plt.show()
