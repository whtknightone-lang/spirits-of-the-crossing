
RUE V111–V120 Goal + Civilization Merge

Features:
- Factions share dominant goals
- Territory + goals combined
- Collective behavior (civilization intent)
- Goal propagation within factions
- Civilization-level reinforcement

Run:
pip install torch matplotlib
python run_v111.py
