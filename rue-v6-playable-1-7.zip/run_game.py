
import matplotlib.pyplot as plt
from engine import World

world = World()

plt.ion()
fig, ax = plt.subplots()

for step in range(300):
    world.step()

    ax.clear()
    ax.scatter(
        world.position[:,0].numpy(),
        world.position[:,1].numpy(),
        s=3
    )

    ax.set_title(f"Step {step} Score {round(world.score,2)}")
    ax.set_xlim(0,1)
    ax.set_ylim(0,1)

    plt.pause(0.01)

plt.ioff()
plt.show()
