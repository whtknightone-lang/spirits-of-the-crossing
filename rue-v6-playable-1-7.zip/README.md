
RUE V6.1-7 Playable Game Loop

Features progression:
V6.1 - Player movement (WASD)
V6.2 - Camera follow
V6.3 - Lineage coloring
V6.4 - Simple goals (grow energy)
V6.5 - Spirit zones
V6.6 - Score system
V6.7 - Basic win/lose loop

Run:
pip install torch matplotlib
python run_game.py
