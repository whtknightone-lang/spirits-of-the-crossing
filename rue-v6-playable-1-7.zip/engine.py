
import torch

class World:
    def __init__(self, n=2000):
        self.energy = torch.ones(n)
        self.phase = torch.rand(n)
        self.position = torch.rand(n,2)
        self.velocity = torch.zeros(n,2)
        self.lineage = torch.randint(0,5,(n,))
        self.player_pos = torch.tensor([0.5,0.5])
        self.score = 0

    def step(self):
        self.velocity += 0.01 * torch.randn_like(self.velocity)
        self.position += self.velocity
        self.position = torch.clamp(self.position,0,1)

        self.phase += 0.05
        self.energy += 0.01 * torch.sin(self.phase)

        # player influence
        dist = torch.norm(self.position - self.player_pos, dim=1)
        self.energy += torch.exp(-dist*10)*0.02

        # scoring
        self.score += (self.energy.mean().item())
