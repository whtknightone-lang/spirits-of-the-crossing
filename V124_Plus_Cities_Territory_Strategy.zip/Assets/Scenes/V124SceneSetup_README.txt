
Scene Setup

1. Keep previous V114–V123 systems in scene:
   - CivilizationSystem
   - EconomySystem
   - BeliefSystem
   - Dashboard
   - Control panel
   - AdaptiveUniverseSystem
   - ScenarioSystem
   - MissionSystem

2. Add:
   - CitySystem
   - TerritorySystem
   - CivilizationExpansionSystem
   - V124StrategyDashboard
   - V124IntegrationManager

3. Result:
   - cities spawn and grow
   - territory is claimed spatially
   - civilization becomes a map-based strategy layer
   - dashboard shows what you have and what is needed
