
using UnityEngine;
using ArtificialUniverse.Cities;
using ArtificialUniverse.Territory;
using ArtificialUniverse.Civilization;

namespace ArtificialUniverse.Core
{
    public class V124IntegrationManager : MonoBehaviour
    {
        void Start()
        {
            if (FindObjectOfType<CitySystem>() == null)
                gameObject.AddComponent<CitySystem>();

            if (FindObjectOfType<TerritorySystem>() == null)
                gameObject.AddComponent<TerritorySystem>();

            if (FindObjectOfType<CivilizationExpansionSystem>() == null)
                gameObject.AddComponent<CivilizationExpansionSystem>();

            if (FindObjectOfType<ArtificialUniverse.UI.V124StrategyDashboard>() == null)
                gameObject.AddComponent<ArtificialUniverse.UI.V124StrategyDashboard>();
        }
    }
}
