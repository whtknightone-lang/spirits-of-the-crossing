
using System.Collections.Generic;
using UnityEngine;
using ArtificialUniverse.Cities;

namespace ArtificialUniverse.Territory
{
    public class TerritorySystem : MonoBehaviour
    {
        public int gridSize = 24;
        public float cellSpacing = 2f;
        public List<TerritoryCell> cells = new();

        private CitySystem citySystem;

        void Awake()
        {
            citySystem = FindObjectOfType<CitySystem>();
            BuildGrid();
        }

        void Update()
        {
            if (citySystem == null) return;

            for (int i = 0; i < cells.Count; i++)
            {
                TerritoryCell cell = cells[i];
                Vector3 worldPos = new Vector3(cell.grid.x * cellSpacing, 0f, cell.grid.y * cellSpacing);

                int bestIndex = -1;
                float bestScore = 0f;

                for (int c = 0; c < citySystem.cities.Count; c++)
                {
                    var city = citySystem.cities[c];
                    float d = Vector3.Distance(worldPos, city.position);
                    if (d > city.influenceRadius) continue;

                    float score = (1f - d / city.influenceRadius) * city.stability * city.prosperity;
                    if (score > bestScore)
                    {
                        bestScore = score;
                        bestIndex = c;
                    }
                }

                cell.ownerCityIndex = bestIndex;
                cell.controlStrength = Mathf.Clamp01(bestScore);
            }
        }

        private void BuildGrid()
        {
            cells.Clear();
            for (int x = -gridSize; x <= gridSize; x++)
            {
                for (int y = -gridSize; y <= gridSize; y++)
                {
                    cells.Add(new TerritoryCell
                    {
                        grid = new Vector2Int(x, y),
                        ownerCityIndex = -1,
                        controlStrength = 0f
                    });
                }
            }
        }
    }
}
