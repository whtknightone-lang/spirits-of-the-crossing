
using UnityEngine;

namespace ArtificialUniverse.Territory
{
    [System.Serializable]
    public class TerritoryCell
    {
        public Vector2Int grid;
        public int ownerCityIndex = -1;
        public float controlStrength = 0f;
    }
}
