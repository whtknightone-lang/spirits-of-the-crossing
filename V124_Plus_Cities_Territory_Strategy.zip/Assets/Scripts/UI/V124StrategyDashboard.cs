
using UnityEngine;
using ArtificialUniverse.Cities;
using ArtificialUniverse.Territory;
using ArtificialUniverse.Civilization;

namespace ArtificialUniverse.UI
{
    public class V124StrategyDashboard : MonoBehaviour
    {
        CitySystem cities;
        TerritorySystem territory;
        CivilizationExpansionSystem expansion;
        CivilizationSystem civ;

        void Awake()
        {
            cities = FindObjectOfType<CitySystem>();
            territory = FindObjectOfType<TerritorySystem>();
            expansion = FindObjectOfType<CivilizationExpansionSystem>();
            civ = FindObjectOfType<CivilizationSystem>();
        }

        void OnGUI()
        {
            int y = 20;
            GUI.Label(new Rect(360, y, 360, 24), "=== V124 STRATEGY DASHBOARD ==="); y += 24;

            if (civ != null)
            {
                GUI.Label(new Rect(360, y, 360, 24), $"Civilization Population: {civ.population:0.0}"); y += 20;
                GUI.Label(new Rect(360, y, 360, 24), $"Harmony: {civ.harmony:0.00}"); y += 20;
                GUI.Label(new Rect(360, y, 360, 24), $"Conflict: {civ.conflict:0.00}"); y += 28;
            }

            if (cities != null)
            {
                GUI.Label(new Rect(360, y, 360, 24), $"Cities: {cities.cities.Count}"); y += 20;
                float totalPop = 0f;
                foreach (var c in cities.cities) totalPop += c.population;
                GUI.Label(new Rect(360, y, 360, 24), $"Urban Population: {totalPop:0.0}"); y += 28;
            }

            if (territory != null)
            {
                int controlled = 0;
                foreach (var cell in territory.cells)
                    if (cell.ownerCityIndex >= 0) controlled++;
                GUI.Label(new Rect(360, y, 360, 24), $"Controlled Territory Cells: {controlled}"); y += 28;
            }

            if (expansion != null)
            {
                GUI.Label(new Rect(360, y, 360, 24), $"Expansion Pressure: {expansion.expansionPressure:0.00}"); y += 20;
                GUI.Label(new Rect(360, y, 360, 24), $"Strategy Bias: {expansion.strategyBias:0.00}"); y += 20;
            }
        }
    }
}
