
using System.Collections.Generic;
using UnityEngine;
using ArtificialUniverse.Civilization;

namespace ArtificialUniverse.Cities
{
    public class CitySystem : MonoBehaviour
    {
        public List<CityData> cities = new();
        public int maxCities = 12;
        public float cityGrowthRate = 0.08f;
        public float expansionThreshold = 60f;

        private CivilizationSystem civ;

        void Awake()
        {
            civ = FindObjectOfType<CivilizationSystem>();
        }

        void Start()
        {
            if (cities.Count == 0)
            {
                SpawnCity("First Haven", Vector3.zero);
            }
        }

        void Update()
        {
            float dt = Time.deltaTime;

            foreach (var city in cities)
            {
                city.population += city.population * cityGrowthRate * Mathf.Max(0.2f, city.stability) * dt;
                city.prosperity = Mathf.Clamp01(city.prosperity + 0.02f * dt);
                city.stability = Mathf.Clamp01(city.stability + 0.01f * dt);
                city.influenceRadius = Mathf.Clamp(city.influenceRadius + 0.4f * dt, 5f, 30f);
            }

            if (civ != null && civ.population > expansionThreshold && cities.Count < maxCities)
            {
                Vector3 p = new Vector3(Random.Range(-20f, 20f), 0f, Random.Range(-20f, 20f));
                SpawnCity("City " + cities.Count, p);
                civ.population *= 0.85f;
            }
        }

        public void SpawnCity(string cityName, Vector3 position)
        {
            cities.Add(new CityData
            {
                cityName = cityName,
                position = position,
                population = Random.Range(10f, 25f),
                prosperity = 0.5f,
                stability = 0.6f,
                influenceRadius = 8f
            });
        }
    }
}
