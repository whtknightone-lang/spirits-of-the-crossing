
using UnityEngine;

namespace ArtificialUniverse.Cities
{
    [System.Serializable]
    public class CityData
    {
        public string cityName;
        public Vector3 position;
        public float population;
        public float prosperity;
        public float stability;
        public float influenceRadius;
    }
}
