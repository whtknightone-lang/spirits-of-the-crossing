
using UnityEngine;
using ArtificialUniverse.Cities;

namespace ArtificialUniverse.Civilization
{
    public class CivilizationExpansionSystem : MonoBehaviour
    {
        public float expansionPressure = 0.5f;
        public float strategyBias = 0.5f;

        private CivilizationSystem civ;
        private CitySystem cities;

        void Awake()
        {
            civ = FindObjectOfType<CivilizationSystem>();
            cities = FindObjectOfType<CitySystem>();
        }

        void Update()
        {
            if (civ == null || cities == null) return;

            expansionPressure = Mathf.Clamp01((civ.harmony + civ.energy + Mathf.Clamp01(civ.population / 100f)) / 3f);
            strategyBias = Mathf.Clamp01(expansionPressure - civ.conflict * 0.4f);

            foreach (var city in cities.cities)
            {
                city.stability = Mathf.Clamp01(city.stability + strategyBias * 0.01f * Time.deltaTime);
                city.prosperity = Mathf.Clamp01(city.prosperity + expansionPressure * 0.01f * Time.deltaTime);
            }
        }
    }
}
