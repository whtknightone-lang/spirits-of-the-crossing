
# V124+ Cities, Territory, and Strategy Layer

Adds:
- city spawning and growth
- territory control
- civilization expansion pressure
- strategy dashboard
- integration hooks for prior V114–V123 systems

Core idea:
Civilization stops being abstract and becomes spatial.
Harmony, conflict, and resources now shape cities and territory.
