
from engine.environment.environment import EnvironmentSystem
from engine.environment.environment_events import apply_environment_effects

class UniverseEnvironmentMixin:

    def init_environment(self):
        self.environment = EnvironmentSystem()
        for p in self.planets:
            self.environment.init_planet(p)

    def environment_step(self):
        self.environment.step(self)

        for a in self.agents:
            biome = self.environment.region_biomes[a.planet_id][a.region_id]
            apply_environment_effects(a, biome)
