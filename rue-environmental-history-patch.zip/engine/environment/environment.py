
import random

BIOMES = ["FOREST", "DESERT", "WATER", "PLAINS", "RUINS"]

class EnvironmentSystem:
    def __init__(self):
        self.region_biomes = {}

    def init_planet(self, planet):
        self.region_biomes[planet.index] = [
            random.choice(BIOMES) for _ in range(planet.n_regions)
        ]

    def step(self, universe):
        for p in universe.planets:
            biomes = self.region_biomes.get(p.index, [])
            for i in range(len(biomes)):
                if random.random() < 0.01:
                    biomes[i] = random.choice(BIOMES)

                # environmental events
                if p.traits["type"] == "FERTILE" and random.random() < 0.02:
                    biomes[i] = "FOREST"

                if p.traits["type"] == "HARSH" and random.random() < 0.02:
                    biomes[i] = "DESERT"

                if p.traits["type"] == "CHAOTIC" and random.random() < 0.01:
                    biomes[i] = "WATER"

                if random.random() < 0.005:
                    biomes[i] = "RUINS"

            self.region_biomes[p.index] = biomes
