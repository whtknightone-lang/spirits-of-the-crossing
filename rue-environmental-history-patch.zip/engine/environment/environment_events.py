
def apply_environment_effects(agent, biome):
    if biome == "FOREST":
        agent.energy += 0.01
    elif biome == "DESERT":
        agent.energy -= 0.01
    elif biome == "WATER":
        agent.energy += 0.005
    elif biome == "RUINS":
        agent.energy -= 0.005
