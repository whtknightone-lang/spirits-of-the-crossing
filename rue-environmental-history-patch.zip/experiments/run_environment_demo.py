
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from engine.simulation.universe import Universe
from engine.environment.universe_environment_patch import UniverseEnvironmentMixin

class GameUniverse(Universe, UniverseEnvironmentMixin):
    def __init__(self):
        super().__init__()
        self.init_environment()

    def step(self):
        super().step()
        self.environment_step()

if __name__ == "__main__":
    u = GameUniverse()
    for i in range(500):
        u.step()
        if i % 50 == 0:
            print("step", i)
