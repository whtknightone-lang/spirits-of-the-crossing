
# RUE Environmental History Patch

Adds dynamic environmental evolution to planets:

- biome drift (forest, desert, water, ruins)
- environmental events (flood, desertification, overgrowth)
- region state tracking
- integration hooks for mythology layer

Run:
python experiments/run_environment_demo.py
