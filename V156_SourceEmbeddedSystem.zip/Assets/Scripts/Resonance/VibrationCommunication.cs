
using UnityEngine;

public class VibrationCommunication : MonoBehaviour
{
    public float vibrationSignal;
    public float receivedSignal;

    void Update()
    {
        // Emit signal
        vibrationSignal = Mathf.PingPong(Time.time * 0.1f, 1f);

        // Receive (simple global resonance placeholder)
        receivedSignal = vibrationSignal * 0.9f;
    }
}
