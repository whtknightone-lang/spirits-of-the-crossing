
using UnityEngine;
using System.Collections.Generic;

public class UnifiedResonanceField : MonoBehaviour
{
    public List<float> signals = new List<float>();
    public float fieldState;

    void Update()
    {
        if (signals.Count == 0) return;

        float sum = 0f;
        foreach (var s in signals) sum += s;

        fieldState = sum / signals.Count;
    }
}
