
using UnityEngine;

public class SourceConnection : MonoBehaviour
{
    [Range(0f,1f)] public float sourcePresence = 0.8f;
    public float localIdentity = 0.2f;

    public float GetAlignment()
    {
        return sourcePresence * (1f - localIdentity);
    }
}
