
using UnityEngine;

public class NonAssertionSystem : MonoBehaviour
{
    public float flowState;

    void Update()
    {
        // Instead of forcing decisions, flow emerges
        flowState = Mathf.Lerp(flowState, Random.Range(0f,1f), Time.deltaTime * 0.5f);
    }
}
