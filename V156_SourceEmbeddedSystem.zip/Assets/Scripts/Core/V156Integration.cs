
using UnityEngine;

public class V156Integration : MonoBehaviour
{
    void Start()
    {
        AddIfMissing<SourceConnection>();
        AddIfMissing<VibrationCommunication>();
        AddIfMissing<NonAssertionSystem>();
        AddIfMissing<UnifiedResonanceField>();
    }

    void AddIfMissing<T>() where T : Component
    {
        if (FindObjectOfType<T>() == null)
            gameObject.AddComponent<T>();
    }
}
