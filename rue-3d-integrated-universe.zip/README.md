# RUE 3D Snowflake Integrated Universe

This package integrates the **3D spherical snowflake brain** directly into the
contrast + clustering RUE universe.

It includes:

- one star
- five orbiting planets
- per-planet region islands
- like-minded clustering and soft repulsion
- 3D layered snowflake brains (core / inner shell / upsilon outer shell)
- real-time universe view + live 3D brain view

## Run

```bash
pip install -r requirements.txt
python experiments/run_3d_integrated_viewer.py
```

## Notes

This is a stability-first integration. The 3D brain uses:
- canonical center / inner / outer shell positions
- distance-based coupling
- faster outer-shell (upsilon) response
- bounded phase velocity
