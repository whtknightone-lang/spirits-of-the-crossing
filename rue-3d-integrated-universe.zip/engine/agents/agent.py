import numpy as np
from engine.snowflake.brain_3d import SnowflakeBrain3D

def circular_diff(a: float, b: float) -> float:
    return float(np.angle(np.exp(1j * (a - b))))

class Agent:
    def __init__(self, planet_id: int, region_id: int):
        self.planet_id = planet_id
        self.region_id = region_id
        self.brain = SnowflakeBrain3D()
        self.energy = 2.0
        self.last_reward = 0.0
        self.last_penalty = 0.0

    def signature(self) -> float:
        return self.brain.mean_phase()

    def reward_components(self, local_phase: float, local_energy: float, social_match: float):
        sig = self.signature()
        match = np.cos(circular_diff(sig, local_phase))

        positive = max(0.0, match - 0.10) * local_energy
        mismatch = max(0.0, 0.15 - match) * 0.35 * local_energy
        living_cost = 0.05
        social_bonus = max(0.0, social_match) * 0.10
        social_penalty = max(0.0, -social_match) * 0.08

        reward = positive + social_bonus
        penalty = mismatch + living_cost + social_penalty
        return reward, penalty, match

    def step(self, local_phase: float, local_energy: float, social_match: float):
        reward, penalty, match = self.reward_components(local_phase, local_energy, social_match)

        drive = np.tanh(local_energy / 5.0) * 0.012
        drive += 0.012 * social_match
        drive -= 0.010 * max(0.0, -social_match)
        drive += 0.012 * match

        self.brain.step(drive=drive)
        self.energy += reward - penalty
        self.last_reward = reward
        self.last_penalty = penalty
