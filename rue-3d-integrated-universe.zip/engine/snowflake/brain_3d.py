import numpy as np

class SnowflakeBrain3D:
    def __init__(self):
        self.n = 21
        self.phases = np.random.rand(self.n) * 2 * np.pi
        self.positions = self._build_positions()
        self.matrix = self._build_matrix()
        self.inner = np.arange(1, 7)
        self.outer = np.arange(7, 21)
        self.center = np.array([0])

    def _build_positions(self):
        pos = np.zeros((21, 3), dtype=float)

        # center
        pos[0] = np.array([0.0, 0.0, 0.0])

        # inner shell: octahedral-like positions
        inner = np.array([
            [ 1.0,  0.0,  0.0],
            [-1.0,  0.0,  0.0],
            [ 0.0,  1.0,  0.0],
            [ 0.0, -1.0,  0.0],
            [ 0.0,  0.0,  1.0],
            [ 0.0,  0.0, -1.0],
        ])
        pos[1:7] = inner * 0.75

        # outer shell: fibonacci sphere on radius 1.6
        n_outer = 14
        ga = np.pi * (3.0 - np.sqrt(5.0))
        pts = []
        for i in range(n_outer):
            y = 1 - (i / float(n_outer - 1)) * 2
            radius = np.sqrt(max(0.0, 1 - y * y))
            theta = ga * i
            x = np.cos(theta) * radius
            z = np.sin(theta) * radius
            pts.append([x, y, z])
        pos[7:21] = np.array(pts) * 1.6
        return pos

    def _build_matrix(self):
        K = np.zeros((21, 21), dtype=float)

        def connect(a, b, w):
            K[a, b] = w
            K[b, a] = w

        # center <-> inner
        for i in range(1, 7):
            connect(0, i, 1.0)

        # inner ring cycle
        inner = [1, 2, 3, 4, 5, 6]
        for i in range(len(inner)):
            connect(inner[i], inner[(i + 1) % len(inner)], 0.65)

        # inner -> outer assignment
        mapping = {
            1: [7, 8],
            2: [9, 10],
            3: [11, 12],
            4: [13, 14],
            5: [15, 16],
            6: [17, 18],
        }
        for src, dsts in mapping.items():
            for d in dsts:
                connect(src, d, 0.50)

        # outer ring cycle
        outer = list(range(7, 21))
        for i in range(len(outer)):
            connect(outer[i], outer[(i + 1) % len(outer)], 0.35)

        # asymmetry bridges
        connect(1, 19, 0.45)
        connect(3, 20, 0.45)
        return K

    def mean_phase(self):
        return float(np.angle(np.mean(np.exp(1j * self.phases))))

    def sync(self):
        return float(abs(np.mean(np.exp(1j * self.phases))))

    def step(self, drive=0.0):
        diff = self.phases[:, None] - self.phases[None, :]
        dist = np.linalg.norm(self.positions[:, None, :] - self.positions[None, :, :], axis=2)

        coupling = np.sin(diff) * self.matrix / (1.0 + dist)
        velocity = coupling.sum(axis=1)

        # layer-specific behavior
        velocity[self.center] += (np.mean(self.phases[self.inner]) - self.phases[self.center]) * 0.01
        velocity[self.inner] += (np.mean(self.phases[self.outer]) - self.phases[self.inner]) * 0.004

        # upsilon outer shell reacts faster
        velocity[self.outer] *= 1.35

        velocity *= 0.04
        velocity += drive
        velocity = np.clip(velocity, -0.18, 0.18)

        self.phases = np.mod(self.phases + velocity, 2 * np.pi)
