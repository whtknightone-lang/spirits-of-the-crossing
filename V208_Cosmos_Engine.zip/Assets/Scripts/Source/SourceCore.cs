
using UnityEngine;

public class SourceCore : MonoBehaviour
{
    [Range(0f,1f)] public float globalClarity = 0.6f;
    [Range(0f,1f)] public float expansionDrive = 0.5f;

    public bool ShouldExpand(float coherence)
    {
        return coherence * globalClarity > 0.5f;
    }
}
