
using UnityEngine;

public class V208CosmosManager : MonoBehaviour
{
    public CosmosEngine cosmos;
    public SourceCore source;

    public float systemCoherence = 0.5f;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            cosmos.UpdateCosmos(systemCoherence);
        }
    }
}
