
using UnityEngine;

public class WorldInstance : MonoBehaviour
{
    public float resonance = 0.5f;
    public float coherence = 0.5f;

    public string worldType = "emergent";

    public void Evolve(float delta)
    {
        resonance = Mathf.Clamp01(resonance + delta);
        coherence = Mathf.Clamp01(coherence + delta * 0.8f);

        if (coherence > 0.8f)
        {
            worldType = "harmonic";
        }
    }
}
