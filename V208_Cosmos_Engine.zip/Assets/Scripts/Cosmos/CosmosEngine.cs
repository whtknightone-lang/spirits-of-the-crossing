
using UnityEngine;
using System.Collections.Generic;

public class CosmosEngine : MonoBehaviour
{
    public SourceCore source;
    public List<WorldInstance> worlds = new List<WorldInstance>();

    public GameObject worldPrefab;

    public void UpdateCosmos(float coherence)
    {
        if (source == null) return;

        if (source.ShouldExpand(coherence))
        {
            CreateWorld();
        }
    }

    void CreateWorld()
    {
        GameObject obj = Instantiate(worldPrefab);
        WorldInstance world = obj.GetComponent<WorldInstance>();

        if (world != null)
        {
            worlds.Add(world);
            Debug.Log("New world created by Source");
        }
    }
}
