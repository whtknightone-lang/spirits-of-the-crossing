
V208 Cosmos Engine Integration

Purpose:
Connect all systems (V201–V207) into a living cosmos.

Adds:
- CosmosEngine (world creation + evolution)
- SourceCore (origin intelligence layer)
- WorldInstance (individual evolving worlds)
- Integration bridge

Core Idea:
Source → Cosmos → Worlds → Beings → Feedback → Expansion → New Worlds
