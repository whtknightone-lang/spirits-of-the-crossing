
using UnityEngine;

public class SystemManager : MonoBehaviour
{
    public float globalResonance;
    public int activePlayers;

    void Update()
    {
        globalResonance = Mathf.PingPong(Time.time * 0.1f, 1f);
    }
}
