
using UnityEngine;

public class GameBootstrap : MonoBehaviour
{
    void Start()
    {
        Debug.Log("V200 System Bootstrapped");

        InitializeCore();
        InitializeAI();
        InitializeWorld();
    }

    void InitializeCore()
    {
        Debug.Log("Core systems online");
    }

    void InitializeAI()
    {
        Debug.Log("AI systems online");
    }

    void InitializeWorld()
    {
        Debug.Log("World systems online");
    }
}
