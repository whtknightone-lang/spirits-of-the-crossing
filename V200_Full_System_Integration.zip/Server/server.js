
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8080 });

let state = { resonance: 0 };

wss.on('connection', ws => {
    ws.on('message', msg => {
        try {
            const data = JSON.parse(msg);
            state.resonance = data.resonance;
        } catch {}
    });
});

setInterval(()=>{
    const msg = JSON.stringify(state);
    wss.clients.forEach(c=>{
        if(c.readyState===1) c.send(msg);
    });
},100);
