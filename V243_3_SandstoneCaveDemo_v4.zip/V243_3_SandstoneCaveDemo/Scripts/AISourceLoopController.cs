using UnityEngine;

namespace V243.SandstoneCave
{
    public class AISourceLoopController : MonoBehaviour
    {
        [Header("References")]
        public PlayerResponseTracker playerResponseTracker;
        public PlanetAffinityInterpreter planetAffinityInterpreter;
        public AdaptiveCaveAudioController adaptiveCaveAudioController;
        public VRHapticsResonanceBridge hapticsBridge;
        public WorldSpaceFeedbackController worldSpaceFeedbackController;

        [Header("AI / Source State")]
        [Range(0f, 1f)] public float aiCuriosity = 0.4f;
        [Range(0f, 1f)] public float aiCalm = 0.5f;
        [Range(0f, 1f)] public float aiMimicry = 0.5f;
        [Range(0f, 1f)] public float sourceClarity = 0.5f;
        [Range(0f, 1f)] public float sourceInvitation = 0.5f;

        [Header("Loop Outputs")]
        public string suggestedSpiritMode = "Seated";
        public string suggestedPlanetSignal = string.Empty;
        [Range(0f, 1f)] public float loopCoherence;

        private void Update()
        {
            if (playerResponseTracker == null)
            {
                return;
            }

            CavePlayerResonanceState p = playerResponseTracker.LiveState;

            aiCuriosity = Mathf.Lerp(aiCuriosity, p.wonder, Time.deltaTime * 0.35f);
            aiCalm = Mathf.Lerp(aiCalm, p.calm, Time.deltaTime * 0.25f);
            aiMimicry = Mathf.Lerp(aiMimicry, Mathf.Max(p.movementFlow, p.socialSync), Time.deltaTime * 0.45f);
            sourceClarity = Mathf.Lerp(sourceClarity, Mathf.Clamp01((p.sourceAlignment + p.calm + p.wonder) / 3f), Time.deltaTime * 0.25f);
            sourceInvitation = Mathf.Lerp(sourceInvitation, Mathf.Clamp01((p.joy + p.wonder + p.socialSync) / 3f), Time.deltaTime * 0.25f);

            loopCoherence = Mathf.Clamp01((aiCuriosity + aiCalm + aiMimicry + sourceClarity + sourceInvitation) / 5f - p.distortion * 0.35f);
            suggestedSpiritMode = ResolveSpiritSuggestion(p);
            suggestedPlanetSignal = ResolvePlanetSignal();

            if (loopCoherence > 0.65f && worldSpaceFeedbackController != null)
            {
                worldSpaceFeedbackController.RevealPlanetFeedback();
            }

            if (loopCoherence > 0.7f && hapticsBridge != null)
            {
                hapticsBridge.fullBodyAmplitude = Mathf.Max(hapticsBridge.fullBodyAmplitude, loopCoherence * 0.85f);
            }

            if (loopCoherence > 0.75f && adaptiveCaveAudioController != null && p.sourceAlignment > 0.65f)
            {
                adaptiveCaveAudioController.ForcePlanetReveal();
            }
        }

        private string ResolveSpiritSuggestion(CavePlayerResonanceState p)
        {
            if (p.socialSync >= 0.65f) return "Pair";
            if (p.spinStability >= 0.65f) return "Dervish";
            if (p.movementFlow >= 0.6f) return "FlowDancer";
            return "Seated";
        }

        private string ResolvePlanetSignal()
        {
            if (planetAffinityInterpreter == null)
            {
                return string.Empty;
            }

            return string.IsNullOrWhiteSpace(planetAffinityInterpreter.achievableAffinityPlanet)
                ? planetAffinityInterpreter.currentAffinityPlanet
                : planetAffinityInterpreter.achievableAffinityPlanet;
        }
    }
}
