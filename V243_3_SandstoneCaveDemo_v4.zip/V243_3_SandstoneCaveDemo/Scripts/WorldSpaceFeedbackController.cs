using UnityEngine;

namespace V243.SandstoneCave
{
    public class WorldSpaceFeedbackController : MonoBehaviour
    {
        [Header("References")]
        public PlayerResponseTracker playerResponseTracker;
        public CaveSessionController sessionController;
        public PlanetAffinityInterpreter planetAffinityInterpreter;
        public Transform playerRoot;
        public Renderer auraRingRenderer;
        public Light resonanceLight;
        public ParticleSystem sourceThreadParticles;
        public FloorSigilProjector floorSigilProjector;

        [Header("Colors")]
        public Color calmColor = new Color(0.2f, 0.8f, 1f);
        public Color flowColor = new Color(0.2f, 1f, 0.5f);
        public Color spinColor = new Color(0.7f, 0.5f, 1f);
        public Color pairColor = new Color(1f, 0.6f, 0.9f);
        public Color crownColor = new Color(1f, 1f, 0.95f);

        private MaterialPropertyBlock _block;

        private void Awake()
        {
            _block = new MaterialPropertyBlock();
        }

        private void Update()
        {
            if (playerResponseTracker == null)
            {
                return;
            }

            CavePlayerResonanceState s = playerResponseTracker.LiveState;
            Color c = ResolveFeedbackColor(s);
            float intensity = Mathf.Clamp01((s.sourceAlignment + s.calm + s.joy + s.wonder) * 0.35f);

            if (auraRingRenderer != null)
            {
                auraRingRenderer.GetPropertyBlock(_block);
                _block.SetColor("_EmissionColor", c * Mathf.Lerp(0.5f, 3.0f, intensity));
                _block.SetFloat("_Pulse", sessionController != null && sessionController.chakraState.isHolding ? 1f : sessionController != null ? sessionController.chakraState.progress01 : 0f);
                auraRingRenderer.SetPropertyBlock(_block);
            }

            if (resonanceLight != null)
            {
                resonanceLight.color = c;
                resonanceLight.intensity = Mathf.Lerp(1.5f, 6f, intensity);
            }

            if (sourceThreadParticles != null)
            {
                var emission = sourceThreadParticles.emission;
                emission.rateOverTime = Mathf.Lerp(3f, 30f, intensity);
                if (intensity > 0.15f && !sourceThreadParticles.isPlaying) sourceThreadParticles.Play();
                if (intensity <= 0.15f && sourceThreadParticles.isPlaying) sourceThreadParticles.Stop();
            }
        }

        public void RevealPlanetFeedback()
        {
            if (floorSigilProjector == null || planetAffinityInterpreter == null)
            {
                return;
            }

            string planet = string.IsNullOrWhiteSpace(planetAffinityInterpreter.achievableAffinityPlanet)
                ? planetAffinityInterpreter.currentAffinityPlanet
                : planetAffinityInterpreter.achievableAffinityPlanet;

            floorSigilProjector.Reveal(planet);
        }

        private Color ResolveFeedbackColor(CavePlayerResonanceState s)
        {
            if (sessionController != null && sessionController.chakraState.isHolding)
            {
                return crownColor;
            }
            if (s.socialSync >= 0.65f) return pairColor;
            if (s.spinStability >= 0.65f) return spinColor;
            if (s.movementFlow >= 0.6f) return flowColor;
            return calmColor;
        }
    }
}
