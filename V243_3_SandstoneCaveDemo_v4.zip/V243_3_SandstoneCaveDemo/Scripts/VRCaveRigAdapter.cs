using UnityEngine;

namespace V243.SandstoneCave
{
    public class VRCaveRigAdapter : MonoBehaviour
    {
        [Header("Rig References")]
        public Transform head;
        public Transform leftHand;
        public Transform rightHand;
        public Transform pelvis;

        [Header("Output")]
        public BreathMovementInterpreter breathMovementInterpreter;
        [Range(0.1f, 4f)] public float breathScale = 1.0f;
        [Range(0.1f, 3f)] public float flowScale = 1.0f;
        [Range(0.1f, 2f)] public float spinScale = 1.0f;
        [Range(0.1f, 2f)] public float socialScale = 1.0f;

        private Vector3 _lastHeadPos;
        private Vector3 _lastLeftPos;
        private Vector3 _lastRightPos;
        private float _lastYaw;

        private void Start()
        {
            if (head != null) _lastHeadPos = head.position;
            if (leftHand != null) _lastLeftPos = leftHand.position;
            if (rightHand != null) _lastRightPos = rightHand.position;
            if (pelvis != null) _lastYaw = pelvis.eulerAngles.y;
        }

        private void Update()
        {
            if (breathMovementInterpreter == null || head == null)
            {
                return;
            }

            float breath = EstimateBreath();
            float flow = EstimateFlow();
            float spin = EstimateSpin();
            float pair = EstimateRelationalOpenness();

            breathMovementInterpreter.UpdateBreath(breath);
            breathMovementInterpreter.UpdateFlowMovement(flow);
            breathMovementInterpreter.UpdateSpin(spin);
            breathMovementInterpreter.UpdateSocialSync(pair);
        }

        private float EstimateBreath()
        {
            Vector3 delta = head.position - _lastHeadPos;
            _lastHeadPos = head.position;
            float verticalWave = Mathf.Abs(delta.y) * 15f * breathScale;
            return Mathf.Clamp01(1f - Mathf.Abs(0.25f - Mathf.Repeat(verticalWave, 0.5f)) * 2f);
        }

        private float EstimateFlow()
        {
            if (leftHand == null || rightHand == null)
            {
                return 0f;
            }

            Vector3 leftDelta = leftHand.position - _lastLeftPos;
            Vector3 rightDelta = rightHand.position - _lastRightPos;
            _lastLeftPos = leftHand.position;
            _lastRightPos = rightHand.position;

            float smoothness = Vector3.Dot(leftDelta.normalized, rightDelta.normalized);
            float magnitude = (leftDelta.magnitude + rightDelta.magnitude) * 4f * flowScale;
            return Mathf.Clamp01((smoothness * 0.5f + 0.5f) * magnitude);
        }

        private float EstimateSpin()
        {
            if (pelvis == null)
            {
                return 0f;
            }

            float yaw = pelvis.eulerAngles.y;
            float deltaYaw = Mathf.Abs(Mathf.DeltaAngle(_lastYaw, yaw));
            _lastYaw = yaw;
            return Mathf.Clamp01(deltaYaw / 30f * spinScale);
        }

        private float EstimateRelationalOpenness()
        {
            if (leftHand == null || rightHand == null || head == null)
            {
                return 0f;
            }

            float leftDistance = Vector3.Distance(head.position, leftHand.position);
            float rightDistance = Vector3.Distance(head.position, rightHand.position);
            float symmetry = 1f - Mathf.Abs(leftDistance - rightDistance);
            return Mathf.Clamp01(symmetry * socialScale);
        }
    }
}
