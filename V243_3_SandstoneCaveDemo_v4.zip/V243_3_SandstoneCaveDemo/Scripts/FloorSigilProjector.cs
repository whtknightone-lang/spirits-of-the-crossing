using System.Collections.Generic;
using UnityEngine;

namespace V243.SandstoneCave
{
    public class FloorSigilProjector : MonoBehaviour
    {
        [System.Serializable]
        public class FloorSigilBinding
        {
            public string planetId = "planet";
            public Projector projector;
            public Renderer floorDecalRenderer;
            public Color color = Color.white;
            [Range(0f, 5f)] public float intensity = 2f;
        }

        public List<FloorSigilBinding> bindings = new List<FloorSigilBinding>();
        [Range(0f, 10f)] public float revealFadeSpeed = 2f;

        private string _activePlanetId = string.Empty;

        private void Update()
        {
            foreach (var binding in bindings)
            {
                bool active = binding.planetId == _activePlanetId;
                float target = active ? binding.intensity : 0f;

                if (binding.projector != null)
                {
                    binding.projector.enabled = active || binding.projector.orthographicSize > 0.01f;
                    binding.projector.farClipPlane = Mathf.MoveTowards(binding.projector.farClipPlane, target, Time.deltaTime * revealFadeSpeed);
                }

                if (binding.floorDecalRenderer != null)
                {
                    Color current = binding.floorDecalRenderer.material.GetColor("_EmissionColor");
                    Color next = Color.Lerp(current, binding.color * target, Time.deltaTime * revealFadeSpeed);
                    binding.floorDecalRenderer.material.SetColor("_EmissionColor", next);
                    binding.floorDecalRenderer.enabled = active || next.maxColorComponent > 0.01f;
                }
            }
        }

        public void Reveal(string planetId)
        {
            _activePlanetId = planetId;
        }

        public void ClearAll()
        {
            _activePlanetId = string.Empty;
        }
    }
}
