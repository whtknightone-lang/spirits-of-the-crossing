using UnityEngine;

namespace V243.SandstoneCave
{
    public class VRHapticsResonanceBridge : MonoBehaviour
    {
        public enum HapticChannel
        {
            LeftHand,
            RightHand,
            Headset,
            Chest,
            Seat,
            FullBody
        }

        [Header("References")]
        public PlayerResponseTracker playerResponseTracker;
        public CaveSessionController sessionController;

        [Header("Debug")]
        public bool debugLogPulses = true;
        [Range(0f, 1f)] public float minimumPulseAmplitude = 0.08f;
        [Range(0.1f, 20f)] public float pulseSpeed = 4f;

        [Header("Runtime")]
        public float leftHandAmplitude;
        public float rightHandAmplitude;
        public float headsetAmplitude;
        public float chestAmplitude;
        public float seatAmplitude;
        public float fullBodyAmplitude;

        private float _pulseClock;

        private void Update()
        {
            if (playerResponseTracker == null)
            {
                return;
            }

            _pulseClock += Time.deltaTime * pulseSpeed;
            CavePlayerResonanceState s = playerResponseTracker.LiveState;
            float envelope = 0.5f + 0.5f * Mathf.Sin(_pulseClock);

            leftHandAmplitude = envelope * Mathf.Max(minimumPulseAmplitude, s.movementFlow * 0.7f);
            rightHandAmplitude = envelope * Mathf.Max(minimumPulseAmplitude, s.socialSync * 0.7f);
            headsetAmplitude = envelope * Mathf.Max(minimumPulseAmplitude, s.wonder * 0.65f);
            chestAmplitude = envelope * Mathf.Max(minimumPulseAmplitude, (s.calm + s.sourceAlignment) * 0.45f);
            seatAmplitude = envelope * Mathf.Max(minimumPulseAmplitude, (1f - s.distortion) * 0.4f);
            fullBodyAmplitude = envelope * Mathf.Max(minimumPulseAmplitude, (s.sourceAlignment + s.joy + s.wonder) * 0.3f);

            if (sessionController != null && sessionController.chakraState.isHolding)
            {
                fullBodyAmplitude = Mathf.Max(fullBodyAmplitude, 0.65f * envelope);
                chestAmplitude = Mathf.Max(chestAmplitude, 0.75f * envelope);
            }

            DispatchPulse(HapticChannel.LeftHand, leftHandAmplitude);
            DispatchPulse(HapticChannel.RightHand, rightHandAmplitude);
            DispatchPulse(HapticChannel.Headset, headsetAmplitude);
            DispatchPulse(HapticChannel.Chest, chestAmplitude);
            DispatchPulse(HapticChannel.Seat, seatAmplitude);
            DispatchPulse(HapticChannel.FullBody, fullBodyAmplitude);
        }

        private void DispatchPulse(HapticChannel channel, float amplitude)
        {
            amplitude = Mathf.Clamp01(amplitude);
            if (!debugLogPulses || amplitude <= minimumPulseAmplitude)
            {
                return;
            }

            // Replace with XR toolkit / OpenXR / platform-specific haptic calls.
            Debug.Log($"[VRHaptics] {channel} amplitude={amplitude:0.00}");
        }
    }
}
