# V243.3 VR + Haptics + AI/Source Loop Wiring Guide

This layer turns the cave into a closed feedback loop:

Player movement/breath -> cave interpretation -> AI/spirit suggestion -> source invitation -> haptics + sigil projection + audio response

## New scripts

- `FloorSigilProjector.cs`
- `WorldSpaceFeedbackController.cs`
- `VRHapticsResonanceBridge.cs`
- `VRCaveRigAdapter.cs`
- `AISourceLoopController.cs`

## Minimal hookup order

### 1. Floor sigil result
- Add `FloorSigilProjector` to the center dais or a nearby manager object.
- Create one projector/decal child per main planet result.
- Match each binding's `planetId` to the ids used in `PlanetAffinityInterpreter`.

### 2. World-space player feedback
- Add `WorldSpaceFeedbackController` to a manager object.
- Assign:
  - `playerResponseTracker`
  - `sessionController`
  - `planetAffinityInterpreter`
  - `auraRingRenderer`
  - `resonanceLight`
  - `sourceThreadParticles`
  - `floorSigilProjector`

### 3. VR rig adapter
- Add `VRCaveRigAdapter` to the XR rig root.
- Assign:
  - `head` = HMD/camera
  - `leftHand` and `rightHand` = tracked controller anchors
  - `pelvis` = rig root or body proxy
  - `breathMovementInterpreter`

This script is XR-ready but intentionally toolkit-agnostic. Replace references with your OpenXR/XR Interaction Toolkit rig transforms.

### 4. Haptics bridge
- Add `VRHapticsResonanceBridge` to a manager object.
- Assign `playerResponseTracker` and `sessionController`.
- Start with debug logging on.
- Replace the `DispatchPulse(...)` body with real OpenXR or vendor haptic calls.

Suggested mapping:
- Left hand: flow / movement pulse
- Right hand: pair / social resonance pulse
- Headset: wonder / visionary micro-pulse
- Chest: calm + source pulse
- Seat/full body: grounding + crown-hold field pulse

### 5. AI/Source loop
- Add `AISourceLoopController` to a manager object.
- Assign:
  - `playerResponseTracker`
  - `planetAffinityInterpreter`
  - `adaptiveCaveAudioController`
  - `hapticsBridge`
  - `worldSpaceFeedbackController`

This script is the first unified “player + AI + source” loop.

## Fast test path

1. Keep session length at 60 seconds.
2. Start session.
3. Use debug keys or VR rig motion.
4. Bias one clear mode:
   - seated/calm/source
   - flow/joy
   - spin/wonder
   - pair/social
5. Press `Y` to force affinity evaluation if needed.
6. Watch for:
   - aura color shift
   - floor sigil reveal
   - audio reveal transition
   - haptic debug pulses
   - AI/source loop coherence rising

## Recommended next pass

- replace projector/decal placeholders with animated floor glyphs
- drive spirit animations from `AISourceLoopController.suggestedSpiritMode`
- add multiplayer group-field averaging for 2-4 players
- replace debug haptics with OpenXR action-based output
