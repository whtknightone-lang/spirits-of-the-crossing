
using UnityEngine;

public class CoCreationField : MonoBehaviour
{
    public float groupEnergy;

    public void UpdateField(float[] energies)
    {
        float sum = 0;
        foreach (var e in energies) sum += e;
        groupEnergy = sum / energies.Length;
    }
}
