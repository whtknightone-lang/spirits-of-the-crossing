
using UnityEngine;

public class GroupIdentity : MonoBehaviour
{
    public float cohesion;

    public void UpdateIdentity(float groupEnergy)
    {
        cohesion = Mathf.Clamp01(groupEnergy);
    }
}
