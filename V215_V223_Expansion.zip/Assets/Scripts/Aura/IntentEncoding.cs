
using UnityEngine;

public class IntentEncoding : MonoBehaviour
{
    public float intent;
    public float emotion;

    public float GetSignal()
    {
        return intent * 0.7f + emotion * 0.3f;
    }
}
