
using UnityEngine;

public class AuraLanguage : MonoBehaviour
{
    public float intent;
    public float emotion;

    public Color GetAuraColor()
    {
        return Color.Lerp(Color.blue, Color.magenta, intent) + new Color(emotion, 0, 0);
    }
}
