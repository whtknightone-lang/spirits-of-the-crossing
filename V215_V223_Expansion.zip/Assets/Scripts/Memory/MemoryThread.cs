
using UnityEngine;
using System.Collections.Generic;

public class MemoryThread : MonoBehaviour
{
    public List<string> events = new List<string>();

    public void Add(string e)
    {
        events.Add(e);
    }
}
