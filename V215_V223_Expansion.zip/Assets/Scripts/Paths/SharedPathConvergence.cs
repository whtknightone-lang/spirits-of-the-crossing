
using UnityEngine;

public class SharedPathConvergence : MonoBehaviour
{
    public Transform[] playerChoices;

    public bool CheckConvergence()
    {
        if (playerChoices.Length < 2) return false;

        Vector3 first = playerChoices[0].position;

        foreach (var p in playerChoices)
        {
            if (Vector3.Distance(p.position, first) > 2f)
                return false;
        }

        Debug.Log("Shared path convergence achieved");
        return true;
    }
}
