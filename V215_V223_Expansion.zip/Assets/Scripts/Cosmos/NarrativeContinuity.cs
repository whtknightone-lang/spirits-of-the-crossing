
using UnityEngine;
using System.Collections.Generic;

public class NarrativeContinuity : MonoBehaviour
{
    public List<string> narrative = new List<string>();

    public void AddEvent(string e)
    {
        narrative.Add(e);
        Debug.Log("Narrative continues: " + e);
    }
}
