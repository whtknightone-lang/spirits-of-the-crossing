
using UnityEngine;

public class AdaptiveWorldResponse : MonoBehaviour
{
    public void Respond(float energy)
    {
        Debug.Log("World adapting to energy: " + energy);
    }
}
