
using UnityEngine;

public class SourcePersonalizationDeep : MonoBehaviour
{
    public float depth;

    public float GetPersonalSignal(float individuality)
    {
        return individuality * depth;
    }
}
