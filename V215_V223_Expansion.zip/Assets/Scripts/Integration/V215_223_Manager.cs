
using UnityEngine;

public class V215_223_Manager : MonoBehaviour
{
    public SharedPathConvergence convergence;
    public CoCreationField field;
    public GroupIdentity group;
    public AdaptiveWorldResponse world;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Y))
        {
            bool aligned = convergence.CheckConvergence();
            if (aligned)
            {
                float energy = Random.Range(0.5f, 1f);
                field.UpdateField(new float[]{energy, energy});
                group.UpdateIdentity(field.groupEnergy);
                world.Respond(field.groupEnergy);
            }
        }
    }
}
