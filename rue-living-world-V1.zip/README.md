
# RUE Living World Engine V1

This is version V1 of the unified Living World Engine.

Includes progressively:
V1: Core unified loop
V2: Environment + spirits integration
V3: Lineage + territory + roles
V4: Mythology + history tracking
V5: Full playable prototype hooks

Run:
python run.py
