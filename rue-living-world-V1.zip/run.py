
print("Running RUE Living World Engine V1")

def step():
    print("Step executed in V1")

if __name__ == "__main__":
    for i in range(5):
        step()
