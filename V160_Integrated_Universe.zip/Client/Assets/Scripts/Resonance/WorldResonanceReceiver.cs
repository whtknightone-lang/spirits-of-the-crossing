
using UnityEngine;

public class WorldResonanceReceiver : MonoBehaviour
{
    public float globalResonance;
    public float globalAlignment;
    public float globalMeaning;

    public void ApplyState(float r, float a, float m)
    {
        globalResonance = r;
        globalAlignment = a;
        globalMeaning = m;

        // Example: influence environment
        RenderSettings.ambientIntensity = Mathf.Lerp(0.5f, 2f, r);
    }
}
