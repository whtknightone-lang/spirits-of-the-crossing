
using UnityEngine;

public class IntegratedResonanceSender : MonoBehaviour
{
    public float resonance;
    public float alignment;
    public float meaning;

    private WebSocketClient client;

    void Awake()
    {
        client = FindObjectOfType<WebSocketClient>();
    }

    void Update()
    {
        resonance = Mathf.PingPong(Time.time * 0.2f, 1f);
        alignment = Mathf.PingPong(Time.time * 0.1f, 1f);
        meaning = Mathf.PingPong(Time.time * 0.05f, 1f);

        if (client != null)
        {
            string payload = JsonUtility.ToJson(new Payload {
                r = resonance,
                a = alignment,
                m = meaning
            });

            client.Send(payload);
        }
    }

    [System.Serializable]
    public class Payload
    {
        public float r;
        public float a;
        public float m;
    }
}
