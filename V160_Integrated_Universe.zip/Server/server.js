
const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8080 });

let players = [];

wss.on('connection', function connection(ws) {
    players.push({ ws, r: 0, a: 0, m: 0 });

    ws.on('message', function incoming(message) {
        try {
            const data = JSON.parse(message);
            const player = players.find(p => p.ws === ws);
            if (player) {
                player.r = data.r;
                player.a = data.a;
                player.m = data.m;
            }
        } catch(e){}
    });

    ws.on('close', () => {
        players = players.filter(p => p.ws !== ws);
    });
});

setInterval(() => {
    if (players.length === 0) return;

    let avgR = players.reduce((a,p)=>a+p.r,0)/players.length;
    let avgA = players.reduce((a,p)=>a+p.a,0)/players.length;
    let avgM = players.reduce((a,p)=>a+p.m,0)/players.length;

    const worldState = JSON.stringify({
        resonance: avgR,
        alignment: avgA,
        meaning: avgM
    });

    players.forEach(p => {
        if (p.ws.readyState === WebSocket.OPEN)
            p.ws.send(worldState);
    });

}, 100);
