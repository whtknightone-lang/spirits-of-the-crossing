
import random

PLANET_TYPES = ["CHAOTIC", "STABLE", "FERTILE", "HARSH"]

def assign_traits():
    t = random.choice(PLANET_TYPES)

    if t == "CHAOTIC":
        return {"type": t, "energy": 1.0, "volatility": 0.3, "coherence": -0.2}
    if t == "STABLE":
        return {"type": t, "energy": 0.9, "volatility": -0.2, "coherence": 0.3}
    if t == "FERTILE":
        return {"type": t, "energy": 1.3, "volatility": 0.0, "coherence": 0.1}
    if t == "HARSH":
        return {"type": t, "energy": 0.7, "volatility": 0.1, "coherence": -0.1}
