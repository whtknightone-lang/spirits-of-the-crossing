
import random

class Spirit:
    def __init__(self, level, role, planet_id=None):
        self.level = level
        self.role = role
        self.planet_id = planet_id

    def act(self, universe):
        if self.level == "MINOR":
            a = random.choice(universe.agents)
            a.energy += 0.01

        elif self.level == "MAJOR":
            for a in universe.agents:
                if a.planet_id == self.planet_id:
                    a.energy += 0.005

        elif self.level == "GUARDIAN":
            planet = universe.planets[self.planet_id]
            if planet.traits["type"] == "CHAOTIC":
                for a in universe.agents:
                    if a.planet_id == self.planet_id:
                        a.energy += 0.01
            elif planet.traits["type"] == "STABLE":
                for a in universe.agents:
                    if a.planet_id == self.planet_id:
                        a.energy += 0.002

def create_spirits(num_planets):
    spirits = []
    for i in range(num_planets):
        spirits.append(Spirit("GUARDIAN", "PLANET", planet_id=i))
        spirits.append(Spirit("MAJOR", "INFLUENCE", planet_id=i))
    for _ in range(5):
        spirits.append(Spirit("MINOR", "LOCAL"))
    return spirits
