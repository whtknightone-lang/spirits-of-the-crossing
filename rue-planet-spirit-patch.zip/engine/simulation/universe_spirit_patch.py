
from engine.planet_traits.planet_traits import assign_traits
from engine.spirits.spirit_hierarchy import create_spirits

class UniverseSpiritMixin:

    def init_planets_traits(self):
        for p in self.planets:
            p.traits = assign_traits()

    def init_spirits(self):
        self.spirits = create_spirits(len(self.planets))

    def spirit_step(self):
        for s in self.spirits:
            s.act(self)
