
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from engine.simulation.universe import Universe
from engine.simulation.universe_spirit_patch import UniverseSpiritMixin

class GameUniverse(Universe, UniverseSpiritMixin):
    def __init__(self):
        super().__init__()
        self.init_planets_traits()
        self.init_spirits()

    def step(self):
        super().step()
        self.spirit_step()

if __name__ == "__main__":
    u = GameUniverse()
    for i in range(500):
        u.step()
        if i % 50 == 0:
            print("step", i)
