
# RUE Planet Personality + Spirit Hierarchy Patch

Adds:
- Planet personality system
- Spirit hierarchy (minor, major, guardian)
- Integration into simulation loop

Run:
python experiments/run_planet_spirit_world.py
