
RUE Snowflake Core V1 Kernel

Steps implemented:

1. Canonical 21-node snowflake adjacency matrix
2. Bounded oscillator dynamics
3. Snowflake brain wrapper
4. Multi-brain stability harness
5. Metrics logging for sync and diversity

Run:

pip install -r requirements.txt
python tests/snowflake_sim.py
