
import numpy as np

def volatility(current, previous):
    return np.mean(np.abs(current-previous))
