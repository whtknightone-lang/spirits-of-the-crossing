
import numpy as np

def sync(phases):
    return abs(np.mean(np.exp(1j*phases)))
