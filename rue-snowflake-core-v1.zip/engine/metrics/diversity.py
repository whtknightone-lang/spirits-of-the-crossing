
import numpy as np

def diversity(phases):
    return np.std(phases)
