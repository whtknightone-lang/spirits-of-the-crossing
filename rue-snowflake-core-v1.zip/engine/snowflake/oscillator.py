
import numpy as np

def update(phases, matrix):

    diff = phases[:,None] - phases[None,:]
    coupling = np.sin(diff) * matrix

    velocity = coupling.sum(axis=1)

    velocity *= 0.05
    velocity = np.clip(velocity,-0.2,0.2)

    phases = phases + velocity

    return np.mod(phases,2*np.pi)
