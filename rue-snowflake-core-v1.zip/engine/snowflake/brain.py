
import numpy as np
from .adjacency import build_matrix
from .oscillator import update

class SnowflakeBrain:

    def __init__(self):
        self.phases = np.random.rand(21)*2*np.pi
        self.matrix = build_matrix()

    def step(self):
        self.phases = update(self.phases,self.matrix)
