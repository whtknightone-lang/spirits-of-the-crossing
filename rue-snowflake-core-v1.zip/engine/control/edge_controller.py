
class EdgeController:

    def __init__(self):
        self.target_sync = 0.52

    def tune(self,sync,params):

        if sync > 0.7:
            params["mutation"] += 0.005
            params["coupling"] -= 0.005

        if sync < 0.3:
            params["coupling"] += 0.005

        return params
