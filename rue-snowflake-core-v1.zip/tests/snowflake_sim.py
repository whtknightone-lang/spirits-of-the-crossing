
import numpy as np
from engine.snowflake.brain import SnowflakeBrain
from engine.metrics.sync import sync
from engine.metrics.diversity import diversity

brains = [SnowflakeBrain() for _ in range(200)]

sync_log=[]
div_log=[]

for step in range(10000):

    for b in brains:
        b.step()

    phases = np.concatenate([b.phases for b in brains])

    s = sync(phases)
    d = diversity(phases)

    sync_log.append(s)
    div_log.append(d)

    if step%1000==0:
        print("step",step,"sync",round(s,3),"div",round(d,3))

print("simulation complete")
