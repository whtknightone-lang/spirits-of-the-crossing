
using UnityEngine;

public class AIMemoryInfluence : MonoBehaviour
{
    public AIMultiDrive drives;

    public void ApplyMemory(string eventType)
    {
        if (drives == null) return;

        if (eventType == "player_helped")
            drives.connection.value += 0.2f;

        if (eventType == "area_unstable")
            drives.stability.value += 0.2f;

        if (eventType == "new_area")
            drives.curiosity.value += 0.2f;
    }
}
