
using UnityEngine;

[System.Serializable]
public class Drive
{
    public string name;
    public float value;
}

public class AIMultiDrive : MonoBehaviour
{
    public Drive curiosity = new Drive { name = "Curiosity", value = 0.5f };
    public Drive stability = new Drive { name = "Stability", value = 0.5f };
    public Drive connection = new Drive { name = "Connection", value = 0.5f };

    public Drive GetStrongestDrive()
    {
        Drive strongest = curiosity;
        if (stability.value > strongest.value) strongest = stability;
        if (connection.value > strongest.value) strongest = connection;
        return strongest;
    }
}
