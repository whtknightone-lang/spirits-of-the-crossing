
using UnityEngine;

public class AIDecisionSystem : MonoBehaviour
{
    public AIMultiDrive drives;
    public string currentAction;

    void Update()
    {
        if (drives == null) return;

        var d = drives.GetStrongestDrive();

        switch (d.name)
        {
            case "Curiosity":
                currentAction = "Explore";
                break;
            case "Stability":
                currentAction = "Stabilize";
                break;
            case "Connection":
                currentAction = "Engage";
                break;
        }
    }
}
