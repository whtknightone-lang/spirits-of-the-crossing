def behavior_summary(avg_energy: float, sync: float) -> str:
    if sync > 0.7:
        return "over-coherent"
    if sync < 0.25:
        return "turbulent"
    if avg_energy > 2.0:
        return "stable-adaptive"
    return "exploratory"
