from pathlib import Path
import csv
import matplotlib.pyplot as plt

def write_metrics_csv(rows, out_path: str) -> None:
    path = Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

def plot_dashboard(rows, out_path: str) -> None:
    if not rows:
        return

    steps = [r["step"] for r in rows]
    sync = [r["sync"] for r in rows]
    div = [r["diversity"] for r in rows]
    vol = [r["volatility"] for r in rows]
    e = [r["avg_energy"] for r in rows]
    coupling = [r["coupling"] for r in rows]
    mutation = [r["mutation_rate"] for r in rows]

    fig = plt.figure(figsize=(10, 8))

    ax1 = fig.add_subplot(3, 1, 1)
    ax1.plot(steps, sync, label="sync")
    ax1.plot(steps, div, label="diversity")
    ax1.plot(steps, vol, label="volatility")
    ax1.legend()
    ax1.set_title("Edge-of-Chaos Metrics")

    ax2 = fig.add_subplot(3, 1, 2)
    ax2.plot(steps, coupling, label="coupling")
    ax2.plot(steps, mutation, label="mutation_rate")
    ax2.legend()
    ax2.set_title("Controller Parameters")

    ax3 = fig.add_subplot(3, 1, 3)
    ax3.plot(steps, e, label="avg_energy")
    ax3.legend()
    ax3.set_title("Average Agent Energy")
    ax3.set_xlabel("Step")

    fig.tight_layout()
    path = Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=150)
    plt.close(fig)
