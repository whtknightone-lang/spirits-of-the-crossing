from dataclasses import dataclass

@dataclass
class SimulationConfig:
    num_planets: int = 3
    num_agents: int = 24
    brain_size: int = 21
    steps: int = 3000
    tune_interval: int = 100
    random_seed: int = 7

@dataclass
class RuntimeParams:
    coupling: float = 0.22
    mutation_rate: float = 0.006
    flare_gain: float = 0.8
    memory_decay: float = 0.008
    exploration: float = 0.006

    coupling_min: float = 0.08
    coupling_max: float = 0.45
    mutation_min: float = 0.0
    mutation_max: float = 0.05
    flare_min: float = 0.2
    flare_max: float = 1.5
    memory_decay_min: float = 0.001
    memory_decay_max: float = 0.03
    exploration_min: float = 0.0
    exploration_max: float = 0.05
