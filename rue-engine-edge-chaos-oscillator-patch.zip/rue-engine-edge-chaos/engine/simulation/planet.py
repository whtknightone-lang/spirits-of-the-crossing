from dataclasses import dataclass

@dataclass
class Planet:
    index: int
    radius: float
    angle: float = 0.0

    def update_orbit(self) -> None:
        self.angle += 0.01 / max(self.radius, 1e-6)
