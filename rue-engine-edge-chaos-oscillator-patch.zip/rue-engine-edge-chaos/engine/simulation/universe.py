from engine.simulation.star import Star
from engine.simulation.planet import Planet

class Universe:
    def __init__(self, num_planets: int):
        self.star = Star()
        self.planets = [Planet(i, radius=5 + i * 3) for i in range(num_planets)]
        self.time = 0

    def step(self, flare_gain: float) -> float:
        self.time += 1
        for planet in self.planets:
            planet.update_orbit()
        return self.star.emit_energy(flare_gain)
