import numpy as np

def gather_agent_phases(agents) -> np.ndarray:
    return np.stack([agent.brain.phase for agent in agents], axis=0)

def order_parameter(phases: np.ndarray) -> float:
    return float(np.abs(np.mean(np.exp(1j * phases))))

def phase_diversity(phases: np.ndarray) -> float:
    return float(np.std(phases))

def phase_volatility(phases_now: np.ndarray, phases_prev: np.ndarray) -> float:
    raw = np.angle(np.exp(1j * (phases_now - phases_prev)))
    return float(np.mean(np.abs(raw)))

def energy_trend(agents) -> float:
    diffs = [agent.energy - agent.last_energy for agent in agents]
    return float(np.mean(diffs))

def average_energy(agents) -> float:
    return float(np.mean([agent.energy for agent in agents]))
