from dataclasses import dataclass
import random

@dataclass
class Star:
    base_energy: float = 5.0
    flare_probability: float = 0.008
    flare_strength: float = 4.0

    def emit_energy(self, flare_gain: float) -> float:
        flare = 0.0
        if random.random() < self.flare_probability:
            flare = self.flare_strength * flare_gain
        return self.base_energy + flare
