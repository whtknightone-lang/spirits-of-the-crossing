from dataclasses import dataclass, field
import numpy as np
from engine.agents.snowflake_brain import SnowflakeBrain

@dataclass
class Agent:
    brain_size: int
    rng: np.random.Generator
    energy: float = 0.0
    last_energy: float = 0.0
    brain: SnowflakeBrain = field(init=False)

    def __post_init__(self):
        self.brain = SnowflakeBrain(self.brain_size, self.rng)

    def step(self, coupling: float, external_drive: float, memory_decay: float, exploration: float) -> None:
        self.last_energy = self.energy
        self.brain.update(coupling, external_drive, memory_decay, exploration, self.rng)
        coherence = abs(np.mean(np.exp(1j * self.brain.phase)))
        self.energy += max(0.0, 1.4 * coherence + 0.03 * external_drive - 0.25)
