import numpy as np


def _connect(mat: np.ndarray, a: int, b: int, w: float) -> None:
    mat[a, b] = w
    mat[b, a] = w


def build_snowflake_matrix(brain_size: int = 21) -> np.ndarray:
    if brain_size != 21:
        # Fallback to a ring for non-21-node experiments.
        mat = np.zeros((brain_size, brain_size), dtype=float)
        for i in range(brain_size):
            _connect(mat, i, (i + 1) % brain_size, 0.45)
            _connect(mat, i, (i + 2) % brain_size, 0.20)
        return mat

    mat = np.zeros((21, 21), dtype=float)

    # center-inner ring
    for i in range(1, 7):
        _connect(mat, 0, i, 1.00)

    # inner cycle
    inner = [1, 2, 3, 4, 5, 6]
    for i in range(len(inner)):
        _connect(mat, inner[i], inner[(i + 1) % len(inner)], 0.65)

    # inner to outer
    mapping = {
        1: [7, 8],
        2: [9, 10],
        3: [11, 12],
        4: [13, 14],
        5: [15, 16],
        6: [17, 18],
    }
    for src, dsts in mapping.items():
        for dst in dsts:
            _connect(mat, src, dst, 0.50)

    # asymmetry bridges
    _connect(mat, 1, 19, 0.45)
    _connect(mat, 3, 20, 0.45)

    # outer cycle
    outer = list(range(7, 21))
    for i in range(len(outer)):
        _connect(mat, outer[i], outer[(i + 1) % len(outer)], 0.35)

    return mat


class SnowflakeBrain:
    def __init__(self, brain_size: int, rng: np.random.Generator):
        self.phase = rng.uniform(0.0, 2.0 * np.pi, size=(brain_size,))
        self.memory = np.zeros(brain_size, dtype=float)
        self.omega = rng.normal(0.0, 0.015, size=(brain_size,))
        self.K = build_snowflake_matrix(brain_size)
        self.degree = np.maximum(self.K.sum(axis=1), 1e-6)
        self.anchor_mask = np.zeros(brain_size, dtype=float)
        self.anchor_mask[0] = 1.0
        if brain_size >= 7:
            self.anchor_mask[1:7] = 0.35

    def update(
        self,
        coupling: float,
        external_drive: float,
        memory_decay: float,
        exploration: float,
        rng: np.random.Generator,
    ) -> None:
        diff = self.phase[None, :] - self.phase[:, None]

        # Sparse structured interaction instead of fully connected diffusion.
        interaction = (self.K * np.sin(diff)).sum(axis=1) / self.degree

        # Neighbor coherence acts as a local stabilizer.
        complex_neighbors = self.K @ np.exp(1j * self.phase)
        neighbor_phase = np.angle(complex_neighbors + 1e-9)
        neighbor_coherence = np.abs(complex_neighbors) / self.degree

        # Soft anchor: center and inner ring resist runaway drift.
        global_phase = np.angle(np.mean(np.exp(1j * self.phase)))
        anchor_pull = -self.anchor_mask * np.sin(self.phase - global_phase)

        # Memory tracks useful local synchrony, but remains bounded.
        self.memory = (1.0 - memory_decay) * self.memory + 0.05 * neighbor_coherence * np.cos(neighbor_phase - self.phase)
        self.memory = np.clip(self.memory, -1.0, 1.0)

        # Exploration weakens when coherence is already healthy.
        adaptive_noise = rng.normal(0.0, exploration * (1.10 - 0.75 * np.clip(neighbor_coherence, 0.0, 1.0)), size=self.phase.shape)

        delta = (
            self.omega
            + 0.11 * coupling * interaction
            + 0.035 * np.sin(neighbor_phase - self.phase) * neighbor_coherence
            + 0.020 * self.memory
            + 0.010 * external_drive * (0.4 + self.anchor_mask)
            + 0.030 * anchor_pull
            + adaptive_noise
        )

        # Velocity clipping prevents bursts from throwing the whole brain into turbulence.
        delta = np.clip(delta, -0.18, 0.18)
        self.phase = (self.phase + delta) % (2.0 * np.pi)
