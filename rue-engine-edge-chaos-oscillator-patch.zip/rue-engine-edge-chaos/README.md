# RUE Engine — Stability-Focused Edge-of-Chaos Starter

This starter extends the minimal RUE prototype with a **stability-first edge-of-chaos controller**.

What it adds:
- runtime metrics:
  - synchronization (Kuramoto order parameter)
  - phase diversity
  - phase volatility
  - energy trend
- a controller that tunes:
  - coupling
  - mutation rate
  - flare gain
  - memory decay
- periodic logging
- automatic dashboard plots after a run

## Install

```bash
pip install -r requirements.txt
```

## Run

```bash
python experiments/run_simulation.py
```

Outputs are written to `outputs/`:
- `edge_chaos_metrics.csv`
- `edge_chaos_dashboard.png`

## Stability defaults

This version is intentionally conservative:
- small controller adjustments
- bounded parameter ranges
- tuning interval of 100 steps
- weak solar flare probability
- damped memory and mutation
