
using UnityEngine;
using ArtificialUniverse.Entities;

namespace ArtificialUniverse.UI
{
    public class SelectionController : MonoBehaviour
    {
        public Camera mainCamera;
        public EntityAgent CurrentSelection { get; private set; }

        private void Update()
        {
            if (!Input.GetMouseButtonDown(0)) return;
            if (mainCamera == null) mainCamera = Camera.main;

            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                CurrentSelection = hit.collider.GetComponent<EntityAgent>();
            }
        }
    }
}
