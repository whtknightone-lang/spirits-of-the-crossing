
using UnityEngine;

namespace ArtificialUniverse.UI
{
    public class HUDController : MonoBehaviour
    {
        [TextArea] public string debugText;

        public void SetDebugText(string value)
        {
            debugText = value;
        }
    }
}
