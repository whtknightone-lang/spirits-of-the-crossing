
using UnityEngine;

namespace ArtificialUniverse.Core
{
    public class UIManager : MonoBehaviour
    {
        public void Initialize()
        {
            Debug.Log("UI Manager initialized.");
        }
    }
}
