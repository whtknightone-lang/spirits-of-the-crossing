
using System.Collections.Generic;
using UnityEngine;
using ArtificialUniverse.Entities;

namespace ArtificialUniverse.Core
{
    public class EntityManager : MonoBehaviour
    {
        [SerializeField] private GameObject entityPrefab;
        [SerializeField] private UniverseManager universeManager;

        private readonly List<EntityAgent> activeAgents = new();

        public void Initialize()
        {
            if (universeManager == null) universeManager = FindObjectOfType<UniverseManager>();
            SpawnInitialAgents();
        }

        private void SpawnInitialAgents()
        {
            if (entityPrefab == null || universeManager == null) return;

            for (int i = 0; i < universeManager.GetInitialEntityCount(); i++)
            {
                Vector3 pos = Random.insideUnitSphere * universeManager.GetWorldRadius();
                pos.y = 0f;
                var go = Instantiate(entityPrefab, pos, Quaternion.identity, transform);
                var agent = go.GetComponent<EntityAgent>();
                if (agent != null)
                {
                    agent.InitializeRandom();
                    activeAgents.Add(agent);
                }
            }
        }

        public IReadOnlyList<EntityAgent> ActiveAgents => activeAgents;
    }
}
