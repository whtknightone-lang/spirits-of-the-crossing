
using UnityEngine;
using ArtificialUniverse.Source;

namespace ArtificialUniverse.Core
{
    public class SourceManager : MonoBehaviour
    {
        [SerializeField] private SourceRiverSystem sourceRiverSystem;
        [SerializeField] private SourceIntentController sourceIntentController;

        public void Initialize()
        {
            if (sourceRiverSystem == null) sourceRiverSystem = FindObjectOfType<SourceRiverSystem>();
            if (sourceIntentController == null) sourceIntentController = FindObjectOfType<SourceIntentController>();
        }

        private void Update()
        {
            sourceRiverSystem?.Tick(Time.deltaTime);
            sourceIntentController?.Tick(Time.deltaTime);
        }
    }
}
