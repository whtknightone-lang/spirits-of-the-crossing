
using System.Collections.Generic;
using UnityEngine;
using ArtificialUniverse.Entities;
using ArtificialUniverse.Source;

namespace ArtificialUniverse.Core
{
    public class UniverseManager : MonoBehaviour
    {
        [Header("Universe Settings")]
        [SerializeField] private int initialEntityCount = 150;
        [SerializeField] private float worldRadius = 50f;

        public readonly List<EntityData> Entities = new();
        public readonly List<ClusterData> Clusters = new();

        public float GlobalVibration { get; private set; }
        public float GlobalHarmony { get; private set; }

        public void Initialize()
        {
            GlobalVibration = 0.5f;
            GlobalHarmony = 0.5f;
        }

        public void RegisterEntity(EntityData entity)
        {
            if (!Entities.Contains(entity))
            {
                Entities.Add(entity);
            }
        }

        public void UnregisterEntity(EntityData entity)
        {
            Entities.Remove(entity);
        }

        public void SetGlobalVibration(float value)
        {
            GlobalVibration = Mathf.Clamp01(value);
        }

        public void SetGlobalHarmony(float value)
        {
            GlobalHarmony = Mathf.Clamp01(value);
        }

        public int GetInitialEntityCount() => initialEntityCount;
        public float GetWorldRadius() => worldRadius;
    }
}
