
using UnityEngine;

namespace ArtificialUniverse.Core
{
    public class GameBootstrap : MonoBehaviour
    {
        [SerializeField] private UniverseManager universeManager;
        [SerializeField] private SourceManager sourceManager;
        [SerializeField] private EntityManager entityManager;
        [SerializeField] private UIManager uiManager;
        [SerializeField] private AudioManager audioManager;

        private void Awake()
        {
            if (universeManager == null) universeManager = FindObjectOfType<UniverseManager>();
            if (sourceManager == null) sourceManager = FindObjectOfType<SourceManager>();
            if (entityManager == null) entityManager = FindObjectOfType<EntityManager>();
            if (uiManager == null) uiManager = FindObjectOfType<UIManager>();
            if (audioManager == null) audioManager = FindObjectOfType<AudioManager>();
        }

        private void Start()
        {
            universeManager?.Initialize();
            sourceManager?.Initialize();
            entityManager?.Initialize();
            uiManager?.Initialize();
            audioManager?.Initialize();
        }
    }
}
