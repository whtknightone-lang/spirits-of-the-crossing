
using System.Collections.Generic;
using UnityEngine;
using ArtificialUniverse.Entities;

namespace ArtificialUniverse.Systems
{
    public class ClusterSystem : MonoBehaviour
    {
        [SerializeField] private float vibrationThreshold = 0.1f;
        [SerializeField] private int minimumClusterSize = 5;

        public List<ClusterData> BuildClusters(IReadOnlyList<EntityAgent> agents)
        {
            List<ClusterData> clusters = new();
            HashSet<string> visited = new();
            int clusterId = 0;

            foreach (var agent in agents)
            {
                if (visited.Contains(agent.Data.Id)) continue;

                List<EntityAgent> group = new() { agent };
                visited.Add(agent.Data.Id);

                foreach (var other in agents)
                {
                    if (visited.Contains(other.Data.Id)) continue;
                    if (Mathf.Abs(other.Data.Vibration - agent.Data.Vibration) < vibrationThreshold)
                    {
                        group.Add(other);
                        visited.Add(other.Data.Id);
                    }
                }

                if (group.Count < minimumClusterSize) continue;

                ClusterData cluster = new()
                {
                    Id = clusterId++,
                    Cohesion = Mathf.Clamp01(group.Count / 20f),
                    AverageVibration = 0f,
                    Center = Vector3.zero,
                    Age = 0f
                };

                foreach (var member in group)
                {
                    cluster.Members.Add(member.Data);
                    cluster.Center += member.transform.position;
                    cluster.AverageVibration += member.Data.Vibration;
                }

                cluster.Center /= group.Count;
                cluster.AverageVibration /= group.Count;
                clusters.Add(cluster);
            }

            return clusters;
        }
    }
}
