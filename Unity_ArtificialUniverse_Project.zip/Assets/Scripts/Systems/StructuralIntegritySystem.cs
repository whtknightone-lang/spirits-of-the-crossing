
using UnityEngine;
using ArtificialUniverse.Entities;

namespace ArtificialUniverse.Systems
{
    public class StructuralIntegritySystem : MonoBehaviour
    {
        public void Tick(EntityAgent agent, float deltaTime)
        {
            float stress = Mathf.Abs(agent.Data.Desire - agent.Data.Focus) * 0.1f;
            agent.Data.Integrity = Mathf.Clamp01(agent.Data.Integrity - stress * deltaTime);
        }
    }
}
