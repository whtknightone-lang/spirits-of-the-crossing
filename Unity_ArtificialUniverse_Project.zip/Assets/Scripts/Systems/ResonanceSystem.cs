
using System.Collections.Generic;
using UnityEngine;
using ArtificialUniverse.Entities;

namespace ArtificialUniverse.Systems
{
    public class ResonanceSystem : MonoBehaviour
    {
        [SerializeField] private float resonanceDistance = 5f;
        [SerializeField] private float influenceStrength = 0.1f;

        public void Tick(IReadOnlyList<EntityAgent> agents, float deltaTime)
        {
            for (int i = 0; i < agents.Count; i++)
            {
                for (int j = i + 1; j < agents.Count; j++)
                {
                    var a = agents[i];
                    var b = agents[j];
                    float distance = Vector3.Distance(a.transform.position, b.transform.position);
                    if (distance > resonanceDistance) continue;

                    float diff = a.Data.Vibration - b.Data.Vibration;
                    float delta = diff * influenceStrength * deltaTime;
                    b.ApplyVibration(delta);
                    a.ApplyVibration(-delta * 0.5f);
                }
            }
        }
    }
}
