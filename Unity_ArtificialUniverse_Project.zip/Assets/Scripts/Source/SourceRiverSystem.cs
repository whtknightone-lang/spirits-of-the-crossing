
using System.Collections.Generic;
using UnityEngine;

namespace ArtificialUniverse.Source
{
    public class SourceRiverSystem : MonoBehaviour
    {
        [SerializeField] private int nodeCount = 120;
        [SerializeField] private float worldRadius = 50f;
        [SerializeField] private List<Vector3> nodes = new();

        public IReadOnlyList<Vector3> Nodes => nodes;

        public void Tick(float deltaTime)
        {
            if (nodes.Count == 0)
            {
                for (int i = 0; i < nodeCount; i++)
                {
                    Vector3 pos = Random.insideUnitSphere * worldRadius;
                    pos.y = 0f;
                    nodes.Add(pos);
                }
            }

            for (int i = 0; i < nodes.Count; i++)
            {
                Vector3 drift = new(Random.Range(-0.5f, 0.5f), 0f, Random.Range(-0.5f, 0.5f));
                nodes[i] += drift * deltaTime;
            }
        }
    }
}
