
using UnityEngine;

namespace ArtificialUniverse.Source
{
    public class SourceIntentController : MonoBehaviour
    {
        public Vector3 IntentVector { get; private set; }

        public void Tick(float deltaTime)
        {
            IntentVector = Vector3.Lerp(IntentVector, Vector3.zero, deltaTime);
        }

        public void ApplyIntent(Vector3 delta)
        {
            IntentVector += delta;
        }
    }
}
