
using UnityEngine;
using ArtificialUniverse.Entities;

namespace ArtificialUniverse.AI
{
    public class AgentBrain : MonoBehaviour
    {
        [SerializeField] private EntityAgent agent;

        private void Awake()
        {
            if (agent == null) agent = GetComponent<EntityAgent>();
        }

        private void Update()
        {
            if (agent == null) return;

            float desireDrift = Random.Range(-0.2f, 0.2f) * Time.deltaTime;
            agent.Data.Desire = Mathf.Clamp01(agent.Data.Desire + desireDrift);
            agent.Data.Focus = Mathf.Clamp01(agent.Data.Focus + (agent.Data.SourceConnection - 0.5f) * Time.deltaTime * 0.5f);
        }
    }
}
