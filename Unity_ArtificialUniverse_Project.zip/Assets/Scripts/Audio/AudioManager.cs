
using UnityEngine;

namespace ArtificialUniverse.Core
{
    public class AudioManager : MonoBehaviour
    {
        [Range(0f, 1f)] public float harmonicLevel = 0.5f;

        public void Initialize()
        {
            Debug.Log("Audio Manager initialized.");
        }

        public void SetHarmonicLevel(float value)
        {
            harmonicLevel = Mathf.Clamp01(value);
        }
    }
}
