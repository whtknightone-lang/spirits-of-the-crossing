
using UnityEngine;

namespace ArtificialUniverse.Entities
{
    [System.Serializable]
    public class EntityData
    {
        public string Id;
        public Vector3 Position;
        public float Vibration;
        public float Desire;
        public float Focus;
        public float Integrity = 1f;
        public float SourceConnection;
        public int Generation;
        public string Species;
        public string Purpose;
        public string SoulId;
    }
}
