
using System.Collections.Generic;
using UnityEngine;

namespace ArtificialUniverse.Entities
{
    [System.Serializable]
    public class ClusterData
    {
        public int Id;
        public Vector3 Center;
        public float AverageVibration;
        public float Cohesion;
        public float Age;
        public List<EntityData> Members = new();
    }
}
