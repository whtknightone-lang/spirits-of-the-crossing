
using UnityEngine;

namespace ArtificialUniverse.Entities
{
    public class EntityAgent : MonoBehaviour
    {
        [SerializeField] private EntityData data = new();

        public EntityData Data => data;

        public void InitializeRandom()
        {
            data.Id = System.Guid.NewGuid().ToString();
            data.Position = transform.position;
            data.Vibration = Random.value;
            data.Desire = Random.value;
            data.Focus = 0f;
            data.Integrity = 1f;
            data.SourceConnection = 0f;
            data.Generation = 0;
            data.Species = "basic";
            data.Purpose = "explore";
            data.SoulId = System.Guid.NewGuid().ToString();
        }

        private void Update()
        {
            float driftX = Random.Range(-1f, 1f) * Time.deltaTime;
            float driftZ = Random.Range(-1f, 1f) * Time.deltaTime;
            transform.position += new Vector3(driftX, 0f, driftZ);
            data.Position = transform.position;
        }

        public void ApplyVibration(float delta)
        {
            data.Vibration = Mathf.Clamp01(data.Vibration + delta);
        }

        public void ApplySourceConnection(float delta)
        {
            data.SourceConnection = Mathf.Clamp01(data.SourceConnection + delta);
        }
    }
}
