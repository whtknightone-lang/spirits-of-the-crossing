
using UnityEngine;

namespace ArtificialUniverse.Data
{
    [CreateAssetMenu(menuName = "Artificial Universe/Universe Config")]
    public class UniverseConfig : ScriptableObject
    {
        public int InitialEntityCount = 150;
        public float WorldRadius = 50f;
        public float ResonanceDistance = 5f;
        public float SourceNodeCount = 120f;
    }
}
