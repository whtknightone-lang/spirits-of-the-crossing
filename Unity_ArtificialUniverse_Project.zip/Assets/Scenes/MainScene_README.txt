
Create a Unity scene named Main.
Recommended GameObjects:
- Bootstrap
  - GameBootstrap
  - UniverseManager
  - EntityManager
  - SourceManager
  - UIManager
  - AudioManager
- Systems
  - ResonanceSystem
  - ClusterSystem
  - StructuralIntegritySystem
- Source
  - SourceRiverSystem
  - SourceIntentController
- UI
  - SelectionController
  - HUDController
- EntityPrefab
  - EntityAgent
  - AgentBrain
  - Collider
  - MeshRenderer
