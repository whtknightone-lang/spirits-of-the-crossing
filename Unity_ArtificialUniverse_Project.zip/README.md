
# Unity Artificial Universe Project Structure

This is a starter Unity project structure for your evolving artificial universe system.

## Included architecture
- Core bootstrap
- Entity model
- Source river / currents
- Resonance and vibration systems
- Cluster / collective systems
- Harmonic communication hooks
- AI manager scaffold
- UI manager scaffold
- ScriptableObject configuration layer

## Recommended Unity version
- Unity 2022 LTS or newer

## Suggested next steps
1. Open the project folder in Unity Hub
2. Create a URP 3D project using this folder as the base, or copy the Assets folder into an existing Unity project
3. Open `Assets/Scenes/Main.unity` after creating a scene in Unity
4. Add the bootstrap components:
   - GameBootstrap
   - UniverseManager
   - SourceManager
   - EntityManager
   - UIManager

## Controls intended
- Number keys for source modulation
- Mouse selection for entities/clusters
- Camera orbit / zoom
- Meditation / source interaction actions

## Notes
This is a structural code scaffold, not a complete compiled Unity game.
