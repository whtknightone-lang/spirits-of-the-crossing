
# V70 Collective Intelligence

Adds:
- entities cluster into groups based on vibration similarity
- groups form collective centers
- group membership visualized

Concept:
Many minds → one field → collective behavior emerges
