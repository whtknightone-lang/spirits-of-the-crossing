
class CollectiveSystem:
    def __init__(self):
        self.groups=[]

    def update(self,eco):
        self.groups=[]
        threshold=0.7

        # reset
        for e in eco.entities:
            e["group_id"]=-1

        group_id=0
        for e in eco.entities:
            if e["group_id"]!=-1:
                continue

            group=[e]
            e["group_id"]=group_id

            for other in eco.entities:
                if other["group_id"]==-1 and abs(other["vibration"]-e["vibration"])<0.1:
                    group.append(other)
                    other["group_id"]=group_id

            if len(group)>3:
                cx=sum(g["pos"][0] for g in group)/len(group)
                cy=sum(g["pos"][1] for g in group)/len(group)

                self.groups.append({
                    "id":group_id,
                    "members":group,
                    "center":[cx,cy],
                    "avg_vibration":sum(g["vibration"] for g in group)/len(group)
                })
                group_id+=1
            else:
                for g in group:
                    g["group_id"]=-1
