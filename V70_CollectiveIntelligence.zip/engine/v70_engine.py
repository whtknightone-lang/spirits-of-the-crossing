
import pygame
from systems.ecosystem import Ecosystem
from systems.collective import CollectiveSystem
from systems.resonance import ResonanceSystem
from systems.player_control import PlayerControlSystem

class V70Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.collective=CollectiveSystem()
        self.resonance=ResonanceSystem()
        self.player=PlayerControlSystem(self.ecosystem)

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(80):
            self.ecosystem.spawn_entity()

    def handle_key(self,key):
        self.player.handle_key(key)

    def update(self,dt):
        self.resonance.update(self.ecosystem)
        self.collective.update(self.ecosystem)
        self.ecosystem.update(dt)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        # draw group centers
        for g in self.collective.groups:
            x=int(g["center"][1]*scale)+40
            y=int(g["center"][0]*scale)+40
            pygame.draw.circle(screen,(255,255,120),(x,y),10,1)

        # draw entities
        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            vib=e.get("vibration",0)
            gid=e.get("group_id",-1)

            color=(120,120+int(vib*120),255-int(vib*150))
            pygame.draw.circle(screen,color,(x,y),4)

            if gid>=0:
                pygame.draw.circle(screen,(255,255,255),(x,y),6,1)

        y=760
        lines=[
            "V70 Collective Intelligence",
            "Click select | 1 boost entity",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Groups: {len(self.collective.groups)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
