
import pygame
from systems.ecosystem import Ecosystem
from systems.morality import MoralitySystem
from systems.conscious_layer import ConsciousLayerSystem

class V55Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.morality=MoralitySystem()
        self.conscious=ConsciousLayerSystem(size)

        self.font=pygame.font.SysFont("arial",16)

    def handle_key(self,key):
        if key==pygame.K_1:
            self.conscious.enter_source()
        if key==pygame.K_2:
            self.conscious.spawn_into_body(self.ecosystem)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.morality.update(self.ecosystem)
        self.conscious.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        # animals
        for a in self.ecosystem.animals:
            x=int(a["pos"][1]*scale)+40
            y=int(a["pos"][0]*scale)+40
            m=a.get("morality",0.5)
            color=(int(255*(1-m)), int(255*m), 120)
            pygame.draw.circle(screen,color,(x,y),3)

        # consciousness (non-physical layer)
        for c in self.conscious.energy_nodes:
            x=int(c["pos"][1]*scale)+40
            y=int(c["pos"][0]*scale)+40
            pygame.draw.circle(screen,(255,255,180),(x,y),2)

        y=760
        lines=[
            "V55 Conscious Layer System",
            "1 = enter source state",
            "2 = spawn into body",
            f"Free energy nodes: {len(self.conscious.energy_nodes)}",
            f"Embodied beings: {len(self.ecosystem.animals)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
