
import random

class Ecosystem:
    def __init__(self,size):
        self.size=size
        self.animals=[{
            "pos":[random.random()*size,random.random()*size],
            "energy":1.0,
            "morality":random.random()
        } for _ in range(80)]

    def update(self,dt):
        for a in self.animals:
            a["pos"][0]+=random.uniform(-1,1)*dt*10
            a["pos"][1]+=random.uniform(-1,1)*dt*10
            a["energy"]-=0.01
