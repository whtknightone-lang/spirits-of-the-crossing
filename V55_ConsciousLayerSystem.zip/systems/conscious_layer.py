
import random

class ConsciousLayerSystem:
    def __init__(self,size):
        self.size=size
        self.mode="embodied"
        self.energy_nodes=[{
            "pos":[random.random()*size,random.random()*size],
            "energy":1.0
        } for _ in range(30)]

    def enter_source(self):
        self.mode="source"

    def spawn_into_body(self,eco):
        if self.energy_nodes:
            node=self.energy_nodes.pop()
            eco.animals.append({
                "pos":node["pos"][:],
                "energy":1.0,
                "morality":0.7
            })

    def update(self,eco):
        # regenerate free energy
        if len(self.energy_nodes)<50:
            self.energy_nodes.append({
                "pos":[random.random()*self.size,random.random()*self.size],
                "energy":1.0
            })
