
class MoralitySystem:
    def update(self,eco):
        for a in eco.animals:
            if a["energy"]<0.3:
                if a["morality"]>0.5:
                    for b in eco.animals:
                        b["energy"]+=0.02
                    a["energy"]=0
                else:
                    a["energy"]+=0.05
