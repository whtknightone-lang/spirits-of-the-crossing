
# V55 Conscious Layer System

Adds:
- non-physical source/player layer
- free energy nodes (unembodied existence)
- ability to spawn into physical forms

Core idea:
Existence is cyclical:
Source → Embodiment → Experience → Return → Recreate

Controls:
1 = enter source mode
2 = spawn into body
