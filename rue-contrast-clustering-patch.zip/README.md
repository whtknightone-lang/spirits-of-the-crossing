# RUE Contrast + Clustering Patch

This patch upgrades the connected RUE demo with a balanced reward model:

- positive resonance reward
- mismatch penalty
- baseline living cost
- like-minded agents attract and form clusters
- mismatched agents are softly repelled

## Behavior
Agents on the same planet compare their 21-node snowflake brain phases.
Agents with similar mean phase signatures attract.
Agents with dissimilar signatures repel.

This creates:
- clusters
- islands of like-minded agents
- migration pressure across a planet's local ring

## Run
```bash
pip install -r requirements.txt
python experiments/run_contrast_clustering_viewer.py
```
