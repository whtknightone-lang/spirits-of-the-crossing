import os
import sys
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from engine.simulation.universe import Universe
from engine.metrics.sync import sync
from engine.metrics.diversity import diversity
from engine.metrics.energy import mean_energy
from engine.visualization.snowflake_viewer import SnowflakeGraph

def main():
    universe = Universe(num_planets=5, agents_per_planet=16, regions_per_planet=8)
    graph = SnowflakeGraph(universe.agents[0].brain.matrix)

    plt.ion()
    fig = plt.figure(figsize=(12, 6))
    ax_system = fig.add_subplot(1, 2, 1)
    ax_brain = fig.add_subplot(1, 2, 2)

    rng = np.random.default_rng(1234)

    for step in range(3500):
        universe.step()

        if step % 100 == 0:
            phases = universe.all_phases()
            energies = universe.all_energies()
            print(
                f"step {step:4d} | "
                f"sync {sync(phases):.3f} | "
                f"div {diversity(phases):.3f} | "
                f"avg_energy {mean_energy(energies):.3f} | "
                f"reward {universe.mean_reward():.3f} | "
                f"penalty {universe.mean_penalty():.3f}"
            )

        ax_system.clear()
        ax_system.set_title("RUE Contrast + Clustering")
        ax_system.scatter([0], [0], s=520, marker="*", label="Star")

        for p in universe.planets:
            x, y = p.pos
            orbit = plt.Circle((0, 0), p.radius, fill=False, alpha=0.18)
            ax_system.add_patch(orbit)
            ax_system.scatter([x], [y], s=180)
            ax_system.text(x + 0.12, y + 0.12, f"P{p.index}")

            for rid in range(p.n_regions):
                rx, ry = p.region_world_pos(rid)
                ax_system.scatter([rx], [ry], s=35, alpha=0.45)

            planet_agents = [a for a in universe.agents if a.planet_id == p.index]
            for a in planet_agents:
                rx, ry = p.region_world_pos(a.region_id)
                jitter = 0.06
                ax_system.scatter(
                    [rx + rng.uniform(-jitter, jitter)],
                    [ry + rng.uniform(-jitter, jitter)],
                    s=18,
                    alpha=0.75
                )

        lim = max(p.radius for p in universe.planets) + 1.5
        ax_system.set_xlim(-lim, lim)
        ax_system.set_ylim(-lim, lim)
        ax_system.set_aspect("equal", adjustable="box")

        ax_brain.clear()
        agent = max(universe.agents, key=lambda a: a.energy)
        colors = agent.brain.phases / (2 * np.pi)
        nx.draw(
            graph.G,
            graph.pos,
            ax=ax_brain,
            node_color=colors,
            cmap=plt.cm.hsv,
            with_labels=True,
            node_size=430,
            edge_color="gray",
        )
        ax_brain.set_title(f"Highest-Energy Snowflake Brain | E={agent.energy:.2f}")

        plt.tight_layout()
        plt.pause(0.01)

    plt.ioff()
    plt.show()

if __name__ == "__main__":
    main()
