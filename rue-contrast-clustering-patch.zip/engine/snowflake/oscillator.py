import numpy as np

def update(phases, matrix, coupling_scale=0.05, drive=0.0):
    diff = phases[:, None] - phases[None, :]
    coupling = np.sin(diff) * matrix
    velocity = coupling.sum(axis=1)

    center_anchor = (phases[0] - phases) * 0.002
    velocity += center_anchor

    velocity *= coupling_scale
    velocity += drive
    velocity = np.clip(velocity, -0.18, 0.18)

    phases = phases + velocity
    return np.mod(phases, 2 * np.pi)
