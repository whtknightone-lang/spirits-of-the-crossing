import math
import numpy as np

class Planet:
    def __init__(self, index: int, radius: float, n_regions: int = 8):
        self.index = index
        self.radius = radius
        self.angle = index * 0.7
        self.energy = 0.0
        self.n_regions = n_regions
        self.region_offsets = np.linspace(0, 2 * np.pi, n_regions, endpoint=False)
        self.region_phases = np.random.rand(n_regions) * 2 * np.pi
        self.region_energies = np.ones(n_regions)

    def update_orbit(self):
        self.angle += 0.02 / self.radius

    def update_regions(self, star_energy: float):
        base = star_energy / max(1.0, (self.radius ** 1.6))
        self.energy = base
        for i in range(self.n_regions):
            self.region_energies[i] = max(0.2, base * (0.85 + 0.25 * np.sin(self.angle + self.region_offsets[i])))
            self.region_phases[i] = np.mod(self.region_phases[i] + 0.01 + 0.01 * np.sin(self.angle + self.region_offsets[i]), 2 * np.pi)

    @property
    def pos(self):
        return (
            self.radius * math.cos(self.angle),
            self.radius * math.sin(self.angle),
        )

    def region_world_pos(self, region_id: int):
        px, py = self.pos
        ang = self.region_offsets[region_id] + self.angle
        r = 0.45
        return px + r * math.cos(ang), py + r * math.sin(ang)
