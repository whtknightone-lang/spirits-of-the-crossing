
import matplotlib.pyplot as plt
from engine import World, GRID_SIZE

world = World()

plt.ion()
fig, ax = plt.subplots()

def on_key(event):
    if event.key == 'w': world.player_pos[1]+=0.03
    if event.key == 's': world.player_pos[1]-=0.03
    if event.key == 'a': world.player_pos[0]-=0.03
    if event.key == 'd': world.player_pos[0]+=0.03

    if event.key == '1': world.energy += 0.1
    if event.key == '2': world.energy -= 0.1
    if event.key == '3': world.energy *= 1.01

fig.canvas.mpl_connect('key_press_event', on_key)

for step in range(500):
    world.step()

    ax.clear()

    # draw territory
    ax.imshow(world.grid_owner.numpy(), origin='lower', extent=[0,1,0,1], alpha=0.3)

    # draw agents
    ax.scatter(world.position[:,0].numpy(), world.position[:,1].numpy(), s=2)

    # draw player
    ax.scatter(world.player_pos[0].item(), world.player_pos[1].item(), s=60)

    ax.set_title(f"Step {step} Score {round(world.score,1)}")
    ax.set_xlim(0,1)
    ax.set_ylim(0,1)

    plt.pause(0.01)

plt.ioff()
plt.show()
