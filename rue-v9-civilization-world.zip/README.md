
RUE V9 Civilization World

Features:
- Civilizations (factions with population + energy)
- Territory grid system
- Emergent cities
- Collapse mechanics
- Environment influence
- Player control (WASD + abilities)
- Real-time visualization

Run:
pip install torch matplotlib
python run_v9.py
