
import torch

GRID_SIZE = 30

class World:
    def __init__(self, n=3000):
        self.energy = torch.ones(n)
        self.phase = torch.rand(n)
        self.position = torch.rand(n,2)
        self.velocity = torch.zeros(n,2)
        self.lineage = torch.randint(0,5,(n,))
        self.player_pos = torch.tensor([0.5,0.5])
        self.score = 0

        # territory grid
        self.grid_owner = torch.zeros((GRID_SIZE, GRID_SIZE), dtype=torch.long)
        self.grid_strength = torch.zeros((GRID_SIZE, GRID_SIZE))

    def step(self):
        # movement
        self.velocity += 0.01 * torch.randn_like(self.velocity)
        self.position += self.velocity
        self.position = torch.clamp(self.position,0,1)

        # oscillator
        self.phase += 0.05
        self.energy += 0.01 * torch.sin(self.phase)

        # environment
        forest = torch.tensor([0.2,0.2])
        desert = torch.tensor([0.8,0.8])

        dist_f = torch.norm(self.position - forest, dim=1)
        dist_d = torch.norm(self.position - desert, dim=1)

        self.energy += torch.exp(-dist_f*5)*0.01
        self.energy -= torch.exp(-dist_d*5)*0.01

        # player influence
        dist_p = torch.norm(self.position - self.player_pos, dim=1)
        self.energy += torch.exp(-dist_p*10)*0.02

        # territory update
        gx = (self.position[:,0] * GRID_SIZE).long().clamp(0, GRID_SIZE-1)
        gy = (self.position[:,1] * GRID_SIZE).long().clamp(0, GRID_SIZE-1)

        for i in range(len(self.energy)):
            self.grid_owner[gx[i], gy[i]] = self.lineage[i]
            self.grid_strength[gx[i], gy[i]] += self.energy[i]

        # city detection
        self.cities = self.grid_strength > 5.0

        # collapse
        collapse_mask = self.grid_strength < 1.0
        self.grid_owner[collapse_mask] = 0

        # score
        self.score += self.energy.mean().item()
