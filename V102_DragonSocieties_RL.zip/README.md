
# V102 Dragon Societies + Reinforcement Learning

Adds:
- reward-based learning loop (joy/harmony survival signal)
- multi-agent dragon societies
- alliance / rivalry emergence
- policy placeholder for RL (PyTorch/Barracuda ready)

Core Concept:
Dragons learn from experience and form societies dynamically.
