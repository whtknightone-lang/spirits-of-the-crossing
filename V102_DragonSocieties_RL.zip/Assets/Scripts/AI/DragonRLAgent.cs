
using UnityEngine;

namespace ArtificialUniverse.AI
{
    public class DragonRLAgent : MonoBehaviour
    {
        public float reward;
        public float lastReward;

        private ArtificialUniverse.Dragons.DragonAvatar avatar;

        void Awake()
        {
            avatar = GetComponent<ArtificialUniverse.Dragons.DragonAvatar>();
        }

        void Update()
        {
            ComputeReward();
            Learn();
        }

        void ComputeReward()
        {
            if (avatar == null) return;

            // reward = joy/harmony - dark pressure
            reward = avatar.harmony * 0.6f + avatar.sourceConnection * 0.4f - avatar.darkPressure * 0.7f;
        }

        void Learn()
        {
            float delta = reward - lastReward;

            // simple policy adjustment placeholder
            avatar.energy = Mathf.Clamp01(avatar.energy + delta * 0.05f);
            avatar.harmony = Mathf.Clamp01(avatar.harmony + delta * 0.03f);

            lastReward = reward;
        }
    }
