
using UnityEngine;

namespace ArtificialUniverse.AI
{
    public class PolicyNetworkStub : MonoBehaviour
    {
        public bool useNeural = false;

        public float Evaluate(float[] state)
        {
            // placeholder for neural policy
            float sum = 0f;
            foreach (var s in state) sum += s;
            return sum / state.Length;
        }
    }
