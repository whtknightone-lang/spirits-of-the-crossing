
using UnityEngine;
using ArtificialUniverse.Dragons;
using ArtificialUniverse.AI;
using ArtificialUniverse.Society;

namespace ArtificialUniverse.Core
{
    public class V102GameManager : MonoBehaviour
    {
        void Start()
        {
            var dragons = FindObjectsOfType<DragonAvatar>();

            foreach (var d in dragons)
            {
                if (d.GetComponent<DragonRLAgent>() == null)
                    d.gameObject.AddComponent<DragonRLAgent>();
            }

            if (FindObjectOfType<DragonSocietySystem>() == null)
            {
                gameObject.AddComponent<DragonSocietySystem>();
            }
        }
    }
