
using System.Collections.Generic;
using UnityEngine;
using ArtificialUniverse.Dragons;

namespace ArtificialUniverse.Society
{
    public class DragonSocietySystem : MonoBehaviour
    {
        public float allianceThreshold = 0.7f;
        public float rivalryThreshold = 0.3f;

        private List<DragonAvatar> dragons = new();

        void Awake()
        {
            dragons.AddRange(FindObjectsOfType<DragonAvatar>());
        }

        void Update()
        {
            for (int i = 0; i < dragons.Count; i++)
            {
                for (int j = i + 1; j < dragons.Count; j++)
                {
                    var a = dragons[i];
                    var b = dragons[j];

                    float affinity = 1f - Mathf.Abs(a.harmony - b.harmony);

                    if (affinity > allianceThreshold)
                    {
                        FormAlliance(a, b);
                    }
                    else if (affinity < rivalryThreshold)
                    {
                        FormRivalry(a, b);
                    }
                }
            }
        }

        void FormAlliance(DragonAvatar a, DragonAvatar b)
        {
            a.sourceConnection += 0.01f * Time.deltaTime;
            b.sourceConnection += 0.01f * Time.deltaTime;
        }

        void FormRivalry(DragonAvatar a, DragonAvatar b)
        {
            a.darkPressure += 0.01f * Time.deltaTime;
            b.darkPressure += 0.01f * Time.deltaTime;
        }
    }
