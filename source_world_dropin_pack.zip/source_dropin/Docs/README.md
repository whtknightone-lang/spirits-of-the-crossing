# Source Drop-In Pack: Worthiness, Importance, Contrast, and World Play

This pack adds a new layer to your Unity resonance architecture:

- Source stays clear, truthful, and joy-rooted.
- Source reads the player's vibration and builds a bridge from resistance to desire.
- The world's nature also responds.
- The world demonstrates worthiness and importance to Source through environmental play, signs, celebration, and contrast.
- Contrast is not punishment. It is a teaching signal that helps individuals learn.
- The same logic can scale into planets, cosmos growth, and rebirth loops.

## Included scripts

- `PlayerResonanceProfile.cs`
- `SourceEssenceProfile.cs`
- `GuidanceBridge.cs`
- `SourceEthicsValidator.cs`
- `SourceGuidanceEngine.cs`
- `AdaptiveInvitationSequencer.cs`
- `WorldResponseProfile.cs`
- `WorldNatureResponseEngine.cs`
- `WorthinessDemonstrationDirector.cs`
- `CreationWireDropInDirector.cs`
- `PlanetWorthinessField.cs`

## Core idea

The player is not the only active learner.

- Source adapts the invitation.
- The world adapts the demonstration.
- The planet stores the residue of joy, growth, and contrast.

That lets every realm show the player:

- that they matter
- that they are seen
- that challenge can be meaningful
- that contrast can teach without corrupting Source

## Suggested scene hookup

1. Add `PlayerResonanceProfile` to the XR rig root.
2. Create a `SourceEssenceProfile` asset with purity/joy/truth all at 1.0.
3. Add `SourceGuidanceEngine` to a `SourceCore` object and assign the essence asset.
4. Create a `WorldResponseProfile` asset for the current realm.
5. Add `WorldNatureResponseEngine` to a `WorldNature` object and assign the profile.
6. Add `AdaptiveInvitationSequencer` and wire player + source + world.
7. Add `WorthinessDemonstrationDirector` and hook optional VFX/Animator/Audio.
8. Add `CreationWireDropInDirector` and press the context menu action to test the loop.
9. Optionally connect `PlanetWorthinessField` so each encounter contributes to long-term planet growth.

## Design extension

Per realm, change the `WorldResponseProfile` values:

- Forest: high playfulness, low contrast, high worthiness amplification
- Ocean: medium playfulness, medium contrast, high responsiveness
- Fire: medium playfulness, high contrast, high demonstration bias
- Machine: low playfulness, low worthiness amplification, high importance signal via precision
- Dark realm: low playfulness, very high contrast, but still governed by Source ethics at the Source layer
