using UnityEngine;
using Resonance.SourceSystem;
using Resonance.WorldSystem;
using Resonance.PlayerSystem;

namespace Resonance.Systems
{
    public class CreationWireDropInDirector : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile player;
        [SerializeField] private AdaptiveInvitationSequencer sequencer;
        [SerializeField] private WorthinessDemonstrationDirector worldDirector;

        [ContextMenu("Run Creation Wire Tick")]
        public void RunTick()
        {
            InvitationSequence sequence = sequencer.BuildSequence();
            if (sequence.invitationSteps == null || sequence.invitationSteps.Count == 0)
            {
                Debug.LogWarning("No valid Source invitation sequence was produced.");
                return;
            }

            foreach (string step in sequence.invitationSteps)
                Debug.Log(step);

            worldDirector.Apply(sequence.worldSnapshot, sequence.bridge);
        }
    }
}
