namespace Resonance.SourceSystem
{
    public static class SourceEthicsValidator
    {
        public static bool Validate(GuidanceBridge bridge)
        {
            if (bridge == null) return false;
            if (string.IsNullOrWhiteSpace(bridge.playerWantsId)) return false;
            if (string.IsNullOrWhiteSpace(bridge.playerAvoidsId)) return false;
            if (string.IsNullOrWhiteSpace(bridge.bridgeMessage)) return false;
            return true;
        }
    }
}
