using UnityEngine;

namespace Resonance.SourceSystem
{
    [CreateAssetMenu(menuName = "Resonance/Source/Essence Profile")]
    public class SourceEssenceProfile : ScriptableObject
    {
        [Range(0f, 1f)] public float purity = 1f;
        [Range(0f, 1f)] public float joy = 1f;
        [Range(0f, 1f)] public float compassion = 1f;
        [Range(0f, 1f)] public float truthfulness = 1f;
        [Range(0f, 1f)] public float patience = 1f;

        public bool IsPure()
        {
            return purity >= 0.99f && joy >= 0.99f && compassion >= 0.99f && truthfulness >= 0.99f;
        }
    }
}
