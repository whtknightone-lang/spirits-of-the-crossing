using System;

namespace Resonance.SourceSystem
{
    [Serializable]
    public class GuidanceBridge
    {
        public string playerAvoidsId;
        public string playerWantsId;
        public string bridgeSymbol;
        public string bridgeMessage;
        public float bridgeIntensity;
        public float likelyAcceptance;
        public float worthinessSignal;
        public float contrastLearningValue;
    }
}
