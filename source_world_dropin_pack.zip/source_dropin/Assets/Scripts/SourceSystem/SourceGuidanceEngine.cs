using UnityEngine;
using Resonance.PlayerSystem;

namespace Resonance.SourceSystem
{
    public class SourceGuidanceEngine : MonoBehaviour
    {
        [SerializeField] private SourceEssenceProfile essence;

        [Header("Adaptive Guidance")]
        [Range(0f, 1f)] public float symbolicBias = 0.7f;
        [Range(0f, 1f)] public float directness = 0.4f;
        [Range(0f, 1f)] public float gentleness = 0.9f;

        public GuidanceBridge BuildBridge(PlayerResonanceProfile player)
        {
            var desired = player.GetStrongestDesiredOutcome();
            var resisted = player.GetAvoidedButImportantThreshold();
            if (desired == null || resisted == null) return null;

            var bridge = new GuidanceBridge
            {
                playerAvoidsId = resisted.id,
                playerWantsId = desired.id,
                bridgeSymbol = SelectBridgeSymbol(player, resisted, desired),
                bridgeMessage = ComposeBridgeMessage(player, resisted, desired),
                bridgeIntensity = ComputeBridgeIntensity(player, resisted, desired),
                likelyAcceptance = ComputeAcceptance(player, resisted, desired),
                worthinessSignal = ComputeWorthinessSignal(player, desired),
                contrastLearningValue = ComputeContrastLearningValue(player, resisted)
            };

            return bridge;
        }

        private string SelectBridgeSymbol(PlayerResonanceProfile player, DesireSignal resisted, DesireSignal desired)
        {
            if (player.fear > 0.7f) return "GentleLightPath";
            if (player.coherence < 0.4f) return "GuidingPulse";
            if (desired.label.ToLower().Contains("growth")) return "RisingTree";
            if (desired.label.ToLower().Contains("power")) return "LivingFlame";
            return "GoldenThread";
        }

        private string ComposeBridgeMessage(PlayerResonanceProfile player, DesireSignal resisted, DesireSignal desired)
        {
            if (!essence.IsPure()) return "Signal integrity compromised.";
            if (player.trust < 0.35f)
            {
                return $"You do not need to embrace {resisted.label} all at once. Take one step, and it will lead you toward {desired.label}.";
            }

            return $"What feels difficult is not against you. Pass through {resisted.label}, and you move closer to {desired.label}.";
        }

        private float ComputeBridgeIntensity(PlayerResonanceProfile player, DesireSignal resisted, DesireSignal desired)
        {
            float intensity =
                desired.strength * 0.4f +
                resisted.fearResistance * 0.25f +
                (1f - player.trust) * 0.15f +
                (1f - player.coherence) * 0.2f;
            return Mathf.Clamp01(intensity);
        }

        private float ComputeAcceptance(PlayerResonanceProfile player, DesireSignal resisted, DesireSignal desired)
        {
            float acceptance =
                player.trust * 0.35f +
                player.openness * 0.30f +
                desired.readiness * 0.20f +
                (1f - resisted.fearResistance) * 0.15f;
            return Mathf.Clamp01(acceptance);
        }

        private float ComputeWorthinessSignal(PlayerResonanceProfile player, DesireSignal desired)
        {
            return Mathf.Clamp01(player.joy * 0.25f + player.trust * 0.35f + player.embodiment * 0.20f + desired.strength * 0.20f);
        }

        private float ComputeContrastLearningValue(PlayerResonanceProfile player, DesireSignal resisted)
        {
            return Mathf.Clamp01(resisted.fearResistance * 0.45f + (1f - player.coherence) * 0.20f + (1f - player.openness) * 0.20f + (1f - player.contrastTolerance) * 0.15f);
        }
    }
}
