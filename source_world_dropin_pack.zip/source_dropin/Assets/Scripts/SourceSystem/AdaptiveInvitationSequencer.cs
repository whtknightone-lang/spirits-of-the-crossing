using System.Collections.Generic;
using UnityEngine;
using Resonance.PlayerSystem;
using Resonance.WorldSystem;

namespace Resonance.SourceSystem
{
    public class AdaptiveInvitationSequencer : MonoBehaviour
    {
        [SerializeField] private SourceGuidanceEngine sourceGuidance;
        [SerializeField] private WorldNatureResponseEngine worldResponse;
        [SerializeField] private PlayerResonanceProfile player;

        [Header("Sequence Output")]
        public List<string> currentInvitations = new List<string>();

        public InvitationSequence BuildSequence()
        {
            currentInvitations.Clear();
            GuidanceBridge bridge = sourceGuidance.BuildBridge(player);
            if (!SourceEthicsValidator.Validate(bridge))
                return default;

            WorldResponseSnapshot world = worldResponse.Evaluate(player, bridge);

            currentInvitations.Add($"Bridge: {bridge.bridgeSymbol}");
            currentInvitations.Add($"Message: {bridge.bridgeMessage}");
            currentInvitations.Add($"World Mode: {world.environmentMode}");
            currentInvitations.Add($"Worthiness Demo: {world.worthinessDemonstration:0.00}");
            currentInvitations.Add($"Contrast: {world.contrastIntensity:0.00}");

            return new InvitationSequence
            {
                bridge = bridge,
                worldSnapshot = world,
                invitationSteps = new List<string>(currentInvitations)
            };
        }
    }

    public struct InvitationSequence
    {
        public GuidanceBridge bridge;
        public WorldResponseSnapshot worldSnapshot;
        public List<string> invitationSteps;
    }
}
