using System;
using System.Collections.Generic;
using UnityEngine;

namespace Resonance.PlayerSystem
{
    [Serializable]
    public class DesireSignal
    {
        public string id;
        public string label;
        [Range(0f, 1f)] public float strength = 0.5f;
        [Range(0f, 1f)] public float fearResistance = 0.5f;
        [Range(0f, 1f)] public float readiness = 0.5f;
    }

    [Serializable]
    public class ResonanceTrait
    {
        public string id;
        public string label;
        [Range(0f, 1f)] public float value = 0.5f;
    }

    public class PlayerResonanceProfile : MonoBehaviour
    {
        [Header("Core State")]
        [Range(0f, 1f)] public float coherence = 0.5f;
        [Range(0f, 1f)] public float trust = 0.5f;
        [Range(0f, 1f)] public float joy = 0.5f;
        [Range(0f, 1f)] public float fear = 0.5f;
        [Range(0f, 1f)] public float openness = 0.5f;
        [Range(0f, 1f)] public float embodiment = 0.5f;
        [Range(0f, 1f)] public float contrastTolerance = 0.5f;

        [Header("Dynamic Desire Map")]
        public List<DesireSignal> desires = new List<DesireSignal>();

        [Header("Traits")]
        public List<ResonanceTrait> traits = new List<ResonanceTrait>();

        public DesireSignal GetStrongestDesiredOutcome()
        {
            DesireSignal best = null;
            float bestScore = float.MinValue;

            foreach (var desire in desires)
            {
                float score = desire.strength * 0.55f + desire.readiness * 0.30f - desire.fearResistance * 0.15f;
                if (score > bestScore)
                {
                    bestScore = score;
                    best = desire;
                }
            }

            return best;
        }

        public DesireSignal GetAvoidedButImportantThreshold()
        {
            DesireSignal best = null;
            float bestScore = float.MinValue;

            foreach (var desire in desires)
            {
                float score = desire.fearResistance * 0.60f + desire.strength * 0.25f + (1f - desire.readiness) * 0.15f;
                if (score > bestScore)
                {
                    bestScore = score;
                    best = desire;
                }
            }

            return best;
        }

        public float GetTraitValue(string id, float fallback = 0.5f)
        {
            foreach (var trait in traits)
            {
                if (string.Equals(trait.id, id, StringComparison.OrdinalIgnoreCase))
                    return trait.value;
            }

            return fallback;
        }
    }
}
