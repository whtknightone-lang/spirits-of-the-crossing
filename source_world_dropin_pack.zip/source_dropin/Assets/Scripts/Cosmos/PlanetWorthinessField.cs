using UnityEngine;
using Resonance.WorldSystem;

namespace Resonance.Cosmos
{
    public class PlanetWorthinessField : MonoBehaviour
    {
        [Range(0f, 1f)] public float planetaryJoy = 0.5f;
        [Range(0f, 1f)] public float planetaryGrowth = 0.5f;
        [Range(0f, 1f)] public float planetaryContrast = 0.5f;

        public void AbsorbWorldResponse(WorldResponseSnapshot snapshot)
        {
            planetaryJoy = Mathf.Clamp01((planetaryJoy * 0.7f) + snapshot.worthinessDemonstration * 0.3f);
            planetaryGrowth = Mathf.Clamp01((planetaryGrowth * 0.65f) + snapshot.playfulness * 0.35f);
            planetaryContrast = Mathf.Clamp01((planetaryContrast * 0.7f) + snapshot.contrastIntensity * 0.3f);
        }
    }
}
