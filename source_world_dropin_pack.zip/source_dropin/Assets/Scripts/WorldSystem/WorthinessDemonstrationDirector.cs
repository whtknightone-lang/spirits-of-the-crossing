using UnityEngine;
using Resonance.SourceSystem;

namespace Resonance.WorldSystem
{
    public class WorthinessDemonstrationDirector : MonoBehaviour
    {
        [Header("Optional Scene Hooks")]
        [SerializeField] private Animator worldAnimator;
        [SerializeField] private ParticleSystem celebrationParticles;
        [SerializeField] private AudioSource importanceTone;

        public void Apply(WorldResponseSnapshot snapshot, GuidanceBridge bridge)
        {
            Debug.Log($"World demonstration mode: {snapshot.environmentMode}. Importance={snapshot.importanceSignal:0.00}, Worthiness={snapshot.worthinessDemonstration:0.00}, Contrast={snapshot.contrastIntensity:0.00}");

            if (worldAnimator != null)
            {
                worldAnimator.SetFloat("Playfulness", snapshot.playfulness);
                worldAnimator.SetFloat("Worthiness", snapshot.worthinessDemonstration);
                worldAnimator.SetFloat("Contrast", snapshot.contrastIntensity);
            }

            if (celebrationParticles != null)
            {
                var emission = celebrationParticles.emission;
                emission.rateOverTime = 5f + snapshot.worthinessDemonstration * 30f;
                if (!celebrationParticles.isPlaying)
                    celebrationParticles.Play();
            }

            if (importanceTone != null)
            {
                importanceTone.pitch = Mathf.Lerp(0.9f, 1.2f, snapshot.importanceSignal);
                if (!importanceTone.isPlaying)
                    importanceTone.Play();
            }
        }
    }
}
