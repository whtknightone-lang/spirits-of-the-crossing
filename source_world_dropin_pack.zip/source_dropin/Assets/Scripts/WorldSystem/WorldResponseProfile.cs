using UnityEngine;

namespace Resonance.WorldSystem
{
    [CreateAssetMenu(menuName = "Resonance/World/Response Profile")]
    public class WorldResponseProfile : ScriptableObject
    {
        public string worldId = "world_default";
        public string worldLabel = "Living World";
        [Range(0f, 1f)] public float playfulness = 0.7f;
        [Range(0f, 1f)] public float responsiveness = 0.8f;
        [Range(0f, 1f)] public float contrastStrength = 0.5f;
        [Range(0f, 1f)] public float worthinessAmplification = 0.8f;
        [Range(0f, 1f)] public float demonstrationBias = 0.7f;
        [Range(0f, 1f)] public float shadowContrastBias = 0.45f;
    }
}
