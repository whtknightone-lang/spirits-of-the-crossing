using UnityEngine;
using Resonance.PlayerSystem;
using Resonance.SourceSystem;

namespace Resonance.WorldSystem
{
    public class WorldNatureResponseEngine : MonoBehaviour
    {
        [SerializeField] private WorldResponseProfile profile;

        [Header("Live State")]
        [Range(0f, 1f)] public float currentPlay = 0.5f;
        [Range(0f, 1f)] public float currentWorthinessDemo = 0.5f;
        [Range(0f, 1f)] public float currentContrast = 0.5f;
        [Range(0f, 1f)] public float currentImportanceSignal = 0.5f;

        public WorldResponseSnapshot Evaluate(PlayerResonanceProfile player, GuidanceBridge bridge)
        {
            var snapshot = new WorldResponseSnapshot();

            float coherenceGate = Mathf.Lerp(0.25f, 1f, player.coherence);
            float trustGate = Mathf.Lerp(0.25f, 1f, player.trust);
            float contrastNeed = Mathf.Clamp01((1f - player.contrastTolerance) * 0.7f + player.fear * 0.3f);

            snapshot.playfulness = profile.playfulness * profile.responsiveness * coherenceGate;
            snapshot.worthinessDemonstration = Mathf.Clamp01(profile.worthinessAmplification * trustGate + player.joy * 0.25f);
            snapshot.importanceSignal = Mathf.Clamp01(profile.demonstrationBias * player.openness + player.embodiment * 0.25f);
            snapshot.contrastIntensity = Mathf.Clamp01(profile.contrastStrength * contrastNeed + profile.shadowContrastBias * bridge.contrastLearningValue);
            snapshot.environmentMode = SelectEnvironmentMode(snapshot);

            currentPlay = snapshot.playfulness;
            currentWorthinessDemo = snapshot.worthinessDemonstration;
            currentContrast = snapshot.contrastIntensity;
            currentImportanceSignal = snapshot.importanceSignal;

            return snapshot;
        }

        private string SelectEnvironmentMode(WorldResponseSnapshot snapshot)
        {
            if (snapshot.contrastIntensity > 0.75f)
                return "ContrastDemonstration";
            if (snapshot.worthinessDemonstration > 0.75f)
                return "CelebrationReveal";
            if (snapshot.playfulness > 0.70f)
                return "LivingPlay";
            return "GentleGuidance";
        }
    }

    public struct WorldResponseSnapshot
    {
        public float playfulness;
        public float worthinessDemonstration;
        public float importanceSignal;
        public float contrastIntensity;
        public string environmentMode;
    }
}
