
using UnityEngine;

public class AIFeedbackDialogue : MonoBehaviour
{
    public string GetLine(float delta)
    {
        if (delta < 0f)
            return "You changed this. The path is clearer now.";

        if (delta > 0f)
            return "Something is drifting. Listen again and retune.";

        return "...";
    }
}
