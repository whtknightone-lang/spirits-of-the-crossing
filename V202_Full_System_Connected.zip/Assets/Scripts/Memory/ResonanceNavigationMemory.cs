
using UnityEngine;
using System.Collections.Generic;

public class ResonanceNavigationMemory : MonoBehaviour
{
    public List<string> successfulActions = new List<string>();
    public List<string> failedActions = new List<string>();

    public void Record(string action, bool success)
    {
        if (success) successfulActions.Add(action);
        else failedActions.Add(action);

        if (successfulActions.Count > 50) successfulActions.RemoveAt(0);
        if (failedActions.Count > 50) failedActions.RemoveAt(0);
    }
}
