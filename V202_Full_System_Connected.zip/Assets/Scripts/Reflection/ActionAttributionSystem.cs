
using UnityEngine;

public class ActionAttributionSystem : MonoBehaviour
{
    public string actorId;
    public string actorType;
    public string actionType;
    public float lastImpact;

    public void Record(string actor, string type, string action, float impact)
    {
        actorId = actor;
        actorType = type;
        actionType = action;
        lastImpact = impact;
    }
}
