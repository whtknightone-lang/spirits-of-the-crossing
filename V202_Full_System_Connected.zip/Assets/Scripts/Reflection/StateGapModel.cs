
using UnityEngine;

[System.Serializable]
public class StateGapModel
{
    public float currentValue = 0.5f;
    public float wantedValue = 0.8f;

    public float GetGap()
    {
        return wantedValue - currentValue;
    }
}
