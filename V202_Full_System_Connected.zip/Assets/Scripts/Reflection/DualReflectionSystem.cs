
using UnityEngine;

public class DualReflectionSystem : MonoBehaviour
{
    public StateGapModel gapModel = new StateGapModel();

    public float previousGap;
    public float currentGap;
    public float delta;

    [Range(0f, 1f)] public float clarity = 0.5f;
    [Range(0f, 1f)] public float resonance = 0.5f;

    public bool lastWasAlignment;
    public bool lastWasDrift;

    public void Evaluate()
    {
        currentGap = gapModel.GetGap();
        delta = currentGap - previousGap;

        lastWasAlignment = false;
        lastWasDrift = false;

        if (delta < 0f)
        {
            PositiveReflection();
        }
        else if (delta > 0f)
        {
            ContrastReflection();
        }

        previousGap = currentGap;
    }

    void PositiveReflection()
    {
        clarity = Mathf.Clamp01(clarity + 0.08f);
        resonance = Mathf.Clamp01(resonance + 0.08f);
        lastWasAlignment = true;
        Debug.Log("Alignment: moved closer to wanted state.");
    }

    void ContrastReflection()
    {
        clarity = Mathf.Clamp01(clarity - 0.08f);
        resonance = Mathf.Clamp01(resonance - 0.08f);
        lastWasDrift = true;
        Debug.Log("Drift: moved away from wanted state.");
    }
}
