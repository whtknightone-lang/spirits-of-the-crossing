
using UnityEngine;

public class V202IntegrationManager : MonoBehaviour
{
    public DualReflectionSystem reflection;
    public ActionAttributionSystem attribution;
    public WorldFeedbackSystem worldFeedback;
    public AIFeedbackDialogue dialogue;
    public ResonanceNavigationMemory memory;

    [Header("Optional links to earlier systems")]
    public MonoBehaviour feelManager;              // V190
    public MonoBehaviour contextualDialogue;       // V194
    public MonoBehaviour experienceGenerator;      // V196
    public MonoBehaviour spiritBond;               // V199

    public string demoActorId = "player_1";
    public string demoActorType = "player";
    public string demoAction = "align_node";

    void Awake()
    {
        if (reflection == null) reflection = FindObjectOfType<DualReflectionSystem>();
        if (attribution == null) attribution = FindObjectOfType<ActionAttributionSystem>();
        if (worldFeedback == null) worldFeedback = FindObjectOfType<WorldFeedbackSystem>();
        if (memory == null) memory = FindObjectOfType<ResonanceNavigationMemory>();

        if (dialogue == null)
        {
            var host = new GameObject("AIFeedbackDialogue");
            dialogue = host.AddComponent<AIFeedbackDialogue>();
        }

        if (reflection == null) reflection = gameObject.AddComponent<DualReflectionSystem>();
        if (attribution == null) attribution = gameObject.AddComponent<ActionAttributionSystem>();
        if (memory == null) memory = gameObject.AddComponent<ResonanceNavigationMemory>();
        if (worldFeedback == null) worldFeedback = gameObject.AddComponent<WorldFeedbackSystem>();

        worldFeedback.reflection = reflection;
    }

    void Update()
    {
        // Demo input to prove full loop
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            ApplyAction(-0.15f, "align_node");
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            ApplyAction(+0.15f, "force_wrong_action");
        }
    }

    public void ApplyAction(float gapShift, string actionName)
    {
        float oldGap = reflection.gapModel.GetGap();
        reflection.gapModel.currentValue -= gapShift;
        attribution.Record(demoActorId, demoActorType, actionName, gapShift);
        reflection.previousGap = oldGap;
        reflection.Evaluate();

        bool success = reflection.delta < 0f;
        memory.Record(actionName, success);

        if (dialogue != null)
        {
            Debug.Log(dialogue.GetLine(reflection.delta));
        }
    }
}
