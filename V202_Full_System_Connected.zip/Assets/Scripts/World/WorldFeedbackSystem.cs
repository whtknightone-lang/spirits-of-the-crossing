
using UnityEngine;

public class WorldFeedbackSystem : MonoBehaviour
{
    public DualReflectionSystem reflection;
    public Light worldLight;
    public AudioSource ambientSource;

    void Update()
    {
        if (reflection == null) return;

        RenderSettings.ambientIntensity = Mathf.Lerp(0.5f, 2f, reflection.resonance);

        if (worldLight != null)
        {
            worldLight.intensity = Mathf.Lerp(0.4f, 2.2f, reflection.resonance);
            worldLight.color = Color.Lerp(Color.red, Color.cyan, reflection.clarity);
        }

        if (ambientSource != null)
        {
            ambientSource.pitch = Mathf.Lerp(0.85f, 1.35f, reflection.resonance);
            ambientSource.volume = Mathf.Lerp(0.2f, 1.0f, reflection.clarity);
        }
    }
}
