
using UnityEngine;
public enum MythPattern {Transformation, Trickster, Guide, Balance, Cycle, Initiation}
public class MythEngine : MonoBehaviour
{
    public MythPattern pattern;
    public string GetBehavior() { return pattern.ToString(); }
}
