
using UnityEngine;
public class RelationshipEngine : MonoBehaviour
{
    public float world=0.5f;
}
