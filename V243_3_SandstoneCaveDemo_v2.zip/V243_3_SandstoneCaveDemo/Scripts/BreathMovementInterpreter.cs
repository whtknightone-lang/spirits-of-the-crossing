using UnityEngine;

namespace V243.SandstoneCave
{
    public class BreathMovementInterpreter : MonoBehaviour
    {
        public CavePlayerResonanceState state = new CavePlayerResonanceState();

        [Header("Debug Input")]
        public bool useDebugKeyboardInput = true;
        public float debugSmoothSpeed = 2f;

        private void Update()
        {
            if (!useDebugKeyboardInput)
            {
                return;
            }

            CavePlayerResonanceState target = new CavePlayerResonanceState
            {
                breathCoherence = Input.GetKey(KeyCode.Alpha1) ? 0.9f : 0.3f,
                movementFlow = Input.GetKey(KeyCode.Alpha2) ? 0.85f : 0.2f,
                spinStability = Input.GetKey(KeyCode.Alpha3) ? 0.85f : 0.1f,
                socialSync = Input.GetKey(KeyCode.Alpha4) ? 0.8f : 0.15f,
                calm = Input.GetKey(KeyCode.Q) ? 0.9f : 0.35f,
                joy = Input.GetKey(KeyCode.W) ? 0.85f : 0.25f,
                wonder = Input.GetKey(KeyCode.E) ? 0.85f : 0.3f,
                distortion = Input.GetKey(KeyCode.R) ? 0.7f : 0.15f,
                sourceAlignment = Input.GetKey(KeyCode.T) ? 0.9f : 0.25f
            };

            state.LerpToward(target, Time.deltaTime * debugSmoothSpeed);
        }

        public void UpdateBreath(float inhaleExhaleRegularity) => state.breathCoherence = Mathf.Clamp01(inhaleExhaleRegularity);
        public void UpdateFlowMovement(float smoothArcScore) => state.movementFlow = Mathf.Clamp01(smoothArcScore);
        public void UpdateSpin(float rotationStability) => state.spinStability = Mathf.Clamp01(rotationStability);
        public void UpdateSocialSync(float pairedRhythmScore) => state.socialSync = Mathf.Clamp01(pairedRhythmScore);
        public void UpdateCalm(float score) => state.calm = Mathf.Clamp01(score);
        public void UpdateJoy(float score) => state.joy = Mathf.Clamp01(score);
        public void UpdateWonder(float score) => state.wonder = Mathf.Clamp01(score);
        public void UpdateDistortion(float score) => state.distortion = Mathf.Clamp01(score);
        public void UpdateSourceAlignment(float score) => state.sourceAlignment = Mathf.Clamp01(score);
    }
}
