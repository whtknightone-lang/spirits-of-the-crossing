
# Unity Conversion: Source / Dark Planet / Source River

This package converts the earlier Python simulation concepts into Unity C# scaffolding.

Included systems:
- SourceRiverSystem.cs
- SourceFieldSystem.cs
- DarkPlanetSystem.cs
- SourceDarkPlanetBridge.cs
- UniverseSceneSetup_README.txt

What is converted:
- source river nodes and flowing current logic
- source connection accumulation for entities
- dark planet pressure / disharmony field
- bridge logic between source coherence and dark planet compression

Recommended Unity version:
- Unity 2022 LTS or newer

Notes:
- This is a Unity-native code scaffold, not a fully authored scene
- Attach these scripts to GameObjects in a Unity scene
- Hook them to your existing EntityAgent / UniverseManager scripts if using the previous project structure
