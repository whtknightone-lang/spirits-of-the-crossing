
using UnityEngine;
using ArtificialUniverse.Source;
using ArtificialUniverse.DarkPlanet;
using ArtificialUniverse.Core;

namespace ArtificialUniverse.Core
{
    public class SourceDarkPlanetBridge : MonoBehaviour
    {
        [SerializeField] private SourceRiverSystem sourceRiver;
        [SerializeField] private SourceFieldSystem sourceField;
        [SerializeField] private DarkPlanetSystem darkPlanet;
        [SerializeField] private EntityManager entityManager;

        [Range(0f, 1f)] public float integrationLevel = 0.5f;

        private void Awake()
        {
            if (sourceRiver == null) sourceRiver = FindObjectOfType<SourceRiverSystem>();
            if (sourceField == null) sourceField = FindObjectOfType<SourceFieldSystem>();
            if (darkPlanet == null) darkPlanet = FindObjectOfType<DarkPlanetSystem>();
            if (entityManager == null) entityManager = FindObjectOfType<EntityManager>();
        }

        private void Update()
        {
            if (entityManager == null) return;

            var agents = entityManager.ActiveAgents;
            float dt = Time.deltaTime;

            sourceRiver?.Tick(dt, agents as System.Collections.Generic.IList<ArtificialUniverse.Entities.EntityAgent>);
            sourceField?.Tick(dt, agents as System.Collections.Generic.IList<ArtificialUniverse.Entities.EntityAgent>);
            darkPlanet?.Tick(dt, agents as System.Collections.Generic.IList<ArtificialUniverse.Entities.EntityAgent>);

            if (sourceField != null && darkPlanet != null)
            {
                float coherence = sourceField.globalSourceMood;
                float pressure = darkPlanet.darkPressure;

                integrationLevel = Mathf.Clamp01(0.5f + (coherence - pressure) * 0.5f);
            }
        }
    }
}
