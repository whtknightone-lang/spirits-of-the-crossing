
using UnityEngine;
using System.Collections.Generic;
using ArtificialUniverse.Entities;

namespace ArtificialUniverse.DarkPlanet
{
    public class DarkPlanetSystem : MonoBehaviour
    {
        [Header("Dark Planet")]
        [SerializeField] private Vector3 darkPlanetCenter = new Vector3(0f, 0f, 0f);
        [SerializeField] private float influenceRadius = 25f;
        [SerializeField] private float compressionStrength = 0.4f;
        [SerializeField] private float disharmonyGain = 0.2f;
        [SerializeField] private float transformationThreshold = 0.75f;

        [Range(0f, 1f)] public float darkPressure = 0.0f;

        public void Tick(float deltaTime, IList<EntityAgent> agents)
        {
            if (agents == null || agents.Count == 0) return;

            float accumulatedPressure = 0f;

            foreach (var agent in agents)
            {
                float dist = Vector3.Distance(agent.transform.position, darkPlanetCenter);
                if (dist > influenceRadius) continue;

                float proximity = 1f - (dist / influenceRadius);
                float disharmony = Mathf.Abs(agent.Data.Desire - agent.Data.Focus);
                float pressure = proximity * disharmony * compressionStrength;

                accumulatedPressure += pressure;
                agent.Data.Integrity = Mathf.Clamp01(agent.Data.Integrity - pressure * deltaTime * disharmonyGain);

                if (pressure > transformationThreshold * 0.25f)
                {
                    agent.Data.Purpose = "shadow_integration";
                }
            }

            darkPressure = Mathf.Clamp01(accumulatedPressure / Mathf.Max(1f, agents.Count));
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = new Color(0.5f, 0.1f, 0.6f, 0.4f);
            Gizmos.DrawWireSphere(darkPlanetCenter, influenceRadius);
        }
    }
}
