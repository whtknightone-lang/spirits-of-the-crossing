
using UnityEngine;
using System.Collections.Generic;
using ArtificialUniverse.Entities;

namespace ArtificialUniverse.Source
{
    public class SourceFieldSystem : MonoBehaviour
    {
        [Range(0f, 1f)] public float globalSourceMood = 0.5f;
        [Range(0f, 1f)] public float globalLearning = 0.0f;
        [Range(0f, 2f)] public float fieldStrength = 0.5f;

        public void Tick(float deltaTime, IList<EntityAgent> agents)
        {
            if (agents == null || agents.Count == 0) return;

            float totalHarmony = 0f;

            foreach (var agent in agents)
            {
                float harmony = 1f - Mathf.Abs(agent.Data.Desire - agent.Data.Focus);
                totalHarmony += harmony;
            }

            globalLearning = Mathf.Lerp(globalLearning, totalHarmony / agents.Count, deltaTime * 0.5f);
            globalSourceMood = Mathf.Lerp(globalSourceMood, globalLearning, deltaTime * 0.25f);

            foreach (var agent in agents)
            {
                float delta = globalSourceMood * fieldStrength * deltaTime * 0.05f;
                agent.ApplySourceConnection(delta);
                agent.ApplyVibration(delta * 0.25f);
            }
        }
    }
}
