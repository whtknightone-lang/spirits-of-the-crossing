
using System.Collections.Generic;
using UnityEngine;

namespace ArtificialUniverse.Source
{
    public class SourceRiverSystem : MonoBehaviour
    {
        [SerializeField] private int nodeCount = 180;
        [SerializeField] private float worldRadius = 60f;
        [SerializeField] private float driftStrength = 2.5f;
        [SerializeField] private float connectionRadius = 4f;

        private readonly List<Vector3> nodes = new();
        public IReadOnlyList<Vector3> Nodes => nodes;

        private void Start()
        {
            if (nodes.Count == 0)
            {
                for (int i = 0; i < nodeCount; i++)
                {
                    Vector3 p = Random.insideUnitSphere * worldRadius;
                    p.y = 0f;
                    nodes.Add(p);
                }
            }
        }

        public void Tick(float deltaTime, IList<ArtificialUniverse.Entities.EntityAgent> agents)
        {
            for (int i = 0; i < nodes.Count; i++)
            {
                Vector3 drift = new Vector3(
                    Random.Range(-1f, 1f),
                    0f,
                    Random.Range(-1f, 1f)
                ) * driftStrength * deltaTime;

                nodes[i] += drift;

                if (nodes[i].magnitude > worldRadius)
                {
                    nodes[i] = nodes[i].normalized * worldRadius;
                    nodes[i] = new Vector3(nodes[i].x, 0f, nodes[i].z);
                }
            }

            if (agents == null) return;

            foreach (var agent in agents)
            {
                float totalConnection = 0f;
                Vector3 pos = agent.transform.position;

                for (int i = 0; i < nodes.Count; i++)
                {
                    float d = Vector3.Distance(pos, nodes[i]);
                    if (d < connectionRadius)
                    {
                        totalConnection += 1f - (d / connectionRadius);
                    }
                }

                if (totalConnection > 0f)
                {
                    agent.ApplySourceConnection(totalConnection * 0.01f);
                }
            }
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = new Color(0.3f, 0.7f, 1f, 0.6f);
            foreach (var n in nodes)
            {
                Gizmos.DrawSphere(transform.position + n, 0.15f);
            }
        }
    }
}
