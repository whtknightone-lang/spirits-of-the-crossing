
Suggested Unity scene setup

1. Create an empty GameObject named Systems
2. Add these components:
   - SourceRiverSystem
   - SourceFieldSystem
   - DarkPlanetSystem
   - SourceDarkPlanetBridge

3. Make sure your scene also contains:
   - UniverseManager
   - EntityManager
   - Entity prefab with EntityAgent

4. Configure DarkPlanetSystem:
   - set darkPlanetCenter
   - set influenceRadius
   - tune compressionStrength and disharmonyGain

5. Configure SourceRiverSystem:
   - nodeCount
   - worldRadius
   - connectionRadius

6. Play mode expectation:
   - entities near the source river gain source connection
   - entities near the dark planet experience compression / integrity loss
   - source and dark pressure balance through SourceDarkPlanetBridge
