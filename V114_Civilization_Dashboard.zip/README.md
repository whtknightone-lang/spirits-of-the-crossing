
# V114 Civilization + Dashboard

Adds:
- Civilization system (resources, population, growth)
- Belief + economy placeholders
- Visual dashboard (real-time stats)
- Integration point with dragons, players, and structures

Goal:
Let you SEE the state of your universe and guide it.
