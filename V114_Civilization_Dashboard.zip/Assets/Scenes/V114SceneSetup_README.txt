
Scene Setup:

1. Create GameObject: Civilization
   - CivilizationSystem
   - EconomySystem
   - BeliefSystem

2. Create GameObject: UI
   - CivilizationDashboard

3. Add V114IntegrationManager to Systems object

4. Run game

You will now see:
- population growth
- harmony vs conflict
- resources
- belief systems

This connects directly to your dragon + realm + source systems.
