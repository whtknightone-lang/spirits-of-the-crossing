
using UnityEngine;
using ArtificialUniverse.Civilization;

namespace ArtificialUniverse.Core
{
    public class V114IntegrationManager : MonoBehaviour
    {
        public CivilizationSystem civ;
        public EconomySystem eco;
        public BeliefSystem belief;

        void Start()
        {
            if (civ == null) civ = FindObjectOfType<CivilizationSystem>();
            if (eco == null) eco = FindObjectOfType<EconomySystem>();
            if (belief == null) belief = FindObjectOfType<BeliefSystem>();
        }
    }
