
using UnityEngine;

namespace ArtificialUniverse.Civilization
{
    public class BeliefSystem : MonoBehaviour
    {
        [Range(0f,1f)] public float beliefInSource = 0.5f;
        [Range(0f,1f)] public float beliefInChaos = 0.3f;

        void Update()
        {
            float dt = Time.deltaTime;

            beliefInSource = Mathf.Clamp01(beliefInSource + 0.01f * dt);
            beliefInChaos = Mathf.Clamp01(beliefInChaos + (1f - beliefInSource) * 0.005f * dt);
        }
    }
