
using UnityEngine;

namespace ArtificialUniverse.Civilization
{
    public class EconomySystem : MonoBehaviour
    {
        public float resources = 100;
        public float production = 2f;
        public float consumption = 1.5f;

        void Update()
        {
            float dt = Time.deltaTime;
            resources += (production - consumption) * dt;

            if (resources < 0)
            {
                resources = 0;
                production *= 0.95f;
            }
        }
    }
