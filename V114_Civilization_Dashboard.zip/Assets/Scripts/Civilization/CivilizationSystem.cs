
using UnityEngine;

namespace ArtificialUniverse.Civilization
{
    public class CivilizationSystem : MonoBehaviour
    {
        [Header("Core Metrics")]
        public float population = 10;
        public float energy = 0.5f;
        public float harmony = 0.5f;
        public float conflict = 0.2f;

        [Header("Growth")]
        public float growthRate = 0.1f;

        void Update()
        {
            float dt = Time.deltaTime;

            // growth based on harmony
            population += population * harmony * growthRate * dt;

            // conflict reduces growth
            population -= population * conflict * 0.05f * dt;

            energy = Mathf.Clamp01(energy + harmony * 0.02f * dt - conflict * 0.02f * dt);
            harmony = Mathf.Clamp01(harmony + energy * 0.01f * dt - conflict * 0.015f * dt);
            conflict = Mathf.Clamp01(conflict + (1f - harmony) * 0.01f * dt);
        }
    }
