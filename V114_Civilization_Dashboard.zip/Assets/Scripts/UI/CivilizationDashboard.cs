
using UnityEngine;
using ArtificialUniverse.Civilization;

namespace ArtificialUniverse.UI
{
    public class CivilizationDashboard : MonoBehaviour
    {
        public CivilizationSystem civ;
        public EconomySystem eco;
        public BeliefSystem belief;

        void Awake()
        {
            if (civ == null) civ = FindObjectOfType<CivilizationSystem>();
            if (eco == null) eco = FindObjectOfType<EconomySystem>();
            if (belief == null) belief = FindObjectOfType<BeliefSystem>();
        }

        void OnGUI()
        {
            if (civ == null) return;

            int y = 20;

            GUI.Label(new Rect(20,y,300,25), "=== CIVILIZATION DASHBOARD ==="); y+=25;

            GUI.Label(new Rect(20,y,300,25), $"Population: {civ.population:0}"); y+=20;
            GUI.Label(new Rect(20,y,300,25), $"Energy: {civ.energy:0.00}"); y+=20;
            GUI.Label(new Rect(20,y,300,25), $"Harmony: {civ.harmony:0.00}"); y+=20;
            GUI.Label(new Rect(20,y,300,25), $"Conflict: {civ.conflict:0.00}"); y+=30;

            if (eco != null)
            {
                GUI.Label(new Rect(20,y,300,25), "--- Economy ---"); y+=20;
                GUI.Label(new Rect(20,y,300,25), $"Resources: {eco.resources:0.0}"); y+=20;
            }

            if (belief != null)
            {
                GUI.Label(new Rect(20,y,300,25), "--- Belief ---"); y+=20;
                GUI.Label(new Rect(20,y,300,25), $"Source: {belief.beliefInSource:0.00}"); y+=20;
                GUI.Label(new Rect(20,y,300,25), $"Chaos: {belief.beliefInChaos:0.00}"); y+=20;
            }
        }
    }
