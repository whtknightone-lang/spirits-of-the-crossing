
import pygame
from systems.ecosystem import Ecosystem
from systems.creator import CreatorSystem

class V83Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.creator=CreatorSystem(self.ecosystem)

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(50):
            self.ecosystem.spawn_entity("basic")

    def handle_key(self,key):
        self.creator.handle_key(key)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.creator.update()

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            t=e.get("species","basic")

            if t=="basic": color=(200,200,200)
            elif t=="explorer": color=(120,180,255)
            elif t=="builder": color=(120,255,180)
            else: color=(255,180,120)

            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V83 Creator Engine",
            "1 spawn explorer | 2 spawn builder | 3 new species",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Species count: {len(self.creator.species_types)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
