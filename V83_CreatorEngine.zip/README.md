
# V83 Creator Engine

Adds:
- ability to create new species dynamically
- player acts as creator layer
- species diversity expands during runtime

Concept:
The system is no longer just evolving—
it can create entirely new forms of existence.
