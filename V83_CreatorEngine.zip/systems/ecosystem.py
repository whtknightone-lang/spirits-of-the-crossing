
import random, uuid

class Ecosystem:
    def __init__(self,size):
        self.size=size
        self.entities=[]

    def spawn_entity(self,species):
        self.entities.append({
            "id":str(uuid.uuid4()),
            "pos":[random.random()*self.size,random.random()*self.size],
            "species":species
        })

    def update(self,dt):
        for e in self.entities:
            e["pos"][0]+=random.uniform(-1,1)*dt*6
            e["pos"][1]+=random.uniform(-1,1)*dt*6
