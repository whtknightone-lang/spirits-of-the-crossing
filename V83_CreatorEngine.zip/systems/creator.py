
import random

class CreatorSystem:
    def __init__(self,eco):
        self.eco=eco
        self.species_types=["basic","explorer","builder"]

    def handle_key(self,key):
        if key==49: # 1
            self.eco.spawn_entity("explorer")
        if key==50: # 2
            self.eco.spawn_entity("builder")
        if key==51: # 3 create new species
            new_type="species_"+str(len(self.species_types))
            self.species_types.append(new_type)

            # spawn a few
            for _ in range(5):
                self.eco.spawn_entity(new_type)

    def update(self):
        # future: species evolve behaviors
        pass
