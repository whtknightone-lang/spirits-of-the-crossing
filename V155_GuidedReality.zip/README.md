V155 Guided Reality + Intuition + Source Calling
