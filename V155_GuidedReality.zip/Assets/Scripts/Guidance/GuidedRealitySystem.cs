
using UnityEngine;

public class GuidedRealitySystem : MonoBehaviour
{
    public float guidanceStrength = 0.5f;

    public Vector3 GetGuidance(Vector3 current, Vector3 goal)
    {
        return Vector3.Lerp(current, goal, guidanceStrength * Time.deltaTime);
    }
}
