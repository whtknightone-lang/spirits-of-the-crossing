
using UnityEngine;

public class IntuitionSystem : MonoBehaviour
{
    public float intuitionSignal;

    void Update()
    {
        intuitionSignal = Mathf.PingPong(Time.time * 0.2f, 1f);
    }
}
