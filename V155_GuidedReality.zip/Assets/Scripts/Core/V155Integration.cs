
using UnityEngine;

public class V155Integration : MonoBehaviour
{
    void Start()
    {
        if (FindObjectOfType<GuidedRealitySystem>() == null)
            gameObject.AddComponent<GuidedRealitySystem>();

        if (FindObjectOfType<IntuitionSystem>() == null)
            gameObject.AddComponent<IntuitionSystem>();

        if (FindObjectOfType<SourceCalling>() == null)
            gameObject.AddComponent<SourceCalling>();
    }
}
