
using UnityEngine;

public class SourceCalling : MonoBehaviour
{
    public Transform player;
    public Transform target;

    public float pullStrength = 1f;

    void Update()
    {
        if (player == null || target == null) return;

        Vector3 direction = (target.position - player.position).normalized;
        player.position += direction * pullStrength * Time.deltaTime;
    }
}
