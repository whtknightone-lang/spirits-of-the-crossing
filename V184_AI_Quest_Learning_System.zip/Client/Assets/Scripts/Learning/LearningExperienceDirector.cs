
using UnityEngine;
public class LearningExperienceDirector : MonoBehaviour
{
    public float learningProgress;
    void Update()
    {
        learningProgress += Time.deltaTime * 0.01f;
    }
}
