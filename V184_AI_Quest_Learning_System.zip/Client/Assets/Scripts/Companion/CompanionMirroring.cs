
using UnityEngine;
public class CompanionMirroring : MonoBehaviour
{
    public Transform player;
    void Update()
    {
        if (player != null)
        {
            transform.position = Vector3.Lerp(transform.position, player.position, Time.deltaTime);
        }
    }
}
