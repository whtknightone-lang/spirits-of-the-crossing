
using UnityEngine;
public class VibrationRewardSystem : MonoBehaviour
{
    public float alignment;
    public bool CheckReward()
    {
        return alignment > 0.8f;
    }
}
