
using UnityEngine;
public class AIQuestGenerator : MonoBehaviour
{
    public float playerResonance;
    public float curiosity;

    public string GenerateQuest()
    {
        if (playerResonance > 0.7f) return "Explore high resonance zone";
        else if (curiosity > 0.5f) return "Follow curiosity signal";
        else return "Stabilize local field";
    }
}
