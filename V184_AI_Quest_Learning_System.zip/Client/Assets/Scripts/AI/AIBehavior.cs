
using UnityEngine;
public class AIBehavior : MonoBehaviour
{
    public float resonance;
    void Update()
    {
        transform.Rotate(0, resonance * Time.deltaTime * 50f, 0);
    }
}
