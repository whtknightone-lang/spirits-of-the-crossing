
# V69 Attraction + Alignment System

Adds:
- entities are attracted to similar vibration
- alignment grows through similarity
- player can amplify or disrupt alignment

Concept:
Like attracts like → alignment forms → clusters stabilize
