
import math

class AttractionSystem:
    def update(self,eco):
        ents=eco.entities
        for i in range(len(ents)):
            for j in range(i+1,len(ents)):
                a=ents[i]; b=ents[j]

                dx=b["pos"][0]-a["pos"][0]
                dy=b["pos"][1]-a["pos"][1]
                d=math.sqrt(dx*dx+dy*dy)+0.001

                similarity = 1 - abs(a["vibration"] - b["vibration"])

                # attraction toward similar vibration
                force = similarity * 0.02

                a["pos"][0] += (dx/d) * force
                a["pos"][1] += (dy/d) * force
                b["pos"][0] -= (dx/d) * force
                b["pos"][1] -= (dy/d) * force

                # alignment grows
                a["alignment"] += similarity * 0.005
                b["alignment"] += similarity * 0.005

                a["alignment"]=min(1,a["alignment"])
                b["alignment"]=min(1,b["alignment"])
