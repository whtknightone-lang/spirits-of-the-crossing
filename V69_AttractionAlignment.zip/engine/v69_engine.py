
import pygame
from systems.ecosystem import Ecosystem
from systems.resonance import ResonanceSystem
from systems.attraction import AttractionSystem
from systems.player_control import PlayerControlSystem

class V69Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.resonance=ResonanceSystem()
        self.attraction=AttractionSystem()
        self.player=PlayerControlSystem(self.ecosystem)

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(70):
            self.ecosystem.spawn_entity()

    def handle_key(self,key):
        self.player.handle_key(key)

    def update(self,dt):
        self.attraction.update(self.ecosystem)
        self.resonance.update(self.ecosystem)
        self.ecosystem.update(dt)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            vib=e.get("vibration",0)
            align=e.get("alignment",0)

            color=(int(100+vib*155), int(100+align*155), 255-int(vib*200))
            pygame.draw.circle(screen,color,(x,y),4)

        if self.player.selected:
            e=self.player.selected
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40
            pygame.draw.circle(screen,(255,255,255),(x,y),8,1)

        y=760
        lines=[
            "V69 Attraction + Alignment",
            "Click select | 1 align | 2 disrupt",
            f"Entities: {len(self.ecosystem.entities)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
