
# V86+ Source Intent System

Adds:
- player can influence source currents directly
- currents now respond to intent (push/pull)
- creates guided flow through the world

Concept:
Source is not only flowing—
it can be directed through intention.
