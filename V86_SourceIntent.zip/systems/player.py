
import pygame

class PlayerSystem:
    def __init__(self,eco,source):
        self.eco=eco
        self.source=source

    def handle_key(self,key):
        if key==pygame.K_1:
            self.source.apply_intent(-0.1,0)
        if key==pygame.K_2:
            self.source.apply_intent(0.1,0)
