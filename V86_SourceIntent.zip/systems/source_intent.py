
import random

class SourceIntentSystem:
    def __init__(self,size):
        self.size=size
        self.currents=[
            [random.random()*size, random.random()*size]
            for _ in range(150)
        ]
        self.intent_vector=[0,0]

    def apply_intent(self,dx,dy):
        self.intent_vector=[dx,dy]

    def update(self,eco):
        for c in self.currents:
            c[0]+=random.uniform(-0.3,0.3)+self.intent_vector[0]
            c[1]+=random.uniform(-0.3,0.3)+self.intent_vector[1]

        for e in eco.entities:
            for c in self.currents:
                dx=e["pos"][0]-c[0]
                dy=e["pos"][1]-c[1]
                dist=(dx*dx+dy*dy)**0.5
                if dist<4:
                    e["source_connection"] += 0.01

            e["source_connection"]=min(1.0,e["source_connection"])
