
# V66 Desire + Asking System

Adds:
- entities generate internal desire
- unmet desire grows (asking for more)
- player can fulfill or ignore desires

Meaning:
Desire drives evolution and behavior.
