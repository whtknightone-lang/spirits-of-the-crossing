
import random

class DesireSystem:
    def update(self,eco):
        for e in eco.entities:
            # desire grows if not fulfilled
            if e["satisfaction"] < e["desire"]:
                e["desire"] += 0.01
            else:
                e["desire"] -= 0.005

            # clamp
            e["desire"]=max(0,min(1,e["desire"]))

            # reset satisfaction slowly
            e["satisfaction"] *= 0.95
