
using UnityEngine;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Net.WebSockets;

public class AutoWebSocketClient : MonoBehaviour
{
    public string serverUri = "ws://localhost:8080";
    public float reconnectDelay = 2f;

    private ClientWebSocket ws;
    private CancellationTokenSource cts;
    private bool connecting;

    public event Action<string> OnMessage;

    async void Start()
    {
        await ConnectLoop();
    }

    async Task ConnectLoop()
    {
        while (true)
        {
            if (!connecting)
            {
                connecting = true;
                try
                {
                    ws = new ClientWebSocket();
                    cts = new CancellationTokenSource();
                    await ws.ConnectAsync(new Uri(serverUri), cts.Token);
                    Debug.Log("WS Connected: " + serverUri);
                    _ = ReceiveLoop();
                }
                catch (Exception e)
                {
                    Debug.LogWarning("WS Connect failed: " + e.Message);
                }
                connecting = false;
            }
            await Task.Delay(TimeSpan.FromSeconds(reconnectDelay));
        }
    }

    async Task ReceiveLoop()
    {
        var buffer = new byte[4096];
        while (ws != null && ws.State == WebSocketState.Open)
        {
            var result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), cts.Token);
            if (result.MessageType == WebSocketMessageType.Close)
            {
                await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "close", CancellationToken.None);
                break;
            }
            var msg = Encoding.UTF8.GetString(buffer, 0, result.Count);
            OnMessage?.Invoke(msg);
        }
    }

    public async void Send(string message)
    {
        if (ws == null || ws.State != WebSocketState.Open) return;
        var bytes = Encoding.UTF8.GetBytes(message);
        await ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
    }

    void OnDestroy()
    {
        try { cts?.Cancel(); ws?.Dispose(); } catch {}
    }
}
