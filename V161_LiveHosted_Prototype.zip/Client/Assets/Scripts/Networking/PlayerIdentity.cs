
using UnityEngine;

public class PlayerIdentity : MonoBehaviour
{
    public string playerId;

    void Awake()
    {
        if (string.IsNullOrEmpty(playerId))
        {
            playerId = System.Guid.NewGuid().ToString();
        }
        DontDestroyOnLoad(gameObject);
    }
}
