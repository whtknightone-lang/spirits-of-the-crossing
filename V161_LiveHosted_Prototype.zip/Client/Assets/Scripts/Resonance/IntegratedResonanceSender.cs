
using UnityEngine;

public class IntegratedResonanceSender : MonoBehaviour
{
    public float resonance;
    public float alignment;
    public float meaning;

    private AutoWebSocketClient client;
    private PlayerIdentity identity;

    void Awake()
    {
        client = FindObjectOfType<AutoWebSocketClient>();
        identity = FindObjectOfType<PlayerIdentity>();
    }

    void Update()
    {
        resonance = Mathf.PingPong(Time.time * 0.2f, 1f);
        alignment = Mathf.PingPong(Time.time * 0.1f, 1f);
        meaning = Mathf.PingPong(Time.time * 0.05f, 1f);

        if (client != null && identity != null)
        {
            var payload = new Payload
            {
                id = identity.playerId,
                r = resonance,
                a = alignment,
                m = meaning
            };
            string json = JsonUtility.ToJson(payload);
            client.Send(json);
        }
    }

    [System.Serializable]
    public class Payload
    {
        public string id;
        public float r;
        public float a;
        public float m;
    }
}
