
using UnityEngine;

public class WorldResonanceReceiver : MonoBehaviour
{
    public float globalResonance;
    public float globalAlignment;
    public float globalMeaning;

    private AutoWebSocketClient client;

    void Awake()
    {
        client = FindObjectOfType<AutoWebSocketClient>();
        if (client != null)
            client.OnMessage += OnServerMessage;
    }

    void OnDestroy()
    {
        if (client != null)
            client.OnMessage -= OnServerMessage;
    }

    void OnServerMessage(string msg)
    {
        try
        {
            var data = JsonUtility.FromJson<ServerState>(msg);
            ApplyState(data);
        }
        catch {}
    }

    void ApplyState(ServerState s)
    {
        globalResonance = s.resonance;
        globalAlignment = s.alignment;
        globalMeaning = s.meaning;

        RenderSettings.ambientIntensity = Mathf.Lerp(0.5f, 2f, globalResonance);
    }

    [System.Serializable]
    public class ServerState
    {
        public float resonance;
        public float alignment;
        public float meaning;
    }
}
