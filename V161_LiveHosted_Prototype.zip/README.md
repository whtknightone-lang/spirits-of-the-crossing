
# V161 Live Hosted Prototype (Deployment Ready)

Includes:
- Auto-reconnecting WebSocket client
- Player ID system
- Server with basic persistence (in-memory + optional file)
- Deployment config for Render/Railway

Flow:
Client emits state -> Server aggregates -> Broadcast -> Clients update

Quick Start:
1) Server:
   cd Server
   npm install
   node server.js

2) Unity:
   Add AutoWebSocketClient + IntegratedResonanceSender + WorldResonanceReceiver
   Set serverUri to your hosted URL (wss://...)

3) Build and run multiple clients
