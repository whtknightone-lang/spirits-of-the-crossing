
const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 8080;
const SAVE_PATH = path.join(__dirname, 'config', 'state.json');

const wss = new WebSocket.Server({ port: PORT });

let players = {}; // id -> {r,a,m}
let lastState = { resonance: 0, alignment: 0, meaning: 0 };

// Load persisted state (optional)
try {
  if (fs.existsSync(SAVE_PATH)) {
    const raw = fs.readFileSync(SAVE_PATH, 'utf-8');
    lastState = JSON.parse(raw);
    console.log('Loaded state:', lastState);
  }
} catch (e) { console.warn('Load failed', e.message); }

wss.on('connection', function connection(ws) {
  ws.on('message', function incoming(message) {
    try {
      const data = JSON.parse(message.toString());
      if (!data.id) return;
      players[data.id] = { r: data.r || 0, a: data.a || 0, m: data.m || 0 };
    } catch(e){}
  });

  ws.on('close', () => {
    // cleanup happens lazily
  });
});

function computeState() {
  const ids = Object.keys(players);
  if (ids.length === 0) return lastState;

  let sumR = 0, sumA = 0, sumM = 0, n = 0;
  for (const id of ids) {
    const p = players[id];
    if (!p) continue;
    sumR += p.r; sumA += p.a; sumM += p.m; n++;
  }
  if (n === 0) return lastState;

  const s = {
    resonance: sumR / n,
    alignment: sumA / n,
    meaning: sumM / n
  };
  lastState = s;
  return s;
}

function broadcast(state) {
  const msg = JSON.stringify(state);
  wss.clients.forEach(c => {
    if (c.readyState === WebSocket.OPEN) c.send(msg);
  });
}

// tick
setInterval(() => {
  const s = computeState();
  broadcast(s);

  // persist occasionally
  try {
    fs.writeFileSync(SAVE_PATH, JSON.stringify(s, null, 2));
  } catch(e){}
}, 100);

console.log('V161 server listening on', PORT);
