
V230–V231 Ruin Activation + Influence System

V230:
- Ruins activate and replay memory echoes
- past civilizations become visible as events

V231:
- Ruins influence AI and player behavior
- amplify archetypes and resonance

Core Idea:
Ruins are not static—they remember and affect those who enter.
