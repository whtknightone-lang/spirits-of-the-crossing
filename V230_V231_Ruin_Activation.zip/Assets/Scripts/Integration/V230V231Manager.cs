
using UnityEngine;

public class V230V231Manager : MonoBehaviour
{
    public RuinActivation ruin;
    public ArchetypeAmplifier amplifier;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.U))
        {
            ruin.Activate();
            amplifier.Amplify();
        }
    }
}
