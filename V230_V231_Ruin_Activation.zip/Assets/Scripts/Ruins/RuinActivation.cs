
using UnityEngine;

public class RuinActivation : MonoBehaviour
{
    public RuinMemoryEcho memory;

    public void Activate()
    {
        Debug.Log("Ruin activated");
        if (memory != null)
            memory.PlayEcho();
    }
}
