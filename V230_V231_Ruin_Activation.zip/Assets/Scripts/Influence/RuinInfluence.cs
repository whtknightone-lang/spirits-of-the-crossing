
using UnityEngine;

public class RuinInfluence : MonoBehaviour
{
    public float influenceStrength = 0.5f;

    public float Affect(float resonance)
    {
        float result = resonance + influenceStrength * 0.2f;
        return Mathf.Clamp01(result);
    }
}
