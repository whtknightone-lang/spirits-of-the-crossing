
using UnityEngine;

public class ArchetypeAmplifier : MonoBehaviour
{
    public string archetype = "Guide";

    public void Amplify()
    {
        Debug.Log("Amplifying archetype: " + archetype);
    }
}
