
using UnityEngine;

public class RuinMemoryEcho : MonoBehaviour
{
    public string[] pastEvents;

    public void PlayEcho()
    {
        foreach (var e in pastEvents)
        {
            Debug.Log("Echo: " + e);
        }
    }
}
