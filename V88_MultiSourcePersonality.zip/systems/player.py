
import pygame

class PlayerSystem:
    def __init__(self,sources):
        self.sources=sources

    def handle_key(self,key):
        if key==pygame.K_1:
            self.sources.add_source("calm")
        if key==pygame.K_2:
            self.sources.add_source("intense")
        if key==pygame.K_3:
            self.sources.add_source("growth")
