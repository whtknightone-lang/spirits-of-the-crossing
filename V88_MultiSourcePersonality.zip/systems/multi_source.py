
import random

class MultiSourceSystem:
    def __init__(self,size):
        self.size=size
        self.sources=[]

    def add_source(self,type_name):
        self.sources.append({
            "type":type_name,
            "pos":[random.random()*self.size,random.random()*self.size]
        })

    def update(self,eco):
        for e in eco.entities:
            total=0
            for s in self.sources:
                dx=e["pos"][0]-s["pos"][0]
                dy=e["pos"][1]-s["pos"][1]
                dist=(dx*dx+dy*dy)**0.5

                if dist<10:
                    if s["type"]=="calm":
                        total+=0.01
                    elif s["type"]=="intense":
                        total+=0.02
                    else:
                        total+=0.015

            e["source_mix"]=min(1.0,total)
