
import pygame
from systems.ecosystem import Ecosystem
from systems.multi_source import MultiSourceSystem
from systems.player import PlayerSystem

class V88Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.sources=MultiSourceSystem(size)
        self.player=PlayerSystem(self.sources)

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(80):
            self.ecosystem.spawn_entity()

    def handle_key(self,key):
        self.player.handle_key(key)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.sources.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,50))
        scale=700/self.size

        # draw sources
        for s in self.sources.sources:
            x=int(s["pos"][1]*scale)+40
            y=int(s["pos"][0]*scale)+40

            if s["type"]=="calm": color=(120,200,255)
            elif s["type"]=="intense": color=(255,120,120)
            else: color=(180,255,180)

            pygame.draw.circle(screen,color,(x,y),6,1)

        # draw entities
        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            influence=e.get("source_mix",0)
            color=(int(100+influence*155),150,255-int(influence*150))

            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V88 Multi-Source Personality System",
            "1 calm | 2 intense | 3 growth source",
            f"Sources: {len(self.sources.sources)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
