
# V140 Persistent Identity + Universe Memory

Adds:
- Player identity persistence (save/load)
- City + world event memory
- Simple JSON storage
- Hooks to integrate with dashboards and AI

Usage:
- Press K to Save
- Press L to Load
