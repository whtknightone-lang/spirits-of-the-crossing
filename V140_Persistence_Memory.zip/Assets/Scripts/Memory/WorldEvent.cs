
using System;

[Serializable]
public class WorldEvent
{
    public string type;
    public string description;
    public float time;
}
