
using UnityEngine;

public class EventHooks : MonoBehaviour
{
    V140PersistenceManager pm;

    void Awake()
    {
        pm = FindObjectOfType<V140PersistenceManager>();
    }

    void Update()
    {
        if (pm == null) return;

        // Example hooks
        if (Input.GetKeyDown(KeyCode.Alpha1))
            pm.RecordEvent("dragon_switch", "Switched to Air");

        if (Input.GetKeyDown(KeyCode.F))
            pm.RecordEvent("meditate", "Player meditated");
    }
}
