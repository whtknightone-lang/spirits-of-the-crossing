
using UnityEngine;
using System.IO;
using System.Collections.Generic;

public class V140PersistenceManager : MonoBehaviour
{
    public PlayerIdentity player = new PlayerIdentity();
    public List<WorldEvent> events = new List<WorldEvent>();

    string path;

    void Awake()
    {
        path = Path.Combine(Application.persistentDataPath, "universe_save.json");
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.K)) Save();
        if (Input.GetKeyDown(KeyCode.L)) Load();
    }

    public void RecordEvent(string type, string description)
    {
        events.Add(new WorldEvent { type = type, description = description, time = Time.time });
        if (events.Count > 200) events.RemoveAt(0);
    }

    public void Save()
    {
        var data = new SaveData { player = player, events = events };
        var json = JsonUtility.ToJson(data, true);
        File.WriteAllText(path, json);
        Debug.Log("Saved to: " + path);
    }

    public void Load()
    {
        if (!File.Exists(path)) { Debug.Log("No save found"); return; }
        var json = File.ReadAllText(path);
        var data = JsonUtility.FromJson<SaveData>(json);
        if (data != null)
        {
            player = data.player ?? new PlayerIdentity();
            events = data.events ?? new List<WorldEvent>();
            Debug.Log("Loaded from: " + path);
        }
    }

    [System.Serializable]
    class SaveData
    {
        public PlayerIdentity player;
        public List<WorldEvent> events;
    }
}
