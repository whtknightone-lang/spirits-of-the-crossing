
using UnityEngine;

public class V140Integration : MonoBehaviour
{
    void Start()
    {
        if (FindObjectOfType<V140PersistenceManager>() == null)
            gameObject.AddComponent<V140PersistenceManager>();

        if (FindObjectOfType<EventHooks>() == null)
            gameObject.AddComponent<EventHooks>();
    }
}
