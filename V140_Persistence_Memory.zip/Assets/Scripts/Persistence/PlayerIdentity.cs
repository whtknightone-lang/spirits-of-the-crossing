
using System;

[Serializable]
public class PlayerIdentity
{
    public string id = "player_1";
    public float harmony;
    public float experience;
    public int sessions;
}
