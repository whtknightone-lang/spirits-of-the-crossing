
using UnityEngine;
using System.Collections.Generic;

public class PlayerSync : MonoBehaviour
{
    public GameObject playerPrefab;

    Dictionary<string, GameObject> players = new Dictionary<string, GameObject>();

    public void UpdatePlayer(string id, Vector3 pos)
    {
        if (!players.ContainsKey(id))
        {
            players[id] = Instantiate(playerPrefab);
        }

        players[id].transform.position = pos;
    }
}
