
using UnityEngine;
using NativeWebSocket;
using System.Text;

public class SendPosition : MonoBehaviour
{
    public WebSocket ws;
    public string playerId = "player_1";
    public string world = "harmonic_world";

    async void Update()
    {
        if (ws == null || ws.State != WebSocketState.Open) return;

        var payload = JsonUtility.ToJson(new Data {
            playerId = playerId,
            world = world,
            x = transform.position.x,
            y = transform.position.y,
            z = transform.position.z
        });

        await ws.SendText(payload);
    }

    [System.Serializable]
    public class Data
    {
        public string playerId;
        public string world;
        public float x,y,z;
    }
}
