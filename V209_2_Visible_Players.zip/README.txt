
V209.2 Visible Players

Adds:
- position sync
- avatar spawning
- movement updates

Result:
Players appear and move in the same world.
