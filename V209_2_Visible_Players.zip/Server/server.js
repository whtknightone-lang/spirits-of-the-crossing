
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8081 });

let worlds = {};

wss.on('connection', ws => {
    ws.on('message', msg => {
        let data = JSON.parse(msg);

        if(!worlds[data.world]) worlds[data.world] = {};
        worlds[data.world][data.playerId] = data;

        broadcast(data.world);
    });
});

function broadcast(world)
{
    let players = Object.values(worlds[world]);

    wss.clients.forEach(client => {
        if(client.readyState === WebSocket.OPEN)
        {
            client.send(JSON.stringify({
                type: "positions",
                players
            }));
        }
    });
}

console.log("V209.2 server running");
