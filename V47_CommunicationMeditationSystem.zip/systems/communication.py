
import random

class CommunicationSystem:
    def update(self, agents):
        for a in agents:
            if "message" not in a:
                a["message"] = random.random()

            # share meaning with neighbors
            for b in agents:
                if a is b:
                    continue
                if abs(a["pos"][0]-b["pos"][0]) < 5 and abs(a["pos"][1]-b["pos"][1]) < 5:
                    avg = (a["message"] + b["message"]) / 2
                    a["message"] = avg
                    b["message"] = avg
