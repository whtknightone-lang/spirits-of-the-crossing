
# V47 Communication + Meditation System

Run:
pip install -r requirements.txt
python main.py

Features:
- Agents communicate and share internal meaning
- Meditation connects player to "source"
- Global alignment through stillness
