
# Playable Polished Slice

One-scene playable loop tying together:
- Dragons (switching + basic control)
- Realms (zones)
- Cities + Territory + Strategy dashboard
- Source/Dark + Control Panel
- Adaptive + Scenario + Mission
- VR (optional hooks)
- V126–V127 city AI + war + migration

Controls:
- 1/2/3/4: switch dragon
- WASD: move (non-VR)
- Space: ability
- F: meditate
- Sliders: Source/Dark/Growth

Scene:
- Create empty GameObject: Systems
- Add PolishedSliceBootstrap
- Press Play
