
Create an empty scene.
Add empty GameObject: Systems
Attach:
- PolishedSliceBootstrap
- QuickHelpOverlay

Press Play.
