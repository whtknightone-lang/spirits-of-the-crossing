
using UnityEngine;

public class QuickHelpOverlay : MonoBehaviour
{
    void OnGUI()
    {
        int y = 10;
        GUI.Label(new Rect(10,y,600,22),"=== QUICK HELP ==="); y+=20;
        GUI.Label(new Rect(10,y,600,22),"1-4 switch dragon | WASD move | Space ability | F meditate"); y+=18;
        GUI.Label(new Rect(10,y,600,22),"Use Control Panel sliders (Source/Dark/Growth) to steer the world"); y+=18;
        GUI.Label(new Rect(10,y,600,22),"Watch dashboards for population, harmony, conflict, territory"); y+=18;
    }
}
