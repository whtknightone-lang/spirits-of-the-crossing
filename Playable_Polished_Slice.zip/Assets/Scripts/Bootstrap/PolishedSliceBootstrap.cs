
using UnityEngine;

// This bootstrap wires up a minimal playable scene using your existing systems.
public class PolishedSliceBootstrap : MonoBehaviour
{
    void Start()
    {
        // Ensure a camera
        if (Camera.main == null)
        {
            var camGO = new GameObject("Main Camera");
            var cam = camGO.AddComponent<Camera>();
            camGO.tag = "MainCamera";
            cam.transform.position = new Vector3(0, 12, -14);
            cam.transform.LookAt(Vector3.zero);
        }

        // Simple ground
        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(5,1,5);

        // Add key managers if not present (they will attach their sub-systems)
        AddIfMissing("V101GameManager");
        AddIfMissing("RealmInteractionSystem");
        AddIfMissing("SourceDarkFeedbackSystem");
        AddIfMissing("V114IntegrationManager");
        AddIfMissing("V115IntegrationManager");
        AddIfMissing("V123IntegrationManager");
        AddIfMissing("V124IntegrationManager");
        AddIfMissing("V125IntegrationManager");
        AddIfMissing("V126Integration");
        AddIfMissing("V127Integration");
        AddIfMissing("V128VRIntegration"); // optional, safe if not present
        AddIfMissing("V129Integration");   // optional
        AddIfMissing("V139Integration");   // optional

        // Spawn 4 simple dragon avatars (as capsules with DragonAvatar if available)
        for (int i = 0; i < 4; i++)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            go.name = "Dragon_" + i;
            go.transform.position = new Vector3(i * 2.5f - 3.75f, 1f, 0f);

            // Try to add DragonAvatar via reflection (so project compiles even if missing)
            var t = System.Type.GetType("ArtificialUniverse.Dragons.DragonAvatar, Assembly-CSharp");
            if (t != null && go.GetComponent(t) == null)
            {
                go.AddComponent(t);
            }
        }

        // Basic HUD (if not already)
        AddIfMissing("V101DragonHUD");

        // Focus camera
        Camera.main.transform.position = new Vector3(0, 14, -16);
        Camera.main.transform.LookAt(Vector3.zero);
    }

    void AddIfMissing(string typeName)
    {
        var t = System.Type.GetType(typeName + ", Assembly-CSharp");
        if (t == null) return;

        if (FindObjectOfType(t) == null)
        {
            gameObject.AddComponent(t);
        }
    }
}
