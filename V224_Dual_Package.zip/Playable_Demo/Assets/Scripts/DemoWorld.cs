
using UnityEngine;

public class DemoWorld : MonoBehaviour
{
    public DemoPlayer player;
    public Camera cam;

    void Update()
    {
        if(player==null) return;

        cam.backgroundColor = Color.Lerp(Color.red, Color.cyan, player.resonance);

        if(player.resonance > 0.8f)
        {
            Debug.Log("Portal Opens");
        }
    }
}
