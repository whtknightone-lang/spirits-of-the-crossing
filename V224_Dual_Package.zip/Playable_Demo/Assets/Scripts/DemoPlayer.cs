
using UnityEngine;

public class DemoPlayer : MonoBehaviour
{
    public float resonance = 0.5f;

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        transform.Translate(new Vector3(h,0,v)*5f*Time.deltaTime);

        if(Input.GetKeyDown(KeyCode.UpArrow)) resonance += 0.1f;
        if(Input.GetKeyDown(KeyCode.DownArrow)) resonance -= 0.1f;

        resonance = Mathf.Clamp01(resonance);
    }
}
