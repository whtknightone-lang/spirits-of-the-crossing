
V224 Playable Demo

Simple guided experience:
- move
- tune resonance
- feel world respond
- reach alignment → portal opens
