
using UnityEngine;

public class DevControlPanel : MonoBehaviour
{
    public float resonance = 0.5f;
    public float receptivity = 0.5f;

    public bool showAura = true;
    public bool showPaths = true;
    public bool allowSource = true;

    void OnGUI()
    {
        GUI.Label(new Rect(10,10,200,20),"Resonance");
        resonance = GUI.HorizontalSlider(new Rect(10,30,200,20), resonance, 0,1);

        GUI.Label(new Rect(10,50,200,20),"Receptivity");
        receptivity = GUI.HorizontalSlider(new Rect(10,70,200,20), receptivity, 0,1);

        showAura = GUI.Toggle(new Rect(10,100,200,20), showAura, "Show Aura");
        showPaths = GUI.Toggle(new Rect(10,120,200,20), showPaths, "Show Paths");
        allowSource = GUI.Toggle(new Rect(10,140,200,20), allowSource, "Allow Source");
    }
}
