
V224 Dev Universe Build

Full system sandbox:
- adjustable resonance, receptivity
- toggle aura, paths, source
- trigger split/merge

Purpose: experimentation + tuning
