
import pygame
from systems.ecosystem import Ecosystem
from systems.resonance_cluster import ResonanceClusterSystem

class V89Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.cluster=ResonanceClusterSystem()

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(100):
            self.ecosystem.spawn_entity()

    def update(self,dt):
        self.ecosystem.update(dt)
        self.cluster.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,55))
        scale=700/self.size

        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            v=e["vibration"]
            color=(int(100+v*155), 120, 255-int(v*155))

            pygame.draw.circle(screen,color,(x,y),4)

        # draw clusters
        for c in self.cluster.clusters:
            cx=int(c["center"][1]*scale)+40
            cy=int(c["center"][0]*scale)+40
            pygame.draw.circle(screen,(255,255,120),(cx,cy),10,1)

        y=760
        lines=[
            "V89 Resonant Clustering",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Clusters: {len(self.cluster.clusters)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
