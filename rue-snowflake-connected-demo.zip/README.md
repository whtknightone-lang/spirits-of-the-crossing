# RUE Snowflake Connected Demo

This package reconnects the **21-node Snowflake Core V1 brain** to a simple
RUE simulation with:

- one star
- five orbiting planets
- snowflake-brain agents assigned to planets
- real-time matplotlib visualization
- live metrics for synchronization, diversity, and average energy

## Run

```bash
pip install -r requirements.txt
python experiments/run_connected_viewer.py
```

## What you will see

- the star at the center
- planets orbiting in real time
- each planet labeled with agent population
- a selected agent's 21-node snowflake brain animating live
- metrics printed every 100 steps

This is a stability-first integration demo, not a full game engine.
