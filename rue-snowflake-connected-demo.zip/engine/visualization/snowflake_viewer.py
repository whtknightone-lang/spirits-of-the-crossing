import numpy as np
import networkx as nx

class SnowflakeGraph:
    def __init__(self, matrix):
        self.G = nx.Graph()
        for i in range(21):
            self.G.add_node(i)
        for i in range(21):
            for j in range(i + 1, 21):
                if matrix[i, j] != 0:
                    self.G.add_edge(i, j)
        self.pos = self._layout()

    def _layout(self):
        pos = {0: (0.0, 0.0)}
        for i in range(6):
            ang = 2 * np.pi * i / 6
            pos[i + 1] = (1.0 * np.cos(ang), 1.0 * np.sin(ang))
        for i in range(14):
            ang = 2 * np.pi * i / 14
            pos[i + 7] = (2.0 * np.cos(ang), 2.0 * np.sin(ang))
        return pos
