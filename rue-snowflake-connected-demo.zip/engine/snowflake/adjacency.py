import numpy as np

def build_matrix():
    K = np.zeros((21, 21), dtype=float)

    def connect(a, b, w):
        K[a, b] = w
        K[b, a] = w

    # center <-> inner
    for i in range(1, 7):
        connect(0, i, 1.0)

    # inner loop
    inner = [1, 2, 3, 4, 5, 6]
    for i in range(len(inner)):
        connect(inner[i], inner[(i + 1) % len(inner)], 0.65)

    # inner -> outer
    mapping = {
        1: [7, 8],
        2: [9, 10],
        3: [11, 12],
        4: [13, 14],
        5: [15, 16],
        6: [17, 18],
    }
    for src, dsts in mapping.items():
        for d in dsts:
            connect(src, d, 0.50)

    # outer loop
    outer = list(range(7, 21))
    for i in range(len(outer)):
        connect(outer[i], outer[(i + 1) % len(outer)], 0.35)

    # asymmetry bridges
    connect(1, 19, 0.45)
    connect(3, 20, 0.45)

    return K
