import numpy as np

def update(phases, matrix, coupling_scale=0.05, drive=0.0):
    diff = phases[:, None] - phases[None, :]
    coupling = np.sin(diff) * matrix
    velocity = coupling.sum(axis=1)

    velocity *= coupling_scale
    velocity += drive
    velocity = np.clip(velocity, -0.20, 0.20)

    phases = phases + velocity
    return np.mod(phases, 2 * np.pi)
