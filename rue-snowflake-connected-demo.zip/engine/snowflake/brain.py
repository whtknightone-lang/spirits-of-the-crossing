import numpy as np
from .adjacency import build_matrix
from .oscillator import update

class SnowflakeBrain:
    def __init__(self):
        self.phases = np.random.rand(21) * 2 * np.pi
        self.matrix = build_matrix()
        self.coupling_scale = 0.05

    def step(self, drive=0.0):
        self.phases = update(
            self.phases,
            self.matrix,
            coupling_scale=self.coupling_scale,
            drive=drive,
        )
