import numpy as np
from engine.snowflake.brain import SnowflakeBrain

class Agent:
    def __init__(self, planet_id: int):
        self.planet_id = planet_id
        self.brain = SnowflakeBrain()
        self.energy = 0.0

    def compute_reward(self, local_energy: float) -> float:
        phases = self.brain.phases
        sync = abs(np.mean(np.exp(1j * phases)))
        diversity = float(np.std(phases))

        sync_reward = 1.0 - abs(sync - 0.5)
        div_reward = float(np.exp(-abs(diversity - 1.6)))
        reward = 0.65 * sync_reward + 0.35 * div_reward

        return max(0.0, reward) * local_energy

    def step(self, local_energy: float):
        drive = np.tanh(local_energy / 5.0) * 0.02
        self.brain.step(drive=drive)
        self.energy += self.compute_reward(local_energy)
