import math

class Planet:
    def __init__(self, index: int, radius: float):
        self.index = index
        self.radius = radius
        self.angle = index * 0.7
        self.energy = 0.0

    def update_orbit(self):
        self.angle += 0.02 / self.radius

    @property
    def pos(self):
        return (
            self.radius * math.cos(self.angle),
            self.radius * math.sin(self.angle),
        )
