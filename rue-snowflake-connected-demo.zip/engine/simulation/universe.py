import numpy as np
from engine.simulation.star import Star
from engine.simulation.planet import Planet
from engine.agents.agent import Agent

class Universe:
    def __init__(self, num_planets: int = 5, agents_per_planet: int = 12):
        self.star = Star()
        self.planets = [Planet(i, radius=2.5 + i * 1.8) for i in range(num_planets)]
        self.agents = []
        for p in self.planets:
            for _ in range(agents_per_planet):
                self.agents.append(Agent(planet_id=p.index))
        self.time = 0
        self.last_star_energy = 0.0

    def step(self):
        self.time += 1
        self.last_star_energy = self.star.emit_energy()

        for p in self.planets:
            p.update_orbit()
            # inverse-square style energy falloff with floor protection
            p.energy = self.last_star_energy / max(1.0, (p.radius ** 1.6))

        for a in self.agents:
            local_energy = self.planets[a.planet_id].energy
            a.step(local_energy=local_energy)

    def all_phases(self):
        return np.concatenate([a.brain.phases for a in self.agents])

    def all_energies(self):
        return np.array([a.energy for a in self.agents], dtype=float)
