
import matplotlib.pyplot as plt
from engine import SpiritEvolutionWorld

world = SpiritEvolutionWorld()

plt.ion()
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

for step in range(300):
    world.step(step)

    ax.clear()
    ax.scatter(
        world.position[:5000,0].numpy(),
        world.position[:5000,1].numpy(),
        world.position[:5000,2].numpy(),
        s=1
    )

    # show artifacts
    ax.scatter(
        world.artifact_pos[:,0].numpy(),
        world.artifact_pos[:,1].numpy(),
        world.artifact_pos[:,2].numpy(),
        s=50
    )

    ax.set_xlim(0,1)
    ax.set_ylim(0,1)
    ax.set_zlim(0,1)

    ax.set_title(f"Step {step} Active Artifacts {int(world.artifact_active.sum())}")

    plt.pause(0.01)

plt.ioff()
plt.show()
