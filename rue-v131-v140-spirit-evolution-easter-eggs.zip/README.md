
RUE V131–V140 Spirit Evolution + Easter Egg System

Features:
- Evolving Elder Spirits (leveling + transformation)
- Player can align as a Spirit
- Hidden Easter Egg artifacts in world
- Artifact activation based on resonance conditions
- World-altering effects from discoveries
- Mythology logging

Run:
pip install torch matplotlib
python run_v131.py
