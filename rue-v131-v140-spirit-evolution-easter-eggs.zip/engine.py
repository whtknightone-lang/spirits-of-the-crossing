
import torch
import random

SPIRITS = 5

class SpiritEvolutionWorld:
    def __init__(self, n=50000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)
        self.velocity = torch.zeros(n,3)

        self.lineage = torch.randint(0,5,(n,))
        self.goal_type = torch.randint(0,4,(n,))
        self.memory = torch.zeros(n)

        # spirit system
        self.faction_spirit = torch.randint(0, SPIRITS, (5,))
        self.spirit_level = torch.ones(SPIRITS)

        # hidden artifacts (Easter eggs)
        self.artifact_pos = torch.rand(10,3)
        self.artifact_type = torch.randint(0,SPIRITS,(10,))
        self.artifact_active = torch.zeros(10)

        self.history = []

    def step(self, step):
        noise = 0.01 * torch.randn_like(self.velocity)

        # basic motion
        self.velocity += noise
        self.position += self.velocity
        self.position.clamp_(0,1)

        # energy dynamics
        self.energy += 0.01 * torch.sin(torch.rand_like(self.energy))

        # memory
        self.memory = 0.9*self.memory + 0.1*self.energy

        # reinforcement
        improve = self.energy > self.memory
        self.energy[improve] *= 1.001
        self.energy[~improve] *= 0.999

        # --- ARTIFACT DETECTION ---
        for i in range(len(self.artifact_pos)):
            if self.artifact_active[i] == 1:
                continue

            dist = torch.norm(self.position - self.artifact_pos[i], dim=1)
            nearby = dist < 0.05

            if nearby.sum() > 20:  # cluster discovery
                spirit = int(self.artifact_type[i])
                self.artifact_active[i] = 1

                # apply effect
                if spirit == 0:  # Wolf
                    self.velocity += 0.02 * (self.position - 0.5)
                elif spirit == 1:  # Owl
                    self.energy[:] = 1.2
                elif spirit == 2:  # Bear
                    self.energy *= 1.01
                elif spirit == 3:  # Eagle
                    self.velocity += 0.02 * torch.randn_like(self.velocity)
                elif spirit == 4:  # Dragon
                    self.energy *= (1 + 0.01 * torch.randn_like(self.energy))

                self.history.append(f"Artifact {i} activated by spirit {spirit} at step {step}")

                # spirit evolves
                self.spirit_level[spirit] += 1

        self.energy *= 0.999
