Resonance VR Vertical Slice

This zip contains a Unity-oriented project scaffold for a playable VR vertical slice based on:
- adaptive Source intelligence
- player resonance tuning
- false-signal/shadow interference
- planet growth
- universe birth/rebirth cycle
- co-creation of problem and solution

Suggested first scene:
Assets/Scenes/SourceChamber_VR.unity

Key loop:
1. Player enters Source Chamber.
2. Source broadcasts through sound / geometry / haptics.
3. Player tunes with gesture, stillness, motion rhythm, and intent.
4. Shadow introduces false resonance.
5. Player stabilizes true signal.
6. Portal opens.
7. Planet node awakens and grows.
8. Universe cycle manager records a birth/rebirth event.
