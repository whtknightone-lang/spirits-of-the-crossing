using UnityEngine;

namespace ResonanceVR.InputSystem
{
    public class VRInputFacade : MonoBehaviour
    {
        [Range(0f,1f)] public float stillness = 0.5f;
        [Range(0f,1f)] public float gestureStability = 0.5f;
        [Range(0f,1f)] public float movementRhythm = 0.5f;
        [Range(0f,1f)] public float intentStrength = 0.5f;

        private void Update()
        {
            // Placeholder keyboard tuning for early non-VR iteration.
            stillness = Mathf.Clamp01(stillness + Input.GetAxis("Vertical") * Time.deltaTime * 0.2f);
            gestureStability = Mathf.Clamp01(gestureStability + Input.GetAxis("Horizontal") * Time.deltaTime * 0.2f);
        }
    }
}
