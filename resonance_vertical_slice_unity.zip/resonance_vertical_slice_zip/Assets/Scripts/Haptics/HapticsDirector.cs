using UnityEngine;
using ResonanceVR.Core;

namespace ResonanceVR.Haptics
{
    public class HapticsDirector : MonoBehaviour
    {
        public ResonanceEngine engine;

        public void PulseHands(float intensity)
        {
            // Hook platform-specific haptics here.
            Debug.Log($"Hand haptics pulse: {intensity:0.00}");
        }

        private void Update()
        {
            if (engine == null) return;
            PulseHands(engine.signalClarity);
        }
    }
}
