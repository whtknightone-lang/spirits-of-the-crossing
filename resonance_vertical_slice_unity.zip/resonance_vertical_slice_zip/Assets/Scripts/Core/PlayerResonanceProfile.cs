using UnityEngine;

namespace ResonanceVR.Core
{
    [System.Serializable]
    public class PlayerResonanceProfile
    {
        [Range(0f,1f)] public float focus = 0.5f;
        [Range(0f,1f)] public float calm = 0.5f;
        [Range(0f,1f)] public float coherence = 0.5f;
        [Range(0f,1f)] public float trust = 0.5f;
        [Range(0f,1f)] public float embodiment = 0.5f;
        [Range(0f,1f)] public float desire = 0.5f;
        [Range(0f,1f)] public float receptivity = 0.5f;
        [Range(0f,1f)] public float shadowLoad = 0.1f;

        public void UpdateFromSignals(float stillness, float gestureStability, float movementRhythm, float intentStrength)
        {
            focus = Mathf.Clamp01((focus + stillness + gestureStability) / 3f);
            calm = Mathf.Clamp01((calm + stillness) / 2f);
            embodiment = Mathf.Clamp01((embodiment + movementRhythm) / 2f);
            desire = Mathf.Clamp01((desire + intentStrength) / 2f);
            receptivity = Mathf.Clamp01((receptivity + stillness + calm) / 3f);
            coherence = Mathf.Clamp01((focus + calm + embodiment + receptivity - shadowLoad) / 4f);
        }
    }
}
