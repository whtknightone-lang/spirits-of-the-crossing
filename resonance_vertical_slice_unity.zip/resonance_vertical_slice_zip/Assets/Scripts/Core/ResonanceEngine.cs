using UnityEngine;

namespace ResonanceVR.Core
{
    public class ResonanceEngine : MonoBehaviour
    {
        public PlayerResonanceProfile player = new PlayerResonanceProfile();
        public SourceIntelligenceProfile source = new SourceIntelligenceProfile();
        public RealmFieldProfile realm = new RealmFieldProfile();

        [Header("Outputs")]
        [Range(0f,1f)] public float matchScore;
        [Range(0f,1f)] public float signalClarity;
        [Range(0f,1f)] public float manifestationPower;
        [Range(0f,1f)] public float portalStability;
        [Range(0f,1f)] public float distortionRisk;

        public void TickResonance(float stillness, float gestureStability, float movementRhythm, float intentStrength)
        {
            player.UpdateFromSignals(stillness, gestureStability, movementRhythm, intentStrength);
            source.AdaptToPlayer(player);

            matchScore = Mathf.Clamp01((player.coherence + player.receptivity + player.focus) / 3f);
            signalClarity = Mathf.Clamp01(matchScore * (1f - player.shadowLoad));
            manifestationPower = Mathf.Clamp01((signalClarity + player.desire + realm.awakeness) / 3f);
            portalStability = Mathf.Clamp01((manifestationPower + realm.permeability) / 2f);
            distortionRisk = Mathf.Clamp01((player.shadowLoad + realm.corruption + (1f - signalClarity)) / 3f);
        }
    }
}
