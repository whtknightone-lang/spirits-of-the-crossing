using UnityEngine;

namespace ResonanceVR.Core
{
    [System.Serializable]
    public class RealmFieldProfile
    {
        [Range(0f,1f)] public float harmony = 0.4f;
        [Range(0f,1f)] public float corruption = 0.2f;
        [Range(0f,1f)] public float awakeness = 0.3f;
        [Range(0f,1f)] public float permeability = 0.2f;

        public void ApplyResonance(float harmonyDelta, float corruptionDelta)
        {
            harmony = Mathf.Clamp01(harmony + harmonyDelta);
            corruption = Mathf.Clamp01(corruption + corruptionDelta);
            awakeness = Mathf.Clamp01((harmony + (1f - corruption)) * 0.5f);
            permeability = Mathf.Clamp01((awakeness + harmony) * 0.5f);
        }
    }
}
