using UnityEngine;

namespace ResonanceVR.Core
{
    public enum SourceCommunicationMode
    {
        Audio,
        Geometry,
        Haptics,
        Symbolic,
        Mixed
    }

    [System.Serializable]
    public class SourceIntelligenceProfile
    {
        [Range(0f,1f)] public float directness = 0.5f;
        [Range(0f,1f)] public float compassion = 0.7f;
        [Range(0f,1f)] public float challenge = 0.4f;
        [Range(0f,1f)] public float mystery = 0.6f;
        public SourceCommunicationMode mode = SourceCommunicationMode.Audio;

        public void AdaptToPlayer(PlayerResonanceProfile player)
        {
            if (player.coherence < 0.35f)
            {
                mode = SourceCommunicationMode.Haptics;
                directness = Mathf.Clamp01(directness + 0.1f);
                compassion = Mathf.Clamp01(compassion + 0.05f);
            }
            else if (player.focus > 0.6f && player.receptivity > 0.6f)
            {
                mode = SourceCommunicationMode.Mixed;
                mystery = Mathf.Clamp01(mystery + 0.05f);
                challenge = Mathf.Clamp01(challenge + 0.05f);
            }
            else
            {
                mode = SourceCommunicationMode.Geometry;
            }
        }
    }
}
