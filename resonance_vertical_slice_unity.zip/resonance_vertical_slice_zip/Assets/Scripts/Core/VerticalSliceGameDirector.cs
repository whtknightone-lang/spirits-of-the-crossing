using UnityEngine;
using ResonanceVR.InputSystem;
using ResonanceVR.World;
using ResonanceVR.Portals;
using ResonanceVR.Cosmos;

namespace ResonanceVR.Core
{
    public class VerticalSliceGameDirector : MonoBehaviour
    {
        public VRInputFacade inputFacade;
        public ResonanceEngine resonanceEngine;
        public ShadowDistortionSystem shadowSystem;
        public PortalController portalController;
        public PlanetGrowthNode planetNode;
        public UniverseCycleManager universeCycle;

        [Range(0f,30f)] public float shadowTriggerTime = 8f;
        private float elapsed;

        private void Update()
        {
            if (inputFacade == null || resonanceEngine == null) return;

            elapsed += Time.deltaTime;
            resonanceEngine.TickResonance(
                inputFacade.stillness,
                inputFacade.gestureStability,
                inputFacade.movementRhythm,
                inputFacade.intentStrength);

            if (elapsed > shadowTriggerTime && shadowSystem != null)
                shadowSystem.ActivateFalseSignal();
        }
    }
}
