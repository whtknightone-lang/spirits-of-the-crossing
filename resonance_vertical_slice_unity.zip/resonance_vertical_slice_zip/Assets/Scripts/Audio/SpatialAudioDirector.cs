using UnityEngine;
using ResonanceVR.Core;

namespace ResonanceVR.Audio
{
    public class SpatialAudioDirector : MonoBehaviour
    {
        public ResonanceEngine engine;
        public AudioSource sourceHum;
        public AudioSource shadowHum;

        private void Update()
        {
            if (engine == null) return;
            if (sourceHum != null) sourceHum.volume = engine.signalClarity;
            if (shadowHum != null) shadowHum.volume = engine.distortionRisk;
        }
    }
}
