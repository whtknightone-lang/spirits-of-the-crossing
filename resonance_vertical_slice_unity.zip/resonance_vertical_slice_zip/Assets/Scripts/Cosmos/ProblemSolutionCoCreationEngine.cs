using UnityEngine;
using ResonanceVR.Core;

namespace ResonanceVR.Cosmos
{
    public class ProblemSolutionCoCreationEngine : MonoBehaviour
    {
        public ResonanceEngine engine;
        public UniverseCycleManager universeCycle;
        [Range(0f,1f)] public float activeProblemIntensity = 0.3f;
        [Range(0f,1f)] public float latentSolutionResonance = 0.3f;

        private void Update()
        {
            if (engine == null || universeCycle == null) return;

            activeProblemIntensity = Mathf.Clamp01((engine.distortionRisk + (1f - engine.signalClarity)) * 0.5f);
            latentSolutionResonance = Mathf.Clamp01((engine.matchScore + engine.manifestationPower) * 0.5f);

            // Principle: as the problem appears, the solution-thread is already being born.
            float coCreationImpulse = Mathf.Clamp01((activeProblemIntensity + latentSolutionResonance) * 0.5f);
            universeCycle.AdvanceCycle(coCreationImpulse * Time.deltaTime * 0.25f);
        }
    }
}
