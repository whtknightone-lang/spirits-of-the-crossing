using UnityEngine;
using ResonanceVR.Core;

namespace ResonanceVR.Cosmos
{
    public class PlanetGrowthNode : MonoBehaviour
    {
        public ResonanceEngine engine;
        [Range(0f,1f)] public float vitality = 0.1f;
        [Range(0f,1f)] public float consciousness = 0.1f;
        [Range(0f,1f)] public float structuralHarmony = 0.1f;

        public void ApplyGrowth(float delta)
        {
            vitality = Mathf.Clamp01(vitality + delta);
            consciousness = Mathf.Clamp01(consciousness + delta * 0.8f);
            structuralHarmony = Mathf.Clamp01(structuralHarmony + delta * 0.9f);
        }

        private void Update()
        {
            if (engine == null) return;
            float growth = engine.manifestationPower * engine.signalClarity * Time.deltaTime * 0.05f;
            ApplyGrowth(growth);
        }
    }
}
