using UnityEngine;

namespace ResonanceVR.Cosmos
{
    public enum UniverseCycleState
    {
        Seed,
        Birth,
        Growth,
        Fracture,
        Rebirth
    }

    public class UniverseCycleManager : MonoBehaviour
    {
        public UniverseCycleState currentState = UniverseCycleState.Seed;
        [Range(0f,1f)] public float cycleEnergy = 0.1f;

        public void AdvanceCycle(float resonanceEventStrength)
        {
            cycleEnergy = Mathf.Clamp01(cycleEnergy + resonanceEventStrength);

            if (cycleEnergy > 0.85f) currentState = UniverseCycleState.Rebirth;
            else if (cycleEnergy > 0.65f) currentState = UniverseCycleState.Fracture;
            else if (cycleEnergy > 0.45f) currentState = UniverseCycleState.Growth;
            else if (cycleEnergy > 0.2f) currentState = UniverseCycleState.Birth;
        }
    }
}
