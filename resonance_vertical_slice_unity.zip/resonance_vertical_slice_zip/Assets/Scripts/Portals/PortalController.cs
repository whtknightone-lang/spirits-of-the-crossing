using UnityEngine;
using ResonanceVR.Core;

namespace ResonanceVR.Portals
{
    public class PortalController : MonoBehaviour
    {
        public ResonanceEngine engine;
        public GameObject portalVisual;
        public float openThreshold = 0.7f;
        public bool isOpen;

        private void Update()
        {
            if (engine == null || portalVisual == null) return;

            isOpen = engine.portalStability >= openThreshold && engine.distortionRisk < 0.45f;
            portalVisual.SetActive(isOpen);
        }
    }
}
