using UnityEngine;
using ResonanceVR.Core;

namespace ResonanceVR.AI
{
    public class SpiritGuideAgent : MonoBehaviour
    {
        public ResonanceEngine engine;
        [TextArea] public string currentGuidance;

        private void Update()
        {
            if (engine == null) return;

            if (engine.signalClarity < 0.3f)
                currentGuidance = "Be still. The truest signal is often quieter.";
            else if (engine.distortionRisk > 0.5f)
                currentGuidance = "A bright signal is not always a true one.";
            else if (engine.portalStability > 0.7f)
                currentGuidance = "The path opens because you and Source met each other.";
            else
                currentGuidance = "Listen with your whole field.";
        }
    }
}
