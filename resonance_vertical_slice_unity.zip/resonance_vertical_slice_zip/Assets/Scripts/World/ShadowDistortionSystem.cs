using UnityEngine;
using ResonanceVR.Core;

namespace ResonanceVR.World
{
    public class ShadowDistortionSystem : MonoBehaviour
    {
        public ResonanceEngine engine;
        [Range(0f,1f)] public float falseSignalStrength = 0.4f;
        public bool active;

        public void ActivateFalseSignal()
        {
            active = true;
        }

        private void Update()
        {
            if (!active || engine == null) return;
            engine.player.shadowLoad = Mathf.Clamp01(engine.player.shadowLoad + falseSignalStrength * Time.deltaTime * 0.1f);
            engine.realm.corruption = Mathf.Clamp01(engine.realm.corruption + falseSignalStrength * Time.deltaTime * 0.05f);
        }
    }
}
