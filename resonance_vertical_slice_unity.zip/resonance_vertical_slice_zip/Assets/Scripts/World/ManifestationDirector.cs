using UnityEngine;
using ResonanceVR.Core;

namespace ResonanceVR.World
{
    public class ManifestationDirector : MonoBehaviour
    {
        public ResonanceEngine engine;
        public Light chamberLight;
        public Renderer altarRenderer;

        private void Update()
        {
            if (engine == null) return;

            if (chamberLight != null)
                chamberLight.intensity = Mathf.Lerp(0.5f, 2.0f, engine.signalClarity);

            if (altarRenderer != null)
                altarRenderer.material.SetFloat("_EmissionStrength", Mathf.Lerp(0.2f, 2.5f, engine.manifestationPower));
        }
    }
}
