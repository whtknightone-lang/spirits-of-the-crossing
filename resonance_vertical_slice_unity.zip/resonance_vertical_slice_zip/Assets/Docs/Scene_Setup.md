# Scene Setup Notes

## Scene name
SourceChamber_VR

## GameObjects
- GameRoot
- XR Origin / Camera Rig
- Directional Light
- Chamber Mesh
- ResonanceAltar
- SourceCore (attach SpatialAudioDirector hooks)
- PortalRing (attach PortalController)
- PlanetSeedNode (attach PlanetGrowthNode)
- ShadowAnchor (attach ShadowDistortionSystem)
- Systems
  - VRInputFacade
  - ResonanceEngine
  - ManifestationDirector
  - HapticsDirector
  - UniverseCycleManager
  - ProblemSolutionCoCreationEngine
  - VerticalSliceGameDirector
  - SpiritGuideAgent

## Wiring
- Assign ResonanceEngine to all systems that require it.
- Assign Portal visual object to PortalController.
- Assign chamber light + altar material to ManifestationDirector.
- Add two AudioSources to SourceCore: sourceHum and shadowHum.

## Placeholder test flow
- Start with all values near 0.5.
- Use keyboard axes in editor to simulate tuning.
- Watch altar intensity change.
- After 8 seconds, shadow false signal activates.
- Recover clarity to open portal.
- Planet node grows as manifestation stabilizes.
- Universe cycle gradually advances.
