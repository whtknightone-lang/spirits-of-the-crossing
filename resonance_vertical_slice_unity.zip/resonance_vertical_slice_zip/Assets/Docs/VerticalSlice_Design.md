# Resonance VR Vertical Slice Design

## Goal
Prove the core loop in one buildable scene:
- player state matters
- Source adapts
- the world translates resonance
- haptics/audio/visuals close the loop
- planet growth and universe rebirth are integrated into the same system

## Scene: SourceChamber_VR
Contains:
- Central Resonance Altar
- Dormant Portal Ring
- Source Core
- Planet Seed Node
- Shadow Distortion Anchor
- Spirit Guide placeholder

## Gameplay flow
1. Player enters chamber.
2. Source chooses initial communication mode.
3. Player begins tuning.
4. If mismatch persists, Source adapts communication style.
5. Shadow creates a stronger but misleading signal.
6. Player stabilizes true resonance.
7. Portal unlocks.
8. Planet seed grows into an awakened node.
9. Universe cycle receives the event and advances a birth/rebirth memory.

## Problem/Solution Co-Creation Principle
The system does not spawn a problem and later attach a solution.
Instead, both emerge from the same field event.
Example:
- Problem: distortion in a planet growth stream.
- Solution: a complementary resonance path already latent in the same event.
- Player role: tune into the solution thread rather than brute-force remove the problem.

## Suggested Unity object graph
- GameRoot
  - XR Rig
  - ResonanceSystems
    - ResonanceEngine
    - SourceAdaptationSystem
    - SignalInterpreter
    - ManifestationDirector
    - HapticsDirector
    - SpatialAudioDirector
    - UniverseCycleManager
    - ProblemSolutionCoCreationEngine
  - SceneActors
    - SourceCore
    - PortalRing
    - PlanetSeedNode
    - ShadowAnchor
    - SpiritGuide

## Build order
1. Wire resonance state updates.
2. Drive basic visuals/audio.
3. Add portal threshold.
4. Add shadow false-signal injection.
5. Add planet growth state machine.
6. Record universe cycle event.
