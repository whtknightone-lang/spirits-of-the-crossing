# Scene Setup Notes

## Bootstrap
Contains GameBootstrap, SaveArchive, and CreationWireDirector.
Loads cosmos state and transitions to CosmosMap.

## CosmosMap
Displays realm nodes, planet states, Source River flow, and universe cycle ring.
Click or approach nodes to enter scenes.

## SourceChamber_VR
First attunement chamber.
Demonstrates Source adaptation, false signal discrimination, and portal opening.

## PlanetGrowthSandbox
Used to visualize how realm actions modify a living planet's traits.
Shows growth branches, wound patterns, and companion/elder influence.

## UniverseRebirthChamber
Represents universe-scale transition when enough memory and coherence thresholds are met.
Problem-solution pairs recompile into next-cycle constants.
