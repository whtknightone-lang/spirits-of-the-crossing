using UnityEngine;
using ResonanceCreation.Resonance;

namespace ResonanceCreation.Portal
{
    public class PortalController : MonoBehaviour
    {
        [SerializeField] private GameObject portalVisual;
        [SerializeField] private float openThreshold = 0.7f;

        public void ApplySnapshot(ResonanceSnapshot snapshot)
        {
            bool open = snapshot.SignalClarity > openThreshold && snapshot.DistortionRisk < 0.5f;
            if (portalVisual != null)
                portalVisual.SetActive(open);
        }
    }
}
