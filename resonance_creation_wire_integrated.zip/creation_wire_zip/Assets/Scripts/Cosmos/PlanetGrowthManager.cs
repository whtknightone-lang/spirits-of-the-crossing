using System.Collections.Generic;
using UnityEngine;
using ResonanceCreation.Resonance;

namespace ResonanceCreation.Cosmos
{
    public class PlanetGrowthManager : MonoBehaviour
    {
        [SerializeField] private List<PlanetNode> planets = new List<PlanetNode>();

        public void InitializePlanets()
        {
            foreach (var planet in planets)
                planet.Initialize();
        }

        public void ApplySnapshot(ResonanceSnapshot snapshot)
        {
            foreach (var planet in planets)
                planet.ApplyGrowth(snapshot.PlanetGrowthImpulse, snapshot.DistortionRisk);
        }
    }
}
