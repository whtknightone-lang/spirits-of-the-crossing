using UnityEngine;

namespace ResonanceCreation.Cosmos
{
    public class PlanetNode : MonoBehaviour
    {
        [SerializeField] private string planetName = "Unnamed Planet";
        [Range(0f,1f)] [SerializeField] private float vitality = 0.5f;
        [Range(0f,1f)] [SerializeField] private float wisdom = 0.3f;
        [Range(0f,1f)] [SerializeField] private float wound = 0.2f;

        public void Initialize()
        {
            Debug.Log($"Planet initialized: {planetName}");
        }

        public void ApplyGrowth(float impulse, float distortion)
        {
            vitality = Mathf.Clamp01(vitality + impulse * 0.02f - distortion * 0.01f);
            wisdom = Mathf.Clamp01(wisdom + impulse * 0.015f);
            wound = Mathf.Clamp01(wound + distortion * 0.02f - impulse * 0.01f);
        }
    }
}
