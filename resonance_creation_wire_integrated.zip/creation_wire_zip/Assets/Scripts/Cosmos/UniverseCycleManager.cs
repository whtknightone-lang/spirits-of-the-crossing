using UnityEngine;
using ResonanceCreation.Resonance;

namespace ResonanceCreation.Cosmos
{
    public enum UniversePhase { Birth, Growth, Fracture, Rebirth }

    public class UniverseCycleManager : MonoBehaviour
    {
        [SerializeField] private UniversePhase currentPhase = UniversePhase.Birth;
        [SerializeField] private float cycleCharge = 0f;

        public void InitializeCycle()
        {
            cycleCharge = 0.15f;
            currentPhase = UniversePhase.Birth;
        }

        public void ApplySnapshot(ResonanceSnapshot snapshot)
        {
            cycleCharge = Mathf.Clamp01(cycleCharge + snapshot.RebirthReadiness * 0.01f - snapshot.DistortionRisk * 0.005f);

            if (cycleCharge < 0.25f) currentPhase = UniversePhase.Birth;
            else if (cycleCharge < 0.6f) currentPhase = UniversePhase.Growth;
            else if (snapshot.DistortionRisk > 0.6f) currentPhase = UniversePhase.Fracture;
            else currentPhase = UniversePhase.Rebirth;
        }
    }
}
