using UnityEngine;
using ResonanceCreation.Resonance;

namespace ResonanceCreation.Shadow
{
    public class FalseSignalEvent : MonoBehaviour
    {
        [SerializeField] private float temptationStrength = 0.5f;

        public bool IsFalseSignalDominant(ResonanceSnapshot snapshot)
        {
            return snapshot.DistortionRisk * temptationStrength > snapshot.SignalClarity;
        }
    }
}
