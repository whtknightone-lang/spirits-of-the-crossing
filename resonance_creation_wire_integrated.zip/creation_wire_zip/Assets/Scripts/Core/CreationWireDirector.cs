using UnityEngine;
using ResonanceCreation.Resonance;
using ResonanceCreation.Cosmos;
using ResonanceCreation.World;

namespace ResonanceCreation.Core
{
    public class CreationWireDirector : MonoBehaviour
    {
        [SerializeField] private ResonanceEngine resonanceEngine;
        [SerializeField] private UniverseCycleManager universeCycleManager;
        [SerializeField] private PlanetGrowthManager planetGrowthManager;
        [SerializeField] private ProblemSolutionCoCreationEngine coCreationEngine;
        [SerializeField] private SourceRiverNetwork sourceRiverNetwork;

        public void InitializeWorld()
        {
            universeCycleManager?.InitializeCycle();
            sourceRiverNetwork?.InitializeNetwork();
            planetGrowthManager?.InitializePlanets();
            coCreationEngine?.SeedFoundationalPairs();
        }

        public void TickCreationWire(PlayerResonanceProfile player, SourceIntelligenceProfile source)
        {
            if (player == null || source == null) return;

            ResonanceSnapshot snapshot = resonanceEngine.Evaluate(player, source);
            coCreationEngine.GenerateFromSnapshot(snapshot);
            planetGrowthManager.ApplySnapshot(snapshot);
            universeCycleManager.ApplySnapshot(snapshot);
            sourceRiverNetwork.Propagate(snapshot);
        }
    }
}
