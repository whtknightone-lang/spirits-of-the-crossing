using UnityEngine;

namespace ResonanceCreation.Core
{
    public class SaveArchive : MonoBehaviour
    {
        public void Load()
        {
            Debug.Log("Loading resonance creation archive.");
        }

        public void Save()
        {
            Debug.Log("Saving resonance creation archive.");
        }
    }
}
