using UnityEngine;

namespace ResonanceCreation.Core
{
    public class GameBootstrap : MonoBehaviour
    {
        [SerializeField] private CreationWireDirector creationWireDirector;
        [SerializeField] private SaveArchive saveArchive;

        private void Awake()
        {
            if (saveArchive != null)
                saveArchive.Load();

            if (creationWireDirector != null)
                creationWireDirector.InitializeWorld();
        }
    }
}
