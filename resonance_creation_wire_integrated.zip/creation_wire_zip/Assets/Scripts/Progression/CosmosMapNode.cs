using UnityEngine;

namespace ResonanceCreation.Progression
{
    public class CosmosMapNode : MonoBehaviour
    {
        [SerializeField] private string targetSceneName;

        public void EnterNode()
        {
            Debug.Log($"Transition to scene: {targetSceneName}");
        }
    }
}
