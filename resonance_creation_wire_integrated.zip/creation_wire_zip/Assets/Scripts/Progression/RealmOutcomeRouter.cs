using UnityEngine;
using ResonanceCreation.Resonance;

namespace ResonanceCreation.Progression
{
    public class RealmOutcomeRouter : MonoBehaviour
    {
        public void RouteOutcome(ResonanceSnapshot snapshot)
        {
            Debug.Log($"Routing outcome. Harmony={snapshot.Harmony:F2}, Rebirth={snapshot.RebirthReadiness:F2}");
        }
    }
}
