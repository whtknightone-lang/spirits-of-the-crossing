using UnityEngine;
using ResonanceCreation.Resonance;

namespace ResonanceCreation.AI
{
    public class CompanionResonanceAgent : MonoBehaviour
    {
        [Range(0f,1f)] public float bond = 0.4f;
        [Range(0f,1f)] public float stabilizingSong = 0.5f;

        public void SyncWithPlayer(PlayerResonanceProfile player)
        {
            if (player == null) return;
            bond = Mathf.Clamp01(bond + player.coherence * 0.01f);
            stabilizingSong = Mathf.Clamp01(stabilizingSong + player.calm * 0.01f);
        }
    }
}
