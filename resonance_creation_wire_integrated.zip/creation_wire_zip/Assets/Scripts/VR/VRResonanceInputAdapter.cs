using UnityEngine;
using ResonanceCreation.Resonance;

namespace ResonanceCreation.VR
{
    public class VRResonanceInputAdapter : MonoBehaviour
    {
        [SerializeField] private PlayerResonanceProfile playerProfile;

        private void Update()
        {
            float stillness = 1f - Mathf.Clamp01(Input.GetAxis("Mouse X") * 0.1f + Input.GetAxis("Mouse Y") * 0.1f);
            float breathProxy = 0.5f + Mathf.Sin(Time.time) * 0.25f;
            float gestureConfidence = Input.GetMouseButton(0) ? 0.8f : 0.4f;

            playerProfile?.UpdateFromEmbodiedInput(stillness, breathProxy, gestureConfidence);
        }
    }
}
