using System.Collections.Generic;
using UnityEngine;
using ResonanceCreation.Resonance;

namespace ResonanceCreation.World
{
    [System.Serializable]
    public class CoCreationPair
    {
        public string problem;
        public string solutionSeed;
        public float activation;
    }

    public class ProblemSolutionCoCreationEngine : MonoBehaviour
    {
        [SerializeField] private List<CoCreationPair> activePairs = new List<CoCreationPair>();

        public void SeedFoundationalPairs()
        {
            activePairs.Clear();
            activePairs.Add(new CoCreationPair{ problem = "Isolation", solutionSeed = "Wind lattice", activation = 0.2f});
            activePairs.Add(new CoCreationPair{ problem = "Fear storm", solutionSeed = "Heart-fire corridor", activation = 0.2f});
        }

        public void GenerateFromSnapshot(ResonanceSnapshot snapshot)
        {
            foreach (var pair in activePairs)
                pair.activation = Mathf.Clamp01(pair.activation + snapshot.ManifestationPower * 0.015f - snapshot.DistortionRisk * 0.005f);

            if (snapshot.DistortionRisk > 0.65f)
            {
                activePairs.Add(new CoCreationPair
                {
                    problem = "Signal fracture",
                    solutionSeed = "Source braid",
                    activation = 0.1f
                });
            }
        }
    }
}
