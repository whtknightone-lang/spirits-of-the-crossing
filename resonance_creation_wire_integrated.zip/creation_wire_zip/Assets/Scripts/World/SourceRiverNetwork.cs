using UnityEngine;
using ResonanceCreation.Resonance;

namespace ResonanceCreation.World
{
    public class SourceRiverNetwork : MonoBehaviour
    {
        [Range(0f,1f)] [SerializeField] private float flowStrength = 0.5f;
        [Range(0f,1f)] [SerializeField] private float branching = 0.3f;

        public void InitializeNetwork()
        {
            flowStrength = 0.5f;
            branching = 0.3f;
        }

        public void Propagate(ResonanceSnapshot snapshot)
        {
            flowStrength = Mathf.Clamp01(flowStrength + snapshot.SignalClarity * 0.01f - snapshot.DistortionRisk * 0.005f);
            branching = Mathf.Clamp01(branching + snapshot.ManifestationPower * 0.01f);
        }
    }
}
