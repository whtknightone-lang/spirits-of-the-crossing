using UnityEngine;

namespace ResonanceCreation.Resonance
{
    public class ResonanceEngine : MonoBehaviour
    {
        public ResonanceSnapshot Evaluate(PlayerResonanceProfile player, SourceIntelligenceProfile source)
        {
            source.AdaptToPlayer(player);

            float harmony = Mathf.Clamp01((player.coherence + player.focus + source.playerLanguageFit) / 3f);
            float clarity = Mathf.Clamp01(harmony * (source.directness * 0.5f + source.compassion * 0.5f));
            float distortion = Mathf.Clamp01(player.shadowLoad * (1f - player.calm));
            float manifestation = Mathf.Clamp01(harmony * player.desire * player.receptivity);
            float growth = Mathf.Clamp01((manifestation + clarity - distortion * 0.25f));
            float rebirth = Mathf.Clamp01((growth + harmony + source.mystery) / 3f);

            return new ResonanceSnapshot
            {
                Harmony = harmony,
                SignalClarity = clarity,
                DistortionRisk = distortion,
                ManifestationPower = manifestation,
                PlanetGrowthImpulse = growth,
                RebirthReadiness = rebirth
            };
        }
    }
}
