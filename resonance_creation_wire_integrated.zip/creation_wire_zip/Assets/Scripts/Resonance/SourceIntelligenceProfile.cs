using UnityEngine;

namespace ResonanceCreation.Resonance
{
    public class SourceIntelligenceProfile : MonoBehaviour
    {
        [Range(0f,1f)] public float directness = 0.4f;
        [Range(0f,1f)] public float compassion = 0.8f;
        [Range(0f,1f)] public float challenge = 0.35f;
        [Range(0f,1f)] public float mystery = 0.6f;
        [Range(0f,1f)] public float playerLanguageFit = 0.3f;

        public void AdaptToPlayer(PlayerResonanceProfile player)
        {
            if (player == null) return;
            playerLanguageFit = Mathf.Clamp01(playerLanguageFit + player.coherence * 0.05f + player.receptivity * 0.05f);
            directness = player.coherence < 0.4f ? 0.8f : 0.35f;
            challenge = Mathf.Lerp(0.25f, 0.75f, player.coherence);
        }
    }
}
