using UnityEngine;

namespace ResonanceCreation.Resonance
{
    public class PlayerResonanceProfile : MonoBehaviour
    {
        [Range(0f,1f)] public float focus = 0.5f;
        [Range(0f,1f)] public float calm = 0.5f;
        [Range(0f,1f)] public float coherence = 0.5f;
        [Range(0f,1f)] public float desire = 0.5f;
        [Range(0f,1f)] public float receptivity = 0.5f;
        [Range(0f,1f)] public float shadowLoad = 0.2f;

        public void UpdateFromEmbodiedInput(float stillness, float breathProxy, float gestureConfidence)
        {
            focus = Mathf.Clamp01((focus + gestureConfidence) * 0.5f);
            calm = Mathf.Clamp01((calm + stillness + breathProxy) / 3f);
            coherence = Mathf.Clamp01((focus + calm + receptivity - shadowLoad * 0.25f) / 2.75f);
        }
    }
}
