namespace ResonanceCreation.Resonance
{
    public struct ResonanceSnapshot
    {
        public float Harmony;
        public float SignalClarity;
        public float DistortionRisk;
        public float ManifestationPower;
        public float PlanetGrowthImpulse;
        public float RebirthReadiness;
    }
}
