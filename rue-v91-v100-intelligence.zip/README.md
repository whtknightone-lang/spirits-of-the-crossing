
RUE V91–V100 Intelligence Layer

Features:
- Memory (running average energy per agent)
- Prediction (simple future estimate)
- Adaptation (behavior shifts based on memory)
- Learning signal (reward-like adjustment)

Run:
pip install torch matplotlib
python run_v91.py
