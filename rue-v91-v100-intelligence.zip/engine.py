
import torch

class IntelligentWorld:
    def __init__(self, n=50000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)
        self.velocity = torch.zeros(n,3)

        # intelligence layers
        self.memory = torch.zeros(n)        # past energy memory
        self.prediction = torch.zeros(n)    # predicted future energy

    def step(self):
        # movement
        self.velocity += 0.01 * torch.randn_like(self.velocity)
        self.position += self.velocity
        self.position.clamp_(0,1)

        # base dynamics
        phase = torch.rand_like(self.energy)
        self.energy += 0.01 * torch.sin(phase)

        # --- MEMORY UPDATE ---
        self.memory = 0.9 * self.memory + 0.1 * self.energy

        # --- PREDICTION ---
        self.prediction = self.energy + (self.energy - self.memory)

        # --- ADAPTATION ---
        improve_mask = self.prediction > self.energy
        decline_mask = self.prediction < self.energy

        self.energy[improve_mask] *= 1.001
        self.energy[decline_mask] *= 0.999

        # decay
        self.energy *= 0.999
