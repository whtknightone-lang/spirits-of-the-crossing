
using UnityEngine;

public class IntentSystem : MonoBehaviour
{
    public string currentIntent = "explore";
    [Range(0f,1f)] public float intentClarity = 0.5f;

    public void SetIntent(string nextIntent, float clarity)
    {
        currentIntent = nextIntent;
        intentClarity = Mathf.Clamp01(clarity);
    }
}
