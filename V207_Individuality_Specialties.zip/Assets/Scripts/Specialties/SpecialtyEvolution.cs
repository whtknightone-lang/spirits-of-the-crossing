
using UnityEngine;

public class SpecialtyEvolution : MonoBehaviour
{
    public SpecialtyProfile profile;
    public IntentSystem intent;
    public float growthRate = 0.05f;

    void Update()
    {
        if (profile == null || intent == null) return;

        float dt = Time.deltaTime * growthRate;

        switch (intent.currentIntent)
        {
            case "guide":
                profile.specialties.guide = Mathf.Clamp01(profile.specialties.guide + dt);
                break;
            case "create":
                profile.specialties.create = Mathf.Clamp01(profile.specialties.create + dt);
                break;
            case "protect":
                profile.specialties.protect = Mathf.Clamp01(profile.specialties.protect + dt);
                break;
            case "explore":
                profile.specialties.explore = Mathf.Clamp01(profile.specialties.explore + dt);
                break;
            case "harmonize":
                profile.specialties.harmonize = Mathf.Clamp01(profile.specialties.harmonize + dt);
                break;
            case "trickster":
                profile.specialties.trickster = Mathf.Clamp01(profile.specialties.trickster + dt);
                break;
        }
    }
}
