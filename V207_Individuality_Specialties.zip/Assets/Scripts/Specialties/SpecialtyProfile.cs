
using UnityEngine;

[System.Serializable]
public class SpecialtyValues
{
    public float guide;
    public float create;
    public float protect;
    public float explore;
    public float harmonize;
    public float trickster;
}

public class SpecialtyProfile : MonoBehaviour
{
    public SpecialtyValues specialties = new SpecialtyValues();

    public string GetDominantSpecialty()
    {
        float best = specialties.guide;
        string label = "Guide";

        if (specialties.create > best) { best = specialties.create; label = "Create"; }
        if (specialties.protect > best) { best = specialties.protect; label = "Protect"; }
        if (specialties.explore > best) { best = specialties.explore; label = "Explore"; }
        if (specialties.harmonize > best) { best = specialties.harmonize; label = "Harmonize"; }
        if (specialties.trickster > best) { best = specialties.trickster; label = "Trickster"; }

        return label;
    }
}
