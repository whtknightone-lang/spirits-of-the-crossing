
using UnityEngine;

public class V207IntegrationManager : MonoBehaviour
{
    public IndividualIdentity identity;
    public IntentSystem intent;
    public SpecialtyProfile specialties;
    public SpecialtyEvolution evolution;
    public CreativeExpression creativity;

    void Awake()
    {
        if (identity == null) identity = gameObject.AddComponent<IndividualIdentity>();
        if (intent == null) intent = gameObject.AddComponent<IntentSystem>();
        if (specialties == null) specialties = gameObject.AddComponent<SpecialtyProfile>();
        if (evolution == null) evolution = gameObject.AddComponent<SpecialtyEvolution>();
        if (creativity == null) creativity = gameObject.AddComponent<CreativeExpression>();

        evolution.profile = specialties;
        evolution.intent = intent;
        creativity.identity = identity;
        creativity.specialties = specialties;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.G)) intent.SetIntent("guide", 0.8f);
        if (Input.GetKeyDown(KeyCode.C)) intent.SetIntent("create", 0.8f);
        if (Input.GetKeyDown(KeyCode.P)) intent.SetIntent("protect", 0.8f);
        if (Input.GetKeyDown(KeyCode.E)) intent.SetIntent("explore", 0.8f);
        if (Input.GetKeyDown(KeyCode.H)) intent.SetIntent("harmonize", 0.8f);
        if (Input.GetKeyDown(KeyCode.T)) intent.SetIntent("trickster", 0.8f);

        if (Input.GetKeyDown(KeyCode.X))
        {
            Debug.Log("Dominant Specialty: " + specialties.GetDominantSpecialty());
            Debug.Log("Creative Expression: " + creativity.Express());
        }
    }
}
