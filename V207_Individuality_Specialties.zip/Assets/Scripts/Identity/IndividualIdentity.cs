
using UnityEngine;

public enum BeingType
{
    Player,
    AI,
    ElderSpirit,
    CompanionSpirit
}

public class IndividualIdentity : MonoBehaviour
{
    public string entityId = "entity";
    public BeingType beingType = BeingType.AI;

    [Range(0f,1f)] public float uniqueness = 0.5f;
    [Range(0f,1f)] public float creativity = 0.5f;
    [Range(0f,1f)] public float intentStrength = 0.5f;
}
