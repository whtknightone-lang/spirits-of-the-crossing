
using UnityEngine;

public class CreativeExpression : MonoBehaviour
{
    public IndividualIdentity identity;
    public SpecialtyProfile specialties;

    public string Express()
    {
        if (identity == null || specialties == null) return "...";

        string specialty = specialties.GetDominantSpecialty();

        switch (specialty)
        {
            case "Guide": return "Creates a path, lesson, or signal for others.";
            case "Create": return "Generates a new object, pattern, or possibility.";
            case "Protect": return "Strengthens boundaries and stabilizes fragile spaces.";
            case "Explore": return "Pushes into the unknown and reveals what is hidden.";
            case "Harmonize": return "Brings field coherence and deeper connection.";
            case "Trickster": return "Disrupts habit to reveal a better path.";
            default: return "Expresses something new.";
        }
    }
}
