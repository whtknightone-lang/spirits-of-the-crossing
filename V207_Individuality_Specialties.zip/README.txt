
V207 Individuality + Evolving Specialties

Purpose:
Everyone becomes more distinct over time:
- AI
- Elder spirits
- Companion spirits
- Players

Core ideas:
- each being has intent
- each being has creative tendency
- specialties evolve through repeated action and resonance
- shared world, individual becoming
