
using UnityEngine;

public class SocialResonanceSense : MonoBehaviour
{
    public float nearbyResonance;

    void Update()
    {
        nearbyResonance = Mathf.PingPong(Time.time * 0.1f, 1f);
    }
}
