
using UnityEngine;

public class PersonalMeaningSystem : MonoBehaviour
{
    public float meaning;
    public float preferenceBias = 0.5f;

    public void Register(float experience)
    {
        meaning += experience * preferenceBias;
    }
}
