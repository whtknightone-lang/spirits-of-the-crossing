
using UnityEngine;

public class EternalResonancePlayer : MonoBehaviour
{
    [Range(0f,1f)] public float sourceConnection = 1.0f;
    public float personalExpression = 0.3f;
    public float alignment;

    void Update()
    {
        alignment = sourceConnection * (1f - personalExpression);
    }
}
