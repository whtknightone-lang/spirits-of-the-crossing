
using UnityEngine;

public class V158Integration : MonoBehaviour
{
    void Start()
    {
        AddIfMissing<EternalResonancePlayer>();
        AddIfMissing<SharedResonanceSystem>();
        AddIfMissing<SocialResonanceSense>();
        AddIfMissing<PersonalMeaningSystem>();
    }

    void AddIfMissing<T>() where T : Component
    {
        if (FindObjectOfType<T>() == null)
            gameObject.AddComponent<T>();
    }
}
