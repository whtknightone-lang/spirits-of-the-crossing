
using UnityEngine;
using System.Collections.Generic;

public class SharedResonanceSystem : MonoBehaviour
{
    public List<float> playerSignals = new List<float>();
    public float sharedField;

    void Update()
    {
        if (playerSignals.Count == 0) return;

        float sum = 0f;
        foreach (var s in playerSignals) sum += s;

        sharedField = sum / playerSignals.Count;
    }
}
