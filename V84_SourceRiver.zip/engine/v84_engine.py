
import pygame
from systems.ecosystem import Ecosystem
from systems.source_river import SourceRiverSystem
from systems.player import PlayerSystem

class V84Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.source=SourceRiverSystem(size)
        self.player=PlayerSystem(self.ecosystem, self.source)

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(60):
            self.ecosystem.spawn_entity()

    def handle_key(self,key):
        self.player.handle_key(key)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.source.update(self.ecosystem)
        self.player.update()

    def render(self,screen):
        screen.fill((10,10,30))
        scale=700/self.size

        # draw source river nodes
        for node in self.source.nodes:
            x=int(node[1]*scale)+40
            y=int(node[0]*scale)+40
            pygame.draw.circle(screen,(100,200,255),(x,y),2)

        # draw entities
        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            s=e.get("source_connection",0)
            color=(100, int(100+155*s), 255)
            pygame.draw.circle(screen,color,(x,y),4)

        if self.player.selected:
            e=self.player.selected
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40
            pygame.draw.circle(screen,(255,255,255),(x,y),8,1)

        y=760
        lines=[
            "V84 Source River System",
            "Click select | 1 meditate | 2 release",
            f"Entities: {len(self.ecosystem.entities)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
