
import pygame
from engine.v84_engine import V84Engine

pygame.init()
screen = pygame.display.set_mode((1500,960))
clock = pygame.time.Clock()

engine = V84Engine(128)

running=True
while running:
    dt=clock.tick(60)/1000.0
    for e in pygame.event.get():
        if e.type==pygame.QUIT:
            running=False
        elif e.type==pygame.KEYDOWN:
            engine.handle_key(e.key)

    engine.update(dt)
    engine.render(screen)
    pygame.display.flip()

pygame.quit()
