
import random

class SourceRiverSystem:
    def __init__(self,size):
        self.size=size
        self.nodes=[
            [random.random()*size, random.random()*size]
            for _ in range(80)
        ]

    def update(self,eco):
        for e in eco.entities:
            # proximity to river increases connection
            for node in self.nodes:
                dx=e["pos"][0]-node[0]
                dy=e["pos"][1]-node[1]
                dist=(dx*dx+dy*dy)**0.5

                if dist<5:
                    e["source_connection"] += 0.01

            e["source_connection"] = min(1.0, e["source_connection"])
