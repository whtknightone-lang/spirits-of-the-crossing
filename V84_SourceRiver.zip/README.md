
# V84+ Source River Meditation System

Adds:
- a flowing "source river" through the world
- entities can connect to it through proximity or meditation
- connection increases awareness and potential

Concept:
The source is always present—
flowing through everything, waiting to be touched.
