
# V67 Source Pinch-Off + Focus System

Adds:
- entities can "pinch off" from source into focused states
- focus increases learning intensity
- returning to source reduces focus

Concept:
Source → Focus (limitation) → Deep Learning → Return → Integration
