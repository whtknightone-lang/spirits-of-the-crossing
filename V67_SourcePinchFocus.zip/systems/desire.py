
class DesireSystem:
    def update(self,eco):
        for e in eco.entities:
            if e["focus"] < 0.3:
                e["desire"] += 0.01
            else:
                e["desire"] -= 0.005
            e["desire"]=max(0,min(1,e["desire"]))
