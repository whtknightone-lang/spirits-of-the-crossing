
import pygame

class PlayerControlSystem:
    def __init__(self,eco,focus_system):
        self.eco=eco
        self.focus_system=focus_system
        self.selected=None

    def handle_key(self,key):
        if not self.selected: return

        if key==pygame.K_1:
            # pinch off from source → increase focus
            self.selected["focus"] = min(1.0, self.selected["focus"] + 0.2)

        if key==pygame.K_2:
            # release back to source → reduce focus
            self.selected["focus"] = max(0.0, self.selected["focus"] - 0.3)

    def update(self,eco):
        mouse=pygame.mouse.get_pressed()
        if mouse[0]:
            mx,my=pygame.mouse.get_pos()
            closest=None
            dist=9999
            for e in eco.entities:
                dx=mx-(e["pos"][1]*5+40)
                dy=my-(e["pos"][0]*5+40)
                d=dx*dx+dy*dy
                if d<dist:
                    dist=d
                    closest=e
            self.selected=closest
