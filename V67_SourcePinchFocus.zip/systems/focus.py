
class FocusSystem:
    def update(self,eco):
        for e in eco.entities:
            # deeper focus increases learning intensity
            e["learning"] += e.get("focus",0) * 0.02

            # natural decay back to source
            e["focus"] *= 0.98
