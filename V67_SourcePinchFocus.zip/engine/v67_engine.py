
import pygame
from systems.ecosystem import Ecosystem
from systems.desire import DesireSystem
from systems.focus import FocusSystem
from systems.player_control import PlayerControlSystem

class V67Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.desire=DesireSystem()
        self.focus=FocusSystem()
        self.player=PlayerControlSystem(self.ecosystem, self.focus)

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(50):
            self.ecosystem.spawn_entity()

    def handle_key(self,key):
        self.player.handle_key(key)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.desire.update(self.ecosystem)
        self.focus.update(self.ecosystem)
        self.player.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            focus=e.get("focus",0)
            desire=e.get("desire",0)

            color=(int(100+focus*155), int(100+desire*155), 255-int(focus*200))
            pygame.draw.circle(screen,color,(x,y),4)

        if self.player.selected:
            e=self.player.selected
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40
            pygame.draw.circle(screen,(255,255,255),(x,y),8,1)

        y=760
        lines=[
            "V67 Source Pinch-Off + Focus",
            "Click select | 1 pinch (focus) | 2 release (return)",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Selected focus: {round(self.player.selected.get('focus',0),2) if self.player.selected else 0}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
