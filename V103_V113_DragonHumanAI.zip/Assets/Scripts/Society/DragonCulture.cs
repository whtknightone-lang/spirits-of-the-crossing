
using UnityEngine;

namespace ArtificialUniverse.Society
{
    public class DragonCulture : MonoBehaviour
    {
        public float sharedHarmony;

        public void UpdateCulture(float harmony)
        {
            sharedHarmony = Mathf.Lerp(sharedHarmony, harmony, Time.deltaTime);
        }
    }
