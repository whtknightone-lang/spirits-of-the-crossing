
using UnityEngine;

namespace ArtificialUniverse.Core
{
    public class StructureSystem : MonoBehaviour
    {
        public GameObject structurePrefab;

        public void CreateStructure(Vector3 position)
        {
            if (structurePrefab == null) return;
            Instantiate(structurePrefab, position, Quaternion.identity);
        }
    }
