
using UnityEngine;
using ArtificialUniverse.Evolution;
using ArtificialUniverse.Players;

namespace ArtificialUniverse.Core
{
    public class V113MasterGameManager : MonoBehaviour
    {
        public SpeciesEvolution evolution;
        public StructureSystem structures;

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.T))
            {
                evolution?.SpawnNextGeneration(Vector3.zero);
            }

            if (Input.GetKeyDown(KeyCode.Y))
            {
                structures?.CreateStructure(new Vector3(Random.Range(-10,10),0,Random.Range(-10,10)));
            }
        }
    }
