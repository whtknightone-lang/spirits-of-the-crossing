
using UnityEngine;

namespace ArtificialUniverse.Players
{
    public class AIPlayerController : MonoBehaviour
    {
        public Vector3 target;

        void Update()
        {
            transform.position = Vector3.MoveTowards(transform.position, target, Time.deltaTime * 5f);

            if (Vector3.Distance(transform.position, target) < 1f)
            {
                target = new Vector3(Random.Range(-20,20),0,Random.Range(-20,20));
            }
        }
    }
