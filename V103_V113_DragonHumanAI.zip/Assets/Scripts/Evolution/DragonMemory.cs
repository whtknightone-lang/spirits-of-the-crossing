
using System.Collections.Generic;
using UnityEngine;

namespace ArtificialUniverse.Evolution
{
    public class DragonMemory : MonoBehaviour
    {
        public List<float> pastRewards = new();
        public float identity;

        public void Record(float reward)
        {
            pastRewards.Add(reward);
            if (pastRewards.Count > 50) pastRewards.RemoveAt(0);
            identity = ComputeIdentity();
        }

        float ComputeIdentity()
        {
            if (pastRewards.Count == 0) return 0f;
            float sum = 0f;
            foreach (var r in pastRewards) sum += r;
            return sum / pastRewards.Count;
        }
    }
