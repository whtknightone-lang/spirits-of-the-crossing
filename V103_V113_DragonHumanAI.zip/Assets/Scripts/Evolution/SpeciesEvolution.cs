
using UnityEngine;

namespace ArtificialUniverse.Evolution
{
    public class SpeciesEvolution : MonoBehaviour
    {
        public GameObject dragonPrefab;

        public void SpawnNextGeneration(Vector3 position)
        {
            if (dragonPrefab == null) return;

            var d = Instantiate(dragonPrefab, position, Quaternion.identity);
            var lineage = d.GetComponent<DragonLineage>();
            if (lineage != null)
            {
                lineage.generation++;
                lineage.Mutate();
            }
        }
    }
