
using UnityEngine;

namespace ArtificialUniverse.Evolution
{
    public class DragonLineage : MonoBehaviour
    {
        public int generation;
        public float mutationFactor = 0.1f;

        public void Mutate()
        {
            mutationFactor += Random.Range(-0.02f, 0.02f);
            mutationFactor = Mathf.Clamp(mutationFactor, 0f, 1f);
        }
    }
