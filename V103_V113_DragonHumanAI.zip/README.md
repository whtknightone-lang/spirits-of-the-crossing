
# V103–V113 Dragons → Human/AI Player Unlock

Adds:
- Dragon memory + lineage (V103–V106)
- Culture + trait evolution (V107–V110)
- Species spawning + mutation (V111–V113)
- Human player + AI player controllers
- New structure system for growth

Core idea:
Life evolves → intelligence emerges → player layers appear → structures grow worlds
