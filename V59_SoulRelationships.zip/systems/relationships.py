
import math

class RelationshipSystem:
    def __init__(self):
        self.bonds={}

    def update(self,eco):
        entities=eco.entities
        for i in range(len(entities)):
            for j in range(i+1,len(entities)):
                a=entities[i]
                b=entities[j]

                dx=a["pos"][0]-b["pos"][0]
                dy=a["pos"][1]-b["pos"][1]
                d=math.sqrt(dx*dx+dy*dy)

                key=(a["id"],b["id"])
                val=self.bonds.get(key,0)

                if d<10:
                    val+=0.01
                else:
                    val-=0.005

                val=max(0,min(1,val))
                self.bonds[key]=val
