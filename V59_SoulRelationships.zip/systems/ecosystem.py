
import random, uuid

class Ecosystem:
    def __init__(self,size):
        self.size=size
        self.entities=[]
        self.entities_by_id={}

    def spawn_entity(self):
        eid=str(uuid.uuid4())
        e={
            "id":eid,
            "pos":[random.random()*self.size,random.random()*self.size],
            "experience":0.0,
            "soul_id":None
        }
        self.entities.append(e)
        self.entities_by_id[eid]=e

    def update(self,dt):
        for e in self.entities:
            e["pos"][0]+=random.uniform(-1,1)*dt*10
            e["pos"][1]+=random.uniform(-1,1)*dt*10
            e["experience"]+=0.01
