
import uuid

class SoulSystem:
    def __init__(self):
        self.archive={}

    def update(self,eco):
        for e in eco.entities:
            if e["soul_id"] is None:
                sid=str(uuid.uuid4())
                e["soul_id"]=sid
                self.archive[sid]={"history":[]}

            self.archive[e["soul_id"]]["history"].append(e["experience"])
