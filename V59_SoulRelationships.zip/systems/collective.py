
class CollectivePurposeSystem:
    def __init__(self):
        self.groups=[]

    def update(self,eco,relationships):
        self.groups=[]

        for (a,b),v in relationships.bonds.items():
            if v>0.6:
                self.groups.append((a,b))

        # assign purpose
        for e in eco.entities:
            linked=False
            for g in self.groups:
                if e["id"] in g:
                    linked=True
                    break

            e["purpose"]="group" if linked else "solo"
