
# V59 Soul Relationships System

Adds:
- persistent relationship bonds between entities
- bond strength grows with proximity + time
- collective groups form from strong bonds
- shared purpose emerges

This creates:
- friendships
- alliances
- emergent social structures
