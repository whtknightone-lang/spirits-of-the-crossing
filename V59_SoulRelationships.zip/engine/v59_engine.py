
import pygame
from systems.ecosystem import Ecosystem
from systems.soul import SoulSystem
from systems.relationships import RelationshipSystem
from systems.collective import CollectivePurposeSystem

class V59Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.souls=SoulSystem()
        self.relationships=RelationshipSystem()
        self.collective=CollectivePurposeSystem()
        self.font=pygame.font.SysFont("arial",16)

        # spawn initial entities
        for _ in range(40):
            self.ecosystem.spawn_entity()

    def update(self,dt):
        self.ecosystem.update(dt)
        self.souls.update(self.ecosystem)
        self.relationships.update(self.ecosystem)
        self.collective.update(self.ecosystem, self.relationships)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        # draw relationships (lines)
        for (a_id,b_id),val in self.relationships.bonds.items():
            if val < 0.3: continue
            a=self.ecosystem.entities_by_id.get(a_id)
            b=self.ecosystem.entities_by_id.get(b_id)
            if not a or not b: continue

            ax=int(a["pos"][1]*scale)+40
            ay=int(a["pos"][0]*scale)+40
            bx=int(b["pos"][1]*scale)+40
            by=int(b["pos"][0]*scale)+40

            color=(100,200,255) if val>0.6 else (200,120,120)
            pygame.draw.line(screen,color,(ax,ay),(bx,by),1)

        # draw entities
        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            purpose=e.get("purpose","none")
            if purpose=="group": color=(120,255,180)
            elif purpose=="solo": color=(255,140,140)
            else: color=(200,200,200)

            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V59 Soul Relationships System",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Bonds: {len(self.relationships.bonds)}",
            f"Groups: {len(self.collective.groups)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
