
using UnityEngine;

public class AIHierarchy : MonoBehaviour
{
    public string level; // Animal, Instructor, Elder

    public string Describe()
    {
        return "AI Level: " + level;
    }
}
