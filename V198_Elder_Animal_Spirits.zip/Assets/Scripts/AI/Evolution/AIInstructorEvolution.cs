
using UnityEngine;

public class AIInstructorEvolution : MonoBehaviour
{
    public float teachingSuccess;
    public string evolutionState = "Base";

    void Update()
    {
        if (teachingSuccess > 0.8f)
            evolutionState = "Master";
        else if (teachingSuccess > 0.4f)
            evolutionState = "Advanced";
    }
}
