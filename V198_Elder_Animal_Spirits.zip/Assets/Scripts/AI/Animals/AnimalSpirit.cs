
using UnityEngine;

public class AnimalSpirit : MonoBehaviour
{
    public string animalType;

    public void Act()
    {
        switch (animalType)
        {
            case "Wolf":
                Debug.Log("Guides through instinct and direction.");
                break;
            case "Eagle":
                Debug.Log("Shows vision from above.");
                break;
            case "Dolphin":
                Debug.Log("Teaches flow and play.");
                break;
        }
    }
}
