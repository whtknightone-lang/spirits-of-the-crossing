
using UnityEngine;

public class ElderSpirit : MonoBehaviour
{
    public float wisdom;
    public float presence;

    public string Guide()
    {
        if (wisdom > 0.7f)
            return "All paths are one when seen clearly.";
        return "Continue. You are close.";
    }
}
