
V198 Elder Spirits + Animal Spirits + Instructor Evolution

Adds:
- Elder spirit system (higher intelligence guides)
- Animal spirit companions (instinct-based learning)
- Instructor evolution based on teaching success

Core Idea:
AI now exists across tiers:
Animal → Instructor → Elder Spirit
