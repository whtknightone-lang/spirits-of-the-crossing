
import pygame
from systems.ecosystem import Ecosystem
from systems.identity import IdentitySystem
from systems.learning import LearningSystem

class V57Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.identity=IdentitySystem()
        self.learning=LearningSystem()
        self.font=pygame.font.SysFont("arial",16)

    def handle_key(self,key):
        if key==pygame.K_1:
            self.ecosystem.spawn_entity("explorer")
        if key==pygame.K_2:
            self.ecosystem.spawn_entity("creator")
        if key==pygame.K_3:
            self.ecosystem.spawn_entity("challenger")

    def update(self,dt):
        self.ecosystem.update(dt)
        self.learning.update(self.ecosystem)
        self.identity.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            # identity color
            i=e.get("identity","none")
            if i=="explorer": color=(120,180,255)
            elif i=="creator": color=(120,255,180)
            elif i=="challenger": color=(255,140,140)
            else: color=(200,200,200)

            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V57 Unconstrained Learning System",
            "1 explorer | 2 creator | 3 challenger",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Avg learning: {self.learning.avg:.3f}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
