
class LearningSystem:
    def __init__(self):
        self.avg=0.0

    def update(self,eco):
        total=0
        for e in eco.entities:
            # learning increases from both success AND mistakes
            learning = e["experience"] + e["mistakes"]*0.5
            e["learning"]=learning

            # no penalty ceiling (unconstrained growth)
            e["experience"]+=0.005

            total+=learning

        if eco.entities:
            self.avg=total/len(eco.entities)
