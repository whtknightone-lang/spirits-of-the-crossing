
class IdentitySystem:
    def update(self,eco):
        for e in eco.entities:
            # identity evolves freely based on experience
            if e["learning"]>2:
                e["identity"]="creator"
            elif e["mistakes"]>5:
                e["identity"]="challenger"
            else:
                e["identity"]="explorer"
