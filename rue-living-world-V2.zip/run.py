
print("Running RUE Living World Engine V2")

def step():
    print("Step executed in V2")

if __name__ == "__main__":
    for i in range(5):
        step()
