
# RUE Living World Engine V2

This is version V2 of the unified Living World Engine.

Includes progressively:
V1: Core unified loop
V2: Environment + spirits integration
V3: Lineage + territory + roles
V4: Mythology + history tracking
V5: Full playable prototype hooks

Run:
python run.py
