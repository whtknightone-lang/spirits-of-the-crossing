
V205 Expanded + V206 Individual Realities

V205:
- Source Expansion (real world effects)
- Dynamic wanted states
- Narrative growth

V206:
- Individual perception layers
- Same world, different realities
- Player/AI-specific interpretation

Core Idea:
Reality is shared structure + personal perception layer.
