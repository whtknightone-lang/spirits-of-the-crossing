
using UnityEngine;

public class V205V206Manager : MonoBehaviour
{
    public SourceExpansionEngine source;
    public DynamicWantedState wanted;
    public WorldExpansionSpawner spawner;
    public NarrativeEngine narrative;

    public PersonalRealityFilter playerReality;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            source.Evaluate();

            if (source.expansionTriggered)
            {
                string next = wanted.GetNext(source.coherence);
                spawner.Expand();
                narrative.AddEvent("Expanded into: " + next);
            }
        }
    }
}
