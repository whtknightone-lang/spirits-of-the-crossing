
using UnityEngine;

public class SourceExpansionEngine : MonoBehaviour
{
    public float coherence;
    public float clarity;
    public float threshold = 0.7f;

    public bool expansionTriggered;

    public void Evaluate()
    {
        expansionTriggered = coherence > threshold && clarity > threshold;

        if (expansionTriggered)
        {
            Debug.Log("Source expanding reality...");
        }
    }
}
