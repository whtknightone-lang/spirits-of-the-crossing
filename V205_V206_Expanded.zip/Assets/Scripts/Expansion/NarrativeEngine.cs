
using UnityEngine;
using System.Collections.Generic;

public class NarrativeEngine : MonoBehaviour
{
    public List<string> history = new List<string>();

    public void AddEvent(string e)
    {
        history.Add(e);
        Debug.Log("Narrative: " + e);
    }
}
