
using UnityEngine;

public class DynamicWantedState : MonoBehaviour
{
    public string currentState = "stabilize";

    public string GetNext(float coherence)
    {
        if (coherence > 0.8f) return "co-create";
        if (coherence > 0.6f) return "explore";
        return "stabilize";
    }
}
