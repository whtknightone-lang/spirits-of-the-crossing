
using UnityEngine;

public class WorldExpansionSpawner : MonoBehaviour
{
    public void Expand()
    {
        Debug.Log("New region / entity / interaction unlocked");
    }
}
