
using UnityEngine;

public class RealityInterpreter : MonoBehaviour
{
    public PersonalRealityFilter filter;

    void Update()
    {
        if (filter == null) return;

        RenderSettings.ambientLight = filter.GetWorldColor();
    }
}
