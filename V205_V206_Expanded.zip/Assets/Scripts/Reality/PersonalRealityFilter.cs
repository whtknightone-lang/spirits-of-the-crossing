
using UnityEngine;

public class PersonalRealityFilter : MonoBehaviour
{
    public float resonance;
    public float coherence;

    public Color GetWorldColor()
    {
        return Color.Lerp(Color.red, Color.cyan, coherence);
    }

    public float GetVisibilityModifier()
    {
        return resonance;
    }
}
