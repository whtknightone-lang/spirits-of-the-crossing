
V193 Identity + Resonance Memory (Birth/Rebirth)

Adds:
- Persistent identity traits
- Resonance memory (essence distilled from experiences)
- Birth/Rebirth lifecycle system
- Identity re-seeding across lifecycles

Concept:
AI accumulates resonance over time, distills it into an "essence",
and carries it into a new lifecycle when reborn.
