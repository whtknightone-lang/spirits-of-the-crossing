
using UnityEngine;

[System.Serializable]
public class Traits
{
    public float curiosity;
    public float stability;
    public float connection;
}

public class AIIdentity : MonoBehaviour
{
    public string id;
    public Traits traits = new Traits();
}
