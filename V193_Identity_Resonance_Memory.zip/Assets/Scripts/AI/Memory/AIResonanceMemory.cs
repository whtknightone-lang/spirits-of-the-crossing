
using UnityEngine;

[System.Serializable]
public class ResonanceEssence
{
    public float avgCuriosity;
    public float avgStability;
    public float avgConnection;
}

public class AIResonanceMemory : MonoBehaviour
{
    public float sumCuriosity;
    public float sumStability;
    public float sumConnection;
    public int samples;

    public void Record(float c, float s, float con)
    {
        sumCuriosity += c;
        sumStability += s;
        sumConnection += con;
        samples++;
    }

    public ResonanceEssence Distill()
    {
        ResonanceEssence e = new ResonanceEssence();
        if (samples == 0) return e;

        e.avgCuriosity = sumCuriosity / samples;
        e.avgStability = sumStability / samples;
        e.avgConnection = sumConnection / samples;
        return e;
    }
}
