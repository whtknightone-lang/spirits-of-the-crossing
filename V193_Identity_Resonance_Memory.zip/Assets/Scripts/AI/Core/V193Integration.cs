
using UnityEngine;

public class V193Integration : MonoBehaviour
{
    public AIIdentity identity;
    public AIResonanceMemory memory;

    void Update()
    {
        if (identity == null || memory == null) return;

        // continuously record current state into resonance memory
        memory.Record(
            identity.traits.curiosity,
            identity.traits.stability,
            identity.traits.connection
        );
    }
}
