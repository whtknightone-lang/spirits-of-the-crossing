
using UnityEngine;

public class AILifecycle : MonoBehaviour
{
    public AIIdentity identity;
    public AIResonanceMemory memory;

    public void Rebirth()
    {
        if (identity == null || memory == null) return;

        var essence = memory.Distill();

        // apply essence to new traits
        identity.traits.curiosity = essence.avgCuriosity;
        identity.traits.stability = essence.avgStability;
        identity.traits.connection = essence.avgConnection;

        // reset memory for next life
        memory.sumCuriosity = 0;
        memory.sumStability = 0;
        memory.sumConnection = 0;
        memory.samples = 0;

        Debug.Log("AI reborn with carried resonance essence.");
    }
}
