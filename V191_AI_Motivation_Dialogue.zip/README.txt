
V191 AI Motivation + Dialogue Layer

Adds:
- AI motivation system (desire-driven behavior)
- basic dialogue generation scaffold
- memory tracking (short-term)
- behavior selection based on internal state

Goal:
Turn AI from reactive entities into self-motivated agents that can speak.
