
using UnityEngine;

public class AIDialogue : MonoBehaviour
{
    public AIMotivation motivation;

    public string GenerateLine()
    {
        if (motivation == null) return "...";

        switch (motivation.dominantDrive)
        {
            case "Explore":
                return "I feel something interesting nearby...";
            case "Stabilize":
                return "Let me help balance this space.";
            case "Connect":
                return "I sense you. Let's move together.";
            default:
                return "...";
        }
    }
}
