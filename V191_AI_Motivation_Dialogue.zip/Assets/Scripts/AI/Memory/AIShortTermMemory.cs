
using UnityEngine;
using System.Collections.Generic;

public class AIShortTermMemory : MonoBehaviour
{
    public List<string> recentEvents = new List<string>();

    public void Remember(string evt)
    {
        recentEvents.Add(evt);
        if (recentEvents.Count > 10)
            recentEvents.RemoveAt(0);
    }
}
