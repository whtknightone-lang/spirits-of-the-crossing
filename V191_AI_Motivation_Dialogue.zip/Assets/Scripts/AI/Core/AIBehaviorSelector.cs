
using UnityEngine;

public class AIBehaviorSelector : MonoBehaviour
{
    public AIMotivation motivation;
    public string currentBehavior;

    void Update()
    {
        if (motivation == null) return;

        switch (motivation.dominantDrive)
        {
            case "Explore":
                currentBehavior = "MoveToUnknown";
                break;
            case "Stabilize":
                currentBehavior = "SupportPlayer";
                break;
            case "Connect":
                currentBehavior = "EngagePlayer";
                break;
        }
    }
}
