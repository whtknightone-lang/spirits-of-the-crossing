
using UnityEngine;

public class AIMotivation : MonoBehaviour
{
    public float curiosity;
    public float stability;
    public float connection;

    public string dominantDrive;

    void Update()
    {
        if (curiosity > stability && curiosity > connection)
            dominantDrive = "Explore";
        else if (stability > connection)
            dominantDrive = "Stabilize";
        else
            dominantDrive = "Connect";
    }
}
