
V189 Demo Slice

This is a minimal playable experience structure:

Flow:
Enter cave → AI companion → interact → solve puzzle → unlock portal

Instructions:
1. Open in Unity
2. Create empty scene and attach scripts
3. Assign references (player, AI, nodes)

This is a scaffold to quickly prototype the experience loop.
