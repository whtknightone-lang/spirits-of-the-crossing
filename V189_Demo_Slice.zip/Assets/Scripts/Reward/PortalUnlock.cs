
using UnityEngine;

public class PortalUnlock : MonoBehaviour
{
    public DemoPuzzleManager puzzle;
    public GameObject portal;

    void Update()
    {
        if (puzzle != null && puzzle.complete)
        {
            portal.SetActive(true);
        }
    }
}
