
using UnityEngine;

public class EnvironmentFeedback : MonoBehaviour
{
    public float intensity;

    void Update()
    {
        RenderSettings.ambientIntensity = Mathf.Lerp(0.5f, 2f, intensity);
    }
}
