
using UnityEngine;

public class DemoPuzzleNode : MonoBehaviour
{
    public float value;
    public bool solved;

    void Update()
    {
        if (value > 0.8f)
            solved = true;
    }

    public void Activate(float amount)
    {
        value += amount;
    }
}
