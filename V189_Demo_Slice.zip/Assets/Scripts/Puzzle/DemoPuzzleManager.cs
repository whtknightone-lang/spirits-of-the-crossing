
using UnityEngine;

public class DemoPuzzleManager : MonoBehaviour
{
    public DemoPuzzleNode[] nodes;
    public bool complete;

    void Update()
    {
        int solved = 0;
        foreach (var n in nodes)
            if (n.solved) solved++;

        complete = solved == nodes.Length;

        if (complete)
            Debug.Log("Puzzle Complete!");
    }
}
