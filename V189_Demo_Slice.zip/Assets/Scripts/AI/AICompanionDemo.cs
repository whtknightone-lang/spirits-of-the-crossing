
using UnityEngine;

public class AICompanionDemo : MonoBehaviour
{
    public Transform player;

    void Update()
    {
        if (player == null) return;

        Vector3 target = player.position + new Vector3(1,0,1);
        transform.position = Vector3.Lerp(transform.position, target, Time.deltaTime);
        transform.LookAt(player);
    }
}
