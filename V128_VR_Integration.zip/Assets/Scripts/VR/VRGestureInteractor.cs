
using UnityEngine;

public class VRGestureInteractor : MonoBehaviour
{
    public Transform leftHand;
    public Transform rightHand;

    void Update()
    {
        if (leftHand == null || rightHand == null) return;

        float d = Vector3.Distance(leftHand.position, rightHand.position);

        if (d < 0.25f)
            Debug.Log("Gesture detected");
    }
}
