
using UnityEngine;

public class VRMeditationSystem : MonoBehaviour
{
    public float calm = 0f;

    void Update()
    {
        if (Input.GetKey(KeyCode.M))
            calm = Mathf.Clamp01(calm + Time.deltaTime * 0.2f);
        else
            calm = Mathf.Clamp01(calm - Time.deltaTime * 0.1f);
    }
}
