
using UnityEngine;

public class VRPlayerRig : MonoBehaviour
{
    public Transform head;
    public Transform leftHand;
    public Transform rightHand;

    public float moveSpeed = 2.5f;

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        Vector3 forward = head != null ? head.forward : transform.forward;
        forward.y = 0f;
        forward.Normalize();

        Vector3 right = new Vector3(forward.z, 0f, -forward.x);
        Vector3 move = (forward * v + right * h) * moveSpeed * Time.deltaTime;

        transform.position += move;
    }
}
