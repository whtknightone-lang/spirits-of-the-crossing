
using UnityEngine;

public class V128VRIntegration : MonoBehaviour
{
    void Start()
    {
        if (FindObjectOfType<VRPlayerRig>() == null)
            gameObject.AddComponent<VRPlayerRig>();

        if (FindObjectOfType<VRMeditationSystem>() == null)
            gameObject.AddComponent<VRMeditationSystem>();

        if (FindObjectOfType<VRGestureInteractor>() == null)
            gameObject.AddComponent<VRGestureInteractor>();
    }
}
