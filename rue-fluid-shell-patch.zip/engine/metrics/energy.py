import numpy as np

def mean_energy(energies):
    return float(np.mean(energies))
