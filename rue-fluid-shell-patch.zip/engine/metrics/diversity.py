import numpy as np

def diversity(phases):
    return float(np.std(phases))
