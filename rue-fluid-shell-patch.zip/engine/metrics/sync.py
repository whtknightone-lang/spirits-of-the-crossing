import numpy as np

def sync(phases):
    return float(abs(np.mean(np.exp(1j * phases))))
