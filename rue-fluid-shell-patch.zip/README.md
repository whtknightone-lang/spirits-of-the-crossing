# RUE Fluid-Shell Patch

This patch adds a **fluid shell** around the 3D snowflake brain and introduces
an **energy core** at the center to drive learning and positive reinforcement.

## What it adds

- fluid shell state coupled to the upsilon outer layer
- shell diffusion for smoother boundary adaptation
- center energy core that accumulates/decays
- core-driven learning and reinforcement bias
- metrics for shell coherence and core energy

## Design intent

- snowflake core = structure / identity
- fluid shell = adaptive boundary / smooth response
- energy core = reinforcement engine / motivational center

## Run

```bash
pip install -r requirements.txt
python experiments/run_fluid_shell_viewer.py
```
