
using UnityEngine;
public class EmotionInfluence : MonoBehaviour
{
    public EmotionalField field;
    public float GetInfluence(){ return field.joy - field.fear; }
}
