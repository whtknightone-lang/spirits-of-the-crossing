
using UnityEngine;
public class EmotionalField : MonoBehaviour
{
    public float joy=0.5f, fear=0.2f, curiosity=0.5f, anger=0.1f, coherence=0.5f;
}
