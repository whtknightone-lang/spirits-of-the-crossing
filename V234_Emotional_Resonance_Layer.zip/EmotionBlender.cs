
using UnityEngine;
public class EmotionBlender : MonoBehaviour
{
    public EmotionalField self;
}
