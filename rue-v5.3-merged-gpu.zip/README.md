
RUE V5.3+ Merged GPU Engine

Includes:
- Fully tensor-based agent system
- Environment integrated into tensors
- Lineage + reproduction on GPU
- Single unified step loop

Run:
pip install torch
python run.py
