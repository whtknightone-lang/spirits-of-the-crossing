
import torch

class GPUWorld:
    def __init__(self, n=10000):
        self.n = n
        self.energy = torch.ones(n)
        self.phase = torch.rand(n)
        self.lineage = torch.zeros(n)
        self.generation = torch.zeros(n)
        self.biome = torch.randint(0, 5, (n,))  # 0 forest,1 desert,2 water,3 plains,4 ruins

    def step(self):
        # oscillator
        self.phase += 0.05

        # environment effects
        self.energy += (self.biome == 0) * 0.01
        self.energy -= (self.biome == 1) * 0.01

        # base dynamics
        self.energy += 0.01 * torch.sin(self.phase)
        self.energy *= 0.999

        # reproduction
        mask = self.energy > 2.0
        if mask.sum() > 0:
            new_energy = self.energy[mask] * 0.5
            self.energy[mask] *= 0.5

            self.energy = torch.cat([self.energy, new_energy])
            self.phase = torch.cat([self.phase, self.phase[mask]])
            self.lineage = torch.cat([self.lineage, self.lineage[mask]])
            self.generation = torch.cat([self.generation, self.generation[mask] + 1])
            self.biome = torch.cat([self.biome, self.biome[mask]])
