
from engine import GPUWorld

world = GPUWorld(20000)

for i in range(200):
    world.step()
    if i % 20 == 0:
        print("step", i, "agents", len(world.energy), "avg energy", world.energy.mean().item())
