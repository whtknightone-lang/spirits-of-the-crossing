# Demo wrapper that expects an existing Universe implementation.
# It creates a tiny mock universe if the real one is not present.

try:
    from engine.simulation.universe import Universe
except Exception:
    class MockPlanet:
        def __init__(self, index):
            self.index = index
            self.energy = 1.0 + index * 0.2
            self.traits = {"type": ["CHAOTIC","STABLE","FERTILE","HARSH"][index % 4]}

    class MockAgent:
        def __init__(self, planet_id, lineage_id):
            self.planet_id = planet_id
            self.lineage_id = lineage_id

    class MockSpirit:
        def __init__(self, level, role, planet_id=None):
            self.level = level
            self.role = role
            self.planet_id = planet_id

    class Universe:
        def __init__(self):
            self.time = 0
            self.planets = [MockPlanet(i) for i in range(4)]
            self.agents = [MockAgent(i % 4, i % 6) for i in range(40)]
            self.spirits = [MockSpirit("GUARDIAN", "PLANET", i) for i in range(4)]

        def step(self):
            self.time += 1
            for p in self.planets:
                p.energy = max(0.5, min(3.5, p.energy + (0.1 if self.time % 7 == 0 else -0.03)))
            for i, a in enumerate(self.agents):
                if self.time % 13 == 0 and i % 5 == 0:
                    a.lineage_id = (a.lineage_id + 1) % 6

from engine.mythology.mythology_layer import MythologyLayer

u = Universe()
m = MythologyLayer()
m.initialize(u)

for _ in range(120):
    u.step()
    m.step(u)

for e in m.log.latest(15):
    print(f"[{e.step}] {e.category.upper()}: {e.title} | {e.details}")

print()
print(m.summarize())
