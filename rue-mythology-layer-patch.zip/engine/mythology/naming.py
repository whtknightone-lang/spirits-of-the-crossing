ADJECTIVES = [
    "Verdant", "Ashen", "Silent", "Radiant", "Stormborn",
    "Golden", "Twilight", "Rootbound", "Shifting", "Hollow"
]

NOUNS = [
    "Keepers", "Hunters", "Weavers", "Wardens", "Pilgrims",
    "Singers", "Shapers", "Cinders", "Tides", "Bloom"
]

PLANET_TITLES = {
    "CHAOTIC": ["Storm Realm", "Broken Sphere", "Wild Orbit"],
    "STABLE": ["Still Crown", "Order World", "Quiet Dominion"],
    "FERTILE": ["Bloom World", "Green Mother", "Abundant Sphere"],
    "HARSH": ["Ash World", "Hard Crown", "Trial Sphere"],
}

def lineage_name(lineage_id: int) -> str:
    a = ADJECTIVES[lineage_id % len(ADJECTIVES)]
    n = NOUNS[(lineage_id * 3) % len(NOUNS)]
    return f"The {a} {n}"

def planet_epithet(planet_type: str, planet_id: int) -> str:
    choices = PLANET_TITLES.get(planet_type, ["Unknown World"])
    return f"Planet {planet_id}: {choices[planet_id % len(choices)]}"
