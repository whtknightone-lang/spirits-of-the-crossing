from collections import Counter, defaultdict
from engine.mythology.event_log import EventLog
from engine.mythology.naming import lineage_name, planet_epithet
from engine.mythology.planet_history import PlanetHistory
from engine.mythology.spirit_identity import SpiritIdentityTracker

class MythologyLayer:
    def __init__(self):
        self.log = EventLog()
        self.history = PlanetHistory()
        self.spirits = SpiritIdentityTracker()
        self.last_dominant = {}
        self.named_lineages = {}
        self.lineage_peak_counts = defaultdict(int)

    def initialize(self, universe):
        for p in universe.planets:
            ptype = getattr(p, "traits", {}).get("type", "UNKNOWN")
            self.history.start_planet(p.index, planet_epithet(ptype, p.index))
            self.log.add(0, "planet", "Planet awakened", planet_id=p.index, planet_type=ptype)
        if hasattr(universe, "spirits"):
            for i, s in enumerate(universe.spirits):
                self.spirits.register(s, i)

    def step(self, universe):
        step = getattr(universe, "time", 0)

        # dominant lineage tracking by planet
        for p in universe.planets:
            planet_agents = [a for a in universe.agents if a.planet_id == p.index]
            if not planet_agents:
                continue
            counts = Counter(getattr(a, "lineage_id", -1) for a in planet_agents)
            dom_id, dom_count = counts.most_common(1)[0]
            self.lineage_peak_counts[dom_id] = max(self.lineage_peak_counts[dom_id], dom_count)

            if dom_id not in self.named_lineages and dom_id != -1:
                self.named_lineages[dom_id] = lineage_name(dom_id)
                self.log.add(step, "lineage", "A lineage received a name", lineage_id=dom_id, name=self.named_lineages[dom_id])

            if self.last_dominant.get(p.index) != dom_id:
                old = self.last_dominant.get(p.index)
                self.last_dominant[p.index] = dom_id
                name = self.named_lineages.get(dom_id, f"Lineage {dom_id}")
                self.log.add(step, "territory", "Planetary dominance shifted", planet_id=p.index, lineage_id=dom_id, lineage_name=name, previous=old)
                self.history.add_note(p.index, step, f"{name} became dominant.")

            # simple era shift hooks
            energy = getattr(p, "energy", 0.0)
            if energy > 3.0:
                self.history.add_note(p.index, step, "An age of abundance spread across the world.")
            elif energy < 0.8:
                self.history.add_note(p.index, step, "A lean era pressed against every region.")

        # spirit identity evolution
        if hasattr(universe, "spirits"):
            for i, _s in enumerate(universe.spirits):
                self.spirits.note_action(i)
                self.spirits.evolve_title(i)

    def summarize(self):
        lines = []
        lines.append("=== MYTH SUMMARY ===")
        for lineage_id, name in sorted(self.named_lineages.items()):
            peak = self.lineage_peak_counts.get(lineage_id, 0)
            lines.append(f"{name} reached a peak count of {peak}.")
        return "\n".join(lines)
