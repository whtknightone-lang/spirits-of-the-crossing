from collections import defaultdict

class PlanetHistory:
    def __init__(self):
        self.eras = defaultdict(list)
        self.current_era = {}

    def start_planet(self, planet_id: int, title: str):
        self.current_era[planet_id] = {
            "title": title,
            "start_step": 0,
            "notes": []
        }

    def add_note(self, planet_id: int, step: int, note: str):
        if planet_id not in self.current_era:
            self.start_planet(planet_id, f"Planet {planet_id}")
        self.current_era[planet_id]["notes"].append((step, note))

    def shift_era(self, planet_id: int, step: int, new_title: str):
        if planet_id in self.current_era:
            finished = self.current_era[planet_id]
            finished["end_step"] = step
            self.eras[planet_id].append(finished)
        self.current_era[planet_id] = {
            "title": new_title,
            "start_step": step,
            "notes": []
        }
