from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class MythEvent:
    step: int
    category: str
    title: str
    details: Dict[str, Any] = field(default_factory=dict)

class EventLog:
    def __init__(self):
        self.events: List[MythEvent] = []

    def add(self, step: int, category: str, title: str, **details):
        self.events.append(MythEvent(step=step, category=category, title=title, details=details))

    def latest(self, n: int = 10):
        return self.events[-n:]
