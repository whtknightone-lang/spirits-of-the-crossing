class SpiritIdentityTracker:
    def __init__(self):
        self.records = {}

    def register(self, spirit, index: int):
        if index not in self.records:
            self.records[index] = {
                "title": f"{spirit.level.title()} {spirit.role.title()} #{index}",
                "acts": 0,
                "planet_id": getattr(spirit, "planet_id", None),
            }

    def note_action(self, index: int):
        if index in self.records:
            self.records[index]["acts"] += 1

    def evolve_title(self, index: int):
        if index not in self.records:
            return
        acts = self.records[index]["acts"]
        if acts > 100:
            self.records[index]["title"] = "Ancient " + self.records[index]["title"]
        elif acts > 30:
            self.records[index]["title"] = "Elder " + self.records[index]["title"]
