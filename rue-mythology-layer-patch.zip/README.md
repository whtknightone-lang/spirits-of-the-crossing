# RUE Mythology Layer Patch

This patch adds a mythology layer to the RUE world:

- event logging
- lineage naming
- planet history tracking
- spirit identity evolution

It is designed to sit on top of the existing
planet personality + spirit hierarchy + lineage systems.

## What it records

- lineage rises and collapses
- territory shifts
- planetary eras
- spirit influence patterns
- major world events

## Run the demo

```bash
python experiments/run_mythology_demo.py
```

## Notes

This patch also includes hooks for future environmental world-history events:
- cities flooded
- deserts spreading
- forests swallowing ruins

Those events are not fully simulated here, but the event model and
planet-history structure are set up so they can be added cleanly.
