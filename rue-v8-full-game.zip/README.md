
RUE V8 Full Game Experience

Features:
- WASD player movement
- Abilities (heal, disrupt, boost)
- Missions system
- Factions (lineage-based coloring)
- Multi-zone environment
- Score + Level + Objective tracking
- Real-time visualization

Run:
pip install torch matplotlib
python run_v8.py
