
import torch

class World:
    def __init__(self, n=3000):
        self.energy = torch.ones(n)
        self.phase = torch.rand(n)
        self.position = torch.rand(n,2)
        self.velocity = torch.zeros(n,2)
        self.lineage = torch.randint(0,6,(n,))
        self.player_pos = torch.tensor([0.5,0.5])
        self.score = 0
        self.level = 1
        self.mission = "Stabilize Energy Above 1.2"

    def step(self):
        self.velocity += 0.01 * torch.randn_like(self.velocity)
        self.position += self.velocity
        self.position = torch.clamp(self.position,0,1)

        self.phase += 0.05
        self.energy += 0.01 * torch.sin(self.phase)

        # zones
        forest = torch.tensor([0.2,0.2])
        desert = torch.tensor([0.8,0.8])

        dist_f = torch.norm(self.position - forest, dim=1)
        dist_d = torch.norm(self.position - desert, dim=1)

        self.energy += torch.exp(-dist_f*5)*0.01
        self.energy -= torch.exp(-dist_d*5)*0.01

        # player influence
        dist_p = torch.norm(self.position - self.player_pos, dim=1)
        self.energy += torch.exp(-dist_p*10)*0.02

        avg_energy = self.energy.mean().item()
        self.score += avg_energy

        if avg_energy > 1.2:
            self.level += 0.01
