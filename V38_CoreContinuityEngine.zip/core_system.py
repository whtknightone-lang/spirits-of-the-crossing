
import torch
import random

EMO_DIM = 7

class CoreManager:
    def __init__(self, n_agents):
        self.cores = [self._new_core() for _ in range(n_agents)]

    def _new_core(self):
        return {
            "resonance": torch.rand(EMO_DIM) * 2 - 1,
            "memory": torch.zeros(EMO_DIM),
            "tension": torch.zeros(EMO_DIM)
        }

    def spawn_initial_agents(self, SIZE, DEVICE):
        agents = []
        for core in self.cores:
            agents.append(self._spawn_from_core(core, SIZE, DEVICE))
        return agents

    def _spawn_from_core(self, core, SIZE, DEVICE):
        return {
            "pos": torch.rand(2, device=DEVICE) * SIZE,
            "emotion": core["resonance"].clone().to(DEVICE),
            "core": core
        }

    def update_agents(self, agents, SIZE, DEVICE):
        for agent in agents:
            noise = torch.randn_like(agent["emotion"]) * 0.01
            agent["emotion"] += noise

            # drift toward core resonance
            agent["emotion"] += 0.02 * (agent["core"]["resonance"].to(DEVICE) - agent["emotion"])

            agent["pos"] += torch.randn(2, device=DEVICE)
            agent["pos"] = torch.clamp(agent["pos"], 0, SIZE-1)

        return agents

    def trigger_death_and_rebirth(self, agents, SIZE, DEVICE):
        idx = random.randint(0, len(agents)-1)
        agent = agents[idx]

        core = agent["core"]

        # compress experience into core
        core["memory"] += 0.1 * agent["emotion"].cpu()
        core["resonance"] += 0.05 * core["memory"]

        # rebirth
        agents[idx] = self._spawn_from_core(core, SIZE, DEVICE)
