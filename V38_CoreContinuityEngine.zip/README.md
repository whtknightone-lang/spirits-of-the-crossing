
# V38 Core Continuity Engine

## Run
pip install -r requirements.txt
python v38_main.py

## Features
- Persistent core identity across death
- Emotional compression into core
- Rebirth system
- Continuous evolution of agents

## Description
Agents die and are reborn from a persistent core resonance system,
creating continuity across lifetimes.
