
import torch
import numpy as np
import pygame
import random
from core_system import CoreManager

SIZE = 128
NUM_AGENTS = 200
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

core_manager = CoreManager(NUM_AGENTS)

agents = core_manager.spawn_initial_agents(SIZE, DEVICE)

pygame.init()
screen = pygame.display.set_mode((512,512))
clock = pygame.time.Clock()

def render(agents):
    img = np.zeros((SIZE, SIZE, 3), dtype=np.uint8)

    for agent in agents:
        x, y = int(agent["pos"][0]), int(agent["pos"][1])
        joy = agent["emotion"][0]

        color = [
            int((joy+1)/2 * 255),
            int((1-abs(joy)) * 200),
            int((1-joy)/2 * 255)
        ]

        img[x % SIZE, y % SIZE] = color

    surf = pygame.surfarray.make_surface(img)
    surf = pygame.transform.scale(surf, (512,512))
    screen.blit(surf, (0,0))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()

    agents = core_manager.update_agents(agents, SIZE, DEVICE)

    if random.random() < 0.01:
        core_manager.trigger_death_and_rebirth(agents, SIZE, DEVICE)

    render(agents)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
