
RUE V151–V160 Quests + Narrative + Spirit + Companion Evolution

Features:
- Quest system (objectives + rewards)
- Narrative event logging
- Spirit leveling + abilities
- Companion animals with evolution
- Synergy between player, spirit, companions

Run:
pip install torch matplotlib
python run_v151.py
