
import matplotlib.pyplot as plt
from engine import EvolutionWorld

world = EvolutionWorld()

plt.ion()
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

def on_key(event):
    if event.key == 'c':
        world.add_companion()

fig.canvas.mpl_connect('key_press_event', on_key)

for step in range(200):
    world.step(step)

    ax.clear()
    ax.scatter(
        world.position[:3000,0].numpy(),
        world.position[:3000,1].numpy(),
        world.position[:3000,2].numpy(),
        s=1
    )

    ax.set_title(f"Step {step} Level {world.player_level} Quest {world.quest_progress}/{world.quest_target} Companions {len(world.companions)}")

    ax.set_xlim(0,1)
    ax.set_ylim(0,1)
    ax.set_zlim(0,1)

    plt.pause(0.01)

plt.ioff()
plt.show()
