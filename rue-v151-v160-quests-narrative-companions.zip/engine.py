
import torch
import random

SPIRITS = 5
COMPANIONS = ["fox","deer","boar","hawk","serpent"]

class EvolutionWorld:
    def __init__(self, n=30000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)
        self.velocity = torch.zeros(n,3)

        # player
        self.player_spirit = 0
        self.player_level = 1
        self.player_xp = 0

        # companions
        self.companions = [{"type": random.choice(COMPANIONS), "level":1, "xp":0}]

        # quests
        self.quest_target = random.randint(1,3)
        self.quest_progress = 0

        # narrative log
        self.history = []

    def step(self, step):
        # movement
        self.velocity += 0.01 * torch.randn_like(self.velocity)
        self.position += self.velocity
        self.position.clamp_(0,1)

        # energy
        self.energy += 0.01 * torch.sin(torch.rand_like(self.energy))
        self.energy *= 0.999

        # quest progress (example: energy threshold)
        if self.energy.mean() > 1.05:
            self.quest_progress += 1
            self.player_xp += 10
            self.history.append(f"Quest progress at step {step}")

        # level up
        if self.player_xp > 100:
            self.player_level += 1
            self.player_xp = 0
            self.history.append(f"Spirit leveled up to {self.player_level}")

        # companion evolution
        for c in self.companions:
            c["xp"] += 1
            if c["xp"] > 50:
                c["level"] += 1
                c["xp"] = 0
                self.history.append(f"{c['type']} evolved to level {c['level']}")

    def add_companion(self):
        self.companions.append({"type": random.choice(COMPANIONS), "level":1, "xp":0})
