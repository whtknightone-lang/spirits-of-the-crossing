
const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8081 });

let worlds = {};

wss.on('connection', ws => {
    ws.on('message', msg => {
        let data = JSON.parse(msg);

        if(data.playerId && data.world)
        {
            if(!worlds[data.world]) worlds[data.world] = [];
            worlds[data.world].push({ id: data.playerId, ws });

            broadcast(data.world);
        }
    });

    ws.on('close', () => {
        for(let world in worlds)
        {
            worlds[world] = worlds[world].filter(p => p.ws !== ws);
            broadcast(world);
        }
    });
});

function broadcast(world)
{
    let players = worlds[world].map(p => p.id);

    worlds[world].forEach(p => {
        p.ws.send(JSON.stringify({
            type: "players",
            players
        }));
    });
}

console.log("Realtime server running on 8081");
