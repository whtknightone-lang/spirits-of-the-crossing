
using UnityEngine;
using System.Collections;
using System.Text;
using NativeWebSocket;

public class WebSocketClient : MonoBehaviour
{
    WebSocket websocket;

    public string playerId = "player_1";
    public string world = "harmonic_world";

    async void Start()
    {
        websocket = new WebSocket("ws://localhost:8081");

        websocket.OnOpen += () => {
            Debug.Log("Connected");
            SendJoin();
        };

        websocket.OnMessage += (bytes) => {
            string msg = Encoding.UTF8.GetString(bytes);
            Debug.Log("Received: " + msg);
        };

        await websocket.Connect();
    }

    async void SendJoin()
    {
        string json = JsonUtility.ToJson(new JoinPayload {
            playerId = playerId,
            world = world
        });

        await websocket.SendText(json);
    }

    async void Update()
    {
        if (websocket != null)
            await websocket.DispatchMessageQueue();
    }

    [System.Serializable]
    public class JoinPayload
    {
        public string playerId;
        public string world;
    }
}
