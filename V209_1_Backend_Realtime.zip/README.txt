
V209.1 Backend + Realtime Multiplayer

Adds:
- WebSocket realtime server
- Player position sync
- World presence sync
- Players can see each other

Flow:
Client connects → joins world → broadcasts state → receives others
