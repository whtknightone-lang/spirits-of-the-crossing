
using UnityEngine;
using ArtificialUniverse.Cities;

public class CityAIController : MonoBehaviour
{
    public float aggression = 0.5f;
    public float expansion = 0.5f;
    public float defense = 0.5f;

    private CitySystem cities;

    void Awake()
    {
        cities = FindObjectOfType<CitySystem>();
    }

    void Update()
    {
        if (cities == null) return;

        foreach (var city in cities.cities)
        {
            if (city.stability < 0.4f)
                city.stability += defense * 0.01f * Time.deltaTime;

            if (city.prosperity > 0.6f)
                city.population += city.population * expansion * 0.001f * Time.deltaTime;
        }
    }
}
