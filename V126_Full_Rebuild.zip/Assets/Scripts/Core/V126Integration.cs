
using UnityEngine;

public class V126Integration : MonoBehaviour
{
    void Start()
    {
        if (FindObjectOfType<CityAIController>() == null)
            gameObject.AddComponent<CityAIController>();

        if (FindObjectOfType<CityConflictSystem>() == null)
            gameObject.AddComponent<CityConflictSystem>();

        if (FindObjectOfType<ConflictVisualizer>() == null)
            gameObject.AddComponent<ConflictVisualizer>();
    }
}
