
using UnityEngine;
using ArtificialUniverse.Cities;

public class CityConflictSystem : MonoBehaviour
{
    private CitySystem cities;

    void Awake()
    {
        cities = FindObjectOfType<CitySystem>();
    }

    void Update()
    {
        if (cities == null) return;

        for (int i = 0; i < cities.cities.Count; i++)
        {
            for (int j = i+1; j < cities.cities.Count; j++)
            {
                var a = cities.cities[i];
                var b = cities.cities[j];

                float dist = Vector3.Distance(a.position, b.position);
                if (dist < 10f)
                {
                    float conflict = 0.01f * Time.deltaTime;
                    a.stability -= conflict;
                    b.stability -= conflict;
                }
            }
        }
    }
}
