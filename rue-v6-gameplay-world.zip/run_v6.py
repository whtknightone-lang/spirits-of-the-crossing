
import matplotlib.pyplot as plt
from engine import World

world = World(3000)

plt.ion()
fig, ax = plt.subplots()

for step in range(200):
    world.step()

    ax.clear()
    scatter = ax.scatter(
        world.position[:,0].numpy(),
        world.position[:,1].numpy(),
        s=2
    )
    ax.set_xlim(0,1)
    ax.set_ylim(0,1)
    ax.set_title(f"Step {step}")

    plt.pause(0.01)

plt.ioff()
plt.show()
