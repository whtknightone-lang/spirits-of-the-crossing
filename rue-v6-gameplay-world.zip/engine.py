
import torch

class World:
    def __init__(self, n=5000):
        self.n = n
        self.energy = torch.ones(n)
        self.phase = torch.rand(n)
        self.position = torch.rand(n, 2)  # 2D for visualization
        self.velocity = torch.zeros(n, 2)

        self.player_pos = torch.tensor([0.5, 0.5])

    def step(self):
        # movement
        self.velocity += 0.01 * torch.randn_like(self.velocity)
        self.position += self.velocity
        self.position = torch.clamp(self.position, 0, 1)

        # oscillator
        self.phase += 0.05

        # environment fields
        forest_center = torch.tensor([0.3, 0.3])
        desert_center = torch.tensor([0.7, 0.7])

        dist_forest = torch.norm(self.position - forest_center, dim=1)
        dist_desert = torch.norm(self.position - desert_center, dim=1)

        self.energy += torch.exp(-dist_forest * 5) * 0.01
        self.energy -= torch.exp(-dist_desert * 5) * 0.01

        # player influence
        dist_player = torch.norm(self.position - self.player_pos, dim=1)
        self.energy += torch.exp(-dist_player * 10) * 0.02

        # dynamics
        self.energy += 0.01 * torch.sin(self.phase)
        self.energy *= 0.999
