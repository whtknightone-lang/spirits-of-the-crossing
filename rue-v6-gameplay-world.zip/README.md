
RUE V6 Gameplay Visual World

Features:
- GPU-based agents (PyTorch)
- Spatial world (positions + movement)
- Environment fields (forest/desert)
- Player influence
- Real-time visualization (matplotlib)

Run:
pip install torch matplotlib
python run_v6.py
