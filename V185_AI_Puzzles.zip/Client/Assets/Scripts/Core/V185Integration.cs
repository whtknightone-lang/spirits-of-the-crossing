
using UnityEngine;

public class V185Integration : MonoBehaviour
{
    void Start()
    {
        AddIfMissing<AIPuzzleGenerator>();
        AddIfMissing<PuzzleDirector>();
        AddIfMissing<HiddenVibrationReward>();
    }

    void AddIfMissing<T>() where T : Component
    {
        if (FindObjectOfType<T>() == null)
            gameObject.AddComponent<T>();
    }
}
