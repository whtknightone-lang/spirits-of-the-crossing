
using UnityEngine;

public class AIPuzzleHintCompanion : MonoBehaviour
{
    public Transform player;
    public ResonancePuzzleNode targetNode;
    public float hintStrength = 1.5f;

    void Update()
    {
        if (player == null || targetNode == null) return;

        // Move near the player, then orient toward the target node to "hint"
        Vector3 desired = Vector3.Lerp(player.position, targetNode.transform.position, 0.35f);
        transform.position = Vector3.Lerp(transform.position, desired, Time.deltaTime * hintStrength);
        transform.LookAt(targetNode.transform.position);
    }
}
