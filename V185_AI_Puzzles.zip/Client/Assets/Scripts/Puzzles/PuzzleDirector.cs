
using UnityEngine;

public class PuzzleDirector : MonoBehaviour
{
    public ResonancePuzzleNode[] nodes;
    public bool allSolved;
    public float solveProgress;

    void Update()
    {
        if (nodes == null || nodes.Length == 0) return;

        int solvedCount = 0;
        foreach (var n in nodes)
        {
            if (n != null && n.solved) solvedCount++;
        }

        solveProgress = (float)solvedCount / nodes.Length;
        allSolved = solvedCount == nodes.Length;

        if (allSolved)
        {
            Debug.Log("Puzzle solved. Hidden resonance reward unlocked.");
        }
    }
}
