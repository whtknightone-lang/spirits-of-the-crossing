
using UnityEngine;

public class ResonancePuzzleNode : MonoBehaviour
{
    [Range(0f,1f)] public float targetValue = 0.5f;
    [Range(0f,1f)] public float currentValue = 0f;
    public bool solved;

    public void Adjust(float amount)
    {
        currentValue = Mathf.Clamp01(currentValue + amount);
        solved = Mathf.Abs(currentValue - targetValue) < 0.05f;
    }
}
