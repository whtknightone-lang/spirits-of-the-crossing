
using UnityEngine;

public class HiddenVibrationReward : MonoBehaviour
{
    public PuzzleDirector director;
    public bool unlocked;
    public float rewardValue = 0.25f;

    void Update()
    {
        if (!unlocked && director != null && director.allSolved)
        {
            unlocked = true;
            Debug.Log("Hidden vibration growth reward granted: " + rewardValue);
        }
    }
}
