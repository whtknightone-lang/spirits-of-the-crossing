
using UnityEngine;

public class AIPuzzleGenerator : MonoBehaviour
{
    public float resonance;
    public int puzzleSeed;
    public string currentPuzzleType = "pattern";

    void Start()
    {
        GeneratePuzzle();
    }

    public void GeneratePuzzle()
    {
        puzzleSeed = Random.Range(0, 100000);
        currentPuzzleType = resonance > 0.66f ? "harmonic" :
                            resonance > 0.33f ? "sequence" : "pattern";
        Debug.Log("Generated puzzle: " + currentPuzzleType + " seed=" + puzzleSeed);
    }
}
