
V185 AI Puzzles

Adds:
- AI-generated puzzle seeds
- Resonance-based puzzle solving
- Companion hint system
- Multi-stage hidden puzzle rewards

Core idea:
Puzzles emerge from alignment, pattern recognition, and interaction with AI/world state.
