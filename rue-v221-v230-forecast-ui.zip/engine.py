
import torch
import math
import random

class ForecastSystem:
    def __init__(self):
        self.time = 0
        self.timeline = []

        # celestial
        self.bodies = torch.rand(11,3)
        self.phase = torch.rand(11) * 2 * math.pi

    def step(self, step):
        self.time += 0.05

        # orbit
        for i in range(len(self.bodies)):
            angle = self.phase[i] + self.time
            self.bodies[i,0] = 0.5 + 0.4 * math.cos(angle)
            self.bodies[i,1] = 0.5 + 0.4 * math.sin(angle)

        # random event (for demo)
        if random.random() < 0.02:
            event = random.choice(["solar_flare","forest_bloom","machine_sync","dragon_event"])
            self.timeline.append(f"Step {step}: {event}")

    def forecast(self):
        # simple probability model
        return {
            "solar_flare": round(random.uniform(0.4,0.9),2),
            "forest_bloom": round(random.uniform(0.3,0.8),2),
            "machine_sync": round(random.uniform(0.1,0.5),2),
            "dragon_event": round(random.uniform(0.2,0.7),2)
        }

    def next_event_hint(self):
        probs = self.forecast()
        best = max(probs, key=probs.get)
        return best, probs[best]
