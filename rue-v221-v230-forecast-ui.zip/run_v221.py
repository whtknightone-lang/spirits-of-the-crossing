
from engine import ForecastSystem

world = ForecastSystem()

for step in range(200):
    world.step(step)

    if step % 20 == 0:
        probs = world.forecast()
        best, strength = world.next_event_hint()

        print("="*40)
        print(f"Step {step}")
        print("Forecast Probabilities:")
        for k,v in probs.items():
            print(f"{k}: {v}")

        print(f"\nLikely Next Event: {best} ({strength})")

        if best == "solar_flare":
            print("Planning Hint: Store energy / prepare expansion")
        elif best == "forest_bloom":
            print("Planning Hint: Move to forest zones")
        elif best == "machine_sync":
            print("Planning Hint: Stabilize systems")
        elif best == "dragon_event":
            print("Planning Hint: Expect chaos / high risk")

        print("="*40)
