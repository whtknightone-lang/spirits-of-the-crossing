
RUE V221–V230 Forecast UI + Event Planning Tools

Features:
- Forecast engine (future alignment + event probability)
- Timeline viewer (past + predicted future)
- Planning tools (event preparation hints)
- Simple console-based UI output

Run:
pip install torch matplotlib
python run_v221.py
