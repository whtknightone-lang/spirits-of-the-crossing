
using UnityEngine;
public class DualReflectionSystem : MonoBehaviour
{
    public float previousGap;
    public float currentGap;
    public float clarity;
    public float resonance;

    void Update()
    {
        float delta = currentGap - previousGap;

        if(delta < 0)
        {
            clarity += 0.1f;
            resonance += 0.1f;
            Debug.Log("Alignment");
        }
        else if(delta > 0)
        {
            clarity -= 0.1f;
            resonance -= 0.1f;
            Debug.Log("Drift");
        }

        previousGap = currentGap;
    }
}
