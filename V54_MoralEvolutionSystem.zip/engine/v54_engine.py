
import pygame
from systems.ecosystem import Ecosystem
from systems.morality import MoralitySystem

class V54Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.morality=MoralitySystem()
        self.font=pygame.font.SysFont("arial",16)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.morality.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for a in self.ecosystem.animals:
            x=int(a["pos"][1]*scale)+40
            y=int(a["pos"][0]*scale)+40

            # color reflects morality
            m=a.get("morality",0.5)
            color=(int(255*(1-m)), int(255*m), 120)

            pygame.draw.circle(screen,color,(x,y),3)

        y=760
        lines=[
            "V54 Moral Evolution System",
            f"Avg morality: {self.morality.avg:.3f}",
            f"Population: {len(self.ecosystem.animals)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
