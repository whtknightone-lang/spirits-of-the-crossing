
class MoralitySystem:
    def __init__(self):
        self.avg=0.0

    def update(self,eco):
        total=0
        for a in eco.animals:
            # decision: selfish vs selfless
            if a["energy"]<0.3:
                if a["morality"]>0.5:
                    # selfless sacrifice boosts others
                    for b in eco.animals:
                        b["energy"]+=0.02
                    a["energy"]=0
                else:
                    # selfish survival attempt
                    a["energy"]+=0.05

            # evolve morality
            a["morality"]+= (0.01 if a["energy"]>1 else -0.005)
            a["morality"]=max(0,min(1,a["morality"]))

            total+=a["morality"]

        if eco.animals:
            self.avg=total/len(eco.animals)
