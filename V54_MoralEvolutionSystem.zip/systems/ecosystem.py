
import random

class Ecosystem:
    def __init__(self,size):
        self.size=size
        self.animals=[{
            "pos":[random.random()*size,random.random()*size],
            "energy":1.0,
            "morality":random.random()
        } for _ in range(100)]

    def update(self,dt):
        for a in self.animals:
            a["pos"][0]+=random.uniform(-1,1)*dt*10
            a["pos"][1]+=random.uniform(-1,1)*dt*10
            a["energy"]-=0.01

            # reproduction
            if a["energy"]>1.5:
                self.animals.append({
                    "pos":a["pos"][:],
                    "energy":1.0,
                    "morality":a["morality"]
                })
                a["energy"]=0.8
