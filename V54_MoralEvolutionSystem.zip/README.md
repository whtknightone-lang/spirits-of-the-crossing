
# V54 Moral Evolution System

Adds:
- moral decision layer (selfish vs selfless)
- morality evolution based on outcomes
- population-level moral dynamics

Meaning:
Agents now choose between:
- survival (self)
- sacrifice (others)

Morality evolves over time.
