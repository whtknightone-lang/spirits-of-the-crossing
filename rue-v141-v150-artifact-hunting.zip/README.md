
RUE V141–V150 Artifact Hunting + Player-as-Spirit Control

Features:
- Artifact detection system (signal strength)
- Player is a Spirit with abilities
- Targeted artifact activation
- Cooldowns + energy cost
- Strategic world interaction

Controls:
WASD: move player
1–5: switch spirit
SPACE: activate ability

Run:
pip install torch matplotlib
python run_v141.py
