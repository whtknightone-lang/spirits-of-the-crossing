
import matplotlib.pyplot as plt
from engine import ArtifactHuntWorld

world = ArtifactHuntWorld()

plt.ion()
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

def on_key(event):
    if event.key == 'w': world.player_pos[1]+=0.05
    if event.key == 's': world.player_pos[1]-=0.05
    if event.key == 'a': world.player_pos[0]-=0.05
    if event.key == 'd': world.player_pos[0]+=0.05
    if event.key == 'q': world.player_pos[2]+=0.05
    if event.key == 'e': world.player_pos[2]-=0.05

    if event.key in ['1','2','3','4','5']:
        world.player_spirit = int(event.key)-1

    if event.key == ' ':
        world.ability()

fig.canvas.mpl_connect('key_press_event', on_key)

for step in range(300):
    world.step()

    ax.clear()

    ax.scatter(world.position[:4000,0].numpy(),
               world.position[:4000,1].numpy(),
               world.position[:4000,2].numpy(),
               s=1)

    # player
    ax.scatter(world.player_pos[0], world.player_pos[1], world.player_pos[2], s=80)

    # artifacts
    ax.scatter(world.artifact_pos[:,0], world.artifact_pos[:,1], world.artifact_pos[:,2], s=50)

    signal = world.detect_signal()

    ax.set_title(f"Step {step} Spirit {world.player_spirit} Signal {round(signal,3)} Cooldown {world.cooldown}")

    ax.set_xlim(0,1)
    ax.set_ylim(0,1)
    ax.set_zlim(0,1)

    plt.pause(0.01)

plt.ioff()
plt.show()
