
import torch

SPIRITS = 5

class ArtifactHuntWorld:
    def __init__(self, n=50000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)
        self.velocity = torch.zeros(n,3)

        self.player_pos = torch.tensor([0.5,0.5,0.5])
        self.player_spirit = 0
        self.cooldown = 0

        # artifacts
        self.artifact_pos = torch.rand(8,3)
        self.artifact_type = torch.randint(0,SPIRITS,(8,))
        self.artifact_active = torch.zeros(8)

    def step(self):
        self.velocity += 0.01 * torch.randn_like(self.velocity)
        self.position += self.velocity
        self.position.clamp_(0,1)

        # simple energy dynamics
        self.energy += 0.01 * torch.sin(torch.rand_like(self.energy))
        self.energy *= 0.999

        if self.cooldown > 0:
            self.cooldown -= 1

    def ability(self):
        if self.cooldown > 0:
            return

        dist = torch.norm(self.position - self.player_pos, dim=1)
        nearby = dist < 0.1

        if self.player_spirit == 0:  # Wolf
            self.velocity[nearby] += 0.05 * (self.position[nearby] - 0.5)
        elif self.player_spirit == 1:  # Owl
            self.energy[nearby] = 1.2
        elif self.player_spirit == 2:  # Bear
            self.energy[nearby] *= 1.01
        elif self.player_spirit == 3:  # Eagle
            self.velocity[nearby] += 0.05 * torch.randn_like(self.velocity[nearby])
        elif self.player_spirit == 4:  # Dragon
            self.energy[nearby] *= (1 + 0.02 * torch.randn_like(self.energy[nearby]))

        self.cooldown = 10

    def detect_signal(self):
        # returns distance to closest artifact
        dists = torch.norm(self.artifact_pos - self.player_pos, dim=1)
        return float(torch.min(dists))
