
import numpy as np

class SnowflakeBrain3D:
    def __init__(self):
        self.n = 21
        self.phases = np.random.rand(self.n) * 2 * np.pi
        self.positions = self._build_positions()
        self.matrix = self._build_matrix()

        # identity memory (slow state)
        self.memory = self.phases.copy()

        self.inner = np.arange(1, 7)
        self.outer = np.arange(7, 21)
        self.center = np.array([0])

    def _build_positions(self):
        pos = np.zeros((21, 3))
        pos[0] = [0,0,0]

        inner = [
            [ 1,0,0],[-1,0,0],
            [0,1,0],[0,-1,0],
            [0,0,1],[0,0,-1]
        ]
        pos[1:7] = np.array(inner)*0.75

        for i in range(14):
            theta = i * 2*np.pi/14
            phi = np.arccos(1 - 2*(i+0.5)/14)
            x = np.sin(phi)*np.cos(theta)
            y = np.sin(phi)*np.sin(theta)
            z = np.cos(phi)
            pos[7+i] = [x,y,z]

        return pos*1.6

    def _build_matrix(self):
        K = np.zeros((21,21))
        def connect(a,b,w):
            K[a,b]=w; K[b,a]=w

        for i in range(1,7):
            connect(0,i,1.0)

        inner=[1,2,3,4,5,6]
        for i in range(6):
            connect(inner[i],inner[(i+1)%6],0.65)

        for i in range(7,21):
            connect(i, 7+(i-6)%14, 0.35)

        return K

    def sync(self):
        return float(abs(np.mean(np.exp(1j*self.phases))))

    def identity_match(self):
        return float(np.mean(np.cos(self.phases - self.memory)))

    def step(self, drive=0.0):

        diff = self.phases[:,None] - self.phases[None,:]
        dist = np.linalg.norm(self.positions[:,None,:]-self.positions[None,:,:],axis=2)

        coupling = np.sin(diff)*self.matrix/(1+dist)
        velocity = coupling.sum(axis=1)

        velocity[self.outer] *= 1.3
        velocity *= 0.04
        velocity += drive
        velocity = np.clip(velocity,-0.18,0.18)

        self.phases = np.mod(self.phases + velocity, 2*np.pi)

        # update memory slowly
        self.memory = 0.98*self.memory + 0.02*self.phases
