
import numpy as np
from engine.snowflake.brain_3d import SnowflakeBrain3D

def circular_diff(a,b):
    return float(np.angle(np.exp(1j*(a-b))))

class Agent:
    def __init__(self, planet_id, region_id):
        self.planet_id = planet_id
        self.region_id = region_id
        self.brain = SnowflakeBrain3D()
        self.energy = 2.0

    def step(self, local_phase, local_energy, social_match):

        match = np.cos(circular_diff(self.brain.phases.mean(), local_phase))

        positive = max(0, match-0.1)*local_energy
        mismatch = max(0, 0.15-match)*0.35*local_energy
        living = 0.05

        # identity reward
        identity = self.brain.identity_match()*0.25

        # coherence preservation
        coherence = self.brain.sync()
        if coherence < 0.3:
            mismatch += 0.1

        drive = 0.01*match + 0.01*social_match

        self.brain.step(drive=drive)

        self.energy += positive + identity - mismatch - living
