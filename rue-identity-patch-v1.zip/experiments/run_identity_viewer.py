
import numpy as np
import matplotlib.pyplot as plt
from engine.agents.agent import Agent

agents = [Agent(0,0) for _ in range(20)]

plt.ion()
fig, ax = plt.subplots()

for step in range(1000):

    for a in agents:
        a.step(local_phase=np.random.rand()*2*np.pi, local_energy=2.0, social_match=0.0)

    energies = [a.energy for a in agents]

    ax.clear()
    ax.plot(energies)
    ax.set_title("Agent Energy (Identity Stabilization)")

    plt.pause(0.01)

plt.ioff()
plt.show()
