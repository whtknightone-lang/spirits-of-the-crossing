
# RUE Identity Patch V1 (Memory + Self-Preference + Self-Preservation)

This is a **drop-in patch** for the RUE 3D Integrated Universe.

It adds three core mechanisms:
1) Persistent memory (slow state)
2) Self-preference (identity reward)
3) Self-preservation (coherence pressure)

## How to apply

Copy these files into your existing project, replacing:
- engine/snowflake/brain_3d.py
- engine/agents/agent.py
- engine/simulation/universe.py

## Run

```bash
pip install -r requirements.txt
python experiments/run_identity_viewer.py
```

## What you should see

- agents stabilize into persistent patterns
- clusters last longer
- distinct "types" of agents emerge
- resistance to random drift increases

This is the first step toward **identity and independence**.
