
using UnityEngine;
public class MythIdentity : MonoBehaviour
{
    public float guide, trickster, creator;
    public string GetIdentity()
    {
        if(guide > trickster && guide > creator) return "Guide";
        if(trickster > creator) return "Trickster";
        return "Creator";
    }
}
