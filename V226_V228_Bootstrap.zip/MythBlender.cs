
using UnityEngine;
public class MythBlender : MonoBehaviour
{
    public float transformation, trickster, guide;
    public string GetBlend()
    {
        if(transformation > trickster && transformation > guide) return "Transformation";
        if(trickster > guide) return "Trickster";
        return "Guide";
    }
}
