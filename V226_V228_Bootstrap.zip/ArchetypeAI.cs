
using UnityEngine;
public enum ArchetypeType {Guide, Trickster, Creator, Protector}
public class ArchetypeAI : MonoBehaviour
{
    public ArchetypeType archetype;
}
