
import pygame
from systems.ecosystem import Ecosystem
from systems.source_response import SourceResponseSystem
from systems.player import PlayerSystem

class V87Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.source=SourceResponseSystem(size)
        self.player=PlayerSystem(self.source)

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(80):
            self.ecosystem.spawn_entity()

    def handle_key(self,key):
        self.player.handle_key(key)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.source.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,45))
        scale=700/self.size

        # draw currents
        for c in self.source.currents:
            x=int(c[1]*scale)+40
            y=int(c[0]*scale)+40
            pygame.draw.circle(screen,(150,220,255),(x,y),2)

        # draw entities
        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            s=e.get("source_connection",0)
            color=(120, int(120+135*s), 255)
            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V87 Source Response System",
            "1 gentle intent | 2 strong intent",
            f"Source mood: {round(self.source.mood,2)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
