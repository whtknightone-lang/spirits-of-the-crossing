
import pygame

class PlayerSystem:
    def __init__(self,source):
        self.source=source

    def handle_key(self,key):
        if key==pygame.K_1:
            self.source.apply_intent(0.3)
        if key==pygame.K_2:
            self.source.apply_intent(1.0)
