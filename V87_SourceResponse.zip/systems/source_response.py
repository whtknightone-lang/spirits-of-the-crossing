
import random

class SourceResponseSystem:
    def __init__(self,size):
        self.size=size
        self.currents=[[random.random()*size, random.random()*size] for _ in range(150)]
        self.intent_strength=0.0
        self.mood=0.5  # how source responds

    def apply_intent(self,strength):
        self.intent_strength = strength

    def update(self,eco):
        # source mood adapts
        self.mood += (self.intent_strength - self.mood) * 0.05

        for c in self.currents:
            drift = random.uniform(-0.3,0.3)
            c[0] += drift + (self.intent_strength * 0.2 * self.mood)
            c[1] += drift

        # influence entities
        for e in eco.entities:
            for c in self.currents:
                dx=e["pos"][0]-c[0]
                dy=e["pos"][1]-c[1]
                dist=(dx*dx+dy*dy)**0.5
                if dist<4:
                    e["source_connection"] += 0.01 * self.mood

            e["source_connection"]=min(1.0,e["source_connection"])
