
# V87 Bidirectional Source Interaction

Adds:
- source responds to player intent (mood system)
- gentle vs strong intent produces different effects
- feedback loop between player and source

Concept:
The source is not passive—
it listens, adapts, and responds.
