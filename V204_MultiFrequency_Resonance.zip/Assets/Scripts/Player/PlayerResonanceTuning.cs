
using UnityEngine;

public class PlayerResonanceTuning : MonoBehaviour
{
    public MultiFrequencyField field;
    public float tuningAmount = 0.1f;

    void Update()
    {
        if (field == null) return;

        if (Input.GetKeyDown(KeyCode.Alpha1)) field.red = Mathf.Clamp01(field.red + tuningAmount);
        if (Input.GetKeyDown(KeyCode.Alpha2)) field.orange = Mathf.Clamp01(field.orange + tuningAmount);
        if (Input.GetKeyDown(KeyCode.Alpha3)) field.yellow = Mathf.Clamp01(field.yellow + tuningAmount);
        if (Input.GetKeyDown(KeyCode.Alpha4)) field.green = Mathf.Clamp01(field.green + tuningAmount);
        if (Input.GetKeyDown(KeyCode.Alpha5)) field.blue = Mathf.Clamp01(field.blue + tuningAmount);
        if (Input.GetKeyDown(KeyCode.Alpha6)) field.indigo = Mathf.Clamp01(field.indigo + tuningAmount);
        if (Input.GetKeyDown(KeyCode.Alpha7)) field.violet = Mathf.Clamp01(field.violet + tuningAmount);
    }
}
