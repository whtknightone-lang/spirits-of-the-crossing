
using UnityEngine;

public class MultiFrequencyField : MonoBehaviour
{
    [Range(0f,1f)] public float red;
    [Range(0f,1f)] public float orange;
    [Range(0f,1f)] public float yellow;
    [Range(0f,1f)] public float green;
    [Range(0f,1f)] public float blue;
    [Range(0f,1f)] public float indigo;
    [Range(0f,1f)] public float violet;

    public float GetAverage()
    {
        return (red + orange + yellow + green + blue + indigo + violet) / 7f;
    }

    public float GetCoherence()
    {
        float avg = GetAverage();
        float variance =
            Mathf.Abs(red-avg)+Mathf.Abs(orange-avg)+Mathf.Abs(yellow-avg)+
            Mathf.Abs(green-avg)+Mathf.Abs(blue-avg)+Mathf.Abs(indigo-avg)+Mathf.Abs(violet-avg);
        return Mathf.Clamp01(1f - variance / 7f);
    }
}
