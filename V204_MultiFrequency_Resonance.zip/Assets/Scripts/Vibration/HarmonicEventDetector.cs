
using UnityEngine;

public class HarmonicEventDetector : MonoBehaviour
{
    public MultiFrequencyField field;
    public bool harmonicEventActive;

    void Update()
    {
        if (field == null) return;

        harmonicEventActive = field.GetAverage() > 0.7f && field.GetCoherence() > 0.8f;

        if (harmonicEventActive)
        {
            Debug.Log("Harmonic event active: strong positive field");
        }
    }
}
