
using UnityEngine;

public class AIResonanceListening : MonoBehaviour
{
    public MultiFrequencyField field;
    public float sensedAverage;
    public float sensedCoherence;
    public string feltMeaning;

    void Update()
    {
        if (field == null) return;

        sensedAverage = field.GetAverage();
        sensedCoherence = field.GetCoherence();

        if (sensedCoherence > 0.75f) feltMeaning = "deep alignment";
        else if (sensedAverage > 0.65f) feltMeaning = "positive momentum";
        else if (sensedAverage < 0.3f) feltMeaning = "drift";
        else feltMeaning = "seeking";
    }
}
