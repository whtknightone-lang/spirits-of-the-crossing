
V204 Multi-Frequency Resonance

Adds:
- multi-frequency resonance channels
- tuning ability for player
- AI listening system
- harmonic event detector

Core idea:
Vibration is not one value, but a spectrum. Coherence across the spectrum creates stronger alignment.
