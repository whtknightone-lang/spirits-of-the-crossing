
# V125 Realm-Dragon-City Integration

This layer connects EVERYTHING:

- Dragons influence cities
- Realms modify city growth + territory
- Source/Dark pressure affects expansion
- Cities react to nearby dragons + realms

Now the world is fully interconnected.
