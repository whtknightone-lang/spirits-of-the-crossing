
using UnityEngine;
using ArtificialUniverse.Integration;

namespace ArtificialUniverse.Core
{
    public class V125IntegrationManager : MonoBehaviour
    {
        void Start()
        {
            if (FindObjectOfType<DragonCityInfluence>() == null)
                gameObject.AddComponent<DragonCityInfluence>();

            if (FindObjectOfType<RealmCityInfluence>() == null)
                gameObject.AddComponent<RealmCityInfluence>();

            if (FindObjectOfType<SourceDarkCityEffect>() == null)
                gameObject.AddComponent<SourceDarkCityEffect>();
        }
    }
