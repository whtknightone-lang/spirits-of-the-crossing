
using UnityEngine;
using ArtificialUniverse.Cities;
using ArtificialUniverse.Realms;

namespace ArtificialUniverse.Integration
{
    public class RealmCityInfluence : MonoBehaviour
    {
        private CitySystem cities;
        private RealmZone[] realms;

        void Awake()
        {
            cities = FindObjectOfType<CitySystem>();
            realms = FindObjectsOfType<RealmZone>();
        }

        void Update()
        {
            if (cities == null || realms == null) return;

            foreach (var city in cities.cities)
            {
                foreach (var realm in realms)
                {
                    float d = Vector3.Distance(city.position, realm.transform.position);
                    if (d > realm.radius) continue;

                    float effect = 1f - (d / realm.radius);

                    city.prosperity += realm.harmonyDelta * effect * Time.deltaTime;
                    city.stability += realm.integrityDelta * effect * Time.deltaTime;
                }

                city.prosperity = Mathf.Clamp01(city.prosperity);
                city.stability = Mathf.Clamp01(city.stability);
            }
        }
    }
