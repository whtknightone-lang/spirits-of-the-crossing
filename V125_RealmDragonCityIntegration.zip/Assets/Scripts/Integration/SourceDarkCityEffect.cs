
using UnityEngine;
using ArtificialUniverse.Cities;
using ArtificialUniverse.Source;

namespace ArtificialUniverse.Integration
{
    public class SourceDarkCityEffect : MonoBehaviour
    {
        private CitySystem cities;
        private SourceDarkFeedbackSystem source;

        void Awake()
        {
            cities = FindObjectOfType<CitySystem>();
            source = FindObjectOfType<SourceDarkFeedbackSystem>();
        }

        void Update()
        {
            if (cities == null || source == null) return;

            foreach (var city in cities.cities)
            {
                float balance = source.sourceMood - source.darkPlanetPressure;

                city.prosperity += balance * 0.01f * Time.deltaTime;
                city.stability += balance * 0.01f * Time.deltaTime;

                if (source.darkPlanetPressure > 0.6f)
                {
                    city.population *= (1f - 0.002f * Time.deltaTime);
                }
            }
        }
    }
