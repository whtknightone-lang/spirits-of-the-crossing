
using UnityEngine;
using ArtificialUniverse.Cities;
using ArtificialUniverse.Dragons;

namespace ArtificialUniverse.Integration
{
    public class DragonCityInfluence : MonoBehaviour
    {
        public float influenceRadius = 15f;

        private CitySystem citySystem;

        void Awake()
        {
            citySystem = FindObjectOfType<CitySystem>();
        }

        void Update()
        {
            if (citySystem == null) return;

            var dragons = FindObjectsOfType<DragonAvatar>();

            foreach (var city in citySystem.cities)
            {
                foreach (var dragon in dragons)
                {
                    float d = Vector3.Distance(city.position, dragon.transform.position);
                    if (d > influenceRadius) continue;

                    float effect = 1f - (d / influenceRadius);

                    switch (dragon.element)
                    {
                        case DragonElement.Air:
                            city.prosperity += effect * 0.01f * Time.deltaTime;
                            break;

                        case DragonElement.Water:
                            city.stability += effect * 0.01f * Time.deltaTime;
                            break;

                        case DragonElement.Nature:
                            city.population += city.population * effect * 0.002f * Time.deltaTime;
                            break;

                        case DragonElement.Fire:
                            city.stability -= effect * 0.015f * Time.deltaTime;
                            break;
                    }
                }

                city.prosperity = Mathf.Clamp01(city.prosperity);
                city.stability = Mathf.Clamp01(city.stability);
            }
        }
    }
