
V125 Scene Setup:

1. Ensure previous systems exist:
   - Dragons
   - Realms
   - Cities
   - Source/Dark
   - Territory

2. Add:
   - DragonCityInfluence
   - RealmCityInfluence
   - SourceDarkCityEffect
   - V125IntegrationManager

3. Result:
   - Dragons directly shape cities
   - Realms modify growth and stability
   - Source/dark pressure impacts population
   - Everything is now connected
