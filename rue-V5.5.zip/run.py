
print("Running V5.5")

class World:
    def __init__(self):
        self.time=0
        self.energy=1.0

    def step(self):
        self.time+=1
        self.energy*=1.01
        print("step", self.time, "energy", round(self.energy,3))

w=World()
for _ in range(10):
    w.step()
