
using UnityEngine;

public class PuzzleSync : MonoBehaviour
{
    public SharedPuzzleNode node;

    public string Serialize()
    {
        return JsonUtility.ToJson(new Payload { v = node.value });
    }

    [System.Serializable]
    public class Payload { public float v; }
}
