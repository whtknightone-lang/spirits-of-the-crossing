
using UnityEngine;

public class SharedPuzzleNode : MonoBehaviour
{
    public float value;
    public bool solved;

    public void SetValue(float v)
    {
        value = Mathf.Clamp01(v);
        solved = value > 0.9f;
    }
}
