
using UnityEngine;

public class SharedPuzzleManager : MonoBehaviour
{
    public SharedPuzzleNode[] nodes;
    public bool allSolved;

    void Update()
    {
        int solvedCount = 0;
        foreach (var n in nodes)
        {
            if (n.solved) solvedCount++;
        }
        allSolved = solvedCount == nodes.Length;

        if (allSolved)
            Debug.Log("Group puzzle solved!");
    }
}
