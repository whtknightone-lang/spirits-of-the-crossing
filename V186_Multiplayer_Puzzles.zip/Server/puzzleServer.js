
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8090 });

let sharedValue = 0;

wss.on('connection', ws => {
    ws.on('message', msg => {
        try {
            const data = JSON.parse(msg);
            sharedValue = (sharedValue + data.v) / 2;
        } catch {}
    });
});

setInterval(()=>{
    const msg = JSON.stringify({ v: sharedValue });
    wss.clients.forEach(c=>{
        if(c.readyState===1) c.send(msg);
    });
},100);
