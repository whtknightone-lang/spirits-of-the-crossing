V186 Multiplayer Shared Puzzle System
