
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from engine import World3D

world = World3D()

plt.ion()
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

def on_key(event):
    if event.key == 'w': world.player_pos[1]+=0.05
    if event.key == 's': world.player_pos[1]-=0.05
    if event.key == 'a': world.player_pos[0]-=0.05
    if event.key == 'd': world.player_pos[0]+=0.05
    if event.key == 'q': world.player_pos[2]+=0.05
    if event.key == 'e': world.player_pos[2]-=0.05

fig.canvas.mpl_connect('key_press_event', on_key)

for step in range(300):
    world.step()

    ax.clear()
    ax.scatter(
        world.position[:,0].numpy(),
        world.position[:,1].numpy(),
        world.position[:,2].numpy(),
        s=2
    )

    ax.scatter(
        world.player_pos[0].item(),
        world.player_pos[1].item(),
        world.player_pos[2].item(),
        s=50
    )

    ax.set_xlim(0,1)
    ax.set_ylim(0,1)
    ax.set_zlim(0,1)

    ax.set_title(f"Step {step}")

    plt.pause(0.01)

plt.ioff()
plt.show()
