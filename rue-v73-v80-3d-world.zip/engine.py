
import torch

class World3D:
    def __init__(self, n=2000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)
        self.velocity = torch.zeros(n,3)
        self.player_pos = torch.tensor([0.5,0.5,0.5])

    def step(self):
        self.velocity += 0.01 * torch.randn_like(self.velocity)
        self.position += self.velocity
        self.position = torch.clamp(self.position, 0, 1)

        dist = torch.norm(self.position - self.player_pos, dim=1)
        self.energy += torch.exp(-dist*8)*0.02

        self.energy *= 0.999
