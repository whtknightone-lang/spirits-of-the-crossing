
RUE V73–V80 3D Visual World

Features:
- 3D visualization (matplotlib)
- Rotating camera view
- Agents rendered in 3D space
- Player entity visible
- Compatible with V67–V72 logic

Run:
pip install torch matplotlib
python run_v73.py
