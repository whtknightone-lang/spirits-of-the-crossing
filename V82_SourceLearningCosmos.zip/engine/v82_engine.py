
import pygame
from systems.ecosystem import Ecosystem
from systems.source_memory import SourceMemorySystem
from systems.rebirth import RebirthSystem

class V82Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.source=SourceMemorySystem()
        self.rebirth=RebirthSystem(self.source)

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(120):
            self.ecosystem.spawn_entity()

    def update(self,dt):
        self.ecosystem.update(dt)
        self.source.update(self.ecosystem)
        self.rebirth.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            learned=e.get("source_influence",0)
            color=(int(100+learned*155), 255-int(learned*100), 150)

            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V82 Source Learning Cosmos",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Source wisdom: {round(self.source.global_learning,3)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
