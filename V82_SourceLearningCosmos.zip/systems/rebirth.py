
import random

class RebirthSystem:
    def __init__(self, source):
        self.source = source

    def update(self,eco):
        for e in eco.entities:
            if e["stress"] > 1.2:
                # collapse → rebirth with source learning
                e["stress"] = random.random()*0.5
                e["source_influence"] += self.source.global_learning * 0.2
                e["source_influence"] = min(1.0, e["source_influence"])
