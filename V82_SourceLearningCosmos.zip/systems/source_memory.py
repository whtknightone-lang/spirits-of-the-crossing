
class SourceMemorySystem:
    def __init__(self):
        self.global_learning=0.0

    def update(self,eco):
        # accumulate learning from all entities
        total=0
        for e in eco.entities:
            learning = max(0, 1 - e["stress"])
            total += learning

        if eco.entities:
            self.global_learning = total / len(eco.entities)

        # push learning back into entities
        for e in eco.entities:
            e["source_influence"] += self.global_learning * 0.01
            e["source_influence"] = min(1.0, e["source_influence"])
