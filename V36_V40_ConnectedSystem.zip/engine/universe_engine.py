
import pygame
import numpy as np
import torch

from systems.joy_engine import JoyEngine
from systems.emotion_engine import EmotionEngine
from systems.core_continuity import CoreContinuitySystem
from systems.planetary_civilization import PlanetaryCivilizationSystem
from systems.galactic_consciousness import GalacticConsciousnessSystem

class UniverseEngine:
    def __init__(self, grid_size=128, device="cpu"):
        self.grid_size = grid_size
        self.device = device

        self.joy = JoyEngine(grid_size, device)
        self.emotion = EmotionEngine(grid_size, device)
        self.core = CoreContinuitySystem(num_agents=220, grid_size=grid_size, device=device)
        self.planetary = PlanetaryCivilizationSystem(grid_size=grid_size, device=device)
        self.galaxy = GalacticConsciousnessSystem(grid_size=grid_size, device=device)

        self.font = pygame.font.SysFont("arial", 16)
        self.tick_count = 0

    def handle_key(self, key):
        if key == pygame.K_UP:
            self.joy.inject_joy(0.15)
        elif key == pygame.K_DOWN:
            self.joy.inject_discord(0.15)
        elif key == pygame.K_1:
            self.emotion.inject_dimension(0, 0.12)  # joy
        elif key == pygame.K_2:
            self.emotion.inject_dimension(1, 0.12)  # love
        elif key == pygame.K_3:
            self.emotion.inject_dimension(2, 0.12)  # confidence
        elif key == pygame.K_4:
            self.emotion.inject_dimension(3, 0.12)  # creativity
        elif key == pygame.K_5:
            self.emotion.inject_dimension(4, 0.12)  # expression
        elif key == pygame.K_6:
            self.emotion.inject_dimension(5, 0.12)  # experience
        elif key == pygame.K_7:
            self.emotion.inject_dimension(6, 0.12)  # kindness
        elif key == pygame.K_b:
            self.core.trigger_random_rebirth()
        elif key == pygame.K_p:
            self.planetary.civilization_event()
        elif key == pygame.K_g:
            self.galaxy.spawn_event()

    def update(self, dt):
        self.tick_count += 1

        self.joy.update(dt)
        self.emotion.update(dt, self.joy.J)
        self.core.update(dt, self.emotion.field)
        self.planetary.update(dt, self.emotion.field, self.core.aggregate_agent_emotion())
        self.galaxy.update(
            dt,
            self.planetary.planet_memory,
            self.planetary.civilization_signature(),
            self.joy.J.mean().item()
        )

        # Cross-system coupling
        self.emotion.field[0] += self.joy.J[0, 0] * 0.002
        self.planetary.planet_memory += self.emotion.field.mean(dim=0) * 0.0005
        self.galaxy.galaxy_field += self.planetary.planet_memory.unsqueeze(0)[:7] * 0.0002

    def render(self, screen):
        screen.fill((8, 10, 18))

        joy_surface = self._surface_from_field(self.joy.J[0, 0], mode="joy")
        emo_surface = self._surface_from_field(self.emotion.field[0], mode="emotion")
        planet_surface = self._surface_from_field(self.planetary.planet_memory, mode="planet")
        galaxy_surface = self._surface_from_field(self.galaxy.galaxy_field[0], mode="galaxy")

        joy_surface = pygame.transform.scale(joy_surface, (420, 320))
        emo_surface = pygame.transform.scale(emo_surface, (420, 320))
        planet_surface = pygame.transform.scale(planet_surface, (420, 320))
        galaxy_surface = pygame.transform.scale(galaxy_surface, (420, 320))

        screen.blit(joy_surface, (20, 20))
        screen.blit(emo_surface, (460, 20))
        screen.blit(planet_surface, (20, 360))
        screen.blit(galaxy_surface, (460, 360))

        self._draw_agents(screen)
        self._draw_text(screen)

    def _surface_from_field(self, field, mode="joy"):
        arr = field.detach().cpu().numpy()
        arr = arr - arr.min()
        maxv = arr.max()
        if maxv > 1e-8:
            arr = arr / maxv

        if mode == "joy":
            img = np.stack([arr * 255, arr * 160, 255 - arr * 180], axis=-1)
        elif mode == "emotion":
            img = np.stack([arr * 255, 255 - arr * 255, arr * 120], axis=-1)
        elif mode == "planet":
            img = np.stack([80 + arr * 120, 120 + arr * 100, arr * 255], axis=-1)
        else:
            img = np.stack([arr * 180, arr * 80, 120 + arr * 135], axis=-1)

        img = img.clip(0, 255).astype(np.uint8)
        return pygame.surfarray.make_surface(np.transpose(img, (1, 0, 2)))

    def _draw_agents(self, screen):
        for agent in self.core.agents[:120]:
            x = int((agent["pos"][0].item() / self.grid_size) * 420) + 20
            y = int((agent["pos"][1].item() / self.grid_size) * 320) + 20
            joy = float(agent["emotion"][0].item())
            color = (
                max(0, min(255, int((joy + 1.0) * 110))),
                190,
                max(0, min(255, int((1.0 - joy) * 110)))
            )
            pygame.draw.circle(screen, color, (x, y), 2)

    def _draw_text(self, screen):
        lines = [
            "Connected Universe Engine V36-V40",
            "UP/DOWN: Joy/Discord   1-7: Emotional axes",
            "B: rebirth   P: civilization event   G: galaxy spawn",
            f"Agents: {len(self.core.agents)}   Civilizations: {len(self.planetary.civilizations)}   Planets: {len(self.galaxy.planets)}",
            f"Mean Joy: {self.joy.J.mean().item():.3f}   Galaxy Resonance: {self.galaxy.galaxy_field.mean().item():.3f}",
            "Panels: Joy | Emotion | Planetary Memory | Galactic Field",
        ]
        y = 648
        for line in lines:
            text = self.font.render(line, True, (235, 235, 245))
            screen.blit(text, (20, y))
            y += 16
