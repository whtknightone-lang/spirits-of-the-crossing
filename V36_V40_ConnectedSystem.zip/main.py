
import pygame
import torch
from engine.universe_engine import UniverseEngine

WIDTH = 900
HEIGHT = 700
GRID_SIZE = 128

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Connected Universe Engine V36-V40")
    clock = pygame.time.Clock()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    engine = UniverseEngine(grid_size=GRID_SIZE, device=device)

    running = True
    while running:
        dt = clock.tick(60) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                engine.handle_key(event.key)

        engine.update(dt)
        engine.render(screen)
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
