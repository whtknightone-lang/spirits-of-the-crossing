
import torch
import torch.nn.functional as F

class JoyEngine:
    def __init__(self, size, device):
        self.size = size
        self.device = device
        self.J = torch.zeros((1, 1, size, size), device=device)
        self.Psi = torch.zeros_like(self.J)

        self.D = 0.18
        self.alpha = 1.0
        self.beta = 0.4
        self.gamma = 0.35
        self.delta = 0.08
        self.epsilon = 0.2
        self.lambda_ = 0.72

        self.laplace_kernel = torch.tensor(
            [[0,1,0],[1,-4,1],[0,1,0]],
            dtype=torch.float32,
            device=device
        ).view(1,1,3,3)

    def laplacian(self, field):
        return F.conv2d(field, self.laplace_kernel, padding=1)

    def update(self, dt):
        R = torch.sigmoid(self.J)
        G = torch.abs(self.laplacian(self.J))
        H = torch.relu(self.J)
        N = torch.rand_like(self.J) * 0.02
        M = torch.tanh(self.J)

        self.J += (
            self.D * self.laplacian(self.J)
            + self.alpha * R * dt
            + self.beta * G * dt
            + self.gamma * H * dt
            + self.delta * N
            + self.epsilon * M * dt
            - self.lambda_ * self.Psi * dt
        )

        self.Psi += 0.04 * torch.randn_like(self.Psi) * dt - 0.03 * self.J * dt
        self.J = torch.clamp(self.J, -2.0, 2.0)
        self.Psi = torch.clamp(self.Psi, -2.0, 2.0)

    def inject_joy(self, amount):
        self.J += amount

    def inject_discord(self, amount):
        self.Psi += amount
