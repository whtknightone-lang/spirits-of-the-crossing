
import random
import torch

class PlanetaryCivilizationSystem:
    def __init__(self, grid_size, device, emo_dim=7):
        self.grid_size = grid_size
        self.device = device
        self.emo_dim = emo_dim

        self.planet_memory = torch.zeros((grid_size, grid_size), device=device)
        self.civilizations = [self._new_civ() for _ in range(5)]

    def _new_civ(self):
        return {
            "identity": torch.rand(self.emo_dim) * 2 - 1,
            "memory": torch.zeros(self.emo_dim),
            "influence": random.uniform(0.2, 1.0),
        }

    def update(self, dt, emotion_field, agent_mean):
        self.planet_memory += emotion_field.mean(dim=0) * 0.002
        self.planet_memory += agent_mean.mean().item() * 0.0007

        for civ in self.civilizations:
            civ["memory"] += civ["identity"] * 0.01
            civ["identity"] += agent_mean.detach().cpu() * 0.002
            civ["identity"] = torch.clamp(civ["identity"], -2.0, 2.0)
            self.planet_memory += civ["identity"].mean().item() * civ["influence"] * 0.0008

        self.planet_memory = torch.clamp(self.planet_memory, -2.0, 2.0)

    def civilization_event(self):
        civ = random.choice(self.civilizations)
        civ["identity"] += 0.08 * civ["memory"]
        civ["memory"] += 0.04 * civ["identity"]

        if random.random() < 0.35 and len(self.civilizations) < 16:
            self.civilizations.append(self._new_civ())

    def civilization_signature(self):
        vals = [c["identity"].mean().item() for c in self.civilizations]
        return sum(vals) / max(1, len(vals))
