
import random
import torch

class CoreContinuitySystem:
    def __init__(self, num_agents, grid_size, device, emo_dim=7):
        self.num_agents = num_agents
        self.grid_size = grid_size
        self.device = device
        self.emo_dim = emo_dim

        self.cores = [self._new_core() for _ in range(num_agents)]
        self.agents = [self._spawn_from_core(core) for core in self.cores]

    def _new_core(self):
        return {
            "resonance": torch.rand(self.emo_dim) * 2 - 1,
            "memory": torch.zeros(self.emo_dim),
            "tension": torch.zeros(self.emo_dim),
        }

    def _spawn_from_core(self, core):
        return {
            "pos": torch.rand(2, device=self.device) * self.grid_size,
            "emotion": core["resonance"].clone().to(self.device),
            "core": core,
            "age": 0.0,
        }

    def update(self, dt, emotion_field):
        for i, agent in enumerate(self.agents):
            x = int(torch.clamp(agent["pos"][0], 0, self.grid_size - 1).item())
            y = int(torch.clamp(agent["pos"][1], 0, self.grid_size - 1).item())
            local = emotion_field[:, x, y]
            resonance = torch.exp(-torch.norm(agent["emotion"] - local))
            agent["emotion"] += 0.03 * (local - agent["emotion"]) * resonance
            agent["emotion"] += 0.01 * torch.randn_like(agent["emotion"]) * dt
            agent["pos"] += torch.randn(2, device=self.device) * (0.5 + resonance) * 0.9
            agent["pos"] = torch.clamp(agent["pos"], 0, self.grid_size - 1)
            agent["age"] += dt

            if agent["age"] > 25.0 and random.random() < 0.0025:
                self._compress_and_rebirth(i)

    def _compress_and_rebirth(self, idx):
        agent = self.agents[idx]
        core = agent["core"]
        core["memory"] += 0.08 * agent["emotion"].detach().cpu()
        core["resonance"] += 0.04 * core["memory"]
        core["tension"] += 0.02 * torch.abs(core["memory"])
        core["resonance"] = torch.clamp(core["resonance"], -2.0, 2.0)
        self.agents[idx] = self._spawn_from_core(core)

    def trigger_random_rebirth(self):
        idx = random.randint(0, len(self.agents) - 1)
        self._compress_and_rebirth(idx)

    def aggregate_agent_emotion(self):
        stacked = torch.stack([a["emotion"] for a in self.agents], dim=0)
        return stacked.mean(dim=0)
