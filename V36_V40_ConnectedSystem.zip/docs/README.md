
# Connected Universe Engine V36-V40

This package connects the previously separated systems into one playable runtime:

- V36 Joy Field
- V37 Emotional Spectrum
- V38 Core Continuity / Rebirth
- V39 Planetary Memory / Civilization Identity
- V40 Galactic Consciousness / Emergent Spawning

## Run
pip install -r requirements.txt
python main.py

## Controls
- Up / Down: inject joy / discord
- 1-7: inject emotional dimensions
  1 Joy
  2 Love
  3 Confidence
  4 Creativity
  5 Expression
  6 Experience
  7 Kindness
- B: force a random rebirth
- P: trigger civilization mutation / growth event
- G: trigger galaxy spawn event

## Notes
The display shows four synchronized layers:
1. Joy Field
2. Emotional Field
3. Planetary Memory
4. Galactic Field

Agents are rendered over the Joy panel to show individual continuity inside the larger system.
