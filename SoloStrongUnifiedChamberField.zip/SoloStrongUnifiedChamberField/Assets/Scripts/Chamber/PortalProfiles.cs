using System;
using System.Collections.Generic;
using UnityEngine;

namespace V243.Chamber
{
    [Serializable]
    public class ResonancePortalProfile
    {
        public ResonancePortalType portalType;
        public string displayName;
        public string sigilId;
        public string ruinMotif;
        public string ghostAlienLikeness;
        public string audioState;
        public string particleState;

        [Header("Core Weights")]
        public float stillnessWeight;
        public float flowWeight;
        public float spinWeight;
        public float pairWeight;
        public float calmWeight;
        public float joyWeight;
        public float wonderWeight;
        public float sourceWeight;
        public float distortionPenalty;

        [Header("Special Biases")]
        public float achievableBias;
        public float challengeBias;
    }

    [Serializable]
    public class PortalScoreResult
    {
        public ResonancePortalType portalType;
        public float score;
        public ResonancePortalProfile profile;
    }

    [Serializable]
    public class PortalProfilesConfig
    {
        public List<ResonancePortalProfile> portals = new List<ResonancePortalProfile>();
    }
}
