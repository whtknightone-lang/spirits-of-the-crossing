using UnityEngine;

namespace V243.Chamber
{
    public class SourceResponseFieldController : MonoBehaviour
    {
        [Header("Tuning")]
        [SerializeField] private float sincerityWeight = 0.55f;
        [SerializeField] private float growthPull = 0.35f;
        [SerializeField] private float distortionSoftening = 0.50f;
        [SerializeField] private float crownBias = 0.40f;

        public ResonanceVector CurrentSourceResponse { get; private set; } = new ResonanceVector();

        public void Recalculate(ResonanceVector playerCore, ResonanceVector aiAggregate)
        {
            playerCore ??= ResonanceVector.Zero;
            aiAggregate ??= ResonanceVector.Zero;

            float sincerity = Mathf.Clamp01(
                playerCore.calm * 0.30f +
                playerCore.wonder * 0.20f +
                playerCore.sourceAlignment * 0.35f +
                playerCore.stillness * 0.15f);

            float openness = Mathf.Clamp01(
                playerCore.flow * 0.20f +
                playerCore.joy * 0.20f +
                playerCore.wonder * 0.25f +
                playerCore.sourceAlignment * 0.35f);

            ResonanceVector response = new ResonanceVector
            {
                stillness = Mathf.Clamp01(playerCore.stillness * sincerityWeight + aiAggregate.stillness * 0.15f),
                flow = Mathf.Clamp01(playerCore.flow * 0.25f + openness * 0.35f),
                spin = Mathf.Clamp01(playerCore.spin * 0.20f + openness * 0.10f),
                pairSync = Mathf.Clamp01(playerCore.pairSync * 0.20f + aiAggregate.pairSync * 0.15f),
                calm = Mathf.Clamp01(playerCore.calm * sincerityWeight + 0.15f),
                joy = Mathf.Clamp01(playerCore.joy * 0.30f + openness * 0.20f),
                wonder = Mathf.Clamp01(playerCore.wonder * 0.45f + growthPull),
                distortion = Mathf.Clamp01(playerCore.distortion * (1f - distortionSoftening)),
                sourceAlignment = Mathf.Clamp01(playerCore.sourceAlignment * 0.50f + sincerity * 0.20f + crownBias)
            };

            response.Clamp01();
            CurrentSourceResponse = response;
        }
    }
}
