using System.Collections.Generic;
using UnityEngine;

namespace V243.Chamber
{
    public class SoloStrongPortalScorer : MonoBehaviour
    {
        [SerializeField] private UnifiedChamberFieldController unifiedChamberFieldController;
        [SerializeField] private PortalProfileLoader portalProfileLoader;

        [Header("Results")]
        public ResonancePortalType currentPortal;
        public ResonancePortalType achievablePortal;
        public ResonancePortalType challengePortal;

        public List<PortalScoreResult> lastScores = new List<PortalScoreResult>();

        private void Reset()
        {
            unifiedChamberFieldController = GetComponent<UnifiedChamberFieldController>();
            portalProfileLoader = GetComponent<PortalProfileLoader>();
        }

        public void EvaluatePortals()
        {
            lastScores.Clear();
            if (portalProfileLoader == null || portalProfileLoader.loadedConfig == null)
            {
                Debug.LogWarning("No portal profile loader/config available.");
                return;
            }

            ResonanceVector player = unifiedChamberFieldController != null ? unifiedChamberFieldController.playerCore : ResonanceVector.Zero;
            ResonanceVector chamber = unifiedChamberFieldController != null ? unifiedChamberFieldController.chamberField : player;
            ResonanceVector source = unifiedChamberFieldController != null ? unifiedChamberFieldController.sourceResponse : ResonanceVector.Zero;

            foreach (ResonancePortalProfile profile in portalProfileLoader.loadedConfig.portals)
            {
                float playerScore = Score(profile, player);
                float chamberScore = Score(profile, chamber);
                float sourceGrowthBias = (
                    source.sourceAlignment * profile.sourceWeight +
                    source.wonder * profile.achievableBias -
                    source.distortion * profile.distortionPenalty * 0.25f);

                // Solo-strong rule:
                // current portal leans heavily to player,
                // achievable portal gets more chamber + source,
                // challenge portal later uses instability + attraction.
                float compositeScore = playerScore * 0.70f + chamberScore * 0.25f + sourceGrowthBias * 0.05f;

                lastScores.Add(new PortalScoreResult
                {
                    portalType = profile.portalType,
                    score = compositeScore,
                    profile = profile
                });
            }

            lastScores.Sort((a, b) => b.score.CompareTo(a.score));
            if (lastScores.Count == 0) return;

            currentPortal = lastScores[0].portalType;
            achievablePortal = DetermineAchievablePortal(player, chamber, source);
            challengePortal = DetermineChallengePortal(player, chamber);
        }

        private ResonancePortalType DetermineAchievablePortal(ResonanceVector player, ResonanceVector chamber, ResonanceVector source)
        {
            float best = float.MinValue;
            ResonancePortalType bestType = currentPortal;

            foreach (ResonancePortalProfile profile in portalProfileLoader.loadedConfig.portals)
            {
                float score =
                    Score(profile, chamber) * 0.55f +
                    Score(profile, source) * 0.25f +
                    Score(profile, player) * 0.20f +
                    profile.achievableBias * 0.20f;

                if (score > best)
                {
                    best = score;
                    bestType = profile.portalType;
                }
            }

            return bestType;
        }

        private ResonancePortalType DetermineChallengePortal(ResonanceVector player, ResonanceVector chamber)
        {
            float best = float.MinValue;
            ResonancePortalType bestType = currentPortal;
            float instability = player.distortion * 0.65f + (1f - player.calm) * 0.20f + (1f - player.stillness) * 0.15f;

            foreach (ResonancePortalProfile profile in portalProfileLoader.loadedConfig.portals)
            {
                float attraction = Score(profile, chamber) * 0.50f + Score(profile, player) * 0.30f;
                float challengeScore = attraction + instability * profile.challengeBias;

                if (challengeScore > best)
                {
                    best = challengeScore;
                    bestType = profile.portalType;
                }
            }

            return bestType;
        }

        private float Score(ResonancePortalProfile p, ResonanceVector sample)
        {
            return
                sample.stillness * p.stillnessWeight +
                sample.flow * p.flowWeight +
                sample.spin * p.spinWeight +
                sample.pairSync * p.pairWeight +
                sample.calm * p.calmWeight +
                sample.joy * p.joyWeight +
                sample.wonder * p.wonderWeight +
                sample.sourceAlignment * p.sourceWeight -
                sample.distortion * p.distortionPenalty;
        }
    }
}
