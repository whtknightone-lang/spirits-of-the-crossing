using UnityEngine;

namespace V243.Chamber
{
    public class SoloStrongDebugHUD : MonoBehaviour
    {
        [SerializeField] private UnifiedChamberFieldController unifiedChamberFieldController;
        [SerializeField] private SoloStrongPortalScorer portalScorer;
        [SerializeField] private bool visible = true;

        private void Reset()
        {
            unifiedChamberFieldController = GetComponent<UnifiedChamberFieldController>();
            portalScorer = GetComponent<SoloStrongPortalScorer>();
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.BackQuote))
            {
                visible = !visible;
            }
        }

        private void OnGUI()
        {
            if (!visible || unifiedChamberFieldController == null) return;

            GUILayout.BeginArea(new Rect(12, 12, 420, 520), GUI.skin.box);
            GUILayout.Label("SoloStrongUnifiedChamberField");
            DrawVector("Player", unifiedChamberFieldController.playerCore);
            DrawVector("AI Aggregate", unifiedChamberFieldController.aiAggregate);
            DrawVector("Source", unifiedChamberFieldController.sourceResponse);
            DrawVector("Chamber", unifiedChamberFieldController.chamberField);

            if (portalScorer != null)
            {
                GUILayout.Space(8);
                GUILayout.Label($"Current Portal: {portalScorer.currentPortal}");
                GUILayout.Label($"Achievable Portal: {portalScorer.achievablePortal}");
                GUILayout.Label($"Challenge Portal: {portalScorer.challengePortal}");
            }

            GUILayout.Space(8);
            GUILayout.Label("Keys: 1 stillness, 2 flow, 3 spin, 4 pair, Q calm, W joy, E wonder, R distortion, T source, Y evaluate, U reset, ` HUD");
            GUILayout.EndArea();
        }

        private void DrawVector(string label, ResonanceVector v)
        {
            GUILayout.Label($"{label}: st={v.stillness:0.00} fl={v.flow:0.00} sp={v.spin:0.00} pr={v.pairSync:0.00} ca={v.calm:0.00} jo={v.joy:0.00} wo={v.wonder:0.00} di={v.distortion:0.00} so={v.sourceAlignment:0.00}");
        }
    }
}
