using System.IO;
using UnityEngine;

namespace V243.Chamber
{
    public class PortalProfileLoader : MonoBehaviour
    {
        [SerializeField] private string fileName = "portal_profiles_solo_strong.json";
        [SerializeField] private bool loadOnAwake = true;

        public PortalProfilesConfig loadedConfig;

        private void Awake()
        {
            if (loadOnAwake)
            {
                Load();
            }
        }

        public bool Load()
        {
            string path = Path.Combine(Application.streamingAssetsPath, fileName);
            if (!File.Exists(path))
            {
                Debug.LogWarning($"Portal profile file not found: {path}");
                loadedConfig = new PortalProfilesConfig();
                return false;
            }

            string json = File.ReadAllText(path);
            loadedConfig = JsonUtility.FromJson<PortalProfilesConfig>(json);
            if (loadedConfig == null)
            {
                Debug.LogWarning("Portal profile JSON could not be parsed.");
                loadedConfig = new PortalProfilesConfig();
                return false;
            }

            Debug.Log($"Loaded {loadedConfig.portals.Count} portal profiles from {path}");
            return true;
        }
    }
}
