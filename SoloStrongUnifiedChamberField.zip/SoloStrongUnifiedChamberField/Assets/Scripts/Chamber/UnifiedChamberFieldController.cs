using UnityEngine;

namespace V243.Chamber
{
    public class UnifiedChamberFieldController : MonoBehaviour
    {
        [Header("Inputs")]
        public ResonanceVector playerCore = new ResonanceVector();
        [SerializeField] private AIFieldInfluenceController aiFieldInfluenceController;
        [SerializeField] private SourceResponseFieldController sourceResponseFieldController;
        [SerializeField] private ChamberWeightsLoader chamberWeightsLoader;

        [Header("Mode")]
        [SerializeField] private bool soloMode = true;

        [Header("Outputs")]
        public ResonanceVector aiAggregate = new ResonanceVector();
        public ResonanceVector sourceResponse = new ResonanceVector();
        public ResonanceVector chamberField = new ResonanceVector();

        public ChamberWeightSet ActiveWeights => soloMode
            ? chamberWeightsLoader != null ? chamberWeightsLoader.loadedConfig.solo : new ChamberWeightsConfig().solo
            : chamberWeightsLoader != null ? chamberWeightsLoader.loadedConfig.multiplayer : new ChamberWeightsConfig().multiplayer;

        public bool SoloMode
        {
            get => soloMode;
            set => soloMode = value;
        }

        private void Reset()
        {
            aiFieldInfluenceController = GetComponent<AIFieldInfluenceController>();
            sourceResponseFieldController = GetComponent<SourceResponseFieldController>();
            chamberWeightsLoader = GetComponent<ChamberWeightsLoader>();
        }

        public void Recalculate()
        {
            if (aiFieldInfluenceController != null)
            {
                aiFieldInfluenceController.RefreshAgents(playerCore);
                aiAggregate = aiFieldInfluenceController.AggregateField.Clone();
            }
            else
            {
                aiAggregate = ResonanceVector.Zero;
            }

            if (sourceResponseFieldController != null)
            {
                sourceResponseFieldController.Recalculate(playerCore, aiAggregate);
                sourceResponse = sourceResponseFieldController.CurrentSourceResponse.Clone();
            }
            else
            {
                sourceResponse = ResonanceVector.Zero;
            }

            ChamberWeightSet w = ActiveWeights;
            chamberField = new ResonanceVector
            {
                stillness = playerCore.stillness * w.playerWeight + aiAggregate.stillness * w.aiWeight + sourceResponse.stillness * w.sourceWeight,
                flow = playerCore.flow * w.playerWeight + aiAggregate.flow * w.aiWeight + sourceResponse.flow * w.sourceWeight,
                spin = playerCore.spin * w.playerWeight + aiAggregate.spin * w.aiWeight + sourceResponse.spin * w.sourceWeight,
                pairSync = playerCore.pairSync * w.playerWeight + aiAggregate.pairSync * w.aiWeight + sourceResponse.pairSync * w.sourceWeight,
                calm = playerCore.calm * w.playerWeight + aiAggregate.calm * w.aiWeight + sourceResponse.calm * w.sourceWeight,
                joy = playerCore.joy * w.playerWeight + aiAggregate.joy * w.aiWeight + sourceResponse.joy * w.sourceWeight,
                wonder = playerCore.wonder * w.playerWeight + aiAggregate.wonder * w.aiWeight + sourceResponse.wonder * w.sourceWeight,
                distortion = playerCore.distortion * 0.80f + aiAggregate.distortion * 0.15f + sourceResponse.distortion * 0.05f,
                sourceAlignment = playerCore.sourceAlignment * 0.65f + aiAggregate.sourceAlignment * 0.15f + sourceResponse.sourceAlignment * 0.20f
            };
            chamberField.Clamp01();
        }
    }
}
