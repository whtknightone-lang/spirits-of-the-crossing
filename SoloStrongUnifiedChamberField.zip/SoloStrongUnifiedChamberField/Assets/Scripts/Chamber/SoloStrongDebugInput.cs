using UnityEngine;

namespace V243.Chamber
{
    public class SoloStrongDebugInput : MonoBehaviour
    {
        [SerializeField] private UnifiedChamberFieldController unifiedChamberFieldController;
        [SerializeField] private SoloStrongPortalScorer soloStrongPortalScorer;

        [Header("Input Step")]
        [SerializeField] private float step = 0.1f;

        private void Reset()
        {
            unifiedChamberFieldController = GetComponent<UnifiedChamberFieldController>();
            soloStrongPortalScorer = GetComponent<SoloStrongPortalScorer>();
        }

        private void Update()
        {
            if (unifiedChamberFieldController == null) return;
            ResonanceVector p = unifiedChamberFieldController.playerCore;

            if (Input.GetKeyDown(KeyCode.Alpha1)) p.stillness = Mathf.Clamp01(p.stillness + step);
            if (Input.GetKeyDown(KeyCode.Alpha2)) p.flow = Mathf.Clamp01(p.flow + step);
            if (Input.GetKeyDown(KeyCode.Alpha3)) p.spin = Mathf.Clamp01(p.spin + step);
            if (Input.GetKeyDown(KeyCode.Alpha4)) p.pairSync = Mathf.Clamp01(p.pairSync + step);
            if (Input.GetKeyDown(KeyCode.Q)) p.calm = Mathf.Clamp01(p.calm + step);
            if (Input.GetKeyDown(KeyCode.W)) p.joy = Mathf.Clamp01(p.joy + step);
            if (Input.GetKeyDown(KeyCode.E)) p.wonder = Mathf.Clamp01(p.wonder + step);
            if (Input.GetKeyDown(KeyCode.R)) p.distortion = Mathf.Clamp01(p.distortion + step);
            if (Input.GetKeyDown(KeyCode.T)) p.sourceAlignment = Mathf.Clamp01(p.sourceAlignment + step);

            if (Input.GetKeyDown(KeyCode.Y))
            {
                unifiedChamberFieldController.Recalculate();
                if (soloStrongPortalScorer != null)
                {
                    soloStrongPortalScorer.EvaluatePortals();
                }
            }

            if (Input.GetKeyDown(KeyCode.U))
            {
                unifiedChamberFieldController.playerCore = new ResonanceVector();
                unifiedChamberFieldController.Recalculate();
            }
        }
    }
}
