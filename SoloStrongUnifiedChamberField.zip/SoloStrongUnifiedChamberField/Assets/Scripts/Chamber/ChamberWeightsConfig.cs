using System;
using UnityEngine;

namespace V243.Chamber
{
    [Serializable]
    public class ChamberWeightSet
    {
        [Range(0f, 1f)] public float playerWeight = 0.70f;
        [Range(0f, 1f)] public float aiWeight = 0.20f;
        [Range(0f, 1f)] public float sourceWeight = 0.10f;
    }

    [Serializable]
    public class ChamberWeightsConfig
    {
        public ChamberWeightSet solo = new ChamberWeightSet
        {
            playerWeight = 0.70f,
            aiWeight = 0.20f,
            sourceWeight = 0.10f
        };

        public ChamberWeightSet multiplayer = new ChamberWeightSet
        {
            playerWeight = 0.60f,
            aiWeight = 0.25f,
            sourceWeight = 0.15f
        };
    }
}
