using System.Collections.Generic;
using UnityEngine;

namespace V243.Chamber
{
    public class AIFieldInfluenceController : MonoBehaviour
    {
        [SerializeField] private List<AIResonanceAgent> agents = new List<AIResonanceAgent>();
        public IReadOnlyList<AIResonanceAgent> Agents => agents;
        public ResonanceVector AggregateField { get; private set; } = new ResonanceVector();

        public void RefreshAgents(ResonanceVector playerCore)
        {
            foreach (AIResonanceAgent agent in agents)
            {
                if (agent != null)
                {
                    agent.UpdateField(playerCore);
                }
            }

            AggregateField = AggregateAgents();
        }

        private ResonanceVector AggregateAgents()
        {
            ResonanceVector aggregate = new ResonanceVector();
            int count = 0;

            foreach (AIResonanceAgent agent in agents)
            {
                if (agent == null) continue;
                ResonanceVector f = agent.CurrentField;
                aggregate.stillness += f.stillness;
                aggregate.flow += f.flow;
                aggregate.spin += f.spin;
                aggregate.pairSync += f.pairSync;
                aggregate.calm += f.calm;
                aggregate.joy += f.joy;
                aggregate.wonder += f.wonder;
                aggregate.distortion += f.distortion;
                aggregate.sourceAlignment += f.sourceAlignment;
                count++;
            }

            if (count == 0)
            {
                return aggregate;
            }

            float n = count;
            aggregate.stillness /= n;
            aggregate.flow /= n;
            aggregate.spin /= n;
            aggregate.pairSync /= n;
            aggregate.calm /= n;
            aggregate.joy /= n;
            aggregate.wonder /= n;
            aggregate.distortion /= n;
            aggregate.sourceAlignment /= n;
            aggregate.Clamp01();
            return aggregate;
        }

#if UNITY_EDITOR
        [ContextMenu("Auto Collect Child Agents")]
        private void AutoCollectChildAgents()
        {
            agents.Clear();
            agents.AddRange(GetComponentsInChildren<AIResonanceAgent>(true));
        }
#endif
    }
}
