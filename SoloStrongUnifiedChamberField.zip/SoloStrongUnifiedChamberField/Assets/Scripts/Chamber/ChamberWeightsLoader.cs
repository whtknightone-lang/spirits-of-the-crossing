using System.IO;
using UnityEngine;

namespace V243.Chamber
{
    public class ChamberWeightsLoader : MonoBehaviour
    {
        [SerializeField] private string fileName = "chamber_weights.json";
        [SerializeField] private bool loadOnAwake = true;

        public ChamberWeightsConfig loadedConfig = new ChamberWeightsConfig();

        private void Awake()
        {
            if (loadOnAwake)
            {
                Load();
            }
        }

        public bool Load()
        {
            string path = Path.Combine(Application.streamingAssetsPath, fileName);
            if (!File.Exists(path))
            {
                Debug.LogWarning($"Chamber weights file not found: {path}. Using defaults.");
                return false;
            }

            string json = File.ReadAllText(path);
            ChamberWeightsConfig parsed = JsonUtility.FromJson<ChamberWeightsConfig>(json);
            if (parsed == null)
            {
                Debug.LogWarning("Chamber weights JSON could not be parsed. Using defaults.");
                return false;
            }

            loadedConfig = parsed;
            return true;
        }
    }
}
