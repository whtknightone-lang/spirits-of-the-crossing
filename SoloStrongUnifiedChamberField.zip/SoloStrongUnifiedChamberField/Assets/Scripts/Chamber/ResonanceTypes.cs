using System;
using UnityEngine;

namespace V243.Chamber
{
    [Serializable]
    public class ResonanceVector
    {
        [Range(0f, 1f)] public float stillness;
        [Range(0f, 1f)] public float flow;
        [Range(0f, 1f)] public float spin;
        [Range(0f, 1f)] public float pairSync;
        [Range(0f, 1f)] public float calm;
        [Range(0f, 1f)] public float joy;
        [Range(0f, 1f)] public float wonder;
        [Range(0f, 1f)] public float distortion;
        [Range(0f, 1f)] public float sourceAlignment;

        public static ResonanceVector Zero => new ResonanceVector();

        public ResonanceVector Clone()
        {
            return new ResonanceVector
            {
                stillness = stillness,
                flow = flow,
                spin = spin,
                pairSync = pairSync,
                calm = calm,
                joy = joy,
                wonder = wonder,
                distortion = distortion,
                sourceAlignment = sourceAlignment
            };
        }

        public void Clamp01()
        {
            stillness = Mathf.Clamp01(stillness);
            flow = Mathf.Clamp01(flow);
            spin = Mathf.Clamp01(spin);
            pairSync = Mathf.Clamp01(pairSync);
            calm = Mathf.Clamp01(calm);
            joy = Mathf.Clamp01(joy);
            wonder = Mathf.Clamp01(wonder);
            distortion = Mathf.Clamp01(distortion);
            sourceAlignment = Mathf.Clamp01(sourceAlignment);
        }
    }

    public enum ResonancePortalType
    {
        FireMilitary,
        OceanSurf,
        ForestCalm,
        SourceEnergyWells,
        AirDancing
    }

    public enum AIInfluenceMode
    {
        Mirror,
        Companion,
        Contrast,
        Guide,
        Challenger
    }
}
