using UnityEngine;

namespace V243.Chamber
{
    public class AIResonanceAgent : MonoBehaviour
    {
        [SerializeField] private string agentId = "AI_Agent";
        [SerializeField] private AIInfluenceMode influenceMode = AIInfluenceMode.Companion;
        [SerializeField] private float influenceStrength = 0.75f;
        [SerializeField] private ResonanceVector baseDisposition = new ResonanceVector
        {
            calm = 0.5f,
            wonder = 0.4f,
            sourceAlignment = 0.35f,
            flow = 0.3f
        };

        public string AgentId => agentId;
        public AIInfluenceMode InfluenceMode => influenceMode;
        public float InfluenceStrength => influenceStrength;
        public ResonanceVector CurrentField { get; private set; } = new ResonanceVector();

        public void UpdateField(ResonanceVector playerCore)
        {
            if (playerCore == null)
            {
                CurrentField = baseDisposition.Clone();
                return;
            }

            ResonanceVector v = baseDisposition.Clone();
            float s = Mathf.Clamp01(influenceStrength);

            switch (influenceMode)
            {
                case AIInfluenceMode.Mirror:
                    v.stillness = Mathf.Lerp(v.stillness, playerCore.stillness, s);
                    v.flow = Mathf.Lerp(v.flow, playerCore.flow, s);
                    v.spin = Mathf.Lerp(v.spin, playerCore.spin, s);
                    v.pairSync = Mathf.Lerp(v.pairSync, playerCore.pairSync, s * 0.6f);
                    v.calm = Mathf.Lerp(v.calm, playerCore.calm, s);
                    v.joy = Mathf.Lerp(v.joy, playerCore.joy, s);
                    v.wonder = Mathf.Lerp(v.wonder, playerCore.wonder, s);
                    v.distortion = Mathf.Lerp(v.distortion, playerCore.distortion * 0.6f, s * 0.5f);
                    v.sourceAlignment = Mathf.Lerp(v.sourceAlignment, playerCore.sourceAlignment, s * 0.8f);
                    break;

                case AIInfluenceMode.Companion:
                    v.calm = Mathf.Lerp(v.calm, playerCore.calm, s * 0.7f);
                    v.flow = Mathf.Lerp(v.flow, playerCore.flow, s * 0.6f);
                    v.joy = Mathf.Lerp(v.joy, playerCore.joy, s * 0.7f);
                    v.sourceAlignment = Mathf.Lerp(v.sourceAlignment, playerCore.sourceAlignment, s * 0.5f);
                    v.distortion = Mathf.Min(v.distortion, playerCore.distortion * 0.5f);
                    v.pairSync = Mathf.Max(v.pairSync, playerCore.pairSync * 0.7f);
                    break;

                case AIInfluenceMode.Contrast:
                    v.stillness = 1f - playerCore.stillness;
                    v.flow = 1f - playerCore.flow;
                    v.spin = 1f - playerCore.spin;
                    v.calm = 1f - playerCore.calm;
                    v.joy = 1f - playerCore.joy;
                    v.wonder = Mathf.Lerp(v.wonder, 1f - playerCore.wonder, s);
                    v.distortion = Mathf.Lerp(v.distortion, playerCore.distortion * 0.8f, s * 0.6f);
                    break;

                case AIInfluenceMode.Guide:
                    v.stillness = Mathf.Max(v.stillness, playerCore.stillness * 0.85f);
                    v.calm = Mathf.Max(v.calm, playerCore.calm * 0.9f);
                    v.wonder = Mathf.Max(v.wonder, playerCore.wonder * 0.85f + 0.15f);
                    v.sourceAlignment = Mathf.Max(v.sourceAlignment, playerCore.sourceAlignment * 0.9f + 0.1f);
                    v.distortion = Mathf.Min(v.distortion, playerCore.distortion * 0.35f);
                    break;

                case AIInfluenceMode.Challenger:
                    v.spin = Mathf.Max(v.spin, playerCore.spin * 0.7f + 0.2f);
                    v.flow = Mathf.Max(v.flow, playerCore.flow * 0.6f + 0.15f);
                    v.joy = Mathf.Lerp(v.joy, playerCore.joy * 0.7f, s * 0.5f);
                    v.distortion = Mathf.Max(v.distortion, playerCore.distortion * 0.6f + 0.1f);
                    break;
            }

            v.Clamp01();
            CurrentField = v;
        }
    }
}
