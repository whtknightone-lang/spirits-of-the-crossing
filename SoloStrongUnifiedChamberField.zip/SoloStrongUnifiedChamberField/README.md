# SoloStrongUnifiedChamberField

Unity-ready package for a player-centered cave field where the solo player remains the dominant signal while AI and source still participate.

## Included scripts

- `ResonanceTypes.cs`
- `ChamberWeightsConfig.cs`
- `PortalProfiles.cs`
- `PortalProfileLoader.cs`
- `ChamberWeightsLoader.cs`
- `AIResonanceAgent.cs`
- `AIFieldInfluenceController.cs`
- `SourceResponseFieldController.cs`
- `UnifiedChamberFieldController.cs`
- `SoloStrongPortalScorer.cs`
- `SoloStrongDebugInput.cs`
- `SoloStrongDebugHUD.cs`

## Included data

- `Assets/StreamingAssets/chamber_weights.json`
- `Assets/StreamingAssets/portal_profiles_solo_strong.json`

## Setup in Unity

1. Create an empty GameObject named `SoloStrongChamberRoot`.
2. Add these components:
   - `ChamberWeightsLoader`
   - `PortalProfileLoader`
   - `AIFieldInfluenceController`
   - `SourceResponseFieldController`
   - `UnifiedChamberFieldController`
   - `SoloStrongPortalScorer`
   - `SoloStrongDebugInput`
   - `SoloStrongDebugHUD`
3. Create child GameObjects with `AIResonanceAgent` for any ghost-alien spirits or support AI.
4. In the inspector on `AIFieldInfluenceController`, assign the agents list or use the context menu to auto-collect children.
5. Put the JSON files in `Assets/StreamingAssets` exactly as included.
6. Enter Play mode and press `Y` to evaluate current / achievable / challenge portals.

## Debug keys

- `1` stillness
- `2` flow
- `3` spin
- `4` pair sync
- `Q` calm
- `W` joy
- `E` wonder
- `R` distortion
- `T` source alignment
- `Y` recalculate chamber + evaluate portals
- `U` reset player state
- `` ` `` toggle HUD

## Design rule

In solo mode:
- **current portal** is mostly player-led
- **achievable portal** is lifted by source and AI guidance
- **challenge portal** is shaped by player tension plus contrast and temptation

This keeps the solo player strong while still making the cave feel alive.
