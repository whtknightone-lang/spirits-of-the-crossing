
import random
import torch

class AgentWorld:
    def __init__(self, size, device, num_agents=80):
        self.size = size
        self.device = device
        self.agents = [self._new_agent() for _ in range(num_agents)]

    def _new_agent(self):
        return {
            "pos": [random.uniform(0, self.size-1), random.uniform(0, self.size-1)],
            "emotion": [random.uniform(-1,1) for _ in range(3)],  # joy, love, confidence proxy
        }

    def update(self, dt, now_field, potential_field, player):
        px, py = player.grid_position()
        for agent in self.agents:
            ax, ay = agent["pos"]
            ix = max(0, min(self.size-1, int(ax)))
            iy = max(0, min(self.size-1, int(ay)))

            local_now = float(now_field[ix, iy].item())
            local_potential = float(potential_field[ix, iy].item())

            dx = px - ax
            dy = py - ay
            dist = max(0.001, (dx*dx + dy*dy) ** 0.5)

            if dist < 12:
                ax += (dx / dist) * dt * 8.0 * (0.2 + max(0.0, player.core[6].item() + 0.5))
                ay += (dy / dist) * dt * 8.0 * (0.2 + max(0.0, player.core[6].item() + 0.5))
                agent["emotion"][1] += 0.01
            else:
                ax += random.uniform(-1, 1) * dt * 10.0
                ay += random.uniform(-1, 1) * dt * 10.0

            agent["emotion"][0] += (local_now - agent["emotion"][0]) * 0.01
            agent["emotion"][1] += (player.core[1].item() * 0.1 - agent["emotion"][1]) * 0.008
            agent["emotion"][2] += (local_potential - agent["emotion"][2]) * 0.01

            ax = max(0, min(self.size - 1, ax))
            ay = max(0, min(self.size - 1, ay))
            agent["pos"] = [ax, ay]
            agent["emotion"] = [max(-1.5, min(1.5, v)) for v in agent["emotion"]]

    def aggregate_world_emotion(self):
        field = torch.zeros((self.size, self.size), device=self.device)
        for agent in self.agents:
            x = int(agent["pos"][0])
            y = int(agent["pos"][1])
            field[x, y] += sum(agent["emotion"]) / 3.0
        return field

    def count_near_player(self, player, radius=10):
        px, py = player.grid_position()
        count = 0
        for agent in self.agents:
            dx = px - agent["pos"][0]
            dy = py - agent["pos"][1]
            if (dx*dx + dy*dy) ** 0.5 <= radius:
                count += 1
        return count

    def to_dict(self):
        return {"agents": self.agents}

    def from_dict(self, data):
        self.agents = data["agents"]
