import pygame

import torch

class PlayerBody:
    def __init__(self, size, device):
        self.size = size
        self.device = device
        self.pos = torch.tensor([size / 2, size / 2], device=device, dtype=torch.float32)
        self.vel = torch.zeros(2, device=device)
        self.facing = torch.tensor([1.0, 0.0], device=device)
        self.speed = 24.0
        self.core = torch.zeros(7, device=device)

    def handle_movement(self, keys, dt):
        direction = torch.zeros(2, device=self.device)

        if keys[276] or keys[pygame.K_LEFT]:
            direction[1] -= 1
        if keys[275] or keys[pygame.K_RIGHT]:
            direction[1] += 1
        if keys[273] or keys[pygame.K_UP]:
            direction[0] -= 1
        if keys[274] or keys[pygame.K_DOWN]:
            direction[0] += 1

        # WASD fallback using raw key indexes commonly available in pygame
        try:
            if keys[pygame.K_a]:
                direction[1] -= 1
            if keys[pygame.K_d]:
                direction[1] += 1
            if keys[pygame.K_w]:
                direction[0] -= 1
            if keys[pygame.K_s]:
                direction[0] += 1
        except Exception:
            pass

        norm = torch.norm(direction)
        if norm > 0:
            direction = direction / norm
            self.facing = direction.clone()

        self.vel = direction * self.speed
        self.pos += self.vel * dt
        self.pos = torch.clamp(self.pos, 0, self.size - 1)

    def update(self, dt, now_field, potential_field):
        x, y = self.grid_position()
        local_now = now_field[x, y]
        local_potential = potential_field[x, y]

        self.core[0] += (local_now - self.core[0]) * 0.02
        self.core[1] += (local_potential - self.core[1]) * 0.015
        self.core[2] += (torch.abs(local_now) - self.core[2]) * 0.01
        self.core[3] += (local_potential * 0.8 - self.core[3]) * 0.02
        self.core[4] += (self.vel.norm() * 0.01 - self.core[4]) * 0.01
        self.core[5] += ((local_now + local_potential) * 0.5 - self.core[5]) * 0.01
        self.core[6] += (0.2 - self.core[6]) * 0.004
        self.core.clamp_(-1.5, 1.5)

    def emit_expression_burst(self, field):
        x, y = self.grid_position()
        r = 4
        x0 = max(0, x-r)
        x1 = min(self.size, x+r+1)
        y0 = max(0, y-r)
        y1 = min(self.size, y+r+1)
        field[x0:x1, y0:y1] += 0.15
        self.core[4] += 0.08

    def emit_kindness_burst(self, field):
        x, y = self.grid_position()
        r = 6
        x0 = max(0, x-r)
        x1 = min(self.size, x+r+1)
        y0 = max(0, y-r)
        y1 = min(self.size, y+r+1)
        field[x0:x1, y0:y1] += 0.10
        self.core[6] += 0.10
        self.core[1] += 0.05

    def recenter(self):
        self.pos[:] = self.size / 2

    def resonance_mean(self):
        return self.core.mean()

    def grid_position(self):
        return int(self.pos[0].item()), int(self.pos[1].item())

    def grid_position_xy(self):
        return self.grid_position()

    def to_dict(self):
        return {
            "pos": self.pos.detach().cpu().tolist(),
            "vel": self.vel.detach().cpu().tolist(),
            "facing": self.facing.detach().cpu().tolist(),
            "core": self.core.detach().cpu().tolist(),
        }

    def from_dict(self, data):
        self.pos = torch.tensor(data["pos"], device=self.device, dtype=torch.float32)
        self.vel = torch.tensor(data["vel"], device=self.device, dtype=torch.float32)
        self.facing = torch.tensor(data["facing"], device=self.device, dtype=torch.float32)
        self.core = torch.tensor(data["core"], device=self.device, dtype=torch.float32)
