
import torch

class ResonanceMemorySystem:
    def __init__(self, size, device):
        self.size = size
        self.device = device
        self.now_field = torch.zeros((size, size), device=device)
        self.memory_field = torch.zeros((size, size), device=device)
        self.potential_field = torch.zeros((size, size), device=device)

    def update(self, dt, world_emotion, player_resonance):
        self.now_field += 0.018 * torch.randn_like(self.now_field) * dt
        self.now_field += world_emotion * 0.003
        self.now_field += player_resonance * 0.002

        self.memory_field += (self.now_field * 0.01 + self.potential_field * 0.002) * max(dt, 0.016)
        self.potential_field = torch.tanh(self.now_field + self.memory_field)

        self.now_field *= 0.999
        self.memory_field *= 0.9995

    def inject_now(self, amount):
        self.now_field += amount

    def inject_memory(self, amount):
        self.memory_field += amount

    def inject_potential(self, amount):
        self.potential_field += amount

    def clamp_all(self):
        self.now_field.clamp_(-2.5, 2.5)
        self.memory_field.clamp_(-2.5, 2.5)
        self.potential_field.clamp_(-2.5, 2.5)

    def from_dict(self, data):
        self.now_field = torch.tensor(data["now"], device=self.device, dtype=torch.float32)
        self.memory_field = torch.tensor(data["memory"], device=self.device, dtype=torch.float32)
        self.potential_field = torch.tensor(data["potential"], device=self.device, dtype=torch.float32)
