
import os
import json
import pygame
import numpy as np
import torch

from systems.resonance_memory import ResonanceMemorySystem
from systems.player_body import PlayerBody
from systems.agent_world import AgentWorld

class V43Engine:
    def __init__(self, size, device):
        self.size = size
        self.device = device

        self.memory = ResonanceMemorySystem(size, device)
        self.player = PlayerBody(size=size, device=device)
        self.world = AgentWorld(size=size, device=device, num_agents=90)

        self.font = pygame.font.SysFont("arial", 16)
        self.title_font = pygame.font.SysFont("arial", 18, bold=True)

    def handle_keydown(self, key):
        if key == pygame.K_n:
            self.memory.inject_now(0.15)
        elif key == pygame.K_m:
            self.memory.inject_memory(0.08)
        elif key == pygame.K_f:
            self.memory.inject_potential(0.08)
        elif key == pygame.K_e:
            self.player.emit_expression_burst(self.memory.now_field)
        elif key == pygame.K_q:
            self.player.emit_kindness_burst(self.memory.now_field)
        elif key == pygame.K_r:
            self.player.recenter()
        elif key == pygame.K_s:
            self.save_state()
        elif key == pygame.K_l:
            self.load_state()

    def handle_input(self, dt):
        keys = pygame.key.get_pressed()
        self.player.handle_movement(keys, dt)

    def update(self, dt):
        self.memory.update(dt, self.world.aggregate_world_emotion(), self.player.resonance_mean())
        self.player.update(dt, self.memory.now_field, self.memory.potential_field)
        self.world.update(dt, self.memory.now_field, self.memory.potential_field, self.player)

        # embodied coupling: body affects universe and universe affects body
        px, py = self.player.grid_position()
        self.memory.now_field[px, py] += self.player.core[0].item() * 0.01
        self.memory.memory_field[px, py] += self.player.core[1].item() * 0.004
        self.memory.potential_field[px, py] += self.player.core[3].item() * 0.006

        self.memory.clamp_all()

    def render(self, screen):
        screen.fill((8, 10, 18))

        world_panel = self._world_surface()
        now_panel = self._field_surface(self.memory.now_field, mode="now")
        potential_panel = self._field_surface(self.memory.potential_field, mode="future")

        world_panel = pygame.transform.scale(world_panel, (620, 620))
        now_panel = pygame.transform.scale(now_panel, (280, 280))
        potential_panel = pygame.transform.scale(potential_panel, (280, 280))

        screen.blit(world_panel, (20, 40))
        screen.blit(now_panel, (680, 60))
        screen.blit(potential_panel, (980, 60))

        screen.blit(self.title_font.render("Embodied World", True, (240,240,248)), (20, 12))
        screen.blit(self.title_font.render("Now Field", True, (240,240,248)), (680, 32))
        screen.blit(self.title_font.render("Potential Field", True, (240,240,248)), (980, 32))

        self._draw_hud(screen)

    def _world_surface(self):
        base = self.memory.now_field.detach().cpu().numpy()
        base = base - base.min()
        maxv = base.max()
        if maxv > 1e-8:
            base = base / maxv

        img = np.stack([
            base * 255,
            90 + base * 120,
            255 - base * 160
        ], axis=-1).clip(0,255).astype(np.uint8)

        surf = pygame.surfarray.make_surface(np.transpose(img, (1,0,2)))

        # draw agents and player directly onto panel surface
        for agent in self.world.agents:
            ax, ay = agent["pos"]
            color = (
                int(max(0, min(255, 120 + agent["emotion"][0] * 80))),
                int(max(0, min(255, 160 + agent["emotion"][1] * 60))),
                int(max(0, min(255, 170 + agent["emotion"][2] * 50))),
            )
            pygame.draw.circle(surf, color, (int(ay), int(ax)), 2)

        px, py = self.player.grid_position_xy()
        pygame.draw.circle(surf, (255, 255, 255), (py, px), 6)
        pygame.draw.circle(surf, (80, 220, 255), (py, px), 10, 2)

        # facing marker
        fx = py + int(self.player.facing[1] * 8)
        fy = px + int(self.player.facing[0] * 8)
        pygame.draw.line(surf, (255, 230, 120), (py, px), (fx, fy), 2)
        return surf

    def _field_surface(self, field, mode="now"):
        arr = field.detach().cpu().numpy()
        arr = arr - arr.min()
        maxv = arr.max()
        if maxv > 1e-8:
            arr = arr / maxv

        if mode == "now":
            img = np.stack([255 - arr * 80, arr * 220, arr * 255], axis=-1)
        else:
            img = np.stack([arr * 255, arr * 180, 255 - arr * 90], axis=-1)

        img = img.clip(0,255).astype(np.uint8)
        return pygame.surfarray.make_surface(np.transpose(img, (1,0,2)))

    def _draw_hud(self, screen):
        lines = [
            "V43 Embodied Player Universe",
            "Move: WASD or arrows",
            "E = expression burst   Q = kindness burst   R = recenter",
            "N/M/F = now / memory / potential injection",
            "S/L = save / load",
            f"Player position: {self.player.grid_position_xy()}",
            f"Player resonance avg: {self.player.core.mean().item():.3f}",
            f"Nearby agents: {self.world.count_near_player(self.player, radius=10)}",
        ]
        y = 390
        for line in lines:
            screen.blit(self.font.render(line, True, (235,235,245)), (680, y))
            y += 22

        labels = ["Joy","Love","Confidence","Creativity","Expression","Experience","Kindness"]
        y = 580
        for i, label in enumerate(labels):
            value = float(self.player.core[i].item())
            bar_w = int((value + 1.0) / 2.0 * 220)
            screen.blit(self.font.render(f"{label}: {value:+.2f}", True, (235,235,245)), (680, y))
            pygame.draw.rect(screen, (50,60,80), (820, y+2, 220, 14))
            pygame.draw.rect(screen, (120,200,255), (820, y+2, max(0, min(220, bar_w)), 14))
            y += 28

    def save_state(self):
        data = {
            "now": self.memory.now_field.detach().cpu().numpy().tolist(),
            "memory": self.memory.memory_field.detach().cpu().numpy().tolist(),
            "potential": self.memory.potential_field.detach().cpu().numpy().tolist(),
            "player": self.player.to_dict(),
            "agents": self.world.to_dict(),
        }
        os.makedirs("save", exist_ok=True)
        with open("save/v43_universe.json", "w") as f:
            json.dump(data, f)

    def load_state(self):
        path = "save/v43_universe.json"
        if not os.path.exists(path):
            return
        with open(path) as f:
            data = json.load(f)

        self.memory.from_dict(data)
        self.player.from_dict(data["player"])
        self.world.from_dict(data["agents"])
