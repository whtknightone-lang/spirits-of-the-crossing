
import pygame
import torch
from engine.v43_engine import V43Engine

WIDTH, HEIGHT = 1280, 820
GRID = 128

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("V43 Embodied Player Universe")
    clock = pygame.time.Clock()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    engine = V43Engine(GRID, device)

    running = True
    while running:
        dt = clock.tick(60) / 1000.0
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                engine.handle_keydown(e.key)

        engine.handle_input(dt)
        engine.update(dt)
        engine.render(screen)
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
