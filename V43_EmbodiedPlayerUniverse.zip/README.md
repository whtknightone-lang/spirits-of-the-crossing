
# V43 Embodied Player Universe

This build gives the player a body inside the universe.

## Run
pip install -r requirements.txt
python main.py

## Controls
- Move: WASD or arrow keys
- E: expression burst
- Q: kindness burst
- R: recenter the player body
- N / M / F: inject now / memory / potential
- S / L: save / load

## What is new
- A visible player body moving inside the universe
- Nearby agents that respond to your position and resonance
- Embodied resonance core that changes based on where and how you move
- Save/load for the embodied state

## Note
This is a prototype embodied layer connected to the resonance-memory universe.
