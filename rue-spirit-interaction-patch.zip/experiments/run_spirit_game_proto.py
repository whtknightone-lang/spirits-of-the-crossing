
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from engine.simulation.universe import Universe
from engine.simulation.universe_patch import UniverseInteractionMixin

class GameUniverse(Universe, UniverseInteractionMixin):
    def __init__(self):
        super().__init__()
        self.init_spirit_layer()

    def step(self):
        super().step()
        self.interaction_step()

if __name__ == "__main__":
    u = GameUniverse()
    for i in range(1000):
        u.step()
        if i % 50 == 0:
            print("step", i)
