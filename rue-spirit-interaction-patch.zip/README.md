
# RUE Spirit Interaction Layer Patch

Adds gameplay layer to RUE:

- agent actions (MOVE, EMIT, STABILIZE, REST)
- agent encounters (merge, repel, orbit)
- world effects (regions evolve from agents)
- spirit animal system (balance + growth assistance)

## Spirit Animals

Special agents that:
- detect imbalance
- reinforce weak regions
- stabilize chaotic clusters
- boost growth and evolution

## Run

python experiments/run_spirit_game_proto.py
