
from engine.interactions.actions import choose_action
from engine.interactions.encounters import resolve_encounter
from engine.interactions.world_effects import apply_world_effect
from engine.interactions.spirit_animals import SpiritAnimal

class UniverseInteractionMixin:

    def init_spirit_layer(self):
        self.spirit_animals = [
            SpiritAnimal("BALANCER"),
            SpiritAnimal("CATALYST"),
            SpiritAnimal("STABILIZER"),
        ]

    def interaction_step(self):
        # actions
        for a in self.agents:
            coherence = a.brain.sync()
            mismatch = 0.5  # placeholder
            action = choose_action(a, coherence, mismatch, a.energy)

            if action == "EMIT":
                a.energy += 0.02
            elif action == "STABILIZE":
                a.energy += 0.01

        # encounters
        for i in range(len(self.agents)):
            for j in range(i+1, len(self.agents)):
                if self.agents[i].planet_id == self.agents[j].planet_id:
                    resolve_encounter(self.agents[i], self.agents[j])

        # world effects
        for a in self.agents:
            planet = self.planets[a.planet_id]
            apply_world_effect(a, planet)

        # spirit animals
        for s in self.spirit_animals:
            s.act(self)
