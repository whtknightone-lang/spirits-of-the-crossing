
def choose_action(agent, coherence, mismatch, energy):
    if energy > 2.0:
        return "EMIT"
    if coherence > 0.6:
        return "STABILIZE"
    if mismatch > 0.4:
        return "MOVE"
    return "REST"
