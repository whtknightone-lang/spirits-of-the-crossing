
import random

class SpiritAnimal:
    def __init__(self, role):
        self.role = role

    def act(self, universe):
        if self.role == "BALANCER":
            weakest = min(universe.planets, key=lambda p: sum(p.region_energies))
            for i in range(len(weakest.region_energies)):
                weakest.region_energies[i] *= 1.05

        elif self.role == "CATALYST":
            p = random.choice(universe.planets)
            for i in range(len(p.region_phases)):
                p.region_phases[i] += 0.1

        elif self.role == "STABILIZER":
            p = random.choice(universe.planets)
            for i in range(len(p.region_phases)):
                p.region_phases[i] *= 0.97
