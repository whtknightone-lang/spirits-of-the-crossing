
import torch, numpy as np

class ResonanceMemory:
    def __init__(self, size, device):
        self.size = size
        self.device = device

        # NOW state
        self.now_field = torch.zeros((size,size), device=device)

        # compressed resonance memory (past distilled)
        self.memory_field = torch.zeros((size,size), device=device)

        # potential future field
        self.potential_field = torch.zeros((size,size), device=device)

    def update(self):
        # NOW evolves
        noise = 0.02 * torch.randn_like(self.now_field)
        self.now_field += noise

        # compress NOW into memory (past is compressed resonance)
        self.memory_field += 0.01 * self.now_field

        # future emerges from interaction of now + memory
        self.potential_field = torch.tanh(self.now_field + self.memory_field)

        # decay to keep system stable
        self.now_field *= 0.99
        self.memory_field *= 0.999

    def render(self):
        field = self.now_field.detach().cpu().numpy()
        field = (field - field.min())/(field.max()+1e-5)

        img = np.uint8(field*255)
        img = np.stack([img, img//2, 255-img], axis=-1)
        return img
