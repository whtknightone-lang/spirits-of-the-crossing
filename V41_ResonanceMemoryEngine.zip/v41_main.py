
import pygame, torch
from resonance_memory import ResonanceMemory

SIZE = 128
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

memory = ResonanceMemory(SIZE, DEVICE)

pygame.init()
screen = pygame.display.set_mode((512,512))
clock = pygame.time.Clock()

def render():
    img = memory.render()
    surf = pygame.surfarray.make_surface(img)
    surf = pygame.transform.scale(surf,(512,512))
    screen.blit(surf,(0,0))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    memory.update()
    render()

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
