
# V41 Resonance Memory Engine

Concept:
- "Now" is the only real state
- Past = compressed resonance memory
- Future = potential emerging from now + memory

Run:
pip install -r requirements.txt
python v41_main.py

System:
NOW -> MEMORY (compression)
NOW + MEMORY -> FUTURE (emergence)
