
import pygame
from systems.ecosystem import Ecosystem
from systems.integrity import StructuralIntegritySystem
from plugins.gpu_accelerator import GPUAccelerator

class CoreEngine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.integrity=StructuralIntegritySystem()
        self.gpu=GPUAccelerator()

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(100):
            self.ecosystem.spawn_entity()

    def update(self,dt):
        self.gpu.process(self.ecosystem)
        self.ecosystem.update(dt)
        self.integrity.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            integrity=e.get("integrity",1.0)
            color=(int(255*(1-integrity)), int(255*integrity), 150)

            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V71–V80 GPU + Structural Integrity",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Avg integrity: {round(self.integrity.avg,3)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
