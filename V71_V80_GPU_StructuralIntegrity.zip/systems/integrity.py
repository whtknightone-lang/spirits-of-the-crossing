
class StructuralIntegritySystem:
    def __init__(self):
        self.avg=0

    def update(self,eco):
        total=0
        for e in eco.entities:
            stress=e.get("stress",0)
            e["integrity"]=max(0,min(1,1-stress))
            total+=e["integrity"]

        if eco.entities:
            self.avg=total/len(eco.entities)
