
import random

class LineageManager:
    def __init__(self):
        self.next_id = 0

    def assign_id(self, agent):
        agent.lineage_id = self.next_id
        agent.generation = 0
        self.next_id += 1

    def reproduce(self, agent):
        child = type(agent)(agent.planet_id, agent.region_id)
        child.brain.memory = agent.brain.memory.copy()

        child.lineage_id = agent.lineage_id
        child.generation = agent.generation + 1

        # mutation
        child.energy = max(1.0, agent.energy * random.uniform(0.8, 1.2))

        return child
