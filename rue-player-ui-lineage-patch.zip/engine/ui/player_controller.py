
class PlayerController:
    def __init__(self):
        self.selected_planet = 0
        self.selected_region = 0

    def handle_input(self, key, universe):
        if key in ['1','2','3','4','5']:
            self.selected_planet = int(key)-1

        if key == 'q':
            self.selected_region -= 1
        if key == 'e':
            self.selected_region += 1

        planet = universe.planets[self.selected_planet]
        self.selected_region %= planet.n_regions

        if key == ' ':
            planet.region_energies[self.selected_region] *= 1.2

        if key == 'a':
            planet.region_phases[self.selected_region] *= 0.9

        if key == 'z':
            for a in universe.agents:
                if a.planet_id == self.selected_planet and a.region_id == self.selected_region:
                    a.energy += 0.5
