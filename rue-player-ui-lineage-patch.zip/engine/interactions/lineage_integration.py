
def integrate_lineage(universe, lineage_manager):
    new_agents = []

    for agent in universe.agents:
        if agent.energy > 3.0:
            child = lineage_manager.reproduce(agent)
            new_agents.append(child)
            agent.energy *= 0.7

    universe.agents.extend(new_agents)
