
import os, sys
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from engine.simulation.universe import Universe
from engine.simulation.universe_patch import UniverseInteractionMixin
from engine.ui.player_controller import PlayerController
from engine.lineage.lineage import LineageManager
from engine.interactions.lineage_integration import integrate_lineage

class GameUniverse(Universe, UniverseInteractionMixin):
    def __init__(self):
        super().__init__()
        self.init_spirit_layer()
        self.lineage = LineageManager()
        for a in self.agents:
            self.lineage.assign_id(a)

    def step(self):
        super().step()
        self.interaction_step()
        integrate_lineage(self, self.lineage)

def main():
    u = GameUniverse()
    player = PlayerController()

    plt.ion()
    fig, ax = plt.subplots()

    def on_key(event):
        player.handle_input(event.key, u)

    fig.canvas.mpl_connect('key_press_event', on_key)

    for i in range(2000):
        u.step()

        ax.clear()
        energies = [a.energy for a in u.agents]
        ax.plot(energies)
        ax.set_title(f"Agents: {len(u.agents)}")

        plt.pause(0.01)

    plt.ioff()
    plt.show()

if __name__ == "__main__":
    main()
