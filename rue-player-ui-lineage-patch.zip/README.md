
# RUE Player UI + Lineage Patch

Adds:
- Player controls (energy injection, region tuning, agent influence)
- UI overlay (keyboard control + selection)
- Long-term lineage system (inheritance + mutation)

## Controls

- [1-5] select planet
- [Q/E] rotate region selection
- [SPACE] inject energy
- [A] align phase
- [Z] possess agent (boost identity)

## Run

python experiments/run_player_ui_lineage.py
