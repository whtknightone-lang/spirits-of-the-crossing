
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'universe.json');

function load() {
    if (!fs.existsSync(DB_PATH)) return { players:{}, world:{} };
    return JSON.parse(fs.readFileSync(DB_PATH));
}

function save(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data,null,2));
}

module.exports = { load, save };
