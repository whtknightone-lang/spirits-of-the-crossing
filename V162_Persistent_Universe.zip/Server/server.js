
const WebSocket = require('ws');
const db = require('./db/database');

let state = db.load();

const wss = new WebSocket.Server({ port: process.env.PORT || 8080 });

wss.on('connection', ws => {
    ws.on('message', msg => {
        try {
            const data = JSON.parse(msg);
            state.players[data.id] = data;
        } catch {}
    });
});

setInterval(()=>{
    const players = Object.values(state.players);
    if(players.length>0){
        let avg = players.reduce((a,p)=>a+p.r,0)/players.length;
        state.world.resonance = avg;
    }

    db.save(state);

    const msg = JSON.stringify(state.world);
    wss.clients.forEach(c=>{
        if(c.readyState===1) c.send(msg);
    });

},200);

console.log("V162 persistent server running");
