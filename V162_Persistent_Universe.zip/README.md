
V162 Persistent Universe

Adds:
- Persistent world state (file-based DB scaffold)
- Player session persistence
- Continuous evolving world
