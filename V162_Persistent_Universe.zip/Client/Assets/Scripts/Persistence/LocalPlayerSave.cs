
using UnityEngine;

public class LocalPlayerSave : MonoBehaviour
{
    public string playerId;

    void Awake()
    {
        playerId = PlayerPrefs.GetString("player_id", System.Guid.NewGuid().ToString());
        PlayerPrefs.SetString("player_id", playerId);
    }
}
