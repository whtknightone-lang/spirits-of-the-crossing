
using UnityEngine;

public class DragonGameManager : MonoBehaviour
{
    public GameObject airDragon;
    public GameObject waterDragon;
    public GameObject natureDragon;
    public GameObject fireDragon;

    void Start()
    {
        ActivateDragon(airDragon);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1)) ActivateDragon(airDragon);
        if (Input.GetKeyDown(KeyCode.Alpha2)) ActivateDragon(waterDragon);
        if (Input.GetKeyDown(KeyCode.Alpha3)) ActivateDragon(natureDragon);
        if (Input.GetKeyDown(KeyCode.Alpha4)) ActivateDragon(fireDragon);
    }

    void ActivateDragon(GameObject dragon)
    {
        airDragon.SetActive(false);
        waterDragon.SetActive(false);
        natureDragon.SetActive(false);
        fireDragon.SetActive(false);

        dragon.SetActive(true);
    }
}
