
using UnityEngine;

namespace ArtificialUniverse.Dragons.Nature
{
    public class ElderNatureDragon : MonoBehaviour
    {
        public float energy = 0.5f;
        public float harmony = 0.5f;

        void Update()
        {
            float dt = Time.deltaTime;

            // Core loop: move → build → spend → recover
            float motion = Mathf.Abs(Input.GetAxis("Vertical"));

            energy = Mathf.Clamp01(energy + motion * 0.2f * dt);

            if (Input.GetKey(KeyCode.Space))
            {
                UseAbility();
            }

            Recover(dt);
        }

        void UseAbility()
        {
            if (energy < 0.2f) return;

            energy -= 0.2f;
            harmony += 0.1f;

            Debug.Log("Growth / Harmony ability activated");
        }

        void Recover(float dt)
        {
            harmony = Mathf.Clamp01(harmony + 0.05f * dt);
            energy = Mathf.Clamp01(energy + 0.03f * dt);
        }
    }
}
