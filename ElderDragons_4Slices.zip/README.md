
# Elder Dragons – 4 Vertical Playable Slices

Includes:
- Elder Air Dragon (flow / movement / resonance)
- Elder Water Dragon (depth / memory / healing)
- Elder Nature Dragon (growth / harmony / life)
- Elder Fire Dragon (intensity / transformation / rebirth)

Each dragon is a playable loop:
Move → Build energy → Use ability → Recover → Repeat

This is a vertical slice scaffold for each dragon archetype.
