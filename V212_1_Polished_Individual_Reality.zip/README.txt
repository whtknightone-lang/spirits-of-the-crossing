
V212.1 Polished Vertical Slice – Individual Realities

Focus:
- each player has their own perceived reality
- world visuals respond uniquely per player
- source guidance is optional and felt

Core loop:
move → tune → perceive → align → reality shifts → personal experience
