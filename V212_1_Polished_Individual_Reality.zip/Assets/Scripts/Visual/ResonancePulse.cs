
using UnityEngine;

public class ResonancePulse : MonoBehaviour
{
    public PlayerController player;

    void Update()
    {
        if(player == null) return;

        float scale = 1f + Mathf.Sin(Time.time * 3f) * player.resonance * 0.3f;
        transform.localScale = new Vector3(scale, scale, scale);
    }
}
