
using UnityEngine;

public class RealityFeedback : MonoBehaviour
{
    public PlayerController player;

    void Update()
    {
        if(player.resonance > 0.7f)
        {
            Debug.Log("Reality aligning (personal)");
        }
        else if(player.resonance < 0.3f)
        {
            Debug.Log("Reality diverging (personal)");
        }
    }
}
