
using UnityEngine;

public class PersonalReality : MonoBehaviour
{
    public PlayerController player;
    public Camera cam;

    void Update()
    {
        if(player == null || cam == null) return;

        // each player sees a different world based on resonance
        Color baseColor = Color.Lerp(Color.red, Color.cyan, player.resonance);

        // add slight variation to simulate individuality
        float offset = Mathf.Sin(Time.time + player.resonance * 10f) * 0.1f;
        cam.backgroundColor = baseColor + new Color(offset, offset, offset);
    }
}
