
using UnityEngine;

public class SourceGuidance : MonoBehaviour
{
    public PlayerController player;
    public Light guideLight;

    [Range(0f,1f)] public float receptivity = 0.5f;

    void Update()
    {
        if(player == null || guideLight == null) return;

        float signal = player.resonance * receptivity;

        guideLight.intensity = Mathf.Lerp(0.2f, 2f, signal);
        guideLight.color = Color.Lerp(Color.red, Color.white, signal);
    }
}
