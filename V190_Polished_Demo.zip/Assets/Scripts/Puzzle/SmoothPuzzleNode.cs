
using UnityEngine;

public class SmoothPuzzleNode : MonoBehaviour
{
    public float value;
    public float target;
    public float speed = 2f;

    void Update()
    {
        value = Mathf.Lerp(value, target, Time.deltaTime * speed);
    }

    public void Interact(float input)
    {
        target = Mathf.Clamp01(target + input);
    }
}
