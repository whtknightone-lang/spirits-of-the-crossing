
using UnityEngine;

public class ResonanceAudio : MonoBehaviour
{
    public AudioSource source;
    public float resonance;

    void Update()
    {
        if (source != null)
        {
            source.pitch = Mathf.Lerp(0.8f, 1.5f, resonance);
            source.volume = Mathf.Lerp(0.2f, 1f, resonance);
        }
    }
}
