
using UnityEngine;

public class GlowFeedback : MonoBehaviour
{
    public Renderer rend;
    public float intensity;

    void Update()
    {
        if (rend != null)
        {
            Color c = Color.Lerp(Color.black, Color.cyan, intensity);
            rend.material.SetColor("_EmissionColor", c);
        }
    }
}
