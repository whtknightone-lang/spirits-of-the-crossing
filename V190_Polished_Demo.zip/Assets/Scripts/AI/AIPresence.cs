
using UnityEngine;

public class AIPresence : MonoBehaviour
{
    public Transform player;
    public float smoothness = 2f;

    void Update()
    {
        if (player == null) return;

        Vector3 target = player.position + new Vector3(1,0,1);
        transform.position = Vector3.Lerp(transform.position, target, Time.deltaTime * smoothness);

        float pulse = Mathf.Sin(Time.time * 2f) * 0.5f + 0.5f;
        transform.localScale = Vector3.one * (1f + pulse * 0.1f);
    }
}
