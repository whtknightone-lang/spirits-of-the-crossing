
using UnityEngine;

public class FeelManager : MonoBehaviour
{
    public float globalResonance;

    void Update()
    {
        RenderSettings.ambientIntensity = Mathf.Lerp(0.5f, 2f, globalResonance);
    }
}
