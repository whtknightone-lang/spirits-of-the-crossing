
# V48 Source Feedback Intelligence

Run:
pip install -r requirements.txt
python main.py

New:
- Source becomes adaptive (not static)
- Feedback based on harmony, diversity, and player state
- Fully interlocked with communication + meditation systems
