
import pygame, numpy as np
from systems.resonance_memory import ResonanceMemorySystem
from systems.player_body import PlayerBody
from systems.agent_world import AgentWorld
from systems.communication import CommunicationSystem
from systems.meditation import MeditationSystem
from systems.source_feedback import SourceFeedbackSystem

class V48Engine:
    def __init__(self, size, device):
        self.size=size
        self.device=device

        self.memory=ResonanceMemorySystem(size,device)
        self.player=PlayerBody(size,device)
        self.world=AgentWorld(size,device,120)

        self.comm=CommunicationSystem()
        self.meditation=MeditationSystem()
        self.source=SourceFeedbackSystem()

        self.font=pygame.font.SysFont("arial",16)

    def handle_key(self,key):
        if key==pygame.K_SPACE:
            self.meditation.toggle()

    def handle_input(self,dt):
        self.player.handle_movement(pygame.key.get_pressed(),dt)

    def update(self,dt):
        self.memory.update(dt,
            self.world.aggregate_world_emotion(),
            self.player.resonance_mean()
        )

        self.player.update(dt,self.memory.now_field,self.memory.potential_field)
        self.world.update(dt,self.memory.now_field,self.memory.potential_field,self.player)

        self.comm.update(self.world.agents)

        # meditation alignment
        if self.meditation.active:
            self.memory.now_field += self.meditation.align(self.memory)

        # NEW: source feedback (adaptive guidance)
        feedback = self.source.compute(self.memory, self.player, self.world)
        self.memory.now_field += feedback
        self.memory.potential_field += feedback * 0.5

        self.memory.clamp_all()

    def render(self,screen):
        screen.fill((10,10,20))

        arr=self.memory.now_field.detach().cpu().numpy()
        arr=(arr-arr.min())/(arr.max()+1e-5)
        img=np.stack([arr*255,arr*200,255-arr*150],axis=-1).astype("uint8")

        surf=pygame.surfarray.make_surface(np.transpose(img,(1,0,2)))
        surf=pygame.transform.scale(surf,(700,700))
        screen.blit(surf,(40,40))

        px,py=self.player.grid_position()
        pygame.draw.circle(surf,(255,255,255),(py,px),6)

        lines=[
            "V48 Source Feedback Intelligence",
            "SPACE = meditate",
            f"Source signal: {self.source.last_signal:.3f}"
        ]

        y=760
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
