
import torch
class ResonanceMemorySystem:
    def __init__(self,size,device):
        self.now_field=torch.zeros((size,size),device=device)
        self.memory_field=torch.zeros((size,size),device=device)
        self.potential_field=torch.zeros((size,size),device=device)
    def update(self,dt,world,player):
        self.now_field+=0.02*torch.randn_like(self.now_field)*dt
        self.memory_field+=self.now_field*0.01
        self.potential_field=torch.tanh(self.now_field+self.memory_field)
    def clamp_all(self):
        self.now_field.clamp_(-2,2)
        self.memory_field.clamp_(-2,2)
        self.potential_field.clamp_(-2,2)
