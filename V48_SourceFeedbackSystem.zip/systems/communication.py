
import random
class CommunicationSystem:
    def update(self, agents):
        for a in agents:
            a.setdefault("msg", random.random())
            for b in agents:
                if a is b: continue
                if abs(a["pos"][0]-b["pos"][0])<5 and abs(a["pos"][1]-b["pos"][1])<5:
                    avg=(a["msg"]+b["msg"])/2
                    a["msg"]=b["msg"]=avg
