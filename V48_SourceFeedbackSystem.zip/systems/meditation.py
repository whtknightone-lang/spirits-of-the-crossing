
class MeditationSystem:
    def __init__(self):
        self.active=False
    def toggle(self):
        self.active=not self.active
    def align(self,memory):
        mean=memory.now_field.mean()
        return (mean-memory.now_field)*0.01
