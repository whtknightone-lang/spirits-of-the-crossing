
# V56 Memory + Multi-Form Embodiment

Adds:
- memory across lifetimes
- multiple embodiment types (animal, spirit, elder)
- experience carries forward

Cycle:
Source → Choose Form → Experience → Return → Remember → Evolve
