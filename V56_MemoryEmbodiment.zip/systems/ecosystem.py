
import random

class Ecosystem:
    def __init__(self,size):
        self.size=size
        self.entities=[]

    def update(self,dt):
        for e in self.entities:
            e["pos"][0]+=random.uniform(-1,1)*dt*10
            e["pos"][1]+=random.uniform(-1,1)*dt*10
