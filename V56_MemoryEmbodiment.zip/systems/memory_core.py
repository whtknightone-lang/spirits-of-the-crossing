
class MemoryCore:
    def __init__(self):
        self.archive=[]

    def store(self,entity):
        self.archive.append({
            "type":entity["type"],
            "experience":entity.get("experience",0),
        })
