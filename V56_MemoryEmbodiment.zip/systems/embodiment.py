
import random

class EmbodimentSystem:
    def __init__(self,size,memory):
        self.size=size
        self.memory=memory
        self.mode="embodied"
        self.current_form="none"

    def enter_source(self):
        self.mode="source"
        self.current_form="source"

    def spawn(self,eco,form):
        entity={
            "pos":[random.random()*self.size,random.random()*self.size],
            "type":form,
            "experience":len(self.memory.archive)*0.1
        }
        eco.entities.append(entity)
        self.current_form=form
        self.mode="embodied"

    def update(self,eco):
        # store past entities as memory when too many
        if len(eco.entities)>50:
            e=eco.entities.pop(0)
            self.memory.store(e)
