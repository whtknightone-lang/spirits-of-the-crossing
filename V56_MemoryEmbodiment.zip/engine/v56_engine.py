
import pygame
from systems.ecosystem import Ecosystem
from systems.memory_core import MemoryCore
from systems.embodiment import EmbodimentSystem

class V56Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.memory=MemoryCore()
        self.embodiment=EmbodimentSystem(size,self.memory)
        self.font=pygame.font.SysFont("arial",16)

    def handle_key(self,key):
        if key==pygame.K_1:
            self.embodiment.enter_source()
        if key==pygame.K_2:
            self.embodiment.spawn(self.ecosystem,"animal")
        if key==pygame.K_3:
            self.embodiment.spawn(self.ecosystem,"spirit")
        if key==pygame.K_4:
            self.embodiment.spawn(self.ecosystem,"elder")

    def update(self,dt):
        self.ecosystem.update(dt)
        self.embodiment.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for a in self.ecosystem.entities:
            x=int(a["pos"][1]*scale)+40
            y=int(a["pos"][0]*scale)+40
            t=a["type"]

            if t=="animal": color=(120,200,120)
            elif t=="spirit": color=(180,180,255)
            else: color=(255,220,120)

            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V56 Memory + Multi-Form Embodiment",
            "1=source 2=animal 3=spirit 4=elder",
            f"Lifetimes stored: {len(self.memory.archive)}",
            f"Current form: {self.embodiment.current_form}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
