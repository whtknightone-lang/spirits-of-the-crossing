
using UnityEngine;

public class V238_240_Manager : MonoBehaviour
{
    public EmotionalIdentityEvolution identity;
    public CollectiveEvent collectiveEvent;

    void Update()
    {
        if(Input.GetKeyDown(KeyCode.C))
        {
            Debug.Log("Identity: " + identity.GetIdentity());
            collectiveEvent.TryTrigger();
        }
    }
}
