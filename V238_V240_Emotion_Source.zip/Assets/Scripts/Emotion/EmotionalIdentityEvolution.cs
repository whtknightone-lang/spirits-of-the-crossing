
using UnityEngine;

public class EmotionalIdentityEvolution : MonoBehaviour
{
    public float accumulatedJoy;
    public float accumulatedFear;

    public string GetIdentity()
    {
        if(accumulatedJoy > accumulatedFear) return "Harmonic Being";
        if(accumulatedFear > accumulatedJoy) return "Chaotic Being";
        return "Balanced Being";
    }
}
