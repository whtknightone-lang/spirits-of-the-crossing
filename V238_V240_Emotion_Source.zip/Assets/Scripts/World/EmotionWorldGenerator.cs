
using UnityEngine;

public class EmotionWorldGenerator : MonoBehaviour
{
    public float joy;
    public float fear;

    public Color GenerateColor()
    {
        return Color.Lerp(Color.red, Color.cyan, joy - fear + 0.5f);
    }
}
