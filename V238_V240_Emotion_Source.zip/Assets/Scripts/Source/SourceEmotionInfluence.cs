
using UnityEngine;

public class SourceEmotionInfluence : MonoBehaviour
{
    [Range(0,1)] public float receptivity = 0.5f;

    public float ApplySource(float currentEmotion)
    {
        float sourceSignal = 1.0f; // pure stable signal
        return Mathf.Lerp(currentEmotion, sourceSignal, receptivity * 0.1f);
    }
}
