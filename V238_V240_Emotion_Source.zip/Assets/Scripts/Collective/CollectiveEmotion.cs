
using UnityEngine;

public class CollectiveEmotion : MonoBehaviour
{
    public float collectiveJoy;
    public float collectiveFear;

    public void UpdateCollective(float[] joys, float[] fears)
    {
        float j = 0, f = 0;
        for(int i=0;i<joys.Length;i++)
        {
            j += joys[i];
            f += fears[i];
        }
        collectiveJoy = j / joys.Length;
        collectiveFear = f / fears.Length;
    }
}
