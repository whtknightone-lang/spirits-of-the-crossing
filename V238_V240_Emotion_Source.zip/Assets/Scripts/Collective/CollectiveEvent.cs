
using UnityEngine;

public class CollectiveEvent : MonoBehaviour
{
    public CollectiveEmotion collective;

    public void TryTrigger()
    {
        if(collective.collectiveJoy > 0.7f)
            Debug.Log("Collective Harmony Event");
        if(collective.collectiveFear > 0.7f)
            Debug.Log("Collective Instability Event");
    }
}
