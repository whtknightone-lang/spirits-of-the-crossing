
print("Running RUE Living World Engine V5")

def step():
    print("Step executed in V5")

if __name__ == "__main__":
    for i in range(5):
        step()
