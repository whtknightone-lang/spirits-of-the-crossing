
class LineageSystem:
    def update(self,eco):
        for e in eco.entities:
            if e["lineage"] is None:
                e["lineage"]=id(e)
