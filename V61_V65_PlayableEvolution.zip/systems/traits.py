
import random

class TraitSystem:
    def update(self,eco):
        for e in eco.entities:
            if random.random()<0.01:
                e["trait"]=random.choice(["adaptive","aggressive","neutral"])
