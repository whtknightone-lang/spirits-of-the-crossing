
import pygame

class PlayerControlSystem:
    def __init__(self,eco):
        self.eco=eco
        self.selected=None

    def handle_key(self,key):
        if not self.selected: return

        if key==pygame.K_1:
            self.selected["trait"]="adaptive"
        if key==pygame.K_2:
            self.selected["trait"]="aggressive"
        if key==pygame.K_3:
            self.eco.spawn_entity(self.selected)

    def update(self,eco):
        mouse=pygame.mouse.get_pressed()
        if mouse[0]:
            mx,my=pygame.mouse.get_pos()
            closest=None
            dist=9999
            for e in eco.entities:
                dx=mx-(e["pos"][1]*5+40)
                dy=my-(e["pos"][0]*5+40)
                d=dx*dx+dy*dy
                if d<dist:
                    dist=d
                    closest=e
            self.selected=closest
