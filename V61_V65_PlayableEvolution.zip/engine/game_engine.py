
import pygame
from systems.ecosystem import Ecosystem
from systems.lineage import LineageSystem
from systems.traits import TraitSystem
from systems.player_control import PlayerControlSystem

class GameEngine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.lineage=LineageSystem()
        self.traits=TraitSystem()
        self.player=PlayerControlSystem(self.ecosystem)

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(30):
            self.ecosystem.spawn_entity()

    def handle_key(self,key):
        self.player.handle_key(key)

    def update(self,dt):
        self.ecosystem.update(dt)
        self.lineage.update(self.ecosystem)
        self.traits.update(self.ecosystem)
        self.player.update(self.ecosystem)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            t=e.get("trait","neutral")
            if t=="adaptive": color=(120,255,180)
            elif t=="aggressive": color=(255,140,140)
            else: color=(200,200,200)

            pygame.draw.circle(screen,color,(x,y),4)

        # highlight selected
        if self.player.selected:
            e=self.player.selected
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40
            pygame.draw.circle(screen,(255,255,255),(x,y),8,1)

        y=760
        lines=[
            "V61-V65 Playable Evolution",
            "Click: select | 1 bless | 2 disrupt | 3 spawn lineage",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Selected: {bool(self.player.selected)}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
