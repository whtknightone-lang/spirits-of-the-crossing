
# V61–V65 Playable Evolution System

Adds:
- lineage system (multi-generation tracking)
- trait inheritance + mutation
- player interaction (select, influence, spawn)
- transition from simulation → playable system

Controls:
Click entity to select
1 = bless (adaptive)
2 = disrupt (aggressive)
3 = spawn lineage

This is the first true "gameplay layer"
