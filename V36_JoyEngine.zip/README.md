
# V36 Joy Engine

## Run Instructions

1. Install dependencies:
   pip install -r requirements.txt

2. Run:
   python v36_main.py

## Controls
UP arrow: Inject Joy
DOWN arrow: Inject Discord

## Description
Real-time Joy Field simulation with agents and emergent audio.
