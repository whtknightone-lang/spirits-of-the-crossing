
import torch
import torch.nn.functional as F
import numpy as np
import pygame
import random
from audio_resonance import joy_to_music

SIZE = 128
NUM_AGENTS = 500
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

D = 0.2
alpha, beta, gamma, delta, epsilon = 1.0, 0.5, 0.5, 0.3, 0.2
lambda_ = 0.8

J = torch.zeros((1,1,SIZE,SIZE), device=DEVICE)
Psi = torch.zeros_like(J)

agents_pos = torch.rand((NUM_AGENTS,2), device=DEVICE) * SIZE
agents_state = torch.rand((NUM_AGENTS,4), device=DEVICE)

laplace_kernel = torch.tensor([
    [0,1,0],
    [1,-4,1],
    [0,1,0]
], dtype=torch.float32, device=DEVICE).view(1,1,3,3)

def laplacian(field):
    return F.conv2d(field, laplace_kernel, padding=1)

def update_field():
    global J, Psi

    R = torch.sigmoid(J)
    G = torch.abs(laplacian(J))
    H = torch.relu(J)
    N = torch.rand_like(J) * 0.05
    M = torch.tanh(J)

    J += (
        D * laplacian(J)
        + alpha * R
        + beta * G
        + gamma * H
        + delta * N
        + epsilon * M
        - lambda_ * Psi
    )

    Psi += 0.1 * torch.rand_like(Psi) - 0.05 * J

def update_agents():
    global J, agents_pos, agents_state

    for i in range(NUM_AGENTS):
        x, y = agents_pos[i].long()
        x = torch.clamp(x, 0, SIZE-1)
        y = torch.clamp(y, 0, SIZE-1)

        local_J = J[0,0,x,y]
        resonance = torch.exp(-torch.norm(agents_state[i] - local_J))
        joy = resonance + 0.3 * random.random()

        J[0,0,x,y] += joy * 0.05

        agents_pos[i] += torch.randn(2, device=DEVICE) * (0.5 + joy)
        agents_pos[i] = torch.clamp(agents_pos[i], 0, SIZE-1)

pygame.init()
screen = pygame.display.set_mode((512,512))
clock = pygame.time.Clock()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_UP]:
        J += 0.05
    if keys[pygame.K_DOWN]:
        Psi += 0.05

    update_field()
    update_agents()

    field = J[0,0].detach().cpu().numpy()
    field = (field - field.min()) / (field.max() + 1e-5)

    img = np.uint8(field * 255)
    img = np.stack([img, img//2, 255-img], axis=-1)

    surf = pygame.surfarray.make_surface(img)
    surf = pygame.transform.scale(surf, (512,512))
    screen.blit(surf, (0,0))

    if random.random() < 0.05:
        joy_to_music(J.mean().item())

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
