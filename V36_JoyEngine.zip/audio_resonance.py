
import numpy as np
import sounddevice as sd

def play_tone(freq, duration=0.2):
    fs = 44100
    t = np.linspace(0, duration, int(fs * duration))
    wave = 0.5 * np.sin(2 * np.pi * freq * t)
    sd.play(wave, fs)

def joy_to_music(J_mean):
    base = 220
    freq = base + J_mean * 400
    play_tone(freq)
