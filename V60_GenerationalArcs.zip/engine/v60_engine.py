
import pygame
from systems.ecosystem import Ecosystem
from systems.relationships import RelationshipSystem
from systems.reproduction import ReproductionSystem

class V60Engine:
    def __init__(self,size):
        self.size=size
        self.ecosystem=Ecosystem(size)
        self.relationships=RelationshipSystem()
        self.reproduction=ReproductionSystem()
        self.font=pygame.font.SysFont("arial",16)

        for _ in range(40):
            self.ecosystem.spawn_entity()

    def update(self,dt):
        self.ecosystem.update(dt)
        self.relationships.update(self.ecosystem)
        self.reproduction.update(self.ecosystem, self.relationships)

    def render(self,screen):
        screen.fill((10,10,20))
        scale=700/self.size

        # draw bonds
        for (a_id,b_id),val in self.relationships.bonds.items():
            if val<0.6: continue
            a=self.ecosystem.entities_by_id.get(a_id)
            b=self.ecosystem.entities_by_id.get(b_id)
            if not a or not b: continue

            ax=int(a["pos"][1]*scale)+40
            ay=int(a["pos"][0]*scale)+40
            bx=int(b["pos"][1]*scale)+40
            by=int(b["pos"][0]*scale)+40

            pygame.draw.line(screen,(255,180,180),(ax,ay),(bx,by),1)

        # draw entities
        for e in self.ecosystem.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40

            gen=e.get("generation",0)
            color=(120,200,255) if gen==0 else (120+gen*20,200-gen*10,150)

            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V60 Generational Arc System",
            f"Entities: {len(self.ecosystem.entities)}",
            f"Births: {self.reproduction.births}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
