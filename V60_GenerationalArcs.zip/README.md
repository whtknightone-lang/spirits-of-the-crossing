
# V60 Generational Arc System

Adds:
- strong bonds can create new entities (non-explicit reproduction model)
- offspring inherit generational lineage
- multi-generation evolution emerges

Concept:
Relationships → connection → creation → continuation of arcs
