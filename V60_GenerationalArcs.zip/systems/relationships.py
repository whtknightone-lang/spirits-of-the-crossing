
import math

class RelationshipSystem:
    def __init__(self):
        self.bonds={}

    def update(self,eco):
        ents=eco.entities
        for i in range(len(ents)):
            for j in range(i+1,len(ents)):
                a=ents[i]; b=ents[j]

                dx=a["pos"][0]-b["pos"][0]
                dy=a["pos"][1]-b["pos"][1]
                d=math.sqrt(dx*dx+dy*dy)

                key=(a["id"],b["id"])
                val=self.bonds.get(key,0)

                if d<8: val+=0.02
                else: val-=0.005

                self.bonds[key]=max(0,min(1,val))
