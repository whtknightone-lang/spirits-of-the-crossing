
import random, uuid

class Ecosystem:
    def __init__(self,size):
        self.size=size
        self.entities=[]
        self.entities_by_id={}

    def spawn_entity(self, parent_a=None, parent_b=None):
        eid=str(uuid.uuid4())

        generation=0
        if parent_a and parent_b:
            generation=max(parent_a.get("generation",0),
                           parent_b.get("generation",0))+1

        e={
            "id":eid,
            "pos":[random.random()*self.size,random.random()*self.size],
            "experience":0.0,
            "generation":generation
        }

        self.entities.append(e)
        self.entities_by_id[eid]=e

    def update(self,dt):
        for e in self.entities:
            e["pos"][0]+=random.uniform(-1,1)*dt*10
            e["pos"][1]+=random.uniform(-1,1)*dt*10
            e["experience"]+=0.01
