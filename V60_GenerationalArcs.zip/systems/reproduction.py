
import random

class ReproductionSystem:
    def __init__(self):
        self.births=0

    def update(self,eco,relationships):
        for (a_id,b_id),val in relationships.bonds.items():
            if val>0.8 and random.random()<0.01:
                a=eco.entities_by_id.get(a_id)
                b=eco.entities_by_id.get(b_id)
                if a and b:
                    eco.spawn_entity(a,b)
                    self.births+=1
