
class GoalSystem:
    def __init__(self):
        self.goal = "stabilize"
        self.progress = 0

    def update(self, universe):
        stable = sum(1 for p in universe.planets if p.energy > 2.0)
        self.progress = stable

    def is_complete(self):
        return self.progress >= 2
