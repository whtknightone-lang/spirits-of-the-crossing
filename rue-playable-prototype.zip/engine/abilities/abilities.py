
def infuse_energy(player, universe):
    if player.energy < 0.5:
        return
    planet = universe.planets[player.selected_planet]
    planet.region_energies[player.selected_region] *= 1.3
    player.energy -= 0.5

def stabilize(player, universe):
    if player.energy < 0.5:
        return
    planet = universe.planets[player.selected_planet]
    planet.region_phases[player.selected_region] *= 0.9
    player.energy -= 0.5

def disrupt(player, universe):
    if player.energy < 0.7:
        return
    planet = universe.planets[player.selected_planet]
    planet.region_phases[player.selected_region] += 0.3
    player.energy -= 0.7
