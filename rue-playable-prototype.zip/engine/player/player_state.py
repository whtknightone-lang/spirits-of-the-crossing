
class PlayerState:
    def __init__(self):
        self.energy = 5.0
        self.role = "BALANCER"
        self.selected_planet = 0
        self.selected_region = 0
