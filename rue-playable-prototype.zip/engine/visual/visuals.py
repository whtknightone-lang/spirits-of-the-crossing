
def agent_color(agent):
    return agent.brain.mean_phase() / 6.28

def agent_size(agent):
    return 20 + agent.energy * 5
