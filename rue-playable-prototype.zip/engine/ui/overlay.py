
def draw_overlay(ax, player, goal):
    ax.set_title(f"Energy: {player.energy:.2f} | Goal Progress: {goal.progress}")
