
import os, sys
import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from engine.simulation.universe import Universe
from engine.player.player_state import PlayerState
from engine.abilities.abilities import infuse_energy, stabilize, disrupt
from engine.goals.goals import GoalSystem
from engine.visual.visuals import agent_color, agent_size
from engine.ui.overlay import draw_overlay

u = Universe()
player = PlayerState()
goal = GoalSystem()

plt.ion()
fig, ax = plt.subplots()

def on_key(event):
    if event.key == ' ':
        infuse_energy(player, u)
    if event.key == 'a':
        stabilize(player, u)
    if event.key == 'd':
        disrupt(player, u)

fig.canvas.mpl_connect('key_press_event', on_key)

for i in range(2000):
    u.step()
    goal.update(u)

    ax.clear()
    xs, ys, cs, ss = [], [], [], []

    for a in u.agents:
        px, py = u.planets[a.planet_id].region_world_pos(a.region_id)
        xs.append(px)
        ys.append(py)
        cs.append(agent_color(a))
        ss.append(agent_size(a))

    ax.scatter(xs, ys, c=cs, s=ss)

    draw_overlay(ax, player, goal)

    plt.pause(0.01)

plt.ioff()
plt.show()
