
# RUE Playable Prototype

This is the first **playable layer** of the RUE system.

Includes:
- visual encoding (agents, roles, territory)
- player abilities system
- UI overlay
- goal system
- hooks for:
  - spirit animal hierarchy (future)
  - planetary personality traits (future)

Run:
python experiments/run_playable_prototype.py
