
# V46 Meaning Learning AI

Run:
pip install -r requirements.txt
python main.py

New:
- AI agents learn their own meaning preferences
- behavior adapts over time
- emergent diversity of motivations
