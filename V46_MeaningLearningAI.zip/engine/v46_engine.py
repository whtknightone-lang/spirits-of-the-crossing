
import pygame, numpy as np
from systems.resonance_memory import ResonanceMemorySystem
from systems.player_body import PlayerBody
from systems.agent_world import AgentWorld
from systems.meaning_learning import MeaningLearningSystem

class V46Engine:
    def __init__(self, size, device):
        self.size=size
        self.device=device

        self.memory=ResonanceMemorySystem(size,device)
        self.player=PlayerBody(size,device)
        self.world=AgentWorld(size,device,120)
        self.meaning=MeaningLearningSystem()

        self.font=pygame.font.SysFont("arial",16)

    def handle_key(self,key):
        if key==pygame.K_e: self.player.emit_expression_burst(self.memory.now_field)
        if key==pygame.K_q: self.player.emit_kindness_burst(self.memory.now_field)

    def handle_input(self,dt):
        self.player.handle_movement(pygame.key.get_pressed(),dt)

    def update(self,dt):
        self.memory.update(dt,
            self.world.aggregate_world_emotion(),
            self.player.resonance_mean()
        )

        self.player.update(dt,self.memory.now_field,self.memory.potential_field)
        self.world.update(dt,self.memory.now_field,self.memory.potential_field,self.player)

        # AI learns meaning dynamically
        self.meaning.update_agents(self.world.agents, self.memory)

        self.memory.clamp_all()

    def render(self,screen):
        screen.fill((10,10,20))

        arr=self.memory.now_field.detach().cpu().numpy()
        arr=(arr-arr.min())/(arr.max()+1e-5)
        img=np.stack([arr*255,arr*180,255-arr*180],axis=-1).astype("uint8")

        surf=pygame.surfarray.make_surface(np.transpose(img,(1,0,2)))
        surf=pygame.transform.scale(surf,(700,700))
        screen.blit(surf,(40,40))

        px,py=self.player.grid_position()
        pygame.draw.circle(surf,(255,255,255),(py,px),6)

        y=760
        screen.blit(self.font.render("V46 Meaning Learning AI",True,(240,240,240)),(40,y))
