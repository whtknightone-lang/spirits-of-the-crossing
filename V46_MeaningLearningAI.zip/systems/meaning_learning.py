
import random

class MeaningLearningSystem:
    def update_agents(self, agents, memory):
        for a in agents:
            # each agent learns its own "meaning"
            joy = memory.now_field.mean().item()
            potential = memory.potential_field.mean().item()

            # simple learning rule
            preference = a.get("meaning_pref", random.random())
            preference += 0.01 * (joy + potential)
            preference = max(0.0, min(1.0, preference))
            a["meaning_pref"] = preference

            # behavior influenced by learned meaning
            if preference > 0.5:
                a["pos"][0] += random.uniform(-1,1)*0.5
                a["pos"][1] += random.uniform(-1,1)*0.5
            else:
                a["pos"][0] += random.uniform(-1,1)*1.5
                a["pos"][1] += random.uniform(-1,1)*1.5
