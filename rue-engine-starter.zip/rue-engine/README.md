# RUE Engine Starter

Minimal starter repository for the Resonance Universe Engine (RUE).

## Included
- star energy source with random solar flares
- multiple orbiting planets
- 21-node oscillator-based snowflake brain
- simple agent update loop
- basic matplotlib orbit visualization

## Quick start

```bash
pip install -r requirements.txt
python experiments/run_simulation.py
```

## Project layout

```text
rue-engine/
├── README.md
├── requirements.txt
├── engine/
│   ├── __init__.py
│   ├── config.py
│   ├── engine_loop.py
│   ├── simulation/
│   │   ├── universe.py
│   │   ├── star.py
│   │   ├── planet.py
│   │   └── orbit.py
│   ├── agents/
│   │   ├── agent.py
│   │   └── snowflake_brain.py
│   ├── ai/
│   │   └── behavior.py
│   └── rendering/
│       └── simple_renderer.py
└── experiments/
    └── run_simulation.py
```

## Notes
This is a clean bootstrap, not the full RSU/RUE platform yet. It is designed so you can expand toward:
- ecosystems
- movement and resource gathering
- evolution / genomes
- GPU-based simulation
- multi-planet civilization systems
