"""Run the minimal RUE starter simulation."""

from __future__ import annotations

import os
import sys
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from engine.config import LOG_EVERY, SIM_STEPS
from engine.engine_loop import EngineLoop
from engine.rendering.simple_renderer import SimpleRenderer


if __name__ == "__main__":
    engine = EngineLoop()

    for step in range(SIM_STEPS):
        energy = engine.step()
        if step % LOG_EVERY == 0:
            avg_agent_energy = statistics.mean(agent.energy for agent in engine.agents)
            avg_activity = statistics.mean(agent.activity for agent in engine.agents)
            print(
                f"step={step:04d}  star_energy={energy:5.2f}  "
                f"avg_agent_energy={avg_agent_energy:6.3f}  avg_activity={avg_activity:6.3f}"
            )

    renderer = SimpleRenderer()
    output_path = os.path.join(os.path.dirname(__file__), "orbit_snapshot.png")
    saved = renderer.render_universe(engine.universe, output_path=output_path)
    print(f"Saved orbit snapshot to: {saved}")
