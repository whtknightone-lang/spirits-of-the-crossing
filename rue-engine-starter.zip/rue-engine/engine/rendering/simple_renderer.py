"""Minimal matplotlib renderer for the star system."""

from __future__ import annotations

import matplotlib.pyplot as plt
from engine.config import OUTPUT_PLOT


class SimpleRenderer:
    def render_universe(self, universe, output_path: str = OUTPUT_PLOT) -> str:
        fig, ax = plt.subplots(figsize=(6, 6))
        ax.scatter([0], [0], s=250, marker='*')

        for planet in universe.planets:
            x, y = planet.position
            orbit = plt.Circle((0, 0), planet.radius, fill=False, alpha=0.25)
            ax.add_patch(orbit)
            ax.scatter([x], [y], s=60)
            ax.text(x, y, f"P{planet.index}", fontsize=9)

        ax.set_aspect('equal', adjustable='box')
        ax.set_title('RUE Starter Star System')
        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_path, dpi=150)
        plt.close(fig)
        return output_path
