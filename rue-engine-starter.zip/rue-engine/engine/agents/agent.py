"""Minimal agent driven by a snowflake brain."""

from __future__ import annotations

from engine.agents.snowflake_brain import SnowflakeBrain
from engine.ai.behavior import infer_activity_level


class Agent:
    def __init__(self) -> None:
        self.brain = SnowflakeBrain()
        self.energy = 0.0
        self.activity = 0.0

    def step(self, external_energy: float = 0.0) -> None:
        self.brain.update(external_energy)
        self.activity = infer_activity_level(self.brain.coherence(), external_energy)
        self.energy += 0.1 * self.activity
