"""Minimal 21-node oscillator brain."""

from __future__ import annotations

import numpy as np
from engine.config import BRAIN_SIZE


class SnowflakeBrain:
    def __init__(self) -> None:
        self.phase = np.random.rand(BRAIN_SIZE) * (2 * np.pi)

    def update(self, external_energy: float = 0.0) -> None:
        diff = self.phase[:, None] - self.phase[None, :]
        coupling = np.sin(diff).sum(axis=1)
        self.phase = (self.phase + 0.02 * coupling + 0.001 * external_energy) % (2 * np.pi)

    def coherence(self) -> float:
        return float(np.abs(np.mean(np.exp(1j * self.phase))))
