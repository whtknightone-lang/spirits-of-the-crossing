"""Simple engine loop wrapper."""

from engine.simulation.universe import Universe
from engine.agents.agent import Agent
from engine.config import NUM_AGENTS


class EngineLoop:
    def __init__(self) -> None:
        self.universe = Universe()
        self.agents = [Agent() for _ in range(NUM_AGENTS)]
        self.step_count = 0

    def step(self):
        self.step_count += 1
        energy = self.universe.step()
        for agent in self.agents:
            agent.step(energy)
        return energy
