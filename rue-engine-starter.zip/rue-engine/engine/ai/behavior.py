"""Very simple behavior layer for the starter."""

from __future__ import annotations


def infer_activity_level(coherence: float, external_energy: float) -> float:
    # More coherence and more available energy produce more activity.
    return max(0.0, 0.5 * coherence + 0.05 * external_energy)
