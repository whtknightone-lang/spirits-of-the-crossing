"""Star model with simple flare events."""

from __future__ import annotations

import random
from engine.config import STAR_BASE_ENERGY, SOLAR_FLARE_BONUS, SOLAR_FLARE_PROBABILITY


class Star:
    def __init__(self) -> None:
        self.base_energy = STAR_BASE_ENERGY

    def emit_energy(self) -> float:
        flare = SOLAR_FLARE_BONUS if random.random() < SOLAR_FLARE_PROBABILITY else 0.0
        return self.base_energy + flare
