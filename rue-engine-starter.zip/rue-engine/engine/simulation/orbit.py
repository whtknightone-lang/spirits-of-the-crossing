"""Orbit helper functions."""

from __future__ import annotations

import math
from typing import Tuple


def position_from_polar(radius: float, angle: float) -> Tuple[float, float]:
    return radius * math.cos(angle), radius * math.sin(angle)
