"""Universe containing one star and multiple planets."""

from __future__ import annotations

from engine.config import NUM_PLANETS
from engine.simulation.star import Star
from engine.simulation.planet import Planet


class Universe:
    def __init__(self) -> None:
        self.star = Star()
        self.planets = [Planet(i) for i in range(NUM_PLANETS)]
        self.time = 0

    def step(self) -> float:
        self.time += 1
        for planet in self.planets:
            planet.update_orbit()
        return self.star.emit_energy()
