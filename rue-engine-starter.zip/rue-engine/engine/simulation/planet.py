"""Planet model."""

from __future__ import annotations

from engine.simulation.orbit import position_from_polar


class Planet:
    def __init__(self, index: int) -> None:
        self.index = index
        self.radius = 5.0 + index * 3.0
        self.angle = 0.0
        self.angular_speed = 0.01 / self.radius

    def update_orbit(self) -> None:
        self.angle += self.angular_speed

    @property
    def position(self):
        return position_from_polar(self.radius, self.angle)
