
# V68 Resonance Influence System

Adds:
- higher vibration individuals influence nearby entities
- resonance attraction toward similar vibration
- focus increases vibration, which spreads

Concept:
Higher states propagate through resonance, not force.
