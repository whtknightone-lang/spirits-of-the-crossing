
import math

class ResonanceSystem:
    def update(self,eco):
        ents=eco.entities
        for i in range(len(ents)):
            for j in range(i+1,len(ents)):
                a=ents[i]; b=ents[j]

                dx=a["pos"][0]-b["pos"][0]
                dy=a["pos"][1]-b["pos"][1]
                d=math.sqrt(dx*dx+dy*dy)

                if d<10:
                    influence = (a["vibration"] - b["vibration"]) * 0.01
                    b["vibration"] += influence
                    a["vibration"] -= influence*0.5
