
class FocusSystem:
    def update(self,eco):
        for e in eco.entities:
            e["focus"] *= 0.98
            e["vibration"] = max(0.0, min(1.0, e["vibration"] + e["focus"]*0.02))
