
# V91 Self-Aware Clusters + Memory

Adds:
- clusters accumulate "age" (persistence)
- clusters track historical existence via vibration identity
- older clusters become more stable/visible

Concept:
Realities remember themselves—
and persistence creates identity over time.
