
import pygame
from systems.ecosystem import Ecosystem
from systems.cluster_identity import ClusterIdentitySystem
from systems.cluster_memory import ClusterMemorySystem

class V91Engine:
    def __init__(self,size):
        self.size=size
        self.eco=Ecosystem(size)
        self.identity=ClusterIdentitySystem()
        self.memory=ClusterMemorySystem()

        self.font=pygame.font.SysFont("arial",16)

        for _ in range(140):
            self.eco.spawn_entity()

    def update(self,dt):
        self.eco.update(dt)
        self.identity.update(self.eco)
        self.memory.update(self.identity)

    def render(self,screen):
        screen.fill((10,10,65))
        scale=700/self.size

        for c in self.identity.clusters:
            cx=int(c["center"][1]*scale)+40
            cy=int(c["center"][0]*scale)+40
            age=int(c.get("age",0))
            pygame.draw.circle(screen,(255,200,120),(cx,cy),10,1)
            pygame.draw.circle(screen,(255,255,255),(cx,cy),max(1,age//20),1)

        for e in self.eco.entities:
            x=int(e["pos"][1]*scale)+40
            y=int(e["pos"][0]*scale)+40
            v=e["vibration"]
            color=(int(100+v*155),120,255-int(v*155))
            pygame.draw.circle(screen,color,(x,y),4)

        y=760
        lines=[
            "V91 Cluster Awareness + Memory",
            f"Clusters: {len(self.identity.clusters)}",
            f"Oldest age: {self.memory.max_age}"
        ]
        for l in lines:
            screen.blit(self.font.render(l,True,(240,240,240)),(40,y))
            y+=20
