
class ClusterMemorySystem:
    def __init__(self):
        self.history={}
        self.max_age=0

    def update(self,identity):
        for c in identity.clusters:
            key=round(c["avg_vibration"],2)

            if key not in self.history:
                self.history[key]=0

            self.history[key]+=1
            c["age"]=self.history[key]

            if c["age"]>self.max_age:
                self.max_age=c["age"]
