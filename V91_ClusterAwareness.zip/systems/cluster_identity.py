
class ClusterIdentitySystem:
    def __init__(self):
        self.clusters=[]

    def update(self,eco):
        self.clusters=[]
        visited=set()

        for e in eco.entities:
            if e["id"] in visited:
                continue

            group=[e]
            visited.add(e["id"])

            for o in eco.entities:
                if o["id"] in visited: continue
                if abs(o["vibration"]-e["vibration"])<0.1:
                    group.append(o)
                    visited.add(o["id"])

            if len(group)>5:
                cx=sum(g["pos"][0] for g in group)/len(group)
                cy=sum(g["pos"][1] for g in group)/len(group)

                self.clusters.append({
                    "members":group,
                    "center":[cx,cy],
                    "avg_vibration":sum(g["vibration"] for g in group)/len(group),
                    "age":0
                })
