
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from engine.simulation.universe import Universe
from engine.simulation.universe_patch import UniverseInteractionMixin
from engine.lineage.lineage import LineageManager
from engine.interactions.lineage_integration import integrate_lineage
from engine.roles.roles import assign_role, apply_role
from engine.player.player_spirit import PlayerSpirit
from engine.territory.territory import update_territory

class GameUniverse(Universe, UniverseInteractionMixin):
    def __init__(self):
        super().__init__()
        self.init_spirit_layer()
        self.lineage = LineageManager()
        for a in self.agents:
            self.lineage.assign_id(a)
        self.player = PlayerSpirit()
        self.territory = {}

    def step(self):
        super().step()
        self.interaction_step()
        integrate_lineage(self, self.lineage)

        for a in self.agents:
            a.role = assign_role(a)
            apply_role(a)

        self.player.influence(self)
        update_territory(self)

if __name__ == "__main__":
    u = GameUniverse()
    for i in range(1000):
        u.step()
        if i % 50 == 0:
            print("step", i, "agents", len(u.agents))
