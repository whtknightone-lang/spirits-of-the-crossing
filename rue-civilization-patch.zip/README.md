
# RUE Civilization Patch

Adds:
- Lineage specialization (roles)
- Player Spirit embodiment
- Territory system

Run:
python experiments/run_spirit_civilization.py
