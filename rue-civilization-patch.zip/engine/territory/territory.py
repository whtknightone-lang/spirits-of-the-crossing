
def update_territory(universe):
    territory = {}

    for p in universe.planets:
        for rid in range(p.n_regions):
            agents = [a for a in universe.agents if a.region_id == rid and a.planet_id == p.index]
            if not agents:
                continue
            dominant = max(set(a.lineage_id for a in agents), key=lambda x: sum(1 for a in agents if a.lineage_id==x))
            territory[(p.index, rid)] = dominant

    universe.territory = territory
