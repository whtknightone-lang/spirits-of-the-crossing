
class PlayerSpirit:
    def __init__(self, role="BALANCER"):
        self.role = role

    def influence(self, universe):
        for a in universe.agents:
            if self.role == "BALANCER":
                a.energy += 0.01
            elif self.role == "CATALYST":
                a.energy += 0.02
            elif self.role == "STABILIZER":
                a.energy += 0.005
