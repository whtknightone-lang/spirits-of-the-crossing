
def assign_role(agent):
    coherence = agent.brain.sync()
    energy = agent.energy

    if coherence > 0.6:
        return "STABILIZER"
    elif energy > 2.5:
        return "HARVESTER"
    else:
        return "EXPLORER"

def apply_role(agent):
    role = getattr(agent, "role", "EXPLORER")

    if role == "STABILIZER":
        agent.energy += 0.01
    elif role == "HARVESTER":
        agent.energy += 0.02
    elif role == "EXPLORER":
        agent.energy += 0.005
