using UnityEngine;

namespace ResonanceVR.VR
{
    public class HapticsDirector : MonoBehaviour
    {
        public void SetCoherencePulse(float coherence, float distortion)
        {
            Debug.Log($"Haptics pulse updated. Coherence={coherence:F2}, Distortion={distortion:F2}");
        }
    }
}
