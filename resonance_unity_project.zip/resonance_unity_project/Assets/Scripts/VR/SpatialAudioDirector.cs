using UnityEngine;

namespace ResonanceVR.VR
{
    public class SpatialAudioDirector : MonoBehaviour
    {
        [Range(0f, 1f)] public float signalClarity;

        public void SetSignalClarity(float value)
        {
            signalClarity = Mathf.Clamp01(value);
            // Route to mixer / FMOD / Wwise parameters here.
        }
    }
}
