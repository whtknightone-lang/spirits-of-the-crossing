using System.Collections.Generic;
using UnityEngine;

namespace ResonanceVR.Persistence
{
    public class MemoryArchive : MonoBehaviour
    {
        private readonly Dictionary<string, string> memory = new();

        public void SaveMemory(string key, string payload)
        {
            memory[key] = payload;
        }

        public bool TryLoadMemory(string key, out string payload)
        {
            return memory.TryGetValue(key, out payload);
        }
    }
}
