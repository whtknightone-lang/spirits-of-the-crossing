using UnityEngine;

namespace ResonanceVR.Core
{
    /// <summary>
    /// Entry bootstrap for wiring top-level references in a scene.
    /// Attach this to a root GameObject in the first prototype scene.
    /// </summary>
    public class ResonanceBootstrap : MonoBehaviour
    {
        [SerializeField] private MonoBehaviour inputRouter;
        [SerializeField] private MonoBehaviour resonanceEngine;
        [SerializeField] private MonoBehaviour manifestationDirector;
        [SerializeField] private MonoBehaviour universeCycleController;

        private void Start()
        {
            Debug.Log("ResonanceBootstrap: Scene startup complete.");
        }
    }
}
