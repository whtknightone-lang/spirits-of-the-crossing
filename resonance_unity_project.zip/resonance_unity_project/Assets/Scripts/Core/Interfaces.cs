namespace ResonanceVR.Core
{
    public interface IUpdatableSystem
    {
        void Tick(float deltaTime);
    }

    public interface IResonanceReadable
    {
        float GetResonanceScore();
    }

    public interface IMemoryWritable
    {
        void WriteMemory(string key, string payload);
    }

    public interface ISourceCommunicationMode
    {
        string ModeId { get; }
        float SuitabilityScore { get; }
    }
}
