using UnityEngine;
using ResonanceVR.Resonance;

namespace ResonanceVR.AI
{
    public class CompanionResonanceAgent : MonoBehaviour
    {
        [Range(0f, 1f)] public float bondStrength = 0.5f;
        [Range(0f, 1f)] public float stabilizationSkill = 0.4f;

        public void SyncWithPlayer(ResonanceState player)
        {
            bondStrength = Mathf.Clamp01(bondStrength + player.attunementToCompanion * 0.01f);
        }

        public float GetStabilizationContribution()
        {
            return bondStrength * stabilizationSkill;
        }
    }
}
