namespace ResonanceVR.Cosmos
{
    [System.Serializable]
    public struct UniverseCycleState
    {
        public float creationPressure;
        public float dissolutionPressure;
        public float noveltyDrive;
        public float compassionField;
        public float challengeField;
        public float cycleAge;
        public float harmonicComplexity;
    }
}
