using UnityEngine;

namespace ResonanceVR.Cosmos
{
    public class UniverseCycleController : MonoBehaviour
    {
        public UniverseCycleState CurrentCycle;

        public void TickCycle(float deltaTime)
        {
            CurrentCycle.cycleAge += deltaTime;
            CurrentCycle.creationPressure = Mathf.PingPong(CurrentCycle.cycleAge * 0.02f, 1f);
            CurrentCycle.dissolutionPressure = Mathf.PingPong((CurrentCycle.cycleAge + 10f) * 0.018f, 1f);
            CurrentCycle.noveltyDrive = Mathf.Clamp01((CurrentCycle.creationPressure + CurrentCycle.dissolutionPressure) * 0.5f);
        }
    }
}
