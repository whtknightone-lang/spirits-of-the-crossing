using UnityEngine;
using ResonanceVR.Resonance;

namespace ResonanceVR.Cosmos
{
    public class PlanetGrowthController : MonoBehaviour
    {
        public PlanetState CurrentPlanet;

        public void ApplyResonance(ResonanceOutput output)
        {
            CurrentPlanet.vitality = Mathf.Clamp01(CurrentPlanet.vitality + output.manifestationPower * 0.02f - output.distortionRisk * 0.01f);
            CurrentPlanet.coherence = Mathf.Clamp01(CurrentPlanet.coherence + output.matchScore * 0.02f - output.distortionRisk * 0.01f);
            CurrentPlanet.corruption = Mathf.Clamp01(CurrentPlanet.corruption + output.distortionRisk * 0.015f - output.solutionVisibility * 0.01f);
            CurrentPlanet.sourceOpenness = Mathf.Clamp01(CurrentPlanet.sourceOpenness + output.signalClarity * 0.02f);
            CurrentPlanet.memoryBloom = Mathf.Clamp01(CurrentPlanet.memoryBloom + output.revelationProbability * 0.01f);
            CurrentPlanet.adaptationPressure = Mathf.Clamp01(CurrentPlanet.adaptationPressure + output.rebirthPressure * 0.01f);
        }
    }
}
