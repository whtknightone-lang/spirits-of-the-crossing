namespace ResonanceVR.Cosmos
{
    [System.Serializable]
    public struct PlanetState
    {
        public float vitality;
        public float coherence;
        public float diversity;
        public float corruption;
        public float adaptationPressure;
        public float sourceOpenness;
        public float memoryBurden;
        public float rebirthThreshold;
        public float portalAffinity;
        public float memoryBloom;
        public float solutionAffinity;
    }
}
