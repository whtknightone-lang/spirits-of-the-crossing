using UnityEngine;

namespace ResonanceVR.Cosmos
{
    [System.Serializable]
    public struct ProblemState
    {
        public string problemId;
        public float severity;
        public float hiddenness;
        public float symbolicDifficulty;
        public float collectiveImpact;
    }

    [System.Serializable]
    public struct SolutionSeedState
    {
        public string solutionId;
        public float accessibility;
        public float requiredAttunement;
        public float embodimentRequirement;
        public float transmutationCost;
        public bool isVisible;
    }

    /// <summary>
    /// Generates a problem pattern and its latent solution at the same time.
    /// The solution may be obscured, costly, symbolic, or distributed.
    /// </summary>
    public class ProblemSolutionCoCreationEngine : MonoBehaviour
    {
        public ProblemState CurrentProblem;
        public SolutionSeedState CurrentSolution;

        public void GenerateFromPlanetAndCycle(PlanetState planet, UniverseCycleState cycle)
        {
            float instability = (planet.corruption + planet.adaptationPressure + cycle.dissolutionPressure) / 3f;
            float grace = (planet.sourceOpenness + cycle.compassionField + planet.solutionAffinity) / 3f;

            CurrentProblem = new ProblemState
            {
                problemId = "PlanetaryDissonance",
                severity = Mathf.Clamp01(instability),
                hiddenness = Mathf.Clamp01(1f - planet.memoryBloom),
                symbolicDifficulty = Mathf.Clamp01(cycle.harmonicComplexity),
                collectiveImpact = Mathf.Clamp01((planet.diversity + instability) * 0.5f)
            };

            CurrentSolution = new SolutionSeedState
            {
                solutionId = "BuriedReharmonizationSeed",
                accessibility = Mathf.Clamp01(grace),
                requiredAttunement = Mathf.Clamp01((instability + cycle.challengeField) * 0.5f),
                embodimentRequirement = Mathf.Clamp01(0.25f + instability * 0.5f),
                transmutationCost = Mathf.Clamp01(instability * 0.75f),
                isVisible = grace > 0.45f
            };
        }
    }
}
