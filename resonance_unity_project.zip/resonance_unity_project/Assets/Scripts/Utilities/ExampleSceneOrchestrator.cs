using UnityEngine;
using ResonanceVR.InputSystem;
using ResonanceVR.Resonance;
using ResonanceVR.Source;
using ResonanceVR.World;
using ResonanceVR.Cosmos;
using ResonanceVR.Gameplay;

namespace ResonanceVR.Utilities
{
    /// <summary>
    /// Minimal wiring example for the first prototype scene.
    /// </summary>
    public class ExampleSceneOrchestrator : MonoBehaviour
    {
        [SerializeField] private XRInputRouter inputRouter;
        [SerializeField] private PlayerResonanceProfile playerProfile;
        [SerializeField] private SourceIntelligenceProfile sourceProfile;
        [SerializeField] private RealmFieldProfile realmField;
        [SerializeField] private ResonanceEngine resonanceEngine;
        [SerializeField] private ManifestationDirector manifestationDirector;
        [SerializeField] private PlanetGrowthController planetGrowth;
        [SerializeField] private UniverseCycleController universeCycle;
        [SerializeField] private ProblemSolutionCoCreationEngine problemSolution;
        [SerializeField] private PortalController portalController;

        private void Update()
        {
            if (inputRouter == null || playerProfile == null || sourceProfile == null || realmField == null || resonanceEngine == null)
                return;

            playerProfile.UpdateFromInput(inputRouter.CurrentFrame);
            universeCycle.TickCycle(Time.deltaTime);

            sourceProfile.AdaptToPlayer(
                playerProfile.CurrentState.coherence,
                playerProfile.CurrentState.shadowActivation,
                universeCycle.CurrentCycle.creationPressure);

            sourceProfile.SelectCommunicationMode(
                playerProfile.CurrentState.coherence,
                playerProfile.CurrentState.trust);

            ResonanceOutput output = resonanceEngine.Evaluate(
                playerProfile.CurrentState,
                sourceProfile.CurrentState,
                realmField,
                planetGrowth.CurrentPlanet,
                universeCycle.CurrentCycle);

            manifestationDirector.Apply(output);
            planetGrowth.ApplyResonance(output);
            problemSolution.GenerateFromPlanetAndCycle(planetGrowth.CurrentPlanet, universeCycle.CurrentCycle);
            portalController.UpdatePortal(output);
        }
    }
}
