using UnityEngine;
using ResonanceVR.Resonance;
using ResonanceVR.VR;

namespace ResonanceVR.World
{
    public class ManifestationDirector : MonoBehaviour
    {
        [SerializeField] private HapticsDirector hapticsDirector;
        [SerializeField] private SpatialAudioDirector audioDirector;

        public void Apply(ResonanceOutput output)
        {
            if (audioDirector != null)
                audioDirector.SetSignalClarity(output.signalClarity);

            if (hapticsDirector != null)
                hapticsDirector.SetCoherencePulse(output.matchScore, output.distortionRisk);

            // Hook material params, lighting, VFX, flora, sky behavior here.
        }
    }
}
