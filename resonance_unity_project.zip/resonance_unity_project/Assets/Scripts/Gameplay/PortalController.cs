using UnityEngine;
using ResonanceVR.Resonance;

namespace ResonanceVR.Gameplay
{
    public class PortalController : MonoBehaviour
    {
        [SerializeField] private GameObject portalVisual;
        [Range(0f, 1f)] public float openThreshold = 0.65f;

        public void UpdatePortal(ResonanceOutput output)
        {
            bool shouldOpen = output.portalStability >= openThreshold && output.signalClarity >= 0.5f;
            if (portalVisual != null)
                portalVisual.SetActive(shouldOpen);
        }
    }
}
