using UnityEngine;
using ResonanceVR.Source;
using ResonanceVR.World;
using ResonanceVR.Cosmos;

namespace ResonanceVR.Resonance
{
    [System.Serializable]
    public struct ResonanceOutput
    {
        public float matchScore;
        public float signalClarity;
        public float manifestationPower;
        public float portalStability;
        public float distortionRisk;
        public float revelationProbability;
        public float rebirthPressure;
        public float solutionVisibility;
    }

    public class ResonanceEngine : MonoBehaviour
    {
        public ResonanceOutput LastOutput;

        public ResonanceOutput Evaluate(
            ResonanceState player,
            SourceState source,
            RealmFieldProfile realm,
            PlanetState planet,
            UniverseCycleState cycle)
        {
            float harmonyBase = (player.coherence + player.receptivity + (1f - player.shadowActivation)) / 3f;
            float sourceAlignment = (source.playerLanguageFit + source.compassion + source.directness) / 3f;
            float realmAlignment = (realm.harmony + realm.speciesTrust + (1f - realm.corruption)) / 3f;
            float planetAlignment = (planet.vitality + planet.coherence + planet.sourceOpenness) / 3f;

            LastOutput.matchScore = Mathf.Clamp01((harmonyBase + sourceAlignment + realmAlignment + planetAlignment) / 4f);
            LastOutput.signalClarity = Mathf.Clamp01(LastOutput.matchScore * (1f - realm.corruption));
            LastOutput.manifestationPower = Mathf.Clamp01((player.desireIntensity + player.receptivity + source.directness) / 3f);
            LastOutput.portalStability = Mathf.Clamp01((LastOutput.matchScore + realm.permeability + planet.portalAffinity) / 3f);
            LastOutput.distortionRisk = Mathf.Clamp01((player.shadowActivation + realm.corruption + cycle.dissolutionPressure) / 3f);
            LastOutput.revelationProbability = Mathf.Clamp01((LastOutput.signalClarity + source.mystery + planet.memoryBloom) / 3f);
            LastOutput.rebirthPressure = Mathf.Clamp01((cycle.creationPressure + cycle.dissolutionPressure + planet.rebirthThreshold) / 3f);
            LastOutput.solutionVisibility = Mathf.Clamp01((LastOutput.signalClarity + (1f - LastOutput.distortionRisk) + planet.solutionAffinity) / 3f);
            return LastOutput;
        }
    }
}
