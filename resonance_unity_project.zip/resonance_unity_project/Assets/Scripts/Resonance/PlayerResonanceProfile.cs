using UnityEngine;
using ResonanceVR.InputSystem;

namespace ResonanceVR.Resonance
{
    public class PlayerResonanceProfile : MonoBehaviour
    {
        [Range(0f, 1f)] public float smoothing = 0.15f;
        public ResonanceState CurrentState;

        public void UpdateFromInput(XRInputFrame frame)
        {
            CurrentState.focus = Mathf.Lerp(CurrentState.focus, frame.gestureConfidence, smoothing);
            CurrentState.calm = Mathf.Lerp(CurrentState.calm, frame.stillness, smoothing);
            CurrentState.coherence = Mathf.Lerp(CurrentState.coherence, (frame.stillness + frame.breathProxy) * 0.5f, smoothing);
            CurrentState.trust = Mathf.Lerp(CurrentState.trust, frame.voiceStability, smoothing);
            CurrentState.desireIntensity = Mathf.Lerp(CurrentState.desireIntensity, frame.locomotionMagnitude, smoothing);
            CurrentState.receptivity = Mathf.Lerp(CurrentState.receptivity, 1f - frame.locomotionMagnitude, smoothing);
            CurrentState.embodiment = Mathf.Lerp(CurrentState.embodiment, (frame.gestureConfidence + frame.breathProxy) * 0.5f, smoothing);
            CurrentState.shadowActivation = Mathf.Lerp(CurrentState.shadowActivation, 1f - frame.voiceStability, smoothing);
        }

        public float GetCoherence() => CurrentState.coherence;
        public float GetSourceAttunement() => CurrentState.attunementToSource;
    }
}
