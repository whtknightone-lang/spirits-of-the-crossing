namespace ResonanceVR.Resonance
{
    [System.Serializable]
    public struct ResonanceState
    {
        public float focus;
        public float calm;
        public float coherence;
        public float trust;
        public float desireIntensity;
        public float receptivity;
        public float embodiment;
        public float shadowActivation;
        public float attunementToSource;
        public float attunementToRealm;
        public float attunementToCompanion;
    }
}
