using UnityEngine;

namespace ResonanceVR.InputSystem
{
    [System.Serializable]
    public struct XRInputFrame
    {
        public Vector3 headPosition;
        public Quaternion headRotation;
        public Vector3 leftHandPosition;
        public Vector3 rightHandPosition;
        public Quaternion leftHandRotation;
        public Quaternion rightHandRotation;
        public float locomotionMagnitude;
        public float gestureConfidence;
        public float voiceStability;
        public float stillness;
        public float breathProxy;
    }
}
