using UnityEngine;

namespace ResonanceVR.InputSystem
{
    /// <summary>
    /// Replace stub logic with OpenXR/XR Interaction Toolkit hooks.
    /// </summary>
    public class XRInputRouter : MonoBehaviour
    {
        public XRInputFrame CurrentFrame { get; private set; }

        private void Update()
        {
            CurrentFrame = SampleStubFrame();
        }

        private XRInputFrame SampleStubFrame()
        {
            return new XRInputFrame
            {
                headPosition = Vector3.zero,
                headRotation = Quaternion.identity,
                leftHandPosition = Vector3.left,
                rightHandPosition = Vector3.right,
                leftHandRotation = Quaternion.identity,
                rightHandRotation = Quaternion.identity,
                locomotionMagnitude = 0.25f,
                gestureConfidence = 0.50f,
                voiceStability = 0.50f,
                stillness = 0.50f,
                breathProxy = 0.50f,
            };
        }
    }
}
