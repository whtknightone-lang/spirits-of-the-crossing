using UnityEngine;

namespace ResonanceVR.Source
{
    [System.Serializable]
    public struct SourceState
    {
        public float directness;
        public float symbolicDensity;
        public float musicalBias;
        public float compassion;
        public float challenge;
        public float mystery;
        public float playerLanguageFit;
        public float collectivePriority;
        public float rebirthGuidanceBias;
    }

    public class SourceIntelligenceProfile : MonoBehaviour
    {
        public SourceState CurrentState;
        public string activeCommunicationMode = "AudioHarmonics";

        public void AdaptToPlayer(float playerCoherence, float shadowLoad, float cyclePressure)
        {
            CurrentState.directness = Mathf.Clamp01(1f - shadowLoad);
            CurrentState.compassion = Mathf.Clamp01(0.5f + (1f - playerCoherence) * 0.5f);
            CurrentState.challenge = Mathf.Clamp01(playerCoherence * 0.75f + cyclePressure * 0.25f);
            CurrentState.mystery = Mathf.Clamp01(cyclePressure);
            CurrentState.playerLanguageFit = Mathf.Clamp01(playerCoherence);
            CurrentState.rebirthGuidanceBias = Mathf.Clamp01(cyclePressure);
        }

        public void SelectCommunicationMode(float playerCoherence, float playerTrust)
        {
            if (playerTrust < 0.35f)
                activeCommunicationMode = "GentleHaptics";
            else if (playerCoherence < 0.45f)
                activeCommunicationMode = "GeometryAndAudio";
            else
                activeCommunicationMode = "SymbolicWorldEvents";
        }
    }
}
