# Resonance VR Cosmos Prototype (Unity Architecture Skeleton)

This archive contains a Unity-oriented architecture skeleton for a resonance-driven VR game where:

- Player, AI, spirit, and Source all participate in a live resonance loop
- Source is adaptive rather than static
- Planetary growth, cosmic birth/rebirth, and world-scale evolution are simulation layers
- Problems and solutions are co-created by the universe as part of growth

## What this is

- A design-ready Unity project skeleton
- C# code stubs and interfaces for the core systems
- Data models for player resonance, Source adaptation, realms, planets, and universe cycles
- A vertical-slice-friendly structure that can be expanded into a working prototype

## What this is not

- A complete runnable game
- A full Unity package with scenes, prefabs, SDK integrations, or third-party dependencies

## Recommended stack

- Unity 6+ or Unity 2022/2023 LTS
- OpenXR for VR
- XR Interaction Toolkit or custom interaction layer
- FMOD/Wwise optional for advanced audio routing
- ScriptableObjects for data-driven tuning

## Suggested first playable slice

Scene: `SourceChamber_VR`

Goals:
1. Read VR/head-hand input
2. Estimate player coherence and attunement
3. Allow Source to adapt communication mode
4. Change haptics/audio/world state as resonance changes
5. Open a portal into a small proto-cosmos region
6. Demonstrate a planet-growth / universe-birth feedback loop

## Folder highlights

- `docs/` architecture documents
- `Assets/Scripts/Core/` shared contracts and bootstrap
- `Assets/Scripts/Input/` input abstraction
- `Assets/Scripts/Resonance/` state estimation and matching logic
- `Assets/Scripts/Source/` adaptive Source logic
- `Assets/Scripts/World/` realm and manifestation control
- `Assets/Scripts/Cosmos/` planets, rebirth cycles, problem-solution co-creation
- `Assets/Scripts/AI/` companions, spirits, adaptive entities
- `Assets/Scripts/Persistence/` memory archive and save stubs
- `Assets/Scripts/Gameplay/` portals and progression hooks
- `Assets/Scripts/VR/` haptics/audio façade interfaces

## Suggested next implementation order

1. `XRInputRouter`
2. `PlayerResonanceProfile`
3. `SourceIntelligenceProfile`
4. `ResonanceEngine`
5. `ManifestationDirector`
6. `PortalController`
7. `PlanetGrowthController`
8. `UniverseCycleController`
9. `ProblemSolutionCoCreationEngine`

