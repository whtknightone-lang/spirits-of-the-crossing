
import torch
import random

class GoalWorld:
    def __init__(self, n=50000):
        self.energy = torch.ones(n)
        self.position = torch.rand(n,3)
        self.velocity = torch.zeros(n,3)

        self.memory = torch.zeros(n)
        self.goal_type = torch.randint(0,4,(n,))  # 0 grow,1 explore,2 stabilize,3 expand

    def step(self):
        # base motion
        noise = 0.01 * torch.randn_like(self.velocity)

        # goal evaluation
        energy = self.energy
        memory = self.memory

        grow_score = energy
        explore_score = torch.norm(self.velocity, dim=1)
        stabilize_score = -torch.abs(energy - 1.2)
        expand_score = torch.norm(self.position - 0.5, dim=1)

        scores = torch.stack([grow_score, explore_score, stabilize_score, expand_score], dim=1)

        # pick score for each agent
        chosen_score = scores[torch.arange(len(self.goal_type)), self.goal_type]

        # directional movement (simple gradient proxy)
        direction = torch.randn_like(self.velocity)
        direction = direction / (torch.norm(direction, dim=1, keepdim=True) + 1e-6)

        self.velocity += noise + 0.01 * direction * chosen_score.unsqueeze(1)

        self.position += self.velocity
        self.position.clamp_(0,1)

        # energy dynamics
        self.energy += 0.01 * torch.sin(torch.rand_like(self.energy))

        # memory update
        self.memory = 0.9 * self.memory + 0.1 * self.energy

        # reinforcement
        improvement = (self.energy > self.memory)
        self.energy[improvement] *= 1.001
        self.energy[~improvement] *= 0.999

        # goal drift
        drift_mask = torch.rand(len(self.goal_type)) < 0.001
        self.goal_type[drift_mask] = torch.randint(0,4,(drift_mask.sum(),))

        self.energy *= 0.999
