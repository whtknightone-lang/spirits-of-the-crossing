
RUE V101–V110 Goal System

Features:
- Goal-driven agents (grow, explore, stabilize, expand)
- Goal evaluation functions
- Directional movement (gradient-like behavior)
- Reinforcement learning loop
- Goal drift (agents change goals if stuck)

Run:
pip install torch matplotlib
python run_v101.py
