
import pygame
from engine.core import CoreEngine

pygame.init()
screen = pygame.display.set_mode((1600,1000))
clock = pygame.time.Clock()

engine = CoreEngine()

running=True
while running:
    dt=clock.tick(60)/1000.0
    for e in pygame.event.get():
        if e.type==pygame.QUIT:
            running=False
        elif e.type==pygame.KEYDOWN:
            engine.handle_key(e.key)

    engine.update(dt)
    engine.render(screen)
    pygame.display.flip()

pygame.quit()
