
# Harmonic communication system

class HarmonicSystem:
    def __init__(self):
        self.level=0.0

    def update(self,eco):
        total=0
        for e in eco.entities:
            total+=e["vibration"]

        if eco.entities:
            self.level=total/len(eco.entities)

        # harmonic feedback loop
        for e in eco.entities:
            e["vibration"] += (self.level - e["vibration"]) * 0.01
