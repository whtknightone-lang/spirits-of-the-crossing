
import pygame

class PlayerController:
    def __init__(self,eco):
        self.eco=eco

    def handle(self,key):
        if key==pygame.K_1:
            for e in self.eco.entities:
                e["vibration"]+=0.05
        if key==pygame.K_2:
            for e in self.eco.entities:
                e["vibration"]*=0.95
