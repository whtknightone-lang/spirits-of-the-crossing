
class ClusterSystem:
    def __init__(self):
        self.clusters=[]

    def update(self,eco):
        self.clusters=[]
        visited=set()

        for e in eco.entities:
            if e["id"] in visited: continue
            group=[e]; visited.add(e["id"])

            for o in eco.entities:
                if o["id"] in visited: continue
                if abs(o["vibration"]-e["vibration"])<0.1:
                    group.append(o); visited.add(o["id"])

            if len(group)>5:
                self.clusters.append(group)
