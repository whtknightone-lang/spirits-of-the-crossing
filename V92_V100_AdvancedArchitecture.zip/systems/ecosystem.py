
import random, uuid

class Ecosystem:
    def __init__(self,n):
        self.size=n
        self.entities=[]

    def spawn(self):
        self.entities.append({
            "id":str(uuid.uuid4()),
            "pos":[random.random()*self.size,random.random()*self.size],
            "vibration":random.random(),
            "state":0.0
        })

    def update(self,dt):
        for e in self.entities:
            e["pos"][0]+=random.uniform(-1,1)*dt*3
            e["pos"][1]+=random.uniform(-1,1)*dt*3
