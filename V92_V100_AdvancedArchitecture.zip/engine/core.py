
import pygame
from systems.ecosystem import Ecosystem
from systems.cluster import ClusterSystem
from ai.brain import NeuralController
from gpu.accelerator import GPU
from controllers.player import PlayerController
from audio.harmonics import HarmonicSystem

class CoreEngine:
    def __init__(self):
        self.eco = Ecosystem(150)
        self.cluster = ClusterSystem()
        self.brain = NeuralController()
        self.gpu = GPU()
        self.player = PlayerController(self.eco)
        self.sound = HarmonicSystem()

        self.font = pygame.font.SysFont("arial",16)

        for _ in range(150):
            self.eco.spawn()

    def handle_key(self,key):
        self.player.handle(key)

    def update(self,dt):
        self.gpu.process(self.eco)
        self.eco.update(dt)
        self.cluster.update(self.eco)
        self.brain.update(self.eco)
        self.sound.update(self.eco)

    def render(self,screen):
        screen.fill((5,5,20))
        scale=800/self.eco.size

        for e in self.eco.entities:
            x=int(e["pos"][1]*scale)+50
            y=int(e["pos"][0]*scale)+50
            vib=e["vibration"]
            col=(int(100+vib*155),120,255-int(vib*155))
            pygame.draw.circle(screen,col,(x,y),3)

        txt=[
            f"Entities: {len(self.eco.entities)}",
            f"Clusters: {len(self.cluster.clusters)}",
            f"GPU load: {self.gpu.load}",
        ]

        y=850
        for t in txt:
            screen.blit(self.font.render(t,True,(240,240,240)),(50,y))
            y+=20
