using UnityEngine;
using Resonance.Core;
using Resonance.SourceSystem;
using Resonance.Planets;

namespace Resonance.World
{
    public class RealmResponseDirector : MonoBehaviour
    {
        [SerializeField] private WorldResponseProfile profile;
        [SerializeField] private PlayerResonanceProfile player;
        [SerializeField] private PlanetNodeController planet;
        [SerializeField] private AudioSource realmAudio;

        public void Configure(WorldResponseProfile responseProfile, PlayerResonanceProfile playerProfile, PlanetNodeController targetPlanet)
        {
            profile = responseProfile;
            player = playerProfile;
            planet = targetPlanet;
        }

        public void PresentResponse(GuidanceBridge bridge)
        {
            if (profile == null || player == null || planet == null || bridge == null)
                return;

            float worthiness = player.GetWorthinessSignal();
            float readiness = player.GetLearningReadiness();
            float contrast = Mathf.Clamp01(profile.contrastSharpness * (1f - readiness + 0.25f));
            float celebration = Mathf.Clamp01(profile.celebratesIndividual * worthiness);
            float importance = Mathf.Clamp01(profile.mirrorsImportanceToSource * worthiness);

            Debug.Log($"Realm [{profile.displayName}] responds. Celebration={celebration:F2}, Contrast={contrast:F2}, Importance={importance:F2}");

            if (realmAudio != null)
            {
                realmAudio.pitch = Mathf.Lerp(0.92f, 1.08f, celebration);
                realmAudio.volume = Mathf.Lerp(0.35f, 0.85f, importance);
                if (!realmAudio.isPlaying) realmAudio.Play();
            }

            planet.RecordEncounter(profile.realmId, celebration, contrast, importance, bridge.destinationId, bridge.thresholdId);
        }
    }
}
