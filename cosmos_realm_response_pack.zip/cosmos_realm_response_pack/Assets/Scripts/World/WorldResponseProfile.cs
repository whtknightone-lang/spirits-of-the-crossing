using UnityEngine;

namespace Resonance.World
{
    [CreateAssetMenu(menuName = "Resonance/World/Response Profile")]
    public class WorldResponseProfile : ScriptableObject
    {
        [Header("Identity")]
        public string realmId = "forest";
        public string displayName = "Forest Realm";

        [Header("Teaching Style")]
        [Range(0f, 1f)] public float playfulness = 0.7f;
        [Range(0f, 1f)] public float tenderness = 0.7f;
        [Range(0f, 1f)] public float contrastSharpness = 0.5f;
        [Range(0f, 1f)] public float discipline = 0.4f;
        [Range(0f, 1f)] public float mystery = 0.6f;

        [Header("Worth / Importance Demonstration")]
        [Range(0f, 1f)] public float celebratesIndividual = 0.8f;
        [Range(0f, 1f)] public float mirrorsImportanceToSource = 0.7f;
        [Range(0f, 1f)] public float welcomesReturn = 0.8f;

        [Header("Planetary Impact")]
        [Range(0f, 1f)] public float healingBias = 0.6f;
        [Range(0f, 1f)] public float growthBias = 0.7f;
        [Range(0f, 1f)] public float rebirthBias = 0.5f;
    }
}
