# Example Realm Profiles

Forest Realm
- playfulness: 0.80
- tenderness: 0.90
- contrastSharpness: 0.35
- discipline: 0.25
- celebratesIndividual: 0.95

Ocean Realm
- playfulness: 0.45
- tenderness: 0.75
- contrastSharpness: 0.60
- mystery: 0.90

Mountain Realm
- discipline: 0.90
- contrastSharpness: 0.70
- mirrorsImportanceToSource: 0.85

Fire Realm
- contrastSharpness: 0.85
- growthBias: 0.90
- rebirthBias: 0.80

Machine Realm
- discipline: 0.95
- playfulness: 0.20
- mystery: 0.25
- mirrorsImportanceToSource: 0.70

Dark Planet Realm
- contrastSharpness: 1.00
- welcomesReturn: 0.40
- rebirthBias: 1.00
