using System;
using UnityEngine;

namespace Resonance.Core
{
    public class PlayerResonanceProfile : MonoBehaviour
    {
        [Range(0f, 1f)] public float coherence = 0.55f;
        [Range(0f, 1f)] public float trust = 0.50f;
        [Range(0f, 1f)] public float joy = 0.50f;
        [Range(0f, 1f)] public float courage = 0.50f;
        [Range(0f, 1f)] public float openness = 0.50f;
        [Range(0f, 1f)] public float shadowLoad = 0.35f;
        [Range(0f, 1f)] public float desireIntensity = 0.60f;

        public float GetWorthinessSignal()
        {
            return Mathf.Clamp01((coherence * 0.30f) + (trust * 0.25f) + (courage * 0.20f) + (joy * 0.25f));
        }

        public float GetLearningReadiness()
        {
            float contrastCapacity = Mathf.Clamp01((courage * 0.35f) + (openness * 0.35f) + ((1f - shadowLoad) * 0.30f));
            return contrastCapacity;
        }
    }
}
