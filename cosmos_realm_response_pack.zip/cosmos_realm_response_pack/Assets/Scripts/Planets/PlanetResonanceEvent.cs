using System;

namespace Resonance.Planets
{
    [Serializable]
    public class PlanetResonanceEvent
    {
        public string realmId;
        public string destinationId;
        public string thresholdId;
        public float celebration;
        public float contrast;
        public float importance;
        public string utcTimestamp;
    }
}
