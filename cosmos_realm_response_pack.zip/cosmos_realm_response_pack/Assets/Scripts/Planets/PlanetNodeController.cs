using System;
using UnityEngine;

namespace Resonance.Planets
{
    public class PlanetNodeController : MonoBehaviour
    {
        [SerializeField] private string planetId = "P1";
        [SerializeField] private PlanetHistoryArchive history;
        [Range(0f, 1f)] [SerializeField] private float growth = 0.25f;
        [Range(0f, 1f)] [SerializeField] private float healing = 0.25f;
        [Range(0f, 1f)] [SerializeField] private float rebirthCharge = 0.10f;

        public void RecordEncounter(string realmId, float celebration, float contrast, float importance, string destinationId, string thresholdId)
        {
            if (history == null)
                history = GetComponent<PlanetHistoryArchive>();

            var e = new PlanetResonanceEvent
            {
                realmId = realmId,
                celebration = celebration,
                contrast = contrast,
                importance = importance,
                destinationId = destinationId,
                thresholdId = thresholdId,
                utcTimestamp = DateTime.UtcNow.ToString("o")
            };

            history?.AddEvent(e);

            growth = Mathf.Clamp01(growth + (celebration * 0.06f) + (importance * 0.04f));
            healing = Mathf.Clamp01(healing + (celebration * 0.04f) - (contrast * 0.01f));
            rebirthCharge = Mathf.Clamp01(rebirthCharge + (contrast * 0.05f) + (importance * 0.03f));

            Debug.Log($"Planet {planetId} recorded encounter from {realmId}. Growth={growth:F2} Healing={healing:F2} Rebirth={rebirthCharge:F2}");
        }

        public float GetGrowth() => growth;
        public float GetHealing() => healing;
        public float GetRebirthCharge() => rebirthCharge;
    }
}
