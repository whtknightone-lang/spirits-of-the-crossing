using System.Collections.Generic;
using UnityEngine;

namespace Resonance.Planets
{
    public class PlanetHistoryArchive : MonoBehaviour
    {
        [SerializeField] private List<PlanetResonanceEvent> events = new List<PlanetResonanceEvent>();

        public IReadOnlyList<PlanetResonanceEvent> Events => events;

        public void AddEvent(PlanetResonanceEvent resonanceEvent)
        {
            events.Add(resonanceEvent);
        }

        public float GetAverageCelebration()
        {
            if (events.Count == 0) return 0f;
            float sum = 0f;
            foreach (var e in events) sum += e.celebration;
            return sum / events.Count;
        }

        public float GetAverageContrast()
        {
            if (events.Count == 0) return 0f;
            float sum = 0f;
            foreach (var e in events) sum += e.contrast;
            return sum / events.Count;
        }

        public float GetAverageImportance()
        {
            if (events.Count == 0) return 0f;
            float sum = 0f;
            foreach (var e in events) sum += e.importance;
            return sum / events.Count;
        }
    }
}
