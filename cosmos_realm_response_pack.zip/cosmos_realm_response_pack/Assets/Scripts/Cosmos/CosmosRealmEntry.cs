using System;
using Resonance.World;
using Resonance.Planets;

namespace Resonance.Cosmos
{
    [Serializable]
    public class CosmosRealmEntry
    {
        public string realmId;
        public string displayName;
        public WorldResponseProfile responseProfile;
        public PlanetNodeController targetPlanet;
    }
}
