using UnityEngine;
using Resonance.Planets;

namespace Resonance.Cosmos
{
    public class UniverseCycleDirector : MonoBehaviour
    {
        [SerializeField] private PlanetNodeController[] planets;

        [Range(0f, 1f)] public float universeBirthPotential;
        [Range(0f, 1f)] public float universeRebirthPotential;

        public void RecalculateCycle()
        {
            if (planets == null || planets.Length == 0)
            {
                universeBirthPotential = 0f;
                universeRebirthPotential = 0f;
                return;
            }

            float growth = 0f;
            float healing = 0f;
            float rebirth = 0f;
            int activeCount = 0;

            foreach (var p in planets)
            {
                if (p == null) continue;
                growth += p.GetGrowth();
                healing += p.GetHealing();
                rebirth += p.GetRebirthCharge();
                activeCount++;
            }

            if (activeCount == 0)
            {
                universeBirthPotential = 0f;
                universeRebirthPotential = 0f;
                return;
            }

            float count = activeCount;
            universeBirthPotential = Mathf.Clamp01((growth / count * 0.55f) + (healing / count * 0.45f));
            universeRebirthPotential = Mathf.Clamp01((rebirth / count * 0.65f) + ((1f - healing / count) * 0.35f));

            Debug.Log($"Universe Cycle updated. Birth={universeBirthPotential:F2} Rebirth={universeRebirthPotential:F2}");
        }
    }
}
