using System.Collections.Generic;
using UnityEngine;
using Resonance.SourceSystem;
using Resonance.World;
using Resonance.Core;

namespace Resonance.Cosmos
{
    public class CosmosMapDirector : MonoBehaviour
    {
        [SerializeField] private List<CosmosRealmEntry> realms = new List<CosmosRealmEntry>();
        [SerializeField] private RealmResponseDirector realmResponsePrefab;
        [SerializeField] private PlayerResonanceProfile player;

        public void RouteBridgeToRealm(GuidanceBridge bridge, string realmId)
        {
            foreach (var realm in realms)
            {
                if (realm.realmId != realmId || realm.responseProfile == null || realm.targetPlanet == null)
                    continue;

                var instance = Instantiate(realmResponsePrefab);
                instance.Configure(realm.responseProfile, player, realm.targetPlanet);
                Debug.Log($"Routing bridge to realm [{realm.displayName}] using profile [{realm.responseProfile.displayName}].");
                instance.PresentResponse(bridge);
                return;
            }

            Debug.LogWarning($"No realm entry found for id: {realmId}");
        }
    }
}
