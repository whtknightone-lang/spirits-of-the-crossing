# Scene Hookup Notes

## Cosmos Map
- Create a `CosmosMapDirector`.
- Add a `CosmosRealmEntry` for each realm.
- Point each entry to:
  - a `WorldResponseProfile`
  - a `PlanetNodeController`

## Planet Nodes
Each planet prefab should include:
- `PlanetNodeController`
- `PlanetHistoryArchive`

## Realm Prefab
Create a realm response prefab with:
- `RealmResponseDirector`
- audio source
- optional VFX anchors
- references to:
  - active player
  - target planet
  - assigned realm profile

## Universe Cycle
Place a `UniverseCycleDirector` in the bootstrap scene and assign all planets.
Call `RecalculateCycle()`:
- after major realm encounters
- after planet growth spikes
- after rebirth chamber events

## Intent
The world should not only challenge the player.
It should also:
- celebrate the player
- mirror their importance
- create contrast for learning
- let every encounter feed planetary and universal evolution
