using System;

namespace Resonance.SourceSystem
{
    [Serializable]
    public class GuidanceBridge
    {
        public string thresholdId;
        public string destinationId;
        public string message;
        public string symbol;
        public float intensity;
        public float acceptance;
    }
}
