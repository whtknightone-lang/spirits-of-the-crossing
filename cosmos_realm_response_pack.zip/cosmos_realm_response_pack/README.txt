Cosmos Realm Response Pack

Purpose
-------
This drop-in Unity-style scaffold wires realm-specific world response profiles into a
cosmos map and gives each planet a persistent resonance history.

What is included
----------------
- Realm-specific WorldResponseProfile assets/classes
- Planet resonance history accumulation
- Cosmos map controller hooks
- Source/world/planet interaction pipeline
- Example scene hookup notes

Suggested scenes
----------------
- Bootstrap
- CosmosMap
- SourceChamber_VR
- ForestRealm
- OceanRealm
- MountainRealm
- FireRealm
- MachineRealm
- DarkPlanetRealm
- UniverseRebirthChamber

Suggested hookup
----------------
1. Add PlanetNodeController objects to the cosmos map.
2. Assign a WorldResponseProfile to each realm entry.
3. Feed player resonance + source bridge + world events into RealmResponseDirector.
4. Let PlanetHistoryArchive accumulate meaningful events over time.
5. Use UniverseCycleDirector to transform aggregate contrast into rebirth opportunities.
