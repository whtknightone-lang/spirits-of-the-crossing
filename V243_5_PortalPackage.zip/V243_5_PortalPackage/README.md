# V243.5 Portal Package

This package adds resonance-matched glimpse portals to the sandstone cave demo.

## Includes
- `CavePortalTypes.cs` — shared enums and serializable data containers
- `PortalProfileLoader.cs` — loads portal data from `StreamingAssets/portal_profiles.json`
- `ResonancePortalInterpreter.cs` — scores current, achievable, and challenge portals
- `GlimpsePortalController.cs` — drives reveal, stability, ancient ruin overlays, and ghost alien statue overlays
- `CavePortalRevealManager.cs` — updates all portal recesses in the cave
- `AncientRuinGhostAlienController.cs` — lets cave/disk/statues read as ancient ruin echoes with ghost alien likeness
- `portal_profiles.json` — starter portal tuning and themes

## Scene hookup
1. Add `PortalProfileLoader` and `ResonancePortalInterpreter` to a manager object.
2. Add `CavePortalRevealManager` to the same object and assign all five `GlimpsePortalController` instances.
3. Create five portal recess prefabs in the cave and assign their portal type.
4. Add `AncientRuinGhostAlienController` to each main statue or spirit likeness.
5. Call `RefreshPortalReveals()` whenever player response changes or at session checkpoints.
6. Call `CommitToCurrentPortal()` when you want one glimpse to become a stable threshold.

## Ancient ruins / ghost alien notes
- The portal profile data includes `ruinMotif` and `ghostAlienLikeness` fields.
- Use those values to drive materials, decals, narrative text, particle presets, or animation variations.
- The center disk should share the same ruin language as the portals so the chamber feels like one ancient system.

## Quick test
- Load profiles.
- Set a few sample values in `ResonancePortalInterpreter.sample`.
- Call `EvaluatePortals()`.
- Call `RefreshPortalReveals()`.
- Verify current/achievable/challenge portals update their seam light, overlays, and audio.
