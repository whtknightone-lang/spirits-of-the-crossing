using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace V243.Portals
{
    public class PortalProfileLoader : MonoBehaviour
    {
        [Tooltip("Relative to StreamingAssets.")]
        public string jsonFileName = "portal_profiles.json";

        [TextArea(3, 10)]
        public string fallbackJson;

        public List<ResonancePortalProfile> loadedProfiles = new();

        public bool LoadProfiles()
        {
            loadedProfiles.Clear();
            string path = Path.Combine(Application.streamingAssetsPath, jsonFileName);
            string json = string.Empty;

            if (File.Exists(path))
            {
                json = File.ReadAllText(path);
            }
            else if (!string.IsNullOrWhiteSpace(fallbackJson))
            {
                json = fallbackJson;
            }
            else
            {
                Debug.LogWarning($"PortalProfileLoader could not find {path} and no fallbackJson was provided.");
                return false;
            }

            var collection = JsonUtility.FromJson<PortalProfileCollection>(json);
            if (collection?.portals == null || collection.portals.Length == 0)
            {
                Debug.LogWarning("PortalProfileLoader found no portal profiles.");
                return false;
            }

            loadedProfiles.AddRange(collection.portals);
            return true;
        }
    }
}
