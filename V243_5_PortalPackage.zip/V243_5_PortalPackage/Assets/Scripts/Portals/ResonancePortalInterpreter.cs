using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace V243.Portals
{
    public class ResonancePortalInterpreter : MonoBehaviour
    {
        public PortalProfileLoader profileLoader;
        public PlayerResponseSample sample = new();

        [Header("Results")]
        public PortalScoreResult currentPortal;
        public PortalScoreResult achievablePortal;
        public PortalScoreResult challengePortal;
        public List<PortalScoreResult> lastScores = new();

        [Header("Tuning")]
        [Range(0f, 1f)] public float achievableSourceBoost = 0.35f;
        [Range(0f, 1f)] public float achievableWonderBoost = 0.2f;
        [Range(0f, 1f)] public float challengeDistortionBoost = 0.3f;

        public void EvaluatePortals()
        {
            EnsureProfiles();
            lastScores.Clear();
            if (profileLoader == null || profileLoader.loadedProfiles.Count == 0)
            {
                Debug.LogWarning("ResonancePortalInterpreter has no loaded profiles.");
                return;
            }

            foreach (var profile in profileLoader.loadedProfiles)
            {
                float baseScore =
                    sample.stillnessScore * profile.stillnessWeight +
                    sample.flowScore * profile.flowWeight +
                    sample.spinScore * profile.spinWeight +
                    sample.pairSyncScore * profile.pairWeight +
                    sample.calmScore * profile.calmWeight +
                    sample.joyScore * profile.joyWeight +
                    sample.wonderScore * profile.wonderWeight +
                    sample.sourceAlignmentScore * profile.sourceWeight -
                    sample.distortionScore * profile.distortionPenalty;

                float achievableScore = baseScore +
                    sample.sourceAlignmentScore * achievableSourceBoost +
                    sample.wonderScore * achievableWonderBoost;

                float challengeScore = baseScore +
                    sample.distortionScore * challengeDistortionBoost +
                    profile.challengeBias;

                float selectedScore = baseScore;
                lastScores.Add(new PortalScoreResult
                {
                    portalType = profile.portalType,
                    displayName = profile.displayName,
                    score = selectedScore,
                    revealAmount = Mathf.Clamp01(Mathf.InverseLerp(0f, 2f, selectedScore)),
                    stability = Mathf.Clamp01(Mathf.InverseLerp(profile.revealThreshold, profile.stabilityThreshold + 1f, achievableScore)),
                    isChallenge = false
                });
            }

            var sortedBase = lastScores.OrderByDescending(s => s.score).ToList();
            currentPortal = sortedBase.Count > 0 ? Clone(sortedBase[0]) : null;
            achievablePortal = SelectAchievable(sortedBase);
            challengePortal = SelectChallenge();
        }

        public ResonancePortalProfile GetProfile(ResonancePortalType type)
        {
            EnsureProfiles();
            return profileLoader == null ? null : profileLoader.loadedProfiles.FirstOrDefault(p => p.portalType == type);
        }

        private PortalScoreResult SelectAchievable(List<PortalScoreResult> sortedBase)
        {
            if (sortedBase.Count == 0) return null;

            var rescored = new List<PortalScoreResult>();
            foreach (var score in sortedBase)
            {
                float achievableScore = score.score +
                    sample.sourceAlignmentScore * achievableSourceBoost +
                    sample.wonderScore * achievableWonderBoost;
                rescored.Add(new PortalScoreResult
                {
                    portalType = score.portalType,
                    displayName = score.displayName,
                    score = achievableScore,
                    revealAmount = Mathf.Clamp01(Mathf.InverseLerp(0f, 2.5f, achievableScore)),
                    stability = Mathf.Clamp01(Mathf.InverseLerp(0.25f, 1.5f, achievableScore)),
                    isChallenge = false
                });
            }

            foreach (var candidate in rescored.OrderByDescending(r => r.score))
            {
                if (currentPortal == null || candidate.portalType != currentPortal.portalType)
                    return candidate;
            }
            return rescored[0];
        }

        private PortalScoreResult SelectChallenge()
        {
            if (profileLoader == null) return null;

            PortalScoreResult best = null;
            float bestScore = float.MinValue;
            foreach (var profile in profileLoader.loadedProfiles)
            {
                float challengeScore =
                    sample.stillnessScore * profile.stillnessWeight +
                    sample.flowScore * profile.flowWeight +
                    sample.spinScore * profile.spinWeight +
                    sample.pairSyncScore * profile.pairWeight +
                    sample.calmScore * profile.calmWeight +
                    sample.joyScore * profile.joyWeight +
                    sample.wonderScore * profile.wonderWeight +
                    sample.sourceAlignmentScore * profile.sourceWeight +
                    sample.distortionScore * challengeDistortionBoost +
                    profile.challengeBias;

                if (currentPortal != null && profile.portalType == currentPortal.portalType)
                    continue;
                if (achievablePortal != null && profile.portalType == achievablePortal.portalType)
                    continue;

                if (challengeScore > bestScore)
                {
                    bestScore = challengeScore;
                    best = new PortalScoreResult
                    {
                        portalType = profile.portalType,
                        displayName = profile.displayName,
                        score = challengeScore,
                        revealAmount = Mathf.Clamp01(Mathf.InverseLerp(0f, 2.5f, challengeScore)),
                        stability = Mathf.Clamp01(Mathf.InverseLerp(0f, 2f, challengeScore * 0.5f)),
                        isChallenge = true
                    };
                }
            }
            return best;
        }

        private static PortalScoreResult Clone(PortalScoreResult src)
        {
            if (src == null) return null;
            return new PortalScoreResult
            {
                portalType = src.portalType,
                displayName = src.displayName,
                score = src.score,
                revealAmount = src.revealAmount,
                stability = src.stability,
                isChallenge = src.isChallenge
            };
        }

        private void EnsureProfiles()
        {
            if (profileLoader != null && profileLoader.loadedProfiles.Count == 0)
                profileLoader.LoadProfiles();
        }
    }
}
