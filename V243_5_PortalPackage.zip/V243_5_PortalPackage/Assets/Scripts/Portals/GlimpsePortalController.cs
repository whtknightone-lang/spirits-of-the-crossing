using UnityEngine;

namespace V243.Portals
{
    public class GlimpsePortalController : MonoBehaviour
    {
        public ResonancePortalType portalType;
        public Renderer[] portalRenderers;
        public GameObject glimpseVisualRoot;
        public GameObject ruinOverlayRoot;
        public GameObject ghostAlienStatueOverlay;
        public Light seamLight;
        public AudioSource portalAudio;
        public Animator animator;

        [Header("State")]
        [Range(0f, 1f)] public float revealAmount;
        [Range(0f, 1f)] public float stability;
        public bool isActiveThreshold;
        public bool containsAncientRuinEcho = true;
        public bool containsGhostAlienLikeness = true;

        private static readonly int EmissionColor = Shader.PropertyToID("_EmissionColor");
        private MaterialPropertyBlock _block;

        private void Awake()
        {
            _block = new MaterialPropertyBlock();
            ApplyVisualState(Color.white);
        }

        public void ApplyProfile(ResonancePortalProfile profile)
        {
            if (profile == null) return;
            containsAncientRuinEcho = !string.IsNullOrWhiteSpace(profile.ruinMotif);
            containsGhostAlienLikeness = !string.IsNullOrWhiteSpace(profile.ghostAlienLikeness);
            ApplyVisualState(profile.portalColor);
        }

        public void SetReveal(float amount)
        {
            revealAmount = Mathf.Clamp01(amount);
            if (glimpseVisualRoot != null)
                glimpseVisualRoot.SetActive(revealAmount > 0.05f);
            if (ruinOverlayRoot != null)
                ruinOverlayRoot.SetActive(containsAncientRuinEcho && revealAmount > 0.15f);
            if (ghostAlienStatueOverlay != null)
                ghostAlienStatueOverlay.SetActive(containsGhostAlienLikeness && revealAmount > 0.2f);
            if (portalAudio != null)
                portalAudio.volume = Mathf.Lerp(0f, 0.65f, revealAmount);
            if (animator != null)
                animator.SetFloat("Reveal", revealAmount);
        }

        public void SetStability(float value)
        {
            stability = Mathf.Clamp01(value);
            if (seamLight != null)
                seamLight.intensity = Mathf.Lerp(0.2f, 2.1f, stability);
            if (animator != null)
                animator.SetFloat("Stability", stability);
        }

        public void ActivateThreshold()
        {
            isActiveThreshold = true;
            revealAmount = 1f;
            stability = 1f;
            if (animator != null)
                animator.SetBool("ActiveThreshold", true);
        }

        private void ApplyVisualState(Color portalColor)
        {
            if (portalRenderers == null) return;
            foreach (var renderer in portalRenderers)
            {
                if (renderer == null) continue;
                renderer.GetPropertyBlock(_block);
                _block.SetColor(EmissionColor, portalColor * Mathf.Lerp(0.1f, 2f, revealAmount));
                renderer.SetPropertyBlock(_block);
            }
            if (seamLight != null)
                seamLight.color = portalColor;
        }

        private void LateUpdate()
        {
            float pulse = Mathf.Lerp(0.2f, 1f, revealAmount) * Mathf.Lerp(0.6f, 1.2f, stability);
            if (portalRenderers != null)
            {
                foreach (var renderer in portalRenderers)
                {
                    if (renderer == null) continue;
                    renderer.GetPropertyBlock(_block);
                    Color baseColor = seamLight != null ? seamLight.color : Color.white;
                    _block.SetColor(EmissionColor, baseColor * pulse);
                    renderer.SetPropertyBlock(_block);
                }
            }
        }
    }
}
