using System;
using UnityEngine;

namespace V243.Portals
{
    public enum ResonancePortalType
    {
        FireMilitary,
        OceanSurf,
        ForestCalm,
        SourceEnergyWells,
        AirDancing
    }

    [Serializable]
    public class ResonancePortalProfile
    {
        public ResonancePortalType portalType;
        public string displayName;
        public float stillnessWeight = 0.25f;
        public float flowWeight = 0.25f;
        public float spinWeight = 0.25f;
        public float pairWeight = 0.25f;
        public float calmWeight = 0.25f;
        public float joyWeight = 0.25f;
        public float wonderWeight = 0.25f;
        public float sourceWeight = 0.25f;
        public float distortionPenalty = 0.5f;
        public float challengeBias = 0.15f;
        public float revealThreshold = 0.4f;
        public float stabilityThreshold = 0.6f;
        public string sigilId;
        public string particlePreset;
        public string audioState;
        public string ruinMotif;
        public string ghostAlienLikeness;
        public Color portalColor = Color.white;
    }

    [Serializable]
    public class PortalProfileCollection
    {
        public ResonancePortalProfile[] portals;
    }

    [Serializable]
    public class PortalScoreResult
    {
        public ResonancePortalType portalType;
        public string displayName;
        public float score;
        public float revealAmount;
        public float stability;
        public bool isChallenge;
    }

    [Serializable]
    public class PlayerResponseSample
    {
        [Range(0f, 1f)] public float stillnessScore;
        [Range(0f, 1f)] public float flowScore;
        [Range(0f, 1f)] public float spinScore;
        [Range(0f, 1f)] public float pairSyncScore;
        [Range(0f, 1f)] public float calmScore;
        [Range(0f, 1f)] public float joyScore;
        [Range(0f, 1f)] public float wonderScore;
        [Range(0f, 1f)] public float distortionScore;
        [Range(0f, 1f)] public float sourceAlignmentScore;
    }
}
