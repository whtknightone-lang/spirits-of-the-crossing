using System.Collections.Generic;
using UnityEngine;

namespace V243.Portals
{
    public class CavePortalRevealManager : MonoBehaviour
    {
        public ResonancePortalInterpreter interpreter;
        public List<GlimpsePortalController> portals = new();

        [Header("Reveal Tuning")]
        [Range(0f, 1f)] public float ambientReveal = 0.08f;
        [Range(0f, 1f)] public float currentReveal = 0.95f;
        [Range(0f, 1f)] public float achievableReveal = 0.6f;
        [Range(0f, 1f)] public float challengeReveal = 0.45f;

        public void RefreshPortalReveals()
        {
            if (interpreter == null) return;
            interpreter.EvaluatePortals();

            foreach (var portal in portals)
            {
                if (portal == null) continue;
                float reveal = ambientReveal;
                float stability = 0.15f;
                bool makeThreshold = false;

                if (interpreter.currentPortal != null && portal.portalType == interpreter.currentPortal.portalType)
                {
                    reveal = Mathf.Max(currentReveal, interpreter.currentPortal.revealAmount);
                    stability = Mathf.Max(0.85f, interpreter.currentPortal.stability);
                }
                else if (interpreter.achievablePortal != null && portal.portalType == interpreter.achievablePortal.portalType)
                {
                    reveal = Mathf.Max(achievableReveal, interpreter.achievablePortal.revealAmount);
                    stability = Mathf.Max(0.5f, interpreter.achievablePortal.stability);
                }
                else if (interpreter.challengePortal != null && portal.portalType == interpreter.challengePortal.portalType)
                {
                    reveal = Mathf.Max(challengeReveal, interpreter.challengePortal.revealAmount);
                    stability = Mathf.Max(0.25f, interpreter.challengePortal.stability);
                }

                var profile = interpreter.GetProfile(portal.portalType);
                portal.ApplyProfile(profile);
                portal.SetReveal(reveal);
                portal.SetStability(stability);

                if (makeThreshold)
                    portal.ActivateThreshold();
            }
        }

        public void CommitToCurrentPortal()
        {
            if (interpreter?.currentPortal == null) return;
            foreach (var portal in portals)
            {
                if (portal != null && portal.portalType == interpreter.currentPortal.portalType)
                    portal.ActivateThreshold();
            }
        }
    }
}
