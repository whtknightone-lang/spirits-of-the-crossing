using UnityEngine;

namespace V243.Portals
{
    public class AncientRuinGhostAlienController : MonoBehaviour
    {
        [Header("References")]
        public Transform centerDisk;
        public Renderer[] statueRenderers;
        public GameObject ruinGlyphRoot;
        public GameObject ghostAlienFaceRoot;
        public Animator statueAnimator;

        [Header("Visual Tuning")]
        [Range(0f, 1f)] public float ruinEchoStrength = 0.5f;
        [Range(0f, 1f)] public float ghostPresence = 0.5f;
        [Range(0f, 1f)] public float centerDiskPull = 0.5f;

        private static readonly int RuinStrength = Shader.PropertyToID("_RuinStrength");
        private static readonly int GhostPresence = Shader.PropertyToID("_GhostPresence");
        private static readonly int DiskPull = Shader.PropertyToID("_DiskPull");
        private MaterialPropertyBlock _block;

        private void Awake()
        {
            _block = new MaterialPropertyBlock();
            ApplyState();
        }

        public void DriveFromPortal(float reveal, float stability)
        {
            ruinEchoStrength = Mathf.Clamp01(Mathf.Lerp(ruinEchoStrength, reveal, 0.5f));
            ghostPresence = Mathf.Clamp01(Mathf.Lerp(ghostPresence, stability, 0.5f));
            centerDiskPull = Mathf.Clamp01((reveal + stability) * 0.5f);
            ApplyState();
        }

        private void ApplyState()
        {
            if (ruinGlyphRoot != null) ruinGlyphRoot.SetActive(ruinEchoStrength > 0.15f);
            if (ghostAlienFaceRoot != null) ghostAlienFaceRoot.SetActive(ghostPresence > 0.15f);
            if (statueAnimator != null)
            {
                statueAnimator.SetFloat("RuinEcho", ruinEchoStrength);
                statueAnimator.SetFloat("GhostPresence", ghostPresence);
                statueAnimator.SetFloat("CenterDiskPull", centerDiskPull);
            }

            foreach (var renderer in statueRenderers)
            {
                if (renderer == null) continue;
                renderer.GetPropertyBlock(_block);
                _block.SetFloat(RuinStrength, ruinEchoStrength);
                _block.SetFloat(GhostPresence, ghostPresence);
                _block.SetFloat(DiskPull, centerDiskPull);
                renderer.SetPropertyBlock(_block);
            }
        }
    }
}
