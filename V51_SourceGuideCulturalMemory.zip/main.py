
import pygame, torch
from engine.v51_engine import V51Engine

WIDTH, HEIGHT = 1480, 940
GRID = 128

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("V51 Source Guide + Cultural Memory")
clock = pygame.time.Clock()

device = "cuda" if torch.cuda.is_available() else "cpu"
engine = V51Engine(GRID, device)

running = True
while running:
    dt = clock.tick(60) / 1000.0

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
        elif e.type == pygame.KEYDOWN:
            engine.handle_key(e.key)

    engine.handle_input(dt)
    engine.update(dt)
    engine.render(screen)
    pygame.display.flip()

pygame.quit()
