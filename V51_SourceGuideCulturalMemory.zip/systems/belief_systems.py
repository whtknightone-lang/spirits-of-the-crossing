
import random
class BeliefSystemEngine:
    def update(self, agents, memory, source):
        source_signal = source.last_signal
        world_bias = memory.potential_field.mean().item()

        for a in agents:
            belief = a.get("belief", random.uniform(-1, 1))
            awareness = a.get("self_awareness", 0.0)
            msg = a.get("msg", 0.0)
            uplift = a.get("uplift", 0.0)

            belief += 0.01 * source_signal
            belief += 0.008 * (msg - 0.5)
            belief += 0.006 * world_bias
            belief += 0.01 * (awareness - 0.5)
            belief += 0.007 * uplift

            belief = max(-1.0, min(1.0, belief))
            a["belief"] = belief

    def force_realignment(self, agents):
        for a in agents:
            current = a.get("belief", 0.0)
            a["belief"] = current * 0.5
