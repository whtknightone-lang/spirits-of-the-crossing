
import math
import random
import torch

class SourceGuideSystem:
    def __init__(self, size):
        self.size = size
        self.pos = [size * 0.35, size * 0.35]
        self.radius = 16.0

    def reposition_near_player(self, player):
        px, py = player.grid_position()
        self.pos = [
            max(0, min(self.size - 1, px + random.randint(-8, 8))),
            max(0, min(self.size - 1, py + random.randint(-8, 8))),
        ]

    def update(self, player, agents, civs, memory):
        px, py = player.grid_position()

        # drift toward the player and toward lower-chaos zones
        mx = float(memory.now_field.mean().item())
        self.pos[0] += (px - self.pos[0]) * 0.01 + mx * 0.05
        self.pos[1] += (py - self.pos[1]) * 0.01 + mx * 0.05
        self.pos[0] = max(0, min(self.size - 1, self.pos[0]))
        self.pos[1] = max(0, min(self.size - 1, self.pos[1]))

        # uplift nearby individuals and shift group consciousness upward
        for a in agents:
            dx = self.pos[0] - a["pos"][0]
            dy = self.pos[1] - a["pos"][1]
            dist = math.sqrt(dx*dx + dy*dy)
            if dist <= self.radius:
                closeness = 1.0 - (dist / self.radius)
                a["uplift"] = max(0.0, min(1.0, a.get("uplift", 0.0) + 0.02 * closeness))
                a["self_awareness"] = max(0.0, min(1.0, a.get("self_awareness", 0.0) + 0.015 * closeness))
                a["belief"] = max(-1.0, min(1.0, a.get("belief", 0.0) + 0.01 * closeness))

        # civ-level coherence rise when guide is near their center
        for civ in civs:
            dx = self.pos[0] - civ["center"][0]
            dy = self.pos[1] - civ["center"][1]
            dist = math.sqrt(dx*dx + dy*dy)
            if dist < 20:
                civ["coherence"] = min(1.0, civ["coherence"] + 0.02 * (1.0 - dist / 20.0))

    def guide_field(self, size, device):
        field = torch.zeros((size, size), device=device)
        x = int(self.pos[0])
        y = int(self.pos[1])
        r = 8
        for i in range(max(0, x-r), min(size, x+r+1)):
            for j in range(max(0, y-r), min(size, y+r+1)):
                dx = x - i
                dy = y - j
                dist = (dx*dx + dy*dy) ** 0.5
                if dist <= r:
                    field[i, j] += 0.08 * (1.0 - dist / max(1.0, r))
        return field
