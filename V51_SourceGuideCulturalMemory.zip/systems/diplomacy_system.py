
import math
import torch

class DiplomacySystem:
    def __init__(self):
        self.links = []
        self.alliance_count = 0
        self.tension_count = 0
        self.cultural_memory_depth = 0.0
        self._memory_accumulator = 0.0

    def update(self, civs, agents, memory):
        self.links = []
        self.alliance_count = 0
        self.tension_count = 0

        for i in range(len(civs)):
            for j in range(i + 1, len(civs)):
                a = civs[i]
                b = civs[j]
                belief_gap = abs(a["belief"] - b["belief"])
                coherence_mix = (a["coherence"] + b["coherence"]) * 0.5
                distance = math.dist(a["center"], b["center"])

                if belief_gap < 0.35 and coherence_mix > 0.45:
                    self.links.append({"a": i, "b": j, "kind": "alliance"})
                    self.alliance_count += 1
                elif belief_gap > 0.7 and distance < 70:
                    self.links.append({"a": i, "b": j, "kind": "tension"})
                    self.tension_count += 1

        self._memory_accumulator += (self.alliance_count * 0.01 + self.tension_count * 0.015)
        self._memory_accumulator += abs(float(memory.memory_field.mean().item())) * 0.002
        self.cultural_memory_depth = min(1.0, self._memory_accumulator)

        # Apply mild agent influence from diplomacy
        for a in agents:
            civ_id = a.get("civ_id", -1)
            if civ_id < 0:
                continue
            local_shift = 0.0
            for link in self.links:
                if civ_id in (link["a"], link["b"]):
                    local_shift += 0.005 if link["kind"] == "alliance" else -0.004
            a["uplift"] = max(0.0, min(1.0, a.get("uplift", 0.0) + local_shift + self.cultural_memory_depth * 0.0008))

    def diplomacy_field(self, size, device):
        field = torch.zeros((size, size), device=device)
        val = self.alliance_count * 0.02 - self.tension_count * 0.015 + self.cultural_memory_depth * 0.03
        field += val
        return field
