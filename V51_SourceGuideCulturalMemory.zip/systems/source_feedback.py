
class SourceFeedbackSystem:
    def __init__(self):
        self.last_signal = 0.0

    def compute(self, memory, player, world):
        harmony = 1.0 - abs(memory.now_field.mean().item())
        diversity = len(world.agents) / 170.0
        player_state = abs(player.core.mean().item())
        signal = (harmony * 0.4 + diversity * 0.3 + player_state * 0.3) - 0.5
        self.last_signal = signal
        return signal * 0.01
