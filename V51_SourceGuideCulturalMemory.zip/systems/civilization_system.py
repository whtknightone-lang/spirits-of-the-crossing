
import math
import torch

class CivilizationSystem:
    def __init__(self):
        self.civs = []

    def force_recluster(self, agents):
        for a in agents:
            a.pop("civ_id", None)

    def update(self, agents, memory, source):
        bands = {0: [], 1: [], 2: [], 3: []}

        for idx, a in enumerate(agents):
            belief = a.get("belief", 0.0)
            if belief < -0.5:
                band = 0
            elif belief < 0.0:
                band = 1
            elif belief < 0.5:
                band = 2
            else:
                band = 3
            bands[band].append((idx, a))

        civs = []
        for band, members in bands.items():
            if not members:
                continue
            xs = [m[1]["pos"][0] for m in members]
            ys = [m[1]["pos"][1] for m in members]
            beliefs = [m[1].get("belief", 0.0) for m in members]
            awareness = [m[1].get("self_awareness", 0.0) for m in members]
            uplift = [m[1].get("uplift", 0.0) for m in members]

            civ = {
                "band": band,
                "members": [m[0] for m in members],
                "center": [sum(xs) / len(xs), sum(ys) / len(ys)],
                "belief": sum(beliefs) / len(beliefs),
                "coherence": max(0.0, min(1.0, (sum(awareness) / len(awareness) + sum(uplift) / len(uplift)) * 0.5)),
                "size": len(members),
            }
            civs.append(civ)

        self.civs = civs
        for civ_id, civ in enumerate(self.civs):
            for idx in civ["members"]:
                agents[idx]["civ_id"] = civ_id

    def civilization_field(self, size, device):
        field = torch.zeros((size, size), device=device)
        for civ in self.civs:
            x = int(civ["center"][0])
            y = int(civ["center"][1])
            x = max(0, min(size - 1, x))
            y = max(0, min(size - 1, y))
            radius = max(2, min(12, civ["size"] // 6 + 2))
            for i in range(max(0, x - radius), min(size, x + radius + 1)):
                for j in range(max(0, y - radius), min(size, y + radius + 1)):
                    field[i, j] += civ["belief"] * 0.1 + civ["coherence"] * 0.06
        return field
