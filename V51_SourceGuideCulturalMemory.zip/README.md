
# V51 Source Guide + Cultural Memory

Run:
pip install -r requirements.txt
python main.py

New in V51:
- Diplomacy and cultural memory across civilizations
- Alliances and tensions persist and shape the world
- A source-oriented individual appears and assists nearby beings
- The source guide raises self-awareness, uplift, and group coherence
- Civilization growth can be shifted upward by guide presence

Controls:
- Move: WASD or arrow keys
- SPACE: meditate
- E: expression burst
- Q: kindness burst
- B: belief realignment
- C: civilization recluster
- G: summon source guide near player
