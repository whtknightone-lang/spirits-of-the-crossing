
import pygame
import numpy as np

from systems.resonance_memory import ResonanceMemorySystem
from systems.player_body import PlayerBody
from systems.agent_world import AgentWorld
from systems.communication import CommunicationSystem
from systems.meditation import MeditationSystem
from systems.source_feedback import SourceFeedbackSystem
from systems.self_awareness import SelfAwarenessSystem
from systems.belief_systems import BeliefSystemEngine
from systems.civilization_system import CivilizationSystem
from systems.diplomacy_system import DiplomacySystem
from systems.source_guide import SourceGuideSystem

class V51Engine:
    def __init__(self, size, device):
        self.size = size
        self.device = device

        self.memory = ResonanceMemorySystem(size, device)
        self.player = PlayerBody(size, device)
        self.world = AgentWorld(size, device, 150)
        self.comm = CommunicationSystem()
        self.meditation = MeditationSystem()
        self.source = SourceFeedbackSystem()
        self.awareness = SelfAwarenessSystem()
        self.beliefs = BeliefSystemEngine()
        self.civilizations = CivilizationSystem()
        self.diplomacy = DiplomacySystem()
        self.source_guide = SourceGuideSystem(size)

        self.font = pygame.font.SysFont("arial", 16)

    def handle_key(self, key):
        if key == pygame.K_SPACE:
            self.meditation.toggle()
        elif key == pygame.K_e:
            self.player.emit_expression_burst(self.memory.now_field)
        elif key == pygame.K_q:
            self.player.emit_kindness_burst(self.memory.now_field)
        elif key == pygame.K_b:
            self.beliefs.force_realignment(self.world.agents)
        elif key == pygame.K_c:
            self.civilizations.force_recluster(self.world.agents)
        elif key == pygame.K_g:
            self.source_guide.reposition_near_player(self.player)

    def handle_input(self, dt):
        self.player.handle_movement(pygame.key.get_pressed(), dt)

    def update(self, dt):
        self.memory.update(dt, self.world.aggregate_world_emotion(), self.player.resonance_mean())
        self.player.update(dt, self.memory.now_field, self.memory.potential_field)
        self.world.update(dt, self.memory.now_field, self.memory.potential_field, self.player)

        self.comm.update(self.world.agents)
        self.awareness.update(self.world.agents, self.player, self.memory)
        self.beliefs.update(self.world.agents, self.memory, self.source)
        self.civilizations.update(self.world.agents, self.memory, self.source)
        self.diplomacy.update(self.civilizations.civs, self.world.agents, self.memory)
        self.source_guide.update(self.player, self.world.agents, self.civilizations.civs, self.memory)

        if self.meditation.active:
            self.memory.now_field += self.meditation.align(self.memory)

        feedback = self.source.compute(self.memory, self.player, self.world)
        self.memory.now_field += feedback
        self.memory.potential_field += feedback * 0.5

        civ_pressure = self.civilizations.civilization_field(self.size, self.memory.device)
        dip_pressure = self.diplomacy.diplomacy_field(self.size, self.memory.device)
        guide_pressure = self.source_guide.guide_field(self.size, self.memory.device)

        self.memory.now_field += civ_pressure * 0.0018
        self.memory.potential_field += civ_pressure * 0.0010
        self.memory.now_field += dip_pressure * 0.0012
        self.memory.potential_field += guide_pressure * 0.0015
        self.memory.now_field += guide_pressure * 0.0010

        self.memory.clamp_all()

    def render(self, screen):
        screen.fill((10, 10, 20))

        arr = self.memory.now_field.detach().cpu().numpy()
        arr = (arr - arr.min()) / (arr.max() + 1e-5)
        img = np.stack([arr * 255, arr * 210, 255 - arr * 140], axis=-1).astype("uint8")
        surf = pygame.surfarray.make_surface(np.transpose(img, (1, 0, 2)))
        surf = pygame.transform.scale(surf, (780, 780))
        screen.blit(surf, (28, 28))

        scale = 780 / self.size

        # civilization territories
        for civ in self.civilizations.civs:
            cx = int(civ["center"][1] * scale) + 28
            cy = int(civ["center"][0] * scale) + 28
            radius = max(8, int(civ["size"] * 0.38))
            color = (
                max(0, min(255, int(120 + civ["belief"] * 100))),
                max(0, min(255, int(120 + civ["coherence"] * 110))),
                max(0, min(255, int(185 - civ["belief"] * 75))),
            )
            pygame.draw.circle(screen, color, (cx, cy), radius, 2)

        # diplomacy links
        for link in self.diplomacy.links:
            a = self.civilizations.civs[link["a"]]
            b = self.civilizations.civs[link["b"]]
            ax = int(a["center"][1] * scale) + 28
            ay = int(a["center"][0] * scale) + 28
            bx = int(b["center"][1] * scale) + 28
            by = int(b["center"][0] * scale) + 28
            color = (120, 240, 180) if link["kind"] == "alliance" else (255, 110, 110)
            pygame.draw.line(screen, color, (ax, ay), (bx, by), 2)

        # agents
        for a in self.world.agents:
            x = int(a["pos"][1] * scale) + 28
            y = int(a["pos"][0] * scale) + 28
            belief = a.get("belief", 0.0)
            aware = a.get("self_awareness", 0.0)
            uplift = a.get("uplift", 0.0)
            color = (
                max(0, min(255, int(105 + belief * 90 + uplift * 40))),
                max(0, min(255, int(130 + aware * 110 + uplift * 30))),
                max(0, min(255, int(180 - belief * 60 + uplift * 25))),
            )
            pygame.draw.circle(screen, color, (x, y), 3)

        # player
        px, py = self.player.grid_position()
        pygame.draw.circle(screen, (255, 255, 255), (int(py * scale) + 28, int(px * scale) + 28), 7)

        # source guide
        gx, gy = self.source_guide.pos
        pygame.draw.circle(screen, (255, 245, 140), (int(gy * scale) + 28, int(gx * scale) + 28), 9)
        pygame.draw.circle(screen, (120, 255, 240), (int(gy * scale) + 28, int(gx * scale) + 28), 16, 2)

        avg_awareness = sum(a.get("self_awareness", 0.0) for a in self.world.agents) / max(1, len(self.world.agents))
        avg_belief = sum(a.get("belief", 0.0) for a in self.world.agents) / max(1, len(self.world.agents))
        avg_uplift = sum(a.get("uplift", 0.0) for a in self.world.agents) / max(1, len(self.world.agents))
        med = "ON" if self.meditation.active else "OFF"

        lines = [
            "V51 Source Guide + Cultural Memory",
            "SPACE meditate | E expression | Q kindness | B belief realign | C recluster | G summon guide",
            f"Meditation: {med}",
            f"Source signal: {self.source.last_signal:.3f}",
            f"Avg self-awareness: {avg_awareness:.3f}",
            f"Avg belief orientation: {avg_belief:.3f}",
            f"Avg uplift / consciousness rise: {avg_uplift:.3f}",
            f"Civilizations: {len(self.civilizations.civs)} | Alliances: {self.diplomacy.alliance_count} | Tensions: {self.diplomacy.tension_count}",
            f"Cultural memory depth: {self.diplomacy.cultural_memory_depth:.3f}",
        ]

        y = 824
        for line in lines:
            screen.blit(self.font.render(line, True, (240, 240, 240)), (28, y))
            y += 20
