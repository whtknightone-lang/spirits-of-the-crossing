
import torch

class ResonanceMemorySystem:
    def __init__(self, grid_size, device):
        self.grid_size = grid_size
        self.device = device
        self.now_field = torch.zeros((grid_size, grid_size), device=device)
        self.memory_field = torch.zeros((grid_size, grid_size), device=device)
        self.potential_field = torch.zeros((grid_size, grid_size), device=device)

    def update(self, dt, joy_field, emotion_mean, planet_memory):
        noise = 0.02 * torch.randn_like(self.now_field)
        self.now_field += noise * dt
        self.now_field += joy_field * 0.004
        self.now_field += emotion_mean * 0.003

        self.memory_field += (self.now_field * 0.01 + planet_memory * 0.002) * max(dt, 0.016)

        self.potential_field = torch.tanh(self.now_field + self.memory_field + planet_memory * 0.2)

        self.now_field *= 0.999
        self.memory_field *= 0.9995

    def inject_now(self, amount):
        self.now_field += amount

    def inject_memory(self, amount):
        self.memory_field += amount

    def inject_potential(self, amount):
        self.potential_field += amount
