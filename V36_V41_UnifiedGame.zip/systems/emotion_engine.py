
import torch
import torch.nn.functional as F

class EmotionEngine:
    def __init__(self, size, device, dims=7):
        self.size = size
        self.device = device
        self.dims = dims
        self.field = torch.zeros((dims, size, size), device=device)

        self.laplace_kernel = torch.tensor(
            [[0,1,0],[1,-4,1],[0,1,0]],
            dtype=torch.float32,
            device=device
        ).view(1,1,3,3)

    def _lap(self, x):
        return F.conv2d(x.unsqueeze(0), self.laplace_kernel, padding=1).squeeze(0)

    def update(self, dt, joy_field):
        joy_2d = joy_field[0, 0]
        mean_field = self.field.mean(dim=0)
        for k in range(self.dims):
            diff = self._lap(self.field[k])
            interaction = torch.tanh(mean_field + joy_2d * 0.25)
            self.field[k] += 0.14 * diff * dt + 0.06 * interaction * dt

        self.field[1] += self.field[0] * 0.004
        self.field[4] += self.field[2] * 0.004
        self.field[0] += self.field[3] * 0.003
        self.field[6] -= torch.relu(-self.field[1]) * 0.003
        self.field = torch.clamp(self.field, -2.0, 2.0)

    def inject_dimension(self, idx, amount):
        if 0 <= idx < self.dims:
            self.field[idx] += amount
