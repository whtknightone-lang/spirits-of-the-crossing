
import random
import torch

class GalacticConsciousnessSystem:
    def __init__(self, grid_size, device, emo_dim=7):
        self.grid_size = grid_size
        self.device = device
        self.emo_dim = emo_dim

        self.galaxy_field = torch.zeros((emo_dim, grid_size, grid_size), device=device)
        self.planets = [self._new_planet() for _ in range(3)]

    def _new_planet(self):
        return {
            "field_bias": torch.rand(self.emo_dim) * 2 - 1,
            "memory_bias": torch.rand(self.emo_dim) * 0.2,
            "life_forms": random.randint(1, 5),
        }

    def update(self, dt, planet_memory, civ_signature, joy_mean, potential_field):
        self.galaxy_field += 0.004 * torch.randn_like(self.galaxy_field) * dt
        self.galaxy_field += planet_memory.unsqueeze(0).repeat(self.emo_dim, 1, 1) * 0.0003
        self.galaxy_field += potential_field.unsqueeze(0).repeat(self.emo_dim, 1, 1) * 0.00025
        self.galaxy_field += civ_signature * 0.0006
        self.galaxy_field[0] += joy_mean * 0.0012

        for planet in self.planets:
            self.galaxy_field += planet["field_bias"].to(self.device).view(self.emo_dim, 1, 1) * 0.0005
            self.galaxy_field += planet["memory_bias"].to(self.device).view(self.emo_dim, 1, 1) * 0.0002

        self.galaxy_field = torch.clamp(self.galaxy_field, -2.0, 2.0)

    def spawn_event(self):
        if len(self.planets) < 20 and random.random() < 0.6:
            self.planets.append(self._new_planet())

        if self.planets:
            planet = random.choice(self.planets)
            planet["life_forms"] += random.randint(1, 3)
            planet["memory_bias"] += torch.rand(self.emo_dim) * 0.02
            planet["field_bias"] += (torch.rand(self.emo_dim) * 0.04) - 0.02
            planet["field_bias"] = torch.clamp(planet["field_bias"], -2.0, 2.0)
