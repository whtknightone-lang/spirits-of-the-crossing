
import pygame
import torch
from engine.unified_universe_engine import UnifiedUniverseEngine

WIDTH = 1280
HEIGHT = 820
GRID_SIZE = 128

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Unified Universe Engine V36-V41")
    clock = pygame.time.Clock()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    engine = UnifiedUniverseEngine(grid_size=GRID_SIZE, device=device)

    running = True
    while running:
        dt = clock.tick(60) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                engine.handle_key(event.key)

        engine.update(dt)
        engine.render(screen)
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
