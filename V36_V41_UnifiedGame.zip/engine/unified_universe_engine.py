
import pygame
import numpy as np

from systems.joy_engine import JoyEngine
from systems.emotion_engine import EmotionEngine
from systems.core_continuity import CoreContinuitySystem
from systems.planetary_civilization import PlanetaryCivilizationSystem
from systems.galactic_consciousness import GalacticConsciousnessSystem
from systems.resonance_memory import ResonanceMemorySystem

class UnifiedUniverseEngine:
    def __init__(self, grid_size=128, device="cpu"):
        self.grid_size = grid_size
        self.device = device

        self.joy = JoyEngine(grid_size, device)
        self.emotion = EmotionEngine(grid_size, device)
        self.core = CoreContinuitySystem(num_agents=240, grid_size=grid_size, device=device)
        self.planetary = PlanetaryCivilizationSystem(grid_size=grid_size, device=device)
        self.galaxy = GalacticConsciousnessSystem(grid_size=grid_size, device=device)
        self.memory = ResonanceMemorySystem(grid_size=grid_size, device=device)

        self.font = pygame.font.SysFont("arial", 16)
        self.title_font = pygame.font.SysFont("arial", 18, bold=True)
        self.tick_count = 0

    def handle_key(self, key):
        if key == pygame.K_UP:
            self.joy.inject_joy(0.15)
        elif key == pygame.K_DOWN:
            self.joy.inject_discord(0.15)
        elif key == pygame.K_1:
            self.emotion.inject_dimension(0, 0.12)
        elif key == pygame.K_2:
            self.emotion.inject_dimension(1, 0.12)
        elif key == pygame.K_3:
            self.emotion.inject_dimension(2, 0.12)
        elif key == pygame.K_4:
            self.emotion.inject_dimension(3, 0.12)
        elif key == pygame.K_5:
            self.emotion.inject_dimension(4, 0.12)
        elif key == pygame.K_6:
            self.emotion.inject_dimension(5, 0.12)
        elif key == pygame.K_7:
            self.emotion.inject_dimension(6, 0.12)
        elif key == pygame.K_b:
            self.core.trigger_random_rebirth()
        elif key == pygame.K_p:
            self.planetary.civilization_event()
        elif key == pygame.K_g:
            self.galaxy.spawn_event()
        elif key == pygame.K_n:
            self.memory.inject_now(0.15)
        elif key == pygame.K_m:
            self.memory.inject_memory(0.08)
        elif key == pygame.K_f:
            self.memory.inject_potential(0.08)

    def update(self, dt):
        self.tick_count += 1

        self.joy.update(dt)
        self.emotion.update(dt, self.joy.J)
        self.core.update(dt, self.emotion.field)
        agent_mean = self.core.aggregate_agent_emotion()
        self.planetary.update(dt, self.emotion.field, agent_mean)

        self.memory.update(
            dt,
            self.joy.J[0, 0],
            self.emotion.field.mean(dim=0),
            self.planetary.planet_memory
        )

        self.galaxy.update(
            dt,
            self.planetary.planet_memory,
            self.planetary.civilization_signature(),
            self.joy.J.mean().item(),
            self.memory.potential_field
        )

        # Cross-system coupling: now-point memory spine
        now_echo = self.memory.now_field * 0.003
        memory_echo = self.memory.memory_field * 0.002
        future_echo = self.memory.potential_field * 0.0025

        self.joy.J[0, 0] += now_echo + future_echo
        self.emotion.field += now_echo.unsqueeze(0)[:self.emotion.dims]
        self.planetary.planet_memory += memory_echo + future_echo * 0.5
        self.galaxy.galaxy_field += future_echo.unsqueeze(0).repeat(self.galaxy.emo_dim, 1, 1) * 0.15

        self._clamp_all()

    def _clamp_all(self):
        self.joy.J.clamp_(-2.5, 2.5)
        self.joy.Psi.clamp_(-2.5, 2.5)
        self.emotion.field.clamp_(-2.5, 2.5)
        self.planetary.planet_memory.clamp_(-2.5, 2.5)
        self.galaxy.galaxy_field.clamp_(-2.5, 2.5)
        self.memory.now_field.clamp_(-2.5, 2.5)
        self.memory.memory_field.clamp_(-2.5, 2.5)
        self.memory.potential_field.clamp_(-2.5, 2.5)

    def render(self, screen):
        screen.fill((6, 8, 14))

        panels = [
            ("Joy Field", self._surface_from_field(self.joy.J[0, 0], "joy"), (20, 44)),
            ("Emotion Field", self._surface_from_field(self.emotion.field[0], "emotion"), (430, 44)),
            ("Planetary Memory", self._surface_from_field(self.planetary.planet_memory, "planet"), (840, 44)),
            ("Galactic Field", self._surface_from_field(self.galaxy.galaxy_field[0], "galaxy"), (20, 420)),
            ("Now Field", self._surface_from_field(self.memory.now_field, "now"), (430, 420)),
            ("Potential Field", self._surface_from_field(self.memory.potential_field, "future"), (840, 420)),
        ]

        for title, surface, pos in panels:
            scaled = pygame.transform.scale(surface, (390, 300))
            screen.blit(scaled, pos)
            label = self.title_font.render(title, True, (240, 240, 248))
            screen.blit(label, (pos[0], pos[1] - 24))

        self._draw_agents(screen)
        self._draw_hud(screen)

    def _surface_from_field(self, field, mode="joy"):
        arr = field.detach().cpu().numpy()
        arr = arr - arr.min()
        maxv = arr.max()
        if maxv > 1e-8:
            arr = arr / maxv

        if mode == "joy":
            img = np.stack([arr * 255, arr * 165, 255 - arr * 170], axis=-1)
        elif mode == "emotion":
            img = np.stack([arr * 255, 255 - arr * 255, arr * 130], axis=-1)
        elif mode == "planet":
            img = np.stack([70 + arr * 120, 115 + arr * 95, arr * 255], axis=-1)
        elif mode == "galaxy":
            img = np.stack([arr * 170, arr * 90, 120 + arr * 135], axis=-1)
        elif mode == "now":
            img = np.stack([255 - arr * 100, arr * 220, arr * 255], axis=-1)
        else:
            img = np.stack([arr * 255, arr * 190, 255 - arr * 80], axis=-1)

        img = img.clip(0, 255).astype(np.uint8)
        return pygame.surfarray.make_surface(np.transpose(img, (1, 0, 2)))

    def _draw_agents(self, screen):
        for agent in self.core.agents[:150]:
            x = int((agent["pos"][0].item() / self.grid_size) * 390) + 20
            y = int((agent["pos"][1].item() / self.grid_size) * 300) + 44
            joy = float(agent["emotion"][0].item())
            color = (
                max(0, min(255, int((joy + 1.2) * 100))),
                200,
                max(0, min(255, int((1.2 - joy) * 90)))
            )
            pygame.draw.circle(screen, color, (x, y), 2)

    def _draw_hud(self, screen):
        lines = [
            "Unified Universe Engine V36-V41",
            "UP/DOWN joy-discord | 1-7 emotional axes | B rebirth | P civilization event | G galaxy spawn",
            "N inject now | M inject memory | F inject potential",
            f"Agents {len(self.core.agents)} | Civilizations {len(self.planetary.civilizations)} | Planets {len(self.galaxy.planets)}",
            f"Mean Joy {self.joy.J.mean().item():.3f} | Now {self.memory.now_field.mean().item():.3f} | Potential {self.memory.potential_field.mean().item():.3f}",
            "Top row: Joy, Emotion, Planetary Memory | Bottom row: Galactic Field, Now, Potential",
        ]

        hud_y = 740
        for line in lines:
            text = self.font.render(line, True, (232, 232, 244))
            screen.blit(text, (20, hud_y))
            hud_y += 16
