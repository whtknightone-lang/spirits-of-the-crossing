
# V101 Unified Dragon Realms

Unity-ready scaffold that unifies:
- Elder Air / Water / Nature / Fire dragons
- realm interaction
- source / dark pressure feedback
- dragon switching
- basic HUD and scene setup notes

Controls
- 1 Air
- 2 Water
- 3 Nature
- 4 Fire
- Space activate dragon ability
- F meditate / recover

Core loop
Dragon choice -> enter matching realm -> gain bonus / suffer mismatch
-> channel source / resist dark pressure -> use ability -> recover
