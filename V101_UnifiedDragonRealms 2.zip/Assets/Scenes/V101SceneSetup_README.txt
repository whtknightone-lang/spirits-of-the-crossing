
Suggested scene setup for V101

Create 4 dragon prefabs or GameObjects:
- ElderAirDragon (DragonAvatar element = Air)
- ElderWaterDragon (DragonAvatar element = Water)
- ElderNatureDragon (DragonAvatar element = Nature)
- ElderFireDragon (DragonAvatar element = Fire)

Add these systems:
- V101GameManager
- RealmInteractionSystem
- SourceDarkFeedbackSystem
- V101DragonHUD

Create 4 realm zones:
- DarkStorm RealmZone
  harmonyDelta = -0.05
  integrityDelta = -0.03
  sourceDelta = 0.01
  darkDelta = 0.09

- DeepOcean RealmZone
  harmonyDelta = 0.08
  integrityDelta = 0.06
  sourceDelta = 0.08
  darkDelta = -0.04

- ForestNature RealmZone
  harmonyDelta = 0.10
  integrityDelta = 0.07
  sourceDelta = 0.06
  darkDelta = -0.03

- FireVolcano RealmZone
  harmonyDelta = 0.02
  integrityDelta = -0.02
  sourceDelta = 0.03
  darkDelta = 0.06

Core vertical slice:
Switch dragon -> enter matching or opposing realm -> manage source/dark forces -> use ability -> meditate -> recover -> repeat
