
using UnityEngine;

namespace ArtificialUniverse.Dragons
{
    [RequireComponent(typeof(CharacterController))]
    public class DragonAvatar : MonoBehaviour
    {
        public DragonElement element;
        [Range(0f, 1f)] public float energy = 0.5f;
        [Range(0f, 1f)] public float harmony = 0.6f;
        [Range(0f, 1f)] public float integrity = 1.0f;
        [Range(0f, 1f)] public float sourceConnection = 0.4f;
        [Range(0f, 1f)] public float darkPressure = 0.2f;

        public float moveSpeed = 12f;
        public float turnSpeed = 95f;
        public float riseSpeed = 8f;

        private CharacterController controller;
        private bool meditating;

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
        }

        private void Update()
        {
            HandleMovement(Time.deltaTime);
            HandleActions(Time.deltaTime);
            Recover(Time.deltaTime);
        }

        private void HandleMovement(float dt)
        {
            float yaw = Input.GetAxis("Horizontal");
            float pitch = Input.GetAxis("Vertical");
            transform.Rotate(Vector3.up, yaw * turnSpeed * dt, Space.World);

            Vector3 motion = transform.forward * moveSpeed * Mathf.Max(0f, pitch);
            if (Input.GetKey(KeyCode.LeftShift))
                motion += transform.forward * moveSpeed * 0.75f;

            if (Input.GetKey(KeyCode.Space))
                motion += Vector3.up * riseSpeed;

            if (Input.GetKey(KeyCode.F))
            {
                meditating = true;
                motion *= 0.35f;
            }
            else
            {
                meditating = false;
            }

            controller.Move(motion * dt);
        }

        private void HandleActions(float dt)
        {
            if (Input.GetKeyDown(KeyCode.Space) && energy > 0.15f)
            {
                ActivatePrimaryAbility();
            }
        }

        private void ActivatePrimaryAbility()
        {
            energy = Mathf.Clamp01(energy - 0.15f);
            harmony = Mathf.Clamp01(harmony + 0.08f);

            switch (element)
            {
                case DragonElement.Air:
                    sourceConnection = Mathf.Clamp01(sourceConnection + 0.07f);
                    break;
                case DragonElement.Water:
                    integrity = Mathf.Clamp01(integrity + 0.08f);
                    break;
                case DragonElement.Nature:
                    harmony = Mathf.Clamp01(harmony + 0.10f);
                    break;
                case DragonElement.Fire:
                    darkPressure = Mathf.Clamp01(darkPressure - 0.05f);
                    break;
            }
        }

        private void Recover(float dt)
        {
            energy = Mathf.Clamp01(energy + 0.05f * dt);
            if (meditating)
            {
                harmony = Mathf.Clamp01(harmony + 0.12f * dt);
                sourceConnection = Mathf.Clamp01(sourceConnection + 0.08f * dt);
                darkPressure = Mathf.Clamp01(darkPressure - 0.06f * dt);
            }

            integrity = Mathf.Clamp01(integrity - darkPressure * 0.02f * dt + sourceConnection * 0.015f * dt);
        }
    }
}
