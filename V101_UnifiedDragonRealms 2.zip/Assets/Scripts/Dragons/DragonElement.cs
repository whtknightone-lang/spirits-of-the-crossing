
namespace ArtificialUniverse.Dragons
{
    public enum DragonElement
    {
        Air,
        Water,
        Nature,
        Fire
    }
}
