
using UnityEngine;
using ArtificialUniverse.Dragons;

namespace ArtificialUniverse.Source
{
    public class SourceDarkFeedbackSystem : MonoBehaviour
    {
        [Range(0f, 1f)] public float sourceMood = 0.6f;
        [Range(0f, 1f)] public float darkPlanetPressure = 0.35f;

        public void Tick(DragonAvatar dragon, float dt)
        {
            float balance = sourceMood - darkPlanetPressure;

            dragon.sourceConnection = Mathf.Clamp01(dragon.sourceConnection + balance * 0.03f * dt);
            dragon.darkPressure = Mathf.Clamp01(dragon.darkPressure - balance * 0.02f * dt);
            dragon.harmony = Mathf.Clamp01(dragon.harmony + balance * 0.02f * dt);

            if (darkPlanetPressure > sourceMood)
            {
                dragon.integrity = Mathf.Clamp01(dragon.integrity - 0.04f * dt);
            }
        }
    }
}
