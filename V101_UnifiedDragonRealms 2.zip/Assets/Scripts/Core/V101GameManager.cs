
using UnityEngine;
using ArtificialUniverse.Dragons;
using ArtificialUniverse.Realms;
using ArtificialUniverse.Source;

namespace ArtificialUniverse.Core
{
    public class V101GameManager : MonoBehaviour
    {
        [SerializeField] private DragonAvatar[] dragons;
        [SerializeField] private RealmInteractionSystem realmInteractionSystem;
        [SerializeField] private SourceDarkFeedbackSystem sourceDarkFeedbackSystem;

        private int activeIndex = 0;

        private void Start()
        {
            ActivateDragon(0);
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Alpha1)) ActivateDragon(0);
            if (Input.GetKeyDown(KeyCode.Alpha2)) ActivateDragon(1);
            if (Input.GetKeyDown(KeyCode.Alpha3)) ActivateDragon(2);
            if (Input.GetKeyDown(KeyCode.Alpha4)) ActivateDragon(3);

            if (dragons != null && activeIndex >= 0 && activeIndex < dragons.Length)
            {
                DragonAvatar current = dragons[activeIndex];
                realmInteractionSystem?.Tick(current, Time.deltaTime);
                sourceDarkFeedbackSystem?.Tick(current, Time.deltaTime);
            }
        }

        private void ActivateDragon(int index)
        {
            activeIndex = Mathf.Clamp(index, 0, dragons.Length - 1);
            for (int i = 0; i < dragons.Length; i++)
            {
                if (dragons[i] != null)
                    dragons[i].gameObject.SetActive(i == activeIndex);
            }
        }
    }
}
