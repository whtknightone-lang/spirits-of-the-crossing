
using UnityEngine;
using ArtificialUniverse.Dragons;

namespace ArtificialUniverse.Realms
{
    public class RealmZone : MonoBehaviour
    {
        public RealmType realmType;
        public float radius = 18f;

        [Range(-1f, 1f)] public float harmonyDelta = 0.1f;
        [Range(-1f, 1f)] public float integrityDelta = 0.1f;
        [Range(-1f, 1f)] public float sourceDelta = 0.1f;
        [Range(-1f, 1f)] public float darkDelta = 0.1f;

        public bool Contains(Vector3 position)
        {
            return Vector3.Distance(transform.position, position) <= radius;
        }

        public float Affinity(DragonElement element)
        {
            return (realmType, element) switch
            {
                (RealmType.DarkStorm, DragonElement.Air) => 1f,
                (RealmType.DeepOcean, DragonElement.Water) => 1f,
                (RealmType.ForestNature, DragonElement.Nature) => 1f,
                (RealmType.FireVolcano, DragonElement.Fire) => 1f,
                _ => 0.35f
            };
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.white;
            Gizmos.DrawWireSphere(transform.position, radius);
        }
    }
}
