
using UnityEngine;
using ArtificialUniverse.Dragons;

namespace ArtificialUniverse.Realms
{
    public class RealmInteractionSystem : MonoBehaviour
    {
        [SerializeField] private RealmZone[] realms;

        private void Awake()
        {
            if (realms == null || realms.Length == 0)
                realms = FindObjectsOfType<RealmZone>();
        }

        public void Tick(DragonAvatar dragon, float dt)
        {
            foreach (var realm in realms)
            {
                if (realm == null || !realm.Contains(dragon.transform.position)) continue;

                float affinity = realm.Affinity(dragon.element);

                dragon.harmony = Mathf.Clamp01(dragon.harmony + realm.harmonyDelta * affinity * dt);
                dragon.integrity = Mathf.Clamp01(dragon.integrity + realm.integrityDelta * affinity * dt);
                dragon.sourceConnection = Mathf.Clamp01(dragon.sourceConnection + realm.sourceDelta * affinity * dt);
                dragon.darkPressure = Mathf.Clamp01(dragon.darkPressure + realm.darkDelta * (1.2f - affinity) * dt);
            }
        }
    }
}
