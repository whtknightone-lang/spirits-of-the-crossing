
namespace ArtificialUniverse.Realms
{
    public enum RealmType
    {
        DarkStorm,
        DeepOcean,
        ForestNature,
        FireVolcano
    }
}
