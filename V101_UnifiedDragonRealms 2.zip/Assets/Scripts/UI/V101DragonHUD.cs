
using UnityEngine;
using ArtificialUniverse.Dragons;

namespace ArtificialUniverse.UI
{
    public class V101DragonHUD : MonoBehaviour
    {
        [SerializeField] private DragonAvatar target;

        private void Awake()
        {
            if (target == null) target = FindObjectOfType<DragonAvatar>();
        }

        private void OnGUI()
        {
            if (target == null) return;

            GUI.Label(new Rect(20, 20, 260, 24), $"Dragon: {target.element}");
            GUI.Label(new Rect(20, 44, 260, 24), $"Energy: {target.energy:0.00}");
            GUI.Label(new Rect(20, 68, 260, 24), $"Harmony: {target.harmony:0.00}");
            GUI.Label(new Rect(20, 92, 260, 24), $"Integrity: {target.integrity:0.00}");
            GUI.Label(new Rect(20, 116, 260, 24), $"Source: {target.sourceConnection:0.00}");
            GUI.Label(new Rect(20, 140, 260, 24), $"Dark Pressure: {target.darkPressure:0.00}");
            GUI.Label(new Rect(20, 172, 700, 24), "1 Air | 2 Water | 3 Nature | 4 Fire | Space ability/ascend | Shift boost | F meditate");
        }
    }
}
