
import numpy as np
import sounddevice as sd

def play_emotion(val):
    base = 220
    freq = base + val * 300
    fs = 44100
    t = np.linspace(0, 0.2, int(fs * 0.2))
    wave = 0.5 * np.sin(2 * np.pi * freq * t)
    sd.play(wave, fs)
