
# V37 Emotional Engine

Run:
pip install -r requirements.txt
python v37_main.py

Controls:
1 Joy
2 Love
3 Confidence
4 Creativity
5 Expression
6 Experience
7 Kindness
