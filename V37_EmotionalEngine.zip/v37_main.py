
import torch
import torch.nn.functional as F
import numpy as np
import pygame
import random
from audio_emotion import play_emotion

SIZE = 128
NUM_AGENTS = 400
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

EMO_DIM = 7

E_field = torch.zeros((EMO_DIM, SIZE, SIZE), device=DEVICE)

agents_pos = torch.rand((NUM_AGENTS,2), device=DEVICE) * SIZE
agents_emotion = torch.rand((NUM_AGENTS,EMO_DIM), device=DEVICE) * 2 - 1

laplace_kernel = torch.tensor([
    [0,1,0],
    [1,-4,1],
    [0,1,0]
], dtype=torch.float32, device=DEVICE).view(1,1,3,3)

def laplacian(field):
    field = field.unsqueeze(0)
    return F.conv2d(field, laplace_kernel, padding=1).squeeze(0)

def update_field():
    global E_field
    for k in range(EMO_DIM):
        diff = laplacian(E_field[k])
        interaction = torch.tanh(E_field.mean(dim=0))
        E_field[k] += 0.1 * diff + 0.05 * interaction

def update_agents():
    global agents_pos, agents_emotion, E_field

    for i in range(NUM_AGENTS):
        x, y = agents_pos[i].long()
        x = torch.clamp(x, 0, SIZE-1)
        y = torch.clamp(y, 0, SIZE-1)

        local_E = E_field[:, x, y]
        resonance = torch.exp(-torch.norm(agents_emotion[i] - local_E))

        agents_emotion[i] += 0.05 * (local_E - agents_emotion[i]) * resonance

        for k in range(EMO_DIM):
            E_field[k, x, y] += agents_emotion[i, k] * 0.02

        agents_pos[i] += torch.randn(2, device=DEVICE) * (0.5 + resonance)
        agents_pos[i] = torch.clamp(agents_pos[i], 0, SIZE-1)

pygame.init()
screen = pygame.display.set_mode((512,512))
clock = pygame.time.Clock()

def render():
    field = E_field[0].detach().cpu().numpy()
    field = (field - field.min()) / (field.max() + 1e-5)

    img = np.uint8(field * 255)
    img = np.stack([img, 255-img, img//2], axis=-1)

    surf = pygame.surfarray.make_surface(img)
    surf = pygame.transform.scale(surf, (512,512))
    screen.blit(surf, (0,0))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()

    if keys[pygame.K_1]:
        E_field[0] += 0.1
    if keys[pygame.K_2]:
        E_field[1] += 0.1
    if keys[pygame.K_3]:
        E_field[2] += 0.1
    if keys[pygame.K_4]:
        E_field[3] += 0.1
    if keys[pygame.K_5]:
        E_field[4] += 0.1
    if keys[pygame.K_6]:
        E_field[5] += 0.1
    if keys[pygame.K_7]:
        E_field[6] += 0.1

    update_field()
    update_agents()
    render()

    if random.random() < 0.05:
        play_emotion(E_field.mean().item())

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
