import numpy as np

class SnowflakeBrain:
    def __init__(self, brain_size: int, rng: np.random.Generator):
        self.phase = rng.uniform(0.0, 2.0 * np.pi, size=(brain_size,))
        self.memory = np.zeros(brain_size, dtype=float)

    def update(self, coupling: float, external_drive: float, memory_decay: float, exploration: float, rng: np.random.Generator) -> None:
        diff = self.phase[:, None] - self.phase[None, :]
        interaction = np.sin(diff).sum(axis=1)
        local_sync = np.mean(np.sin(diff), axis=1)
        noise = rng.normal(0.0, exploration, size=self.phase.shape)
        self.memory = (1.0 - memory_decay) * self.memory + 0.08 * interaction
        self.phase = (
            self.phase
            + 0.16 * coupling * interaction
            + 0.04 * local_sync
            + 0.012 * external_drive
            + 0.025 * self.memory
            + noise
        ) % (2.0 * np.pi)
