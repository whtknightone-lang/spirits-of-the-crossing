from dataclasses import dataclass
from engine.config import RuntimeParams

@dataclass
class EdgeChaosTargets:
    sync: float = 0.50
    diversity: float = 1.20
    volatility: float = 0.30
    energy_trend: float = 0.02

def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))

class EdgeChaosController:
    def __init__(self, targets: EdgeChaosTargets | None = None):
        self.targets = targets or EdgeChaosTargets()

    def tune(self, params: RuntimeParams, sync: float, diversity: float, volatility: float, energy_trend: float) -> RuntimeParams:
        params.coupling += 0.05 * (self.targets.sync - sync)
        params.coupling += 0.02 * (self.targets.volatility - volatility)

        params.mutation_rate += 0.008 * (sync - self.targets.sync)
        params.mutation_rate += 0.003 * (self.targets.diversity - diversity)

        params.flare_gain += 0.01 * (sync - self.targets.sync)
        params.flare_gain -= 0.01 * (volatility - self.targets.volatility)

        params.memory_decay += 0.004 * (sync - self.targets.sync)
        params.memory_decay -= 0.004 * (energy_trend - self.targets.energy_trend)

        params.exploration += 0.006 * (self.targets.diversity - diversity)
        params.exploration += 0.004 * (sync - self.targets.sync)

        params.coupling = _clamp(params.coupling, params.coupling_min, params.coupling_max)
        params.mutation_rate = _clamp(params.mutation_rate, params.mutation_min, params.mutation_max)
        params.flare_gain = _clamp(params.flare_gain, params.flare_min, params.flare_max)
        params.memory_decay = _clamp(params.memory_decay, params.memory_decay_min, params.memory_decay_max)
        params.exploration = _clamp(params.exploration, params.exploration_min, params.exploration_max)
        return params

    def regime_label(self, sync: float, volatility: float) -> str:
        if sync > 0.75 and volatility < 0.12:
            return "too_ordered"
        if sync < 0.30 or volatility > 0.55:
            return "too_chaotic"
        return "edge_zone"
