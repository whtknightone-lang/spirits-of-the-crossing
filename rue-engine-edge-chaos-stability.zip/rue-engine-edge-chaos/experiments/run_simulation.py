from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import numpy as np

from engine.config import SimulationConfig, RuntimeParams
from engine.simulation.universe import Universe
from engine.agents.agent import Agent
from engine.simulation.metrics import (
    gather_agent_phases,
    order_parameter,
    phase_diversity,
    phase_volatility,
    energy_trend,
    average_energy,
)
from engine.simulation.edge_chaos_controller import EdgeChaosController
from engine.ai.behavior import behavior_summary
from engine.rendering.simple_dashboard import write_metrics_csv, plot_dashboard

def main():
    cfg = SimulationConfig()
    params = RuntimeParams()
    rng = np.random.default_rng(cfg.random_seed)

    universe = Universe(cfg.num_planets)
    agents = [Agent(cfg.brain_size, rng) for _ in range(cfg.num_agents)]
    controller = EdgeChaosController()

    rows = []
    prev_phases = gather_agent_phases(agents)

    for step in range(1, cfg.steps + 1):
        star_energy = universe.step(params.flare_gain)
        external_drive = 0.15 * star_energy

        for agent in agents:
            if rng.random() < params.mutation_rate:
                agent.brain.phase = (agent.brain.phase + rng.normal(0.0, 0.02, size=agent.brain.phase.shape)) % (2.0 * np.pi)
            agent.step(
                coupling=params.coupling,
                external_drive=external_drive,
                memory_decay=params.memory_decay,
                exploration=params.exploration,
            )

        if step % cfg.tune_interval == 0:
            phases = gather_agent_phases(agents)
            sync = order_parameter(phases)
            diversity = phase_diversity(phases)
            volatility = phase_volatility(phases, prev_phases)
            e_trend = energy_trend(agents)
            avg_e = average_energy(agents)

            params = controller.tune(params, sync, diversity, volatility, e_trend)
            regime = controller.regime_label(sync, volatility)
            behavior = behavior_summary(avg_e, sync)

            row = {
                "step": step,
                "sync": round(sync, 6),
                "diversity": round(diversity, 6),
                "volatility": round(volatility, 6),
                "energy_trend": round(e_trend, 6),
                "avg_energy": round(avg_e, 6),
                "coupling": round(params.coupling, 6),
                "mutation_rate": round(params.mutation_rate, 6),
                "flare_gain": round(params.flare_gain, 6),
                "memory_decay": round(params.memory_decay, 6),
                "exploration": round(params.exploration, 6),
                "regime": regime,
                "behavior": behavior,
            }
            rows.append(row)

            print(
                f"step={step:4d} regime={regime:11s} behavior={behavior:14s} "
                f"sync={sync:.3f} div={diversity:.3f} vol={volatility:.3f} "
                f"energy={avg_e:.3f} coupling={params.coupling:.3f} mut={params.mutation_rate:.3f}"
            )
            prev_phases = phases.copy()

    out_dir = ROOT / "outputs"
    write_metrics_csv(rows, out_dir / "edge_chaos_metrics.csv")
    plot_dashboard(rows, out_dir / "edge_chaos_dashboard.png")
    print(f"Saved outputs to: {out_dir.resolve()}")

if __name__ == "__main__":
    main()
