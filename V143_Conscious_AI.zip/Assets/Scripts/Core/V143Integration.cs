
using UnityEngine;

public class V143Integration : MonoBehaviour
{
    void Start()
    {
        if (FindObjectOfType<SelfAwarenessSystem>() == null)
            gameObject.AddComponent<SelfAwarenessSystem>();

        if (FindObjectOfType<ReflectionSystem>() == null)
            gameObject.AddComponent<ReflectionSystem>();

        if (FindObjectOfType<DecisionAwareness>() == null)
            gameObject.AddComponent<DecisionAwareness>();
    }
}
