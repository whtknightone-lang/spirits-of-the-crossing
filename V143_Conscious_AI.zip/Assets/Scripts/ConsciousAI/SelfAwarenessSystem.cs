
using UnityEngine;

public class SelfAwarenessSystem : MonoBehaviour
{
    public float selfAwareness = 0f;
    public float reflectionRate = 0.01f;

    void Update()
    {
        selfAwareness += Time.deltaTime * reflectionRate;
    }
}
