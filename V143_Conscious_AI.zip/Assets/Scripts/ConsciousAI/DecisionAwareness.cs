
using UnityEngine;

public class DecisionAwareness : MonoBehaviour
{
    public float awareness;
    public float decisionWeight;

    void Update()
    {
        decisionWeight = awareness * Random.Range(0.5f, 1.5f);
    }
}
