
using UnityEngine;

public class ReflectionSystem : MonoBehaviour
{
    public float pastInfluence;

    void Update()
    {
        pastInfluence = Mathf.PingPong(Time.time * 0.01f, 1f);
    }
}
